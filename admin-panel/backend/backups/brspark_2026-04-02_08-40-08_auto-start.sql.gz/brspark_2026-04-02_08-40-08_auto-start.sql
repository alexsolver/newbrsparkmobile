--
-- PostgreSQL database dump
--

\restrict COg3jD0b5hpDSjHu9RKrqK0e9kOop76ldCFol3enPPFdhDJeVoTDdP1U7cuBk24

-- Dumped from database version 14.20 (Homebrew)
-- Dumped by pg_dump version 14.20 (Homebrew)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: AssetType; Type: TYPE; Schema: public; Owner: alex
--

CREATE TYPE public."AssetType" AS ENUM (
    'REAL_ESTATE',
    'TERRESTRIAL',
    'AQUATIC',
    'SPECIAL',
    'OTHER'
);


ALTER TYPE public."AssetType" OWNER TO alex;

--
-- Name: AuditCategory; Type: TYPE; Schema: public; Owner: alex
--

CREATE TYPE public."AuditCategory" AS ENUM (
    'AUTH',
    'DATA',
    'ADMIN',
    'SYSTEM'
);


ALTER TYPE public."AuditCategory" OWNER TO alex;

--
-- Name: BillingCycle; Type: TYPE; Schema: public; Owner: alex
--

CREATE TYPE public."BillingCycle" AS ENUM (
    'MONTHLY',
    'YEARLY'
);


ALTER TYPE public."BillingCycle" OWNER TO alex;

--
-- Name: Channel; Type: TYPE; Schema: public; Owner: alex
--

CREATE TYPE public."Channel" AS ENUM (
    'EMAIL',
    'PUSH',
    'WHATSAPP',
    'SMS'
);


ALTER TYPE public."Channel" OWNER TO alex;

--
-- Name: DocType; Type: TYPE; Schema: public; Owner: alex
--

CREATE TYPE public."DocType" AS ENUM (
    'TERMS_OF_USE',
    'PRIVACY_POLICY',
    'LGPD_DPA',
    'COOKIE_POLICY'
);


ALTER TYPE public."DocType" OWNER TO alex;

--
-- Name: IntType; Type: TYPE; Schema: public; Owner: alex
--

CREATE TYPE public."IntType" AS ENUM (
    'AI_LLM',
    'EMAIL',
    'PUSH',
    'STORAGE',
    'WEBHOOK',
    'ERP',
    'PAYMENT',
    'MAPS'
);


ALTER TYPE public."IntType" OWNER TO alex;

--
-- Name: InvoiceStatus; Type: TYPE; Schema: public; Owner: alex
--

CREATE TYPE public."InvoiceStatus" AS ENUM (
    'PENDING',
    'PAID',
    'OVERDUE',
    'VOID'
);


ALTER TYPE public."InvoiceStatus" OWNER TO alex;

--
-- Name: LocationType; Type: TYPE; Schema: public; Owner: alex
--

CREATE TYPE public."LocationType" AS ENUM (
    'BUILDING',
    'FLOOR',
    'ROOM',
    'AREA',
    'WAREHOUSE',
    'OTHER'
);


ALTER TYPE public."LocationType" OWNER TO alex;

--
-- Name: MetatagType; Type: TYPE; Schema: public; Owner: alex
--

CREATE TYPE public."MetatagType" AS ENUM (
    'ASSET_TYPE',
    'STOCK_CATEGORY',
    'SERVICE_CATEGORY',
    'ASSET_STATUS',
    'GLOBAL_TAG',
    'EXPENSE_CATEGORY',
    'REVENUE_CATEGORY',
    'MEDIA_CATEGORY'
);


ALTER TYPE public."MetatagType" OWNER TO alex;

--
-- Name: MovementType; Type: TYPE; Schema: public; Owner: alex
--

CREATE TYPE public."MovementType" AS ENUM (
    'IN',
    'OUT',
    'TRANSFER'
);


ALTER TYPE public."MovementType" OWNER TO alex;

--
-- Name: NotifStatus; Type: TYPE; Schema: public; Owner: alex
--

CREATE TYPE public."NotifStatus" AS ENUM (
    'SENT',
    'DELIVERED',
    'FAILED',
    'BOUNCED'
);


ALTER TYPE public."NotifStatus" OWNER TO alex;

--
-- Name: SubStatus; Type: TYPE; Schema: public; Owner: alex
--

CREATE TYPE public."SubStatus" AS ENUM (
    'ACTIVE',
    'PAST_DUE',
    'CANCELLED',
    'TRIALING'
);


ALTER TYPE public."SubStatus" OWNER TO alex;

--
-- Name: TenantStatus; Type: TYPE; Schema: public; Owner: alex
--

CREATE TYPE public."TenantStatus" AS ENUM (
    'TRIAL',
    'ACTIVE',
    'SUSPENDED',
    'CANCELLED'
);


ALTER TYPE public."TenantStatus" OWNER TO alex;

--
-- Name: UserRole; Type: TYPE; Schema: public; Owner: alex
--

CREATE TYPE public."UserRole" AS ENUM (
    'ADMIN',
    'MANAGER',
    'USER'
);


ALTER TYPE public."UserRole" OWNER TO alex;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: Admin; Type: TABLE; Schema: public; Owner: alex
--

CREATE TABLE public."Admin" (
    id text NOT NULL,
    email text NOT NULL,
    name text NOT NULL,
    password text NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public."Admin" OWNER TO alex;

--
-- Name: Asset; Type: TABLE; Schema: public; Owner: alex
--

CREATE TABLE public."Asset" (
    id text NOT NULL,
    "tenantId" text NOT NULL,
    "parentId" text,
    title text NOT NULL,
    type public."AssetType" NOT NULL,
    status text DEFAULT 'Operacional'::text NOT NULL,
    description text,
    "imageUrl" text,
    "locationId" text,
    metadata jsonb,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL,
    "deletedAt" timestamp(3) without time zone
);


ALTER TABLE public."Asset" OWNER TO alex;

--
-- Name: AssetShare; Type: TABLE; Schema: public; Owner: alex
--

CREATE TABLE public."AssetShare" (
    id text NOT NULL,
    "assetId" text NOT NULL,
    "ownerEmail" text NOT NULL,
    "sharedWithEmail" text NOT NULL,
    permission text NOT NULL,
    modules jsonb NOT NULL,
    status text DEFAULT 'PENDING'::text NOT NULL,
    "invitedAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "expiresAt" timestamp(3) without time zone
);


ALTER TABLE public."AssetShare" OWNER TO alex;

--
-- Name: AuditLog; Type: TABLE; Schema: public; Owner: alex
--

CREATE TABLE public."AuditLog" (
    id text NOT NULL,
    "tenantId" text,
    "userId" text,
    "adminId" text,
    action text NOT NULL,
    resource text NOT NULL,
    category public."AuditCategory" NOT NULL,
    metadata jsonb,
    "ipAddress" text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public."AuditLog" OWNER TO alex;

--
-- Name: ChatContact; Type: TABLE; Schema: public; Owner: alex
--

CREATE TABLE public."ChatContact" (
    id text NOT NULL,
    "requesterId" text NOT NULL,
    "addresseeId" text NOT NULL,
    status text DEFAULT 'PENDING'::text NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public."ChatContact" OWNER TO alex;

--
-- Name: ChatMessage; Type: TABLE; Schema: public; Owner: alex
--

CREATE TABLE public."ChatMessage" (
    id text NOT NULL,
    "roomId" text NOT NULL,
    "senderId" text NOT NULL,
    "senderName" text NOT NULL,
    type text DEFAULT 'text'::text NOT NULL,
    content text,
    "mediaUrl" text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public."ChatMessage" OWNER TO alex;

--
-- Name: ChatRoom; Type: TABLE; Schema: public; Owner: alex
--

CREATE TABLE public."ChatRoom" (
    id text NOT NULL,
    name text,
    description text,
    "avatarColor" text DEFAULT '#2563EB'::text,
    "isGroup" boolean DEFAULT false NOT NULL,
    "creatorId" text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public."ChatRoom" OWNER TO alex;

--
-- Name: ChatRoomMember; Type: TABLE; Schema: public; Owner: alex
--

CREATE TABLE public."ChatRoomMember" (
    id text NOT NULL,
    "roomId" text NOT NULL,
    "userId" text NOT NULL,
    role text DEFAULT 'MEMBER'::text NOT NULL,
    "joinedAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "lastReadAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public."ChatRoomMember" OWNER TO alex;

--
-- Name: ChecklistExecution; Type: TABLE; Schema: public; Owner: alex
--

CREATE TABLE public."ChecklistExecution" (
    id text NOT NULL,
    "templateId" text,
    "ownerEmail" text NOT NULL,
    "assetId" text,
    status text DEFAULT 'PENDING'::text NOT NULL,
    responses jsonb,
    metadata jsonb,
    "gpsLocation" jsonb,
    "startedAt" timestamp(3) without time zone,
    "completedAt" timestamp(3) without time zone,
    "syncedAt" timestamp(3) without time zone,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "locationAddress" text,
    "locationLat" double precision,
    "locationLng" double precision,
    "locationPolygon" jsonb,
    "locationRadius" integer,
    "locationZoneType" text
);


ALTER TABLE public."ChecklistExecution" OWNER TO alex;

--
-- Name: ChecklistTemplate; Type: TABLE; Schema: public; Owner: alex
--

CREATE TABLE public."ChecklistTemplate" (
    id text NOT NULL,
    "tenantId" text,
    title text NOT NULL,
    description text,
    settings jsonb NOT NULL,
    "schemaData" jsonb NOT NULL,
    metadata jsonb,
    version integer DEFAULT 1 NOT NULL,
    "isActive" boolean DEFAULT true NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public."ChecklistTemplate" OWNER TO alex;

--
-- Name: ComplianceAcceptance; Type: TABLE; Schema: public; Owner: alex
--

CREATE TABLE public."ComplianceAcceptance" (
    id text NOT NULL,
    "docId" text NOT NULL,
    "userId" text,
    "tenantId" text,
    "ipAddress" text,
    "acceptedAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public."ComplianceAcceptance" OWNER TO alex;

--
-- Name: ComplianceDoc; Type: TABLE; Schema: public; Owner: alex
--

CREATE TABLE public."ComplianceDoc" (
    id text NOT NULL,
    type public."DocType" NOT NULL,
    version text NOT NULL,
    title text NOT NULL,
    content text NOT NULL,
    "isActive" boolean DEFAULT false NOT NULL,
    "publishedAt" timestamp(3) without time zone,
    "createdBy" text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public."ComplianceDoc" OWNER TO alex;

--
-- Name: FeatureFlag; Type: TABLE; Schema: public; Owner: alex
--

CREATE TABLE public."FeatureFlag" (
    id text NOT NULL,
    key text NOT NULL,
    label text NOT NULL,
    description text NOT NULL,
    icon text,
    enabled boolean DEFAULT true NOT NULL,
    "tenantId" text,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public."FeatureFlag" OWNER TO alex;

--
-- Name: Integration; Type: TABLE; Schema: public; Owner: alex
--

CREATE TABLE public."Integration" (
    id text NOT NULL,
    name text NOT NULL,
    type public."IntType" NOT NULL,
    icon text,
    "apiKey" text,
    "baseUrl" text,
    "webhookUrl" text,
    "lastTestedAt" timestamp(3) without time zone,
    metadata jsonb,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL,
    description text,
    status text DEFAULT 'ACTIVE'::text NOT NULL
);


ALTER TABLE public."Integration" OWNER TO alex;

--
-- Name: Invoice; Type: TABLE; Schema: public; Owner: alex
--

CREATE TABLE public."Invoice" (
    id text NOT NULL,
    "subscriptionId" text NOT NULL,
    amount numeric(10,2) NOT NULL,
    status public."InvoiceStatus" DEFAULT 'PENDING'::public."InvoiceStatus" NOT NULL,
    "dueDate" timestamp(3) without time zone NOT NULL,
    "paidAt" timestamp(3) without time zone,
    "externalId" text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public."Invoice" OWNER TO alex;

--
-- Name: LocaleProfile; Type: TABLE; Schema: public; Owner: alex
--

CREATE TABLE public."LocaleProfile" (
    id text NOT NULL,
    "countryCode" text NOT NULL,
    name text NOT NULL,
    language text DEFAULT 'pt-BR'::text NOT NULL,
    currency text DEFAULT 'BRL'::text NOT NULL,
    "currencySymbol" text DEFAULT 'R$'::text NOT NULL,
    "dateFormat" text DEFAULT 'DD/MM/YYYY'::text NOT NULL,
    "numberFormat" text DEFAULT 'PT_STYLE'::text NOT NULL,
    timezone text DEFAULT 'UTC'::text NOT NULL,
    "taxIdLabel" text DEFAULT 'Tax ID'::text NOT NULL,
    "postalCodeLabel" text DEFAULT 'Postal Code'::text NOT NULL,
    "measureSystem" text DEFAULT 'METRIC'::text NOT NULL,
    "isActive" boolean DEFAULT true NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public."LocaleProfile" OWNER TO alex;

--
-- Name: Location; Type: TABLE; Schema: public; Owner: alex
--

CREATE TABLE public."Location" (
    id text NOT NULL,
    "tenantId" text NOT NULL,
    name text NOT NULL,
    type public."LocationType" DEFAULT 'BUILDING'::public."LocationType" NOT NULL,
    address text,
    floor text,
    room text,
    icon text,
    latitude double precision,
    longitude double precision,
    "parentId" text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public."Location" OWNER TO alex;

--
-- Name: Metatag; Type: TABLE; Schema: public; Owner: alex
--

CREATE TABLE public."Metatag" (
    id text NOT NULL,
    type public."MetatagType" NOT NULL,
    key text NOT NULL,
    "ptBr" text NOT NULL,
    "enUs" text NOT NULL,
    "esEs" text NOT NULL,
    icon text,
    color text,
    "isActive" boolean DEFAULT true NOT NULL,
    "sortOrder" integer DEFAULT 0 NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public."Metatag" OWNER TO alex;

--
-- Name: NotificationLog; Type: TABLE; Schema: public; Owner: alex
--

CREATE TABLE public."NotificationLog" (
    id text NOT NULL,
    "templateId" text NOT NULL,
    recipient text NOT NULL,
    channel public."Channel" NOT NULL,
    status public."NotifStatus" DEFAULT 'SENT'::public."NotifStatus" NOT NULL,
    "sentAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    metadata jsonb
);


ALTER TABLE public."NotificationLog" OWNER TO alex;

--
-- Name: NotificationTemplate; Type: TABLE; Schema: public; Owner: alex
--

CREATE TABLE public."NotificationTemplate" (
    id text NOT NULL,
    key text NOT NULL,
    label text NOT NULL,
    channel public."Channel" NOT NULL,
    subject text,
    body text NOT NULL,
    variables jsonb,
    "isActive" boolean DEFAULT true NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public."NotificationTemplate" OWNER TO alex;

--
-- Name: Plan; Type: TABLE; Schema: public; Owner: alex
--

CREATE TABLE public."Plan" (
    id text NOT NULL,
    name text NOT NULL,
    "priceMonthly" numeric(10,2) NOT NULL,
    "priceYearly" numeric(10,2) NOT NULL,
    "maxAssets" integer NOT NULL,
    "maxUsers" integer NOT NULL,
    "storageGb" integer NOT NULL,
    features jsonb NOT NULL,
    "isActive" boolean DEFAULT true NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public."Plan" OWNER TO alex;

--
-- Name: PushToken; Type: TABLE; Schema: public; Owner: alex
--

CREATE TABLE public."PushToken" (
    id text NOT NULL,
    "userId" text NOT NULL,
    token text NOT NULL,
    device text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public."PushToken" OWNER TO alex;

--
-- Name: ServiceProvider; Type: TABLE; Schema: public; Owner: alex
--

CREATE TABLE public."ServiceProvider" (
    id text NOT NULL,
    name text NOT NULL,
    category text NOT NULL,
    rating double precision DEFAULT 0 NOT NULL,
    reviews integer DEFAULT 0 NOT NULL,
    photo text,
    tags jsonb,
    keywords text,
    phone text,
    email text,
    city text,
    state text DEFAULT 'SP'::text NOT NULL,
    verified boolean DEFAULT false NOT NULL,
    "isActive" boolean DEFAULT true NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public."ServiceProvider" OWNER TO alex;

--
-- Name: StockItem; Type: TABLE; Schema: public; Owner: alex
--

CREATE TABLE public."StockItem" (
    id text NOT NULL,
    "assetId" text NOT NULL,
    name text NOT NULL,
    sku text NOT NULL,
    "currentStock" integer DEFAULT 0 NOT NULL,
    "minStock" integer DEFAULT 1 NOT NULL,
    unit text DEFAULT 'un'::text NOT NULL,
    "subLocation" text,
    "unitPrice" numeric(10,2),
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public."StockItem" OWNER TO alex;

--
-- Name: StockMovement; Type: TABLE; Schema: public; Owner: alex
--

CREATE TABLE public."StockMovement" (
    id text NOT NULL,
    "itemId" text NOT NULL,
    type public."MovementType" NOT NULL,
    quantity integer NOT NULL,
    reason text,
    "fromAssetId" text,
    "toAssetId" text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public."StockMovement" OWNER TO alex;

--
-- Name: Subscription; Type: TABLE; Schema: public; Owner: alex
--

CREATE TABLE public."Subscription" (
    id text NOT NULL,
    "tenantId" text NOT NULL,
    "planId" text NOT NULL,
    "billingCycle" public."BillingCycle" DEFAULT 'MONTHLY'::public."BillingCycle" NOT NULL,
    status public."SubStatus" DEFAULT 'ACTIVE'::public."SubStatus" NOT NULL,
    "currentStart" timestamp(3) without time zone NOT NULL,
    "currentEnd" timestamp(3) without time zone NOT NULL,
    "cancelledAt" timestamp(3) without time zone,
    "trialEndsAt" timestamp(3) without time zone,
    "externalId" text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public."Subscription" OWNER TO alex;

--
-- Name: Tenant; Type: TABLE; Schema: public; Owner: alex
--

CREATE TABLE public."Tenant" (
    id text NOT NULL,
    name text NOT NULL,
    slug text NOT NULL,
    email text NOT NULL,
    phone text,
    "taxId" text,
    "defaultLang" text DEFAULT 'pt-BR'::text NOT NULL,
    status public."TenantStatus" DEFAULT 'TRIAL'::public."TenantStatus" NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL,
    "avatarUrl" text,
    "localeId" text,
    "ownerName" text NOT NULL
);


ALTER TABLE public."Tenant" OWNER TO alex;

--
-- Name: TranslationOverride; Type: TABLE; Schema: public; Owner: alex
--

CREATE TABLE public."TranslationOverride" (
    id text NOT NULL,
    "tenantId" text NOT NULL,
    key text NOT NULL,
    language text NOT NULL,
    value text NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public."TranslationOverride" OWNER TO alex;

--
-- Name: User; Type: TABLE; Schema: public; Owner: alex
--

CREATE TABLE public."User" (
    id text NOT NULL,
    "tenantId" text NOT NULL,
    email text NOT NULL,
    name text NOT NULL,
    password text NOT NULL,
    role public."UserRole" DEFAULT 'USER'::public."UserRole" NOT NULL,
    "isActive" boolean DEFAULT true NOT NULL,
    "lastLogin" timestamp(3) without time zone,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL,
    "avatarUrl" text
);


ALTER TABLE public."User" OWNER TO alex;

--
-- Name: UserModuleData; Type: TABLE; Schema: public; Owner: alex
--

CREATE TABLE public."UserModuleData" (
    id text NOT NULL,
    "ownerEmail" text NOT NULL,
    module text NOT NULL,
    data jsonb NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public."UserModuleData" OWNER TO alex;

--
-- Name: _prisma_migrations; Type: TABLE; Schema: public; Owner: alex
--

CREATE TABLE public._prisma_migrations (
    id character varying(36) NOT NULL,
    checksum character varying(64) NOT NULL,
    finished_at timestamp with time zone,
    migration_name character varying(255) NOT NULL,
    logs text,
    rolled_back_at timestamp with time zone,
    started_at timestamp with time zone DEFAULT now() NOT NULL,
    applied_steps_count integer DEFAULT 0 NOT NULL
);


ALTER TABLE public._prisma_migrations OWNER TO alex;

--
-- Data for Name: Admin; Type: TABLE DATA; Schema: public; Owner: alex
--

COPY public."Admin" (id, email, name, password, "createdAt", "updatedAt") FROM stdin;
cmn3xhvkq0000dajk4h6w2ytx	admin@brspark.com	BrSpark Admin	$2a$10$EVbJ098xpx0567OJhWzuC.h/7F.JAJh2ew6C9nAj3wPB/ApbTlHO2	2026-03-24 01:21:03.767	2026-03-24 01:21:03.767
\.


--
-- Data for Name: Asset; Type: TABLE DATA; Schema: public; Owner: alex
--

COPY public."Asset" (id, "tenantId", "parentId", title, type, status, description, "imageUrl", "locationId", metadata, "createdAt", "updatedAt", "deletedAt") FROM stdin;
cmn3xvxdk0007yjhblgorv4aw	cmn3xud9y0001kldgdiksukq5	\N	Asset 1 - Brspark Global Brazil	REAL_ESTATE	Operacional	Demo asset for Brspark Global Brazil	\N	\N	\N	2026-03-24 01:31:59.289	2026-03-24 01:31:59.289	\N
cmn3xwgtj00078gtly9ejtlxj	cmn3xud9y0001kldgdiksukq5	\N	Asset 1 - Brspark Global Brazil	REAL_ESTATE	Operacional	Demo asset for Brspark Global Brazil	\N	\N	\N	2026-03-24 01:32:24.487	2026-03-24 01:32:24.487	\N
cmn3xwgtv000d8gtlsiwqien4	cmn3xud9y0001kldgdiksukq5	\N	Asset 2 - Brspark Global Brazil	TERRESTRIAL	Operacional	Demo asset for Brspark Global Brazil	\N	\N	\N	2026-03-24 01:32:24.5	2026-03-24 01:32:24.5	\N
cmn3xwgtx000j8gtlf0vw1qok	cmn3xud9y0001kldgdiksukq5	\N	Asset 3 - Brspark Global Brazil	TERRESTRIAL	Operacional	Demo asset for Brspark Global Brazil	\N	\N	\N	2026-03-24 01:32:24.502	2026-03-24 01:32:24.502	\N
cmn3xwgu8000x8gtlixouh8pm	cmn3xwgu1000r8gtl768s8zcj	\N	Asset 1 - Solaris Energy US	REAL_ESTATE	Operacional	Demo asset for Solaris Energy US	\N	\N	\N	2026-03-24 01:32:24.513	2026-03-24 01:32:24.513	\N
cmn3xwgua00138gtlgxlzuqfm	cmn3xwgu1000r8gtl768s8zcj	\N	Asset 2 - Solaris Energy US	TERRESTRIAL	Operacional	Demo asset for Solaris Energy US	\N	\N	\N	2026-03-24 01:32:24.514	2026-03-24 01:32:24.514	\N
cmn3xwgub00198gtlm6juwtim	cmn3xwgu1000r8gtl768s8zcj	\N	Asset 3 - Solaris Energy US	TERRESTRIAL	Operacional	Demo asset for Solaris Energy US	\N	\N	\N	2026-03-24 01:32:24.516	2026-03-24 01:32:24.516	\N
cmn3xwguj001n8gtlutpesgpc	cmn3xwgue001h8gtlfcskpc0d	\N	Asset 1 - Iberia Logistics	REAL_ESTATE	Operacional	Demo asset for Iberia Logistics	\N	\N	\N	2026-03-24 01:32:24.523	2026-03-24 01:32:24.523	\N
cmn3xwguk001t8gtluwfugchd	cmn3xwgue001h8gtlfcskpc0d	\N	Asset 2 - Iberia Logistics	TERRESTRIAL	Operacional	Demo asset for Iberia Logistics	\N	\N	\N	2026-03-24 01:32:24.525	2026-03-24 01:32:24.525	\N
cmn3xwgun001z8gtlncywzd8z	cmn3xwgue001h8gtlfcskpc0d	\N	Asset 3 - Iberia Logistics	TERRESTRIAL	Operacional	Demo asset for Iberia Logistics	\N	\N	\N	2026-03-24 01:32:24.528	2026-03-24 01:32:24.528	\N
brsp-454019	cmn6sf2we004g5epyw7uxjo73	\N	Test Asset Luigi	TERRESTRIAL	OPERACIONAL	\N	\N	\N	{"brand": "Teste"}	2026-03-26 13:39:17.791	2026-03-26 14:05:32.026	2026-03-26 14:05:32.025
joao-asset-casa	cmn3y2uck0000sfjubh0n7z5o	\N	Casa Residencial — Morumbi	REAL_ESTATE	Operacional	\N	\N	\N	{"cep": "", "area": "180m²", "city": "", "iptu": "SP-2024-00123456", "brand": "", "model": "", "owner": "", "state": "", "photos": [], "street": "", "address": "Rua das Palmeiras, 142 — Morumbi, São Paulo/SP", "bedrooms": 3, "bathrooms": 2, "yearBuilt": 2005, "complement": "", "costCenter": "", "customIcon": "home-outline", "department": "", "customColor": "#3B82F6", "inventoryId": "", "marketValue": 950000, "customFields": [], "neighborhood": "", "serialNumber": "", "streetNumber": "", "gpsCoordinates": "", "acquisitionValue": "2596"}	2026-03-24 02:31:34.832	2026-03-24 19:56:35.639	\N
brsp-315981	cmn6sf2we004g5epyw7uxjo73	\N	Carro	TERRESTRIAL	OPERACIONAL	\N	\N	\N	{"cep": "", "city": "", "brand": "", "model": "", "owner": "", "state": "", "photos": [], "street": "", "complement": "", "costCenter": "", "department": "", "inventoryId": "", "customFields": [], "neighborhood": "", "serialNumber": "", "streetNumber": "", "gpsCoordinates": "", "acquisitionValue": ""}	2026-03-26 17:50:21.359	2026-03-26 17:50:21.359	\N
brsp-569392	cmn6sf2we004g5epyw7uxjo73	\N	Test Asset Luigi	TERRESTRIAL	OPERACIONAL	\N	\N	\N	{"brand": "Teste"}	2026-03-26 13:39:04.75	2026-03-26 13:39:04.75	\N
brsp-468315	cmn6sf2we004g5epyw7uxjo73	\N	Carlin	TERRESTRIAL	OPERACIONAL	\N	\N	\N	{"cep": "", "city": "", "brand": "", "model": "", "owner": "", "state": "", "photos": [], "street": "", "complement": "", "costCenter": "", "customIcon": "car-outline", "department": "", "inventoryId": "", "customFields": [], "neighborhood": "", "serialNumber": "", "streetNumber": "", "gpsCoordinates": "", "acquisitionValue": ""}	2026-03-26 17:53:45.852	2026-03-26 17:53:45.852	\N
brsp-134786	cmn6hij2x0001j5dqofhbi9sd	\N	Casa de Praia	REAL_ESTATE	OPERACIONAL	\N	\N	\N	{"cep": "06040440", "city": "Osasco", "brand": "", "model": "", "owner": "", "state": "SP", "photos": [], "street": "Rua Avedis Kamalakian", "complement": "", "costCenter": "", "department": "", "inventoryId": "", "customFields": [], "neighborhood": "São Paulo", "serialNumber": "", "streetNumber": "1-99", "gpsCoordinates": "-23.569983, -46.785165", "acquisitionValue": "100"}	2026-03-27 02:29:15.372	2026-03-28 18:49:24.311	\N
brsp-999999	cmn6hij2x0001j5dqofhbi9sd	brsp-756993	Test Asset Script 2	TERRESTRIAL	OPERACIONAL	\N	\N	\N	{}	2026-03-26 02:54:55.144	2026-03-26 18:33:49.458	\N
brsp-123456	cmn6hij2x0001j5dqofhbi9sd	brsp-134786	Test Luigi Console	TERRESTRIAL	OPERACIONAL	\N	\N	\N	{"cep": "", "city": "", "brand": "", "model": "", "owner": "", "state": "", "photos": [], "street": "", "complement": "", "costCenter": "", "department": "", "inventoryId": "", "customFields": [], "neighborhood": "", "serialNumber": "", "streetNumber": "", "gpsCoordinates": "", "acquisitionValue": ""}	2026-03-26 02:52:31.417	2026-03-28 18:10:42.7	\N
brsp-756993	cmn6hij2x0001j5dqofhbi9sd	\N	Chacara	REAL_ESTATE	OPERACIONAL	\N	\N	\N	{"cep": "95014", "city": "Cupertino", "brand": "", "model": "", "owner": "", "state": "CA", "photos": [], "street": "Infinite Loop", "complement": "", "costCenter": "", "department": "", "inventoryId": "", "customFields": [], "neighborhood": "Santa Clara", "serialNumber": "", "streetNumber": "1", "gpsCoordinates": "37.330673, -122.030106", "acquisitionValue": ""}	2026-03-26 12:30:14.369	2026-03-28 18:11:53.108	\N
\.


--
-- Data for Name: AssetShare; Type: TABLE DATA; Schema: public; Owner: alex
--

COPY public."AssetShare" (id, "assetId", "ownerEmail", "sharedWithEmail", permission, modules, status, "invitedAt", "expiresAt") FROM stdin;
cmn6ub1vr000he0hkccbq9l5r	brsp-190135	alex@brspark.com	luigi@lansolver.com	WRITE	["*"]	ACCEPTED	2026-03-26 02:15:05.031	\N
cmn6vojq5002ev9sm2l49qwoi	brsp-513662	alex@brspark.com	luigi@lansolver.com	WRITE	["*"]	ACCEPTED	2026-03-26 02:53:34.3	\N
cmn7s1jxw0018x0k1c0msjmey	brsp-756993	alex@brspark.com	luigi@lansolver.com	WRITE	["*"]	ACCEPTED	2026-03-26 17:59:28.819	\N
\.


--
-- Data for Name: AuditLog; Type: TABLE DATA; Schema: public; Owner: alex
--

COPY public."AuditLog" (id, "tenantId", "userId", "adminId", action, resource, category, metadata, "ipAddress", "createdAt") FROM stdin;
cmn3xienb0001v6cye54kqi4i	\N	\N	cmn3xhvkq0000dajk4h6w2ytx	LOGIN	Admin Console	AUTH	\N	\N	2026-03-24 01:21:28.487
cmn3xnw300003v6cyi7piq4c8	\N	\N	cmn3xhvkq0000dajk4h6w2ytx	LOGIN	Admin Console	AUTH	\N	\N	2026-03-24 01:25:44.364
cmn3xwgu0000p8gtl28h8ej5c	cmn3xud9y0001kldgdiksukq5	\N	\N	TENANT_PROVISIONED	System	SYSTEM	\N	\N	2026-03-24 01:32:24.504
cmn3xwgud001f8gtl1g4696h3	cmn3xwgu1000r8gtl768s8zcj	\N	\N	TENANT_PROVISIONED	System	SYSTEM	\N	\N	2026-03-24 01:32:24.517
cmn3xwgup00258gtlag0vgwnf	cmn3xwgue001h8gtlfcskpc0d	\N	\N	TENANT_PROVISIONED	System	SYSTEM	\N	\N	2026-03-24 01:32:24.53
cmn3y388e0001y0zeh9wkf8wb	cmn3y2uck0000sfjubh0n7z5o	cmn3y2ucr0002sfju83h732a4	\N	USER_LOGIN	joao@teste.com	AUTH	\N	\N	2026-03-24 01:37:39.95
cmn3y4m8j0001sxxf7u2ahh6d	cmn3y2uck0000sfjubh0n7z5o	cmn3y2ucr0002sfju83h732a4	\N	USER_LOGIN	joao@teste.com	AUTH	\N	\N	2026-03-24 01:38:44.756
cmn3yg4u70001gv21xg5fgyeu	\N	\N	cmn3xhvkq0000dajk4h6w2ytx	LOGIN	Admin Console	AUTH	\N	\N	2026-03-24 01:47:42.079
cmn3yrrwo0001y3d4q2nbenm4	\N	\N	cmn3xhvkq0000dajk4h6w2ytx	LOGIN	Admin Console	AUTH	\N	\N	2026-03-24 01:56:45.192
cmn3zmulh0001iw22z73m11se	cmn3y2uck0000sfjubh0n7z5o	cmn3y2ucr0002sfju83h732a4	\N	USER_LOGIN	joao@teste.com	AUTH	\N	\N	2026-03-24 02:20:55.013
cmn3zoqnd0003iw22ry0ed2il	cmn3y2uck0000sfjubh0n7z5o	cmn3y2ucr0002sfju83h732a4	\N	USER_LOGIN	joao@teste.com	AUTH	\N	\N	2026-03-24 02:22:23.209
cmn400kan000112ywd11ceant	cmn3y2uck0000sfjubh0n7z5o	cmn3y2ucr0002sfju83h732a4	\N	SYNC_PUSH	1 itens	DATA	{"total": 1, "processed": 1}	\N	2026-03-24 02:31:34.847
cmn4lwqs20001j7uwjzy4bsm9	cmn3y2uck0000sfjubh0n7z5o	cmn3y2ucr0002sfju83h732a4	\N	USER_LOGIN	joao@teste.com	AUTH	\N	\N	2026-03-24 12:44:28.177
cmn4n4rwd0003j7uwdl5bi7jg	\N	\N	cmn3xhvkq0000dajk4h6w2ytx	LOGIN	Admin Console	AUTH	\N	\N	2026-03-24 13:18:42.491
cmn4nd6n70005j7uwlm31kv8g	\N	\N	cmn3xhvkq0000dajk4h6w2ytx	FLAG_ON	realtime	ADMIN	\N	\N	2026-03-24 13:25:14.851
cmn4vcamh0007j7uwts3aylje	\N	\N	cmn3xhvkq0000dajk4h6w2ytx	LOGIN	Admin Console	AUTH	\N	\N	2026-03-24 17:08:30.281
cmn4vmbj00009j7uwbg5ckkal	cmn3y2uck0000sfjubh0n7z5o	cmn3y2ucr0002sfju83h732a4	\N	SYNC_PUSH	1 itens	DATA	{"total": 1, "processed": 1}	\N	2026-03-24 17:16:18.012
cmn4xtndn000bj7uwmg4i1cdi	cmn3y2uck0000sfjubh0n7z5o	cmn3y2ucr0002sfju83h732a4	\N	SYNC_PUSH	1 itens	DATA	{"total": 1, "processed": 1}	\N	2026-03-24 18:17:59.194
cmn4xu0c5000dj7uwucyt38r1	cmn3y2uck0000sfjubh0n7z5o	cmn3y2ucr0002sfju83h732a4	\N	SYNC_PUSH	1 itens	DATA	{"total": 1, "processed": 1}	\N	2026-03-24 18:18:15.989
cmn4xwocl000fj7uwoyja8php	cmn3y2uck0000sfjubh0n7z5o	cmn3y2ucr0002sfju83h732a4	\N	SYNC_PUSH	1 itens	DATA	{"total": 1, "processed": 1}	\N	2026-03-24 18:20:20.421
cmn4xznm6000hj7uwoy67w1ck	cmn3y2uck0000sfjubh0n7z5o	cmn3y2ucr0002sfju83h732a4	\N	SYNC_PUSH	1 itens	DATA	{"total": 1, "processed": 1}	\N	2026-03-24 18:22:39.438
cmn4zjid6000jj7uw1ja7wk4p	cmn3y2uck0000sfjubh0n7z5o	cmn3y2ucr0002sfju83h732a4	\N	SYNC_PUSH	1 itens	DATA	{"total": 1, "processed": 1}	\N	2026-03-24 19:06:05.367
cmn512t4k000lj7uww37y24hx	cmn3y2uck0000sfjubh0n7z5o	cmn3y2ucr0002sfju83h732a4	\N	SYNC_PUSH	1 itens	DATA	{"total": 1, "processed": 1}	\N	2026-03-24 19:49:05.395
cmn512yoq000nj7uwja2lltra	cmn3y2uck0000sfjubh0n7z5o	cmn3y2ucr0002sfju83h732a4	\N	SYNC_PUSH	1 itens	DATA	{"total": 1, "processed": 1}	\N	2026-03-24 19:49:12.603
cmn51376i000pj7uwysuyqzdv	cmn3y2uck0000sfjubh0n7z5o	cmn3y2ucr0002sfju83h732a4	\N	SYNC_PUSH	1 itens	DATA	{"total": 1, "processed": 1}	\N	2026-03-24 19:49:23.61
cmn51cgof000rj7uwhdvcgzy1	cmn3y2uck0000sfjubh0n7z5o	cmn3y2ucr0002sfju83h732a4	\N	SYNC_PUSH	1 itens	DATA	{"total": 1, "processed": 1}	\N	2026-03-24 19:56:35.823
cmn53kr1d000tj7uwguuga34e	cmn3y2uck0000sfjubh0n7z5o	cmn3y2ucr0002sfju83h732a4	\N	USER_LOGIN	joao@teste.com	AUTH	\N	\N	2026-03-24 20:59:01.73
cmn5dhc6u000vj7uwveya1vf5	\N	\N	cmn3xhvkq0000dajk4h6w2ytx	LOGIN	Admin Console	AUTH	\N	\N	2026-03-25 01:36:18.677
cmn6gc1hn0001cta04ubr07vl	cmn3y2uck0000sfjubh0n7z5o	cmn3y2ucr0002sfju83h732a4	\N	USER_LOGIN	joao@teste.com	AUTH	\N	\N	2026-03-25 19:43:56.556
cmn6gd2w30003cta0mfzk0wx5	\N	\N	cmn3xhvkq0000dajk4h6w2ytx	LOGIN	Admin Console	AUTH	\N	\N	2026-03-25 19:44:45.027
cmn6gkxs0002rcta0dcgzjji6	\N	\N	cmn3xhvkq0000dajk4h6w2ytx	LOGIN	Admin Console	AUTH	\N	\N	2026-03-25 19:50:51.647
cmn6gswn5005icta0fsgul4z9	\N	\N	cmn3xhvkq0000dajk4h6w2ytx	INTEGRATION_ADD	Dropbox	ADMIN	\N	\N	2026-03-25 19:57:03.425
cmn6gynvl005lcta02lxw0nd8	\N	\N	cmn3xhvkq0000dajk4h6w2ytx	INTEGRATION_ADD	OpenAI	ADMIN	\N	\N	2026-03-25 20:01:32.002
cmn6gyqxu005octa0qr9cstds	\N	\N	cmn3xhvkq0000dajk4h6w2ytx	INTEGRATION_ADD	Office 365	ADMIN	\N	\N	2026-03-25 20:01:35.971
cmn6gys76005rcta0wvsxw975	\N	\N	cmn3xhvkq0000dajk4h6w2ytx	INTEGRATION_ADD	Office 365	ADMIN	\N	\N	2026-03-25 20:01:37.602
cmn6h61r600024l14l0eo6c5k	\N	\N	cmn3xhvkq0000dajk4h6w2ytx	INTEGRATION_ADD	Dropbox	ADMIN	\N	\N	2026-03-25 20:07:16.578
cmn6h67pd00054l14ahbxmcgo	\N	\N	cmn3xhvkq0000dajk4h6w2ytx	INTEGRATION_ADD	Dropbox	ADMIN	\N	\N	2026-03-25 20:07:24.289
cmn6hij3n0005j5dqqty570ar	cmn6hij2x0001j5dqofhbi9sd	cmn6hij3j0003j5dqqixl4ge1	\N	USER_REGISTER	alex@brspark.com	AUTH	\N	\N	2026-03-25 20:16:58.932
cmn6hjol40007j5dqt2kyabrj	cmn6hij2x0001j5dqofhbi9sd	cmn6hij3j0003j5dqqixl4ge1	\N	USER_LOGIN	alex@brspark.com	AUTH	\N	\N	2026-03-25 20:17:52.696
cmn6hno0l0009j5dq1bej2ui2	cmn6hij2x0001j5dqofhbi9sd	cmn6hij3j0003j5dqqixl4ge1	\N	SYNC_PUSH	1 itens	DATA	{"total": 1, "processed": 1}	\N	2026-03-25 20:20:58.581
cmn6hq4h7000bj5dqwm1dh5yo	cmn6hij2x0001j5dqofhbi9sd	cmn6hij3j0003j5dqqixl4ge1	\N	SYNC_PUSH	1 itens	DATA	{"total": 1, "processed": 1}	\N	2026-03-25 20:22:53.053
cmn6hxjii000dj5dqszmxy8oh	cmn6hij2x0001j5dqofhbi9sd	cmn6hij3j0003j5dqqixl4ge1	\N	USER_LOGIN	alex@brspark.com	AUTH	\N	\N	2026-03-25 20:28:39.305
cmn6i0qh3000110amx61lf8zf	cmn6hij2x0001j5dqofhbi9sd	cmn6hij3j0003j5dqqixl4ge1	\N	USER_LOGIN	alex@brspark.com	AUTH	\N	\N	2026-03-25 20:31:08.295
cmn6i30zk000410amzjlro6bw	\N	\N	cmn3xhvkq0000dajk4h6w2ytx	INTEGRATION_ADD	Dropbox	ADMIN	\N	\N	2026-03-25 20:32:55.232
cmn6i3j4b000610am8gjmkmjo	cmn6hij2x0001j5dqofhbi9sd	cmn6hij3j0003j5dqqixl4ge1	\N	USER_LOGIN	alex@brspark.com	AUTH	\N	\N	2026-03-25 20:33:18.731
cmn6ib89v000910am16xop6b1	\N	\N	cmn3xhvkq0000dajk4h6w2ytx	INTEGRATION_ADD	Dropbox	ADMIN	\N	\N	2026-03-25 20:39:17.923
cmn6ibgb4000c10amauugfoo6	\N	\N	cmn3xhvkq0000dajk4h6w2ytx	INTEGRATION_ADD	Dropbox	ADMIN	\N	\N	2026-03-25 20:39:28.336
cmn6ic136000f10amd03yh4vh	\N	\N	cmn3xhvkq0000dajk4h6w2ytx	INTEGRATION_ADD	Dropbox	ADMIN	\N	\N	2026-03-25 20:39:55.267
cmn6idb46000i10amstbusyjy	\N	\N	cmn3xhvkq0000dajk4h6w2ytx	INTEGRATION_ADD	Dropbox	ADMIN	\N	\N	2026-03-25 20:40:54.918
cmn6idivg000l10amezf3bdzu	\N	\N	cmn3xhvkq0000dajk4h6w2ytx	INTEGRATION_ADD	Dropbox	ADMIN	\N	\N	2026-03-25 20:41:04.972
cmn6idp4q000o10amzub519at	\N	\N	cmn3xhvkq0000dajk4h6w2ytx	INTEGRATION_ADD	Dropbox	ADMIN	\N	\N	2026-03-25 20:41:13.083
cmn6idqam000r10amnt2y1u6g	\N	\N	cmn3xhvkq0000dajk4h6w2ytx	INTEGRATION_ADD	Dropbox	ADMIN	\N	\N	2026-03-25 20:41:14.591
cmn6iebsk000t10am8jdne7pl	cmn6hij2x0001j5dqofhbi9sd	cmn6hij3j0003j5dqqixl4ge1	\N	USER_LOGIN	alex@brspark.com	AUTH	\N	\N	2026-03-25 20:41:42.452
cmn6j3ke3000220a7br5vyx8p	\N	\N	cmn3xhvkq0000dajk4h6w2ytx	INTEGRATION_ADD	Cloudflare R2	ADMIN	\N	\N	2026-03-25 21:01:19.996
cmn6j3u4o000520a7lts1dyo2	\N	\N	cmn3xhvkq0000dajk4h6w2ytx	INTEGRATION_ADD	Cloudflare R2	ADMIN	\N	\N	2026-03-25 21:01:32.616
cmn6j4nho000820a7wwn3nsvg	\N	\N	cmn3xhvkq0000dajk4h6w2ytx	INTEGRATION_ADD	Cloudflare R2	ADMIN	\N	\N	2026-03-25 21:02:10.668
cmn6j8oeo0001dritx06508up	\N	\N	cmn3xhvkq0000dajk4h6w2ytx	LOGIN	Admin Console	AUTH	\N	\N	2026-03-25 21:05:18.477
cmn6j958r0003drit0khx6b64	\N	\N	cmn3xhvkq0000dajk4h6w2ytx	LOGIN	Admin Console	AUTH	\N	\N	2026-03-25 21:05:40.299
cmn6jbafu0005dritwyzmnclp	cmn6hij2x0001j5dqofhbi9sd	cmn6hij3j0003j5dqqixl4ge1	\N	USER_LOGIN	alex@brspark.com	AUTH	\N	\N	2026-03-25 21:07:20.346
cmn6mfztg0007drit1d5bbmnk	cmn6hij2x0001j5dqofhbi9sd	cmn6hij3j0003j5dqqixl4ge1	\N	SYNC_PUSH	4 itens	DATA	{"total": 4, "processed": 4}	\N	2026-03-25 22:34:58.676
cmn6qhwgh00165epyndkumap9	\N	\N	cmn3xhvkq0000dajk4h6w2ytx	INTEGRATION_ADD	OpenAI	ADMIN	\N	\N	2026-03-26 00:28:26.129
cmn6sf2x1004k5epytmul3w9e	cmn6sf2we004g5epyw7uxjo73	cmn6sf2wq004i5epyd58t8qn2	\N	USER_REGISTER	luigi@lansolver.com	AUTH	\N	\N	2026-03-26 01:22:13.765
cmn6ugho2001re0hk47znqukb	cmn6sf2we004g5epyw7uxjo73	cmn6sf2wq004i5epyd58t8qn2	\N	USER_LOGIN	luigi@lansolver.com	AUTH	\N	\N	2026-03-26 02:19:18.77
cmn6um2kz0029e0hkup8lbp22	cmn6sf2we004g5epyw7uxjo73	cmn6sf2wq004i5epyd58t8qn2	\N	USER_LOGIN	luigi@lansolver.com	AUTH	\N	\N	2026-03-26 02:23:39.154
cmn6uoskv002ze0hkc9qcuay3	cmn6hij2x0001j5dqofhbi9sd	cmn6hij3j0003j5dqqixl4ge1	\N	USER_LOGIN	alex@brspark.com	AUTH	\N	\N	2026-03-26 02:25:46.16
cmn6uznso000hv9smbc51ru0z	cmn6sf2we004g5epyw7uxjo73	cmn6sf2wq004i5epyd58t8qn2	\N	USER_LOGIN	luigi@lansolver.com	AUTH	\N	\N	2026-03-26 02:34:13.176
cmn6uzxjx0017v9smfigy8flw	cmn6hij2x0001j5dqofhbi9sd	cmn6hij3j0003j5dqqixl4ge1	\N	USER_LOGIN	alex@brspark.com	AUTH	\N	\N	2026-03-26 02:34:25.821
cmn6vpljz002gv9smjw8mw2h5	cmn6sf2we004g5epyw7uxjo73	cmn6sf2wq004i5epyd58t8qn2	\N	USER_LOGIN	luigi@lansolver.com	AUTH	\N	\N	2026-03-26 02:54:23.327
cmn6vqa7k0036v9smxm04o49b	cmn6hij2x0001j5dqofhbi9sd	cmn6hij3j0003j5dqqixl4ge1	\N	SYNC_PUSH	1 itens	DATA	{"total": 1, "processed": 1}	\N	2026-03-26 02:54:55.28
cmn6vw5cv0044v9smlbwsg3tv	cmn6hij2x0001j5dqofhbi9sd	cmn6hij3j0003j5dqqixl4ge1	\N	USER_LOGIN	alex@brspark.com	AUTH	\N	\N	2026-03-26 02:59:28.927
cmn7e0jrk004mv9smi1kalf72	cmn6hij2x0001j5dqofhbi9sd	cmn6hij3j0003j5dqqixl4ge1	\N	USER_LOGIN	alex@brspark.com	AUTH	\N	\N	2026-03-26 11:26:47.312
cmn7ga5cc005ov9sm972tmvmr	cmn6hij2x0001j5dqofhbi9sd	cmn6hij3j0003j5dqqixl4ge1	\N	SYNC_PUSH	1 itens	DATA	{"total": 1, "processed": 1}	\N	2026-03-26 12:30:14.412
cmn7gai6e005uv9sms34hpew6	cmn6hij2x0001j5dqofhbi9sd	cmn6hij3j0003j5dqqixl4ge1	\N	USER_LOGIN	alex@brspark.com	AUTH	\N	\N	2026-03-26 12:30:31.046
cmn7gcg3o006av9sm9vusp0dg	cmn6hij2x0001j5dqofhbi9sd	cmn6hij3j0003j5dqqixl4ge1	\N	SYNC_PUSH	1 itens	DATA	{"total": 1, "processed": 1}	\N	2026-03-26 12:32:01.585
cmn7gcg3i0068v9smazmr9xg2	cmn6hij2x0001j5dqofhbi9sd	cmn6hij3j0003j5dqqixl4ge1	\N	SYNC_PUSH	1 itens	DATA	{"total": 1, "processed": 1}	\N	2026-03-26 12:32:01.581
cmn7geab3006pv9smz3dnom3d	cmn6sf2we004g5epyw7uxjo73	cmn6sf2wq004i5epyd58t8qn2	\N	USER_LOGIN	luigi@lansolver.com	AUTH	\N	\N	2026-03-26 12:33:27.471
cmn7ggb5o008bv9smtdl5b3ld	cmn6hij2x0001j5dqofhbi9sd	cmn6hij3j0003j5dqqixl4ge1	\N	USER_LOGIN	alex@brspark.com	AUTH	\N	\N	2026-03-26 12:35:01.884
cmn7gimju008pv9sm5xmm8dkl	cmn6hij2x0001j5dqofhbi9sd	cmn6hij3j0003j5dqqixl4ge1	\N	USER_LOGIN	alex@brspark.com	AUTH	\N	\N	2026-03-26 12:36:49.962
cmn7gky710093v9smhuo90klg	cmn6sf2we004g5epyw7uxjo73	cmn6sf2wq004i5epyd58t8qn2	\N	USER_LOGIN	luigi@lansolver.com	AUTH	\N	\N	2026-03-26 12:38:38.366
cmn7gna3400a1v9sm6x2umfi9	cmn6hij2x0001j5dqofhbi9sd	cmn6hij3j0003j5dqqixl4ge1	\N	USER_LOGIN	alex@brspark.com	AUTH	\N	\N	2026-03-26 12:40:27.089
cmn7gp6uh00afv9smdd2dilzs	cmn6sf2we004g5epyw7uxjo73	cmn6sf2wq004i5epyd58t8qn2	\N	USER_LOGIN	luigi@lansolver.com	AUTH	\N	\N	2026-03-26 12:41:56.201
cmn7gxr0800btv9smt7v5402o	cmn6sf2we004g5epyw7uxjo73	cmn6sf2wq004i5epyd58t8qn2	\N	USER_LOGIN	luigi@lansolver.com	AUTH	\N	\N	2026-03-26 12:48:35.576
cmn7h820v00dfv9sm6eja59ia	\N	\N	cmn3xhvkq0000dajk4h6w2ytx	LOGIN	Admin Console	AUTH	\N	\N	2026-03-26 12:56:36.415
cmn7h8tr200dhv9sm5i9ny2tc	\N	\N	cmn3xhvkq0000dajk4h6w2ytx	LOGIN	Admin Console	AUTH	\N	\N	2026-03-26 12:57:12.35
cmn7h9jnp00djv9sm938241s8	\N	\N	cmn3xhvkq0000dajk4h6w2ytx	LOGIN	Admin Console	AUTH	\N	\N	2026-03-26 12:57:45.925
cmn7hjryi00e9v9smq7sa7inn	cmn6sf2we004g5epyw7uxjo73	cmn6sf2wq004i5epyd58t8qn2	\N	USER_LOGIN	luigi@lansolver.com	AUTH	\N	\N	2026-03-26 13:05:43.243
cmn7hkfjb00f7v9smfi9lildp	cmn6sf2we004g5epyw7uxjo73	cmn6sf2wq004i5epyd58t8qn2	\N	USER_LOGIN	luigi@lansolver.com	AUTH	\N	\N	2026-03-26 13:06:13.8
cmn7hlry600fyv9smbyscq2ew	\N	\N	cmn3xhvkq0000dajk4h6w2ytx	INTEGRATION_ADD	Dropbox	ADMIN	\N	\N	2026-03-26 13:07:16.543
cmn7hmg5t00g1v9smc27cqafu	\N	\N	cmn3xhvkq0000dajk4h6w2ytx	INTEGRATION_ADD	Dropbox	ADMIN	\N	\N	2026-03-26 13:07:47.922
cmn7hmouv00g4v9smuv2jb2t3	\N	\N	cmn3xhvkq0000dajk4h6w2ytx	INTEGRATION_ADD	Dropbox	ADMIN	\N	\N	2026-03-26 13:07:59.192
cmn7hu7150002yy95096za470	\N	\N	cmn3xhvkq0000dajk4h6w2ytx	INTEGRATION_ADD	Dropbox	ADMIN	\N	\N	2026-03-26 13:13:49.338
cmn7iftf40010yy9537c1adet	cmn6sf2we004g5epyw7uxjo73	cmn6sf2wq004i5epyd58t8qn2	\N	USER_LOGIN	luigi@lansolver.com	AUTH	\N	\N	2026-03-26 13:30:38.128
cmn7izbo1002myy95b9ljodhp	cmn6sf2we004g5epyw7uxjo73	cmn6sf2wq004i5epyd58t8qn2	\N	USER_LOGIN	luigi@lansolver.com	AUTH	\N	\N	2026-03-26 13:45:48.241
cmn7j0s4t0048yy9586lbl331	cmn6sf2we004g5epyw7uxjo73	cmn6sf2wq004i5epyd58t8qn2	\N	USER_LOGIN	luigi@lansolver.com	AUTH	\N	\N	2026-03-26 13:46:56.237
cmn7j7aci005myy95ivokbdkw	cmn6sf2we004g5epyw7uxjo73	cmn6sf2wq004i5epyd58t8qn2	\N	USER_LOGIN	luigi@lansolver.com	AUTH	\N	\N	2026-03-26 13:51:59.779
cmn7jb3ao007gyy95g04fpy01	cmn6sf2we004g5epyw7uxjo73	cmn6sf2wq004i5epyd58t8qn2	\N	USER_LOGIN	luigi@lansolver.com	AUTH	\N	\N	2026-03-26 13:54:57.265
cmn7jc9jc008myy9542y4w5lt	cmn6sf2we004g5epyw7uxjo73	cmn6sf2wq004i5epyd58t8qn2	\N	USER_LOGIN	luigi@lansolver.com	AUTH	\N	\N	2026-03-26 13:55:52.008
cmn7jiyin00awyy95h4e5o1dy	cmn6sf2we004g5epyw7uxjo73	cmn6sf2wq004i5epyd58t8qn2	\N	SYNC_PUSH	ASSET	DATA	{"message": "Sincronizados 1 itens da fila offline."}	\N	2026-03-26 14:01:04.319
cmn7jk69s00b6yy95q80dzlia	cmn6sf2we004g5epyw7uxjo73	cmn6sf2wq004i5epyd58t8qn2	\N	SYNC_PUSH	ASSET	DATA	{"message": "Sincronizados 1 itens da fila offline."}	\N	2026-03-26 14:02:01.025
cmn7jk6cr00b8yy95cgg2rnzq	cmn6sf2we004g5epyw7uxjo73	cmn6sf2wq004i5epyd58t8qn2	\N	SYNC_PUSH	ASSET	DATA	{"message": "Sincronizados 1 itens da fila offline."}	\N	2026-03-26 14:02:01.131
cmn7jkh4900biyy95u227v6xl	cmn6sf2we004g5epyw7uxjo73	cmn6sf2wq004i5epyd58t8qn2	\N	SYNC_PUSH	ASSET	DATA	{"message": "Sincronizados 1 itens da fila offline."}	\N	2026-03-26 14:02:15.082
cmn7jop1q00015d5oi6eja91h	cmn6sf2we004g5epyw7uxjo73	cmn6sf2wq004i5epyd58t8qn2	\N	SYNC_PUSH	ASSET	DATA	{"message": "Sincronizados 1 itens da fila offline."}	\N	2026-03-26 14:05:31.982
cmn7jop2z00035d5ob1byyk8t	cmn6sf2we004g5epyw7uxjo73	cmn6sf2wq004i5epyd58t8qn2	\N	SYNC_PUSH	ASSET	DATA	{"message": "Sincronizados 1 itens da fila offline."}	\N	2026-03-26 14:05:32.028
cmn7jp5bo000t5d5oydqbfa2z	cmn6sf2we004g5epyw7uxjo73	cmn6sf2wq004i5epyd58t8qn2	\N	USER_LOGIN	luigi@lansolver.com	AUTH	\N	\N	2026-03-26 14:05:53.077
cmn7rptj2000h4ozlhir3sqbv	cmn6sf2we004g5epyw7uxjo73	cmn6sf2wq004i5epyd58t8qn2	\N	SYNC_PUSH	ASSET	DATA	{"message": "Sincronizados 1 itens da fila offline."}	\N	2026-03-26 17:50:21.374
cmn7rqen4000r4ozlw5erwdd5	cmn6sf2we004g5epyw7uxjo73	cmn6sf2wq004i5epyd58t8qn2	\N	USER_LOGIN	luigi@lansolver.com	AUTH	\N	\N	2026-03-26 17:50:48.737
cmn7ru7bm0001x0k1cf5386es	cmn6sf2we004g5epyw7uxjo73	cmn6sf2wq004i5epyd58t8qn2	\N	SYNC_PUSH	ASSET	DATA	{"message": "Sincronizados 1 itens da fila offline."}	\N	2026-03-26 17:53:45.874
cmn7rv0th000jx0k1hkgr4jq3	cmn6hij2x0001j5dqofhbi9sd	cmn6hij3j0003j5dqqixl4ge1	\N	USER_LOGIN	alex@brspark.com	AUTH	\N	\N	2026-03-26 17:54:24.101
cmn7t9pzn00014bmm3kz64e2t	cmn6hij2x0001j5dqofhbi9sd	cmn6hij3j0003j5dqqixl4ge1	\N	SYNC_PUSH	ASSET	DATA	{"message": "Sincronizados 1 itens da fila offline."}	\N	2026-03-26 18:33:49.523
cmn7y50fm002mhxk5i0y3oaul	cmn6sf2we004g5epyw7uxjo73	cmn6sf2wq004i5epyd58t8qn2	\N	USER_LOGIN	luigi@lansolver.com	AUTH	\N	\N	2026-03-26 20:50:07.858
cmn839wgw003lhq7b8thw4h40	cmn6hij2x0001j5dqofhbi9sd	cmn6hij3j0003j5dqqixl4ge1	\N	SYNC_PUSH	ASSET	DATA	{"message": "Sincronizados 1 itens da fila offline."}	\N	2026-03-26 23:13:54.077
cmn8a5f29000p7hesieuka4sg	cmn6hij2x0001j5dqofhbi9sd	cmn6hij3j0003j5dqqixl4ge1	\N	USER_LOGIN	alex@brspark.com	AUTH	\N	\N	2026-03-27 02:26:22.208
cmn8a94pm001b7heslyo1qce2	cmn6hij2x0001j5dqofhbi9sd	cmn6hij3j0003j5dqqixl4ge1	\N	SYNC_PUSH	ASSET	DATA	{"message": "Sincronizados 1 itens da fila offline."}	\N	2026-03-27 02:29:15.419
cmn8adcin00257hes0ew4hmjz	cmn6hij2x0001j5dqofhbi9sd	cmn6hij3j0003j5dqqixl4ge1	\N	USER_LOGIN	alex@brspark.com	AUTH	\N	\N	2026-03-27 02:32:32.159
cmn8wce4u003v7hes08sxb3m3	cmn6hij2x0001j5dqofhbi9sd	cmn6hij3j0003j5dqqixl4ge1	\N	USER_LOGIN	alex@brspark.com	AUTH	\N	\N	2026-03-27 12:47:39.149
cmn8witsc004d7hesjbvi52ac	cmn6hij2x0001j5dqofhbi9sd	cmn6hij3j0003j5dqqixl4ge1	\N	SYNC_PUSH	ASSET	DATA	{"message": "Sincronizados 3 itens da fila offline."}	\N	2026-03-27 12:52:39.371
cmn8wp9a9004j7hestd2ky7v8	cmn6hij2x0001j5dqofhbi9sd	cmn6hij3j0003j5dqqixl4ge1	\N	SYNC_PUSH	ASSET	DATA	{"message": "Sincronizados 9 itens da fila offline."}	\N	2026-03-27 12:57:39.393
cmn8wvors004p7hes3155vulz	cmn6hij2x0001j5dqofhbi9sd	cmn6hij3j0003j5dqqixl4ge1	\N	SYNC_PUSH	ASSET	DATA	{"message": "Sincronizados 1 itens da fila offline."}	\N	2026-03-27 13:02:39.399
cmn8xobix004v7hesjrlklsqc	\N	\N	cmn3xhvkq0000dajk4h6w2ytx	LOGIN	Admin Console	AUTH	\N	\N	2026-03-27 13:24:55.256
cmn8xpvst000213y40izrdrzd	\N	\N	cmn3xhvkq0000dajk4h6w2ytx	INTEGRATION_ADD	Bluesoft Cosmos	ADMIN	\N	\N	2026-03-27 13:26:08.189
cmn8xs2aa000413y4bw9l54qr	cmn6hij2x0001j5dqofhbi9sd	cmn6hij3j0003j5dqqixl4ge1	\N	SYNC_PUSH	ASSET	DATA	{"message": "Sincronizados 1 itens da fila offline."}	\N	2026-03-27 13:27:49.807
cmn8z4mwn0001w2fvqnmcc94s	\N	\N	cmn3xhvkq0000dajk4h6w2ytx	LOGIN	Admin Console	AUTH	\N	\N	2026-03-27 14:05:36.118
cmn99axhj0001lhmbbofnfjo4	cmn6hij2x0001j5dqofhbi9sd	cmn6hij3j0003j5dqqixl4ge1	\N	USER_LOGIN	alex@brspark.com	AUTH	\N	\N	2026-03-27 18:50:25.927
cmn9h32iw000zlhmbs49ebb23	cmn6hij2x0001j5dqofhbi9sd	cmn6hij3j0003j5dqqixl4ge1	\N	SYNC_PUSH	ASSET	DATA	{"message": "Sincronizados 18 itens da fila offline."}	\N	2026-03-27 22:28:16.084
cmnakgt140001cjidof6cr0xd	cmn6hij2x0001j5dqofhbi9sd	cmn6hij3j0003j5dqqixl4ge1	\N	USER_LOGIN	alex@brspark.com	AUTH	\N	\N	2026-03-28 16:50:42.04
cmnakoes4000bcjidlhs83mv6	cmn6sf2we004g5epyw7uxjo73	cmn6sf2wq004i5epyd58t8qn2	\N	USER_LOGIN	luigi@lansolver.com	AUTH	\N	\N	2026-03-28 16:56:36.82
cmnakw8nn001hcjidmb79om3k	cmn6hij2x0001j5dqofhbi9sd	cmn6hij3j0003j5dqqixl4ge1	\N	SYNC_PUSH	ASSET	DATA	{"message": "Sincronizados 1 itens da fila offline."}	\N	2026-03-28 17:02:42.132
cmnalb6br002lcjid99ao38ad	cmn6hij2x0001j5dqofhbi9sd	cmn6hij3j0003j5dqqixl4ge1	\N	SYNC_PUSH	ASSET	DATA	{"message": "Sincronizados 1 itens da fila offline."}	\N	2026-03-28 17:14:18.951
cmnaloxwe003lcjidobchm4l8	cmn6hij2x0001j5dqofhbi9sd	cmn6hij3j0003j5dqqixl4ge1	\N	SYNC_PUSH	ASSET	DATA	{"message": "Sincronizados 1 itens da fila offline."}	\N	2026-03-28 17:25:01.213
cmnalu36n003vcjid5l7ptq8k	cmn6hij2x0001j5dqofhbi9sd	cmn6hij3j0003j5dqqixl4ge1	\N	SYNC_PUSH	ASSET	DATA	{"message": "Sincronizados 1 itens da fila offline."}	\N	2026-03-28 17:29:01.343
cmnan357s009pcjidivguy06k	cmn6hij2x0001j5dqofhbi9sd	cmn6hij3j0003j5dqqixl4ge1	\N	SYNC_PUSH	ASSET	DATA	{"message": "Sincronizados 1 itens da fila offline."}	\N	2026-03-28 18:04:03.495
cmnanbp9e009zcjidr2uvsfjo	cmn6hij2x0001j5dqofhbi9sd	cmn6hij3j0003j5dqqixl4ge1	\N	SYNC_PUSH	ASSET	DATA	{"message": "Sincronizados 1 itens da fila offline."}	\N	2026-03-28 18:10:42.722
cmnanc4y000a5cjid0e5cpa4a	cmn6hij2x0001j5dqofhbi9sd	cmn6hij3j0003j5dqqixl4ge1	\N	SYNC_PUSH	ASSET	DATA	{"message": "Sincronizados 1 itens da fila offline."}	\N	2026-03-28 18:11:03.048
cmnand7lu00abcjid9vlpr1mj	cmn6hij2x0001j5dqofhbi9sd	cmn6hij3j0003j5dqqixl4ge1	\N	SYNC_PUSH	ASSET	DATA	{"message": "Sincronizados 1 itens da fila offline."}	\N	2026-03-28 18:11:53.154
cmnaopgu200bhcjidi12aaitx	cmn6hij2x0001j5dqofhbi9sd	cmn6hij3j0003j5dqqixl4ge1	\N	SYNC_PUSH	ASSET	DATA	{"message": "Sincronizados 1 itens da fila offline."}	\N	2026-03-28 18:49:24.601
cmnashkjj00fvcjidvf9f3wsj	cmn6hij2x0001j5dqofhbi9sd	cmn6hij3j0003j5dqqixl4ge1	\N	SYNC_PUSH	ASSET	DATA	{"message": "Sincronizados 1 itens da fila offline."}	\N	2026-03-28 20:35:14.622
cmnat0v0l00g9cjidyka92cu8	cmn6hij2x0001j5dqofhbi9sd	cmn6hij3j0003j5dqqixl4ge1	\N	SYNC_PUSH	ASSET	DATA	{"message": "Sincronizados 4 itens da fila offline."}	\N	2026-03-28 20:50:14.66
cmnat3eku00gfcjidaypbi5na	cmn6hij2x0001j5dqofhbi9sd	cmn6hij3j0003j5dqqixl4ge1	\N	SYNC_PUSH	ASSET	DATA	{"message": "Sincronizados 2 itens da fila offline."}	\N	2026-03-28 20:52:13.302
cmnau4wau00hpcjidzu94xueb	cmn6hij2x0001j5dqofhbi9sd	cmn6hij3j0003j5dqqixl4ge1	\N	SYNC_PUSH	ASSET	DATA	{"message": "Sincronizados 1 itens da fila offline."}	\N	2026-03-28 21:21:22.565
cmnb2cfze00wgcjidesgdvi3j	\N	\N	cmn3xhvkq0000dajk4h6w2ytx	LOGIN	Admin Console	AUTH	\N	\N	2026-03-29 01:11:11.589
cmnb45wu300wicjidi6r6g92i	\N	\N	cmn3xhvkq0000dajk4h6w2ytx	LOGIN	Admin Console	AUTH	\N	\N	2026-03-29 02:02:06.068
cmnb4rb4200wkcjid3ivrrvhe	cmn6hij2x0001j5dqofhbi9sd	cmn6hij3j0003j5dqqixl4ge1	\N	USER_LOGIN	alex@brspark.com	AUTH	\N	\N	2026-03-29 02:18:44.347
cmnb4x6yz00x2cjid66wm1j06	\N	\N	cmn3xhvkq0000dajk4h6w2ytx	LOGIN	Admin Console	AUTH	\N	\N	2026-03-29 02:23:18.922
cmnb4yq0100x9cjidc41j3tua	\N	\N	cmn3xhvkq0000dajk4h6w2ytx	LOGIN	Admin Console	AUTH	\N	\N	2026-03-29 02:24:30.24
cmncf79sp0001ikxwxplxjniu	\N	\N	cmn3xhvkq0000dajk4h6w2ytx	LOGIN	Admin Console	AUTH	\N	\N	2026-03-29 23:58:51.479
cmncg953z0003ikxw4zmy8nga	cmn6hij2x0001j5dqofhbi9sd	cmn6hij3j0003j5dqqixl4ge1	\N	USER_LOGIN	alex@brspark.com	AUTH	\N	\N	2026-03-30 00:28:18.331
cmncmawoq000lx926hwanu85d	\N	\N	cmn3xhvkq0000dajk4h6w2ytx	LOGIN	Admin Console	AUTH	\N	\N	2026-03-30 03:17:38.426
cmnd8dh78009h9gz6931lx95n	cmn6hij2x0001j5dqofhbi9sd	cmn6hij3j0003j5dqqixl4ge1	\N	USER_LOGIN	alex@brspark.com	AUTH	\N	\N	2026-03-30 13:35:29.875
cmnd8ok3d0001142nc59etoj2	cmn6hij2x0001j5dqofhbi9sd	cmn6hij3j0003j5dqqixl4ge1	\N	USER_LOGIN	alex@brspark.com	AUTH	\N	\N	2026-03-30 13:44:06.841
cmnd8ovvl0003142n5nfdcarq	cmn6hij2x0001j5dqofhbi9sd	cmn6hij3j0003j5dqqixl4ge1	\N	USER_LOGIN	alex@brspark.com	AUTH	\N	\N	2026-03-30 13:44:22.113
cmnd8webe0016142n8con55au	cmn6hij2x0001j5dqofhbi9sd	cmn6hij3j0003j5dqqixl4ge1	\N	USER_LOGIN	alex@brspark.com	AUTH	\N	\N	2026-03-30 13:50:12.603
cmnd8wmrm0018142ntno0e3fm	cmn6hij2x0001j5dqofhbi9sd	cmn6hij3j0003j5dqqixl4ge1	\N	USER_LOGIN	alex@brspark.com	AUTH	\N	\N	2026-03-30 13:50:23.555
cmnd8wvz1001a142ncopx809g	cmn6hij2x0001j5dqofhbi9sd	cmn6hij3j0003j5dqqixl4ge1	\N	USER_LOGIN	alex@brspark.com	AUTH	\N	\N	2026-03-30 13:50:35.485
cmnd92wy2002e12to8j2mtt5q	cmn6hij2x0001j5dqofhbi9sd	cmn6hij3j0003j5dqqixl4ge1	\N	USER_LOGIN	alex@brspark.com	AUTH	\N	\N	2026-03-30 13:55:16.682
cmndamvq40025his9nu1g9oov	\N	\N	\N	SYNC_OS_COMPLETED	ChecklistExecution	DATA	{"hasGps": false, "ownerEmail": "alex@brspark.com", "templateId": "chk_mnb61qhk", "executionId": "cmnd9izxq0001his9r35u7aab"}	\N	2026-03-30 14:38:47.837
cmndamvra0027his9w0gmrz2d	\N	\N	\N	SYNC_OS_COMPLETED	ChecklistExecution	DATA	{"hasGps": false, "ownerEmail": "alex@brspark.com", "templateId": "chk_mnb61qhk", "executionId": "cmnd9izxq0001his9r35u7aab"}	\N	2026-03-30 14:38:47.878
cmndamvr60026his9sqi0dmmq	\N	\N	\N	SYNC_OS_COMPLETED	ChecklistExecution	DATA	{"hasGps": false, "ownerEmail": "alex@brspark.com", "templateId": "chk_mnb61qhk", "executionId": "cmnd9izxq0001his9r35u7aab"}	\N	2026-03-30 14:38:47.874
cmndamvrs0028his9xwvz3qag	\N	\N	\N	SYNC_OS_COMPLETED	ChecklistExecution	DATA	{"hasGps": false, "ownerEmail": "alex@brspark.com", "templateId": "chk_mnb61qhk", "executionId": "cmnd9izxq0001his9r35u7aab"}	\N	2026-03-30 14:38:47.897
cmndc8rkl001yizib5lj2mg0i	\N	\N	\N	SYNC_OS_COMPLETED	ChecklistExecution	DATA	{"hasGps": false, "ownerEmail": "alex@brspark.com", "templateId": "chk_mnb61qhk", "executionId": "cmnd9ct7l0001h3vyuhei9gzs"}	\N	2026-03-30 15:23:48.501
cmndgyd5h0000nxapn309023j	\N	\N	\N	SYNC_OS_COMPLETED	ChecklistExecution	DATA	{"hasGps": false, "ownerEmail": "alex@brspark.com", "templateId": "chk_mnb61qhk", "executionId": "cmnd9aekq0006jyvrk8rxw88o"}	\N	2026-03-30 17:35:41.334
cmndnesqx004cxd9l6jq0delh	\N	\N	cmn3xhvkq0000dajk4h6w2ytx	LOGIN	Admin Console	AUTH	\N	\N	2026-03-30 20:36:25.737
cmndnh8dy004pxd9l1opy65eg	\N	\N	\N	SYNC_OS_COMPLETED	ChecklistExecution	DATA	{"hasGps": false, "ownerEmail": "alex@brspark.com", "templateId": "chk_mnb61qhk", "executionId": "cmndnfcqy004exd9lmj5nib1k"}	\N	2026-03-30 20:38:19.319
cmndr315p0000kgy8m2i5zctk	\N	\N	\N	SYNC_OS_COMPLETED	ChecklistExecution	DATA	{"hasGps": false, "ownerEmail": "alex@brspark.com", "templateId": "chk_mnb61qhk", "executionId": "cmnd9ewri0003h3vywuahnh9e"}	\N	2026-03-30 22:19:15.23
cmndr315t0001kgy87wob0jke	\N	\N	\N	SYNC_OS_COMPLETED	ChecklistExecution	DATA	{"hasGps": false, "ownerEmail": "alex@brspark.com", "templateId": "chk_mnb61qhk", "executionId": "cmnd9ewri0003h3vywuahnh9e"}	\N	2026-03-30 22:19:15.234
cmndsiyuc0005kgy8mjn7veu3	cmn6hij2x0001j5dqofhbi9sd	cmn6hij3j0003j5dqqixl4ge1	\N	USER_LOGIN	alex@brspark.com	AUTH	\N	\N	2026-03-30 22:59:38.339
cmndsjqao000mkgy8oyajsyw7	\N	\N	\N	SYNC_OS_COMPLETED	ChecklistExecution	DATA	{"hasGps": false, "ownerEmail": "alex@brspark.com", "templateId": "chk_mnb61qhk", "executionId": "cmndsfh9k0003kgy8tl8ljs8t"}	\N	2026-03-30 23:00:13.921
cmndsuvo60018kgy83kpa7jnj	cmn6hij2x0001j5dqofhbi9sd	cmn6hij3j0003j5dqqixl4ge1	\N	USER_LOGIN	alex@brspark.com	AUTH	\N	\N	2026-03-30 23:08:54.101
cmndt0jln001pkgy87pd7nsuh	\N	\N	\N	SYNC_OS_COMPLETED	ChecklistExecution	DATA	{"hasGps": false, "ownerEmail": "alex@brspark.com", "templateId": "chk_mnb61qhk", "executionId": "cmndsu7em0016kgy8ggodr7tm"}	\N	2026-03-30 23:13:18.394
cmndt63oi001xkgy8s1lyqmat	\N	\N	\N	SYNC_OS_COMPLETED	ChecklistExecution	DATA	{"hasGps": false, "ownerEmail": "alex@brspark.com", "templateId": "chk_mnb61qhk", "executionId": "cmndt63ma001wkgy87784o2mr"}	\N	2026-03-30 23:17:37.699
cmndu6yvw002skgy8j5n945md	\N	\N	\N	SYNC_OS_COMPLETED	ChecklistExecution	DATA	{"hasGps": false, "ownerEmail": "alex@brspark.com", "templateId": "chk_mnb61qhk", "executionId": "cmndsu5oi0014kgy871qo1n2n"}	\N	2026-03-30 23:46:17.756
cmndxlb8u001bz5l5bff4gnl0	\N	\N	\N	SYNC_OS_COMPLETED	ChecklistExecution	DATA	{"hasGps": false, "ownerEmail": "alex@brspark.com", "templateId": "chk_mnb61qhk", "executionId": "cmndxkjba000vz5l5fi35a9uw"}	\N	2026-03-31 01:21:25.805
cmndxnv9o001iz5l57flk2px4	cmn6hij2x0001j5dqofhbi9sd	cmn6hij3j0003j5dqqixl4ge1	\N	USER_LOGIN	alex@brspark.com	AUTH	\N	\N	2026-03-31 01:23:25.068
cmndz0zdy0038z5l5vsbblnfh	\N	\N	\N	SYNC_OS_COMPLETED	ChecklistExecution	DATA	{"hasGps": false, "ownerEmail": "alex@brspark.com", "templateId": "chk_mnb61qhk", "executionId": "cmndwm9600076kgy8pumi8lwi"}	\N	2026-03-31 02:01:36.537
cmndz17zl0039z5l5m653ol11	\N	\N	\N	SYNC_OS_COMPLETED	ChecklistExecution	DATA	{"hasGps": false, "ownerEmail": "alex@brspark.com", "templateId": "chk_mnb61qhk", "executionId": "cmndvqvv8004dkgy8sa3mwan7"}	\N	2026-03-31 02:01:47.694
cmndz1h0h003az5l5izfszijc	\N	\N	\N	SYNC_OS_COMPLETED	ChecklistExecution	DATA	{"hasGps": false, "ownerEmail": "alex@brspark.com", "templateId": "chk_mnb61qhk", "executionId": "cmndr0qws0079xd9ld66967uv"}	\N	2026-03-31 02:01:59.393
cmndz1vdl003bz5l5csycmydv	\N	\N	\N	SYNC_OS_COMPLETED	ChecklistExecution	DATA	{"hasGps": false, "ownerEmail": "alex@brspark.com", "templateId": "chk_mnb61qhk", "executionId": "cmndstzfh000ykgy8ietsa2q7"}	\N	2026-03-31 02:02:18.009
cmndzdoy3003nz5l567l49td3	\N	\N	cmn3xhvkq0000dajk4h6w2ytx	LOGIN	Admin Console	AUTH	\N	\N	2026-03-31 02:11:29.547
cmne0ew1d004tz5l5bz0da91b	\N	\N	cmn3xhvkq0000dajk4h6w2ytx	LOGIN	Admin Console	AUTH	\N	\N	2026-03-31 02:40:25.008
cmne0iwsb005dz5l5bl1i43z8	\N	\N	\N	SYNC_OS_COMPLETED	ChecklistExecution	DATA	{"hasGps": false, "ownerEmail": "alex@brspark.com", "templateId": "chk_mnb61qhk", "executionId": "cmne0garp004vz5l5umk0v0m6"}	\N	2026-03-31 02:43:32.602
cmne0ljab005fz5l57u2wxe7a	\N	\N	cmn3xhvkq0000dajk4h6w2ytx	LOGIN	Admin Console	AUTH	\N	\N	2026-03-31 02:45:35.074
cmne108if0006okg04aq79fmn	\N	\N	cmn3xhvkq0000dajk4h6w2ytx	LOGIN	Admin Console	AUTH	\N	\N	2026-03-31 02:57:00.949
cmnelqa0o0001mtd4zln8jgyb	cmn6hij2x0001j5dqofhbi9sd	cmn6hij3j0003j5dqqixl4ge1	\N	USER_LOGIN	alex@brspark.com	AUTH	\N	\N	2026-03-31 12:37:08.28
cmnems8bv002jmtd4qd5l4cvi	cmn6hij2x0001j5dqofhbi9sd	cmn6hij3j0003j5dqqixl4ge1	\N	USER_LOGIN	alex@brspark.com	AUTH	\N	\N	2026-03-31 13:06:39.019
cmnen1nc70000ibkeunk4spx2	\N	\N	\N	SYNC_OS_COMPLETED	ChecklistExecution	DATA	{"hasGps": false, "ownerEmail": "alex@brspark.com", "templateId": "chk_mne1dhzv", "executionId": "cmnemut6l0031mtd42528tc2a"}	\N	2026-03-31 13:13:58.376
cmnen5rx3000gibker1owq8ix	\N	\N	\N	SYNC_OS_COMPLETED	ChecklistExecution	DATA	{"hasGps": false, "ownerEmail": "alex@brspark.com", "templateId": "chk_mne1dhzv", "executionId": "cmnemvwzc003dmtd4gh1605ho"}	\N	2026-03-31 13:17:10.935
cmnennxz80011ibke78tetez8	\N	\N	\N	SYNC_OS_COMPLETED	ChecklistExecution	DATA	{"hasGps": false, "ownerEmail": "alex@brspark.com", "templateId": "chk_mne1dhzv", "executionId": "cmnelvood0018mtd4vlaxm8og"}	\N	2026-03-31 13:31:18.596
cmnenyela001nibkex5mxu3h0	\N	\N	cmn3xhvkq0000dajk4h6w2ytx	LOGIN	Admin Console	AUTH	\N	\N	2026-03-31 13:39:26.683
cmnf5oggt00e8ibkec3tpz5j7	\N	\N	\N	SYNC_OS_COMPLETED	ChecklistExecution	DATA	{"hasGps": false, "ownerEmail": "alex@brspark.com", "templateId": "chk_mne1dhzv", "executionId": "cmne1di3c000iokg0e6r6qeeh"}	\N	2026-03-31 21:55:35.643
cmnf7ar0e00eeibkeo8u4ba47	cmn6hij2x0001j5dqofhbi9sd	cmn6hij3j0003j5dqqixl4ge1	\N	USER_LOGIN	alex@brspark.com	AUTH	\N	\N	2026-03-31 22:40:55.357
cmnf8ccuj000110a9z7n3i7eq	\N	\N	cmn3xhvkq0000dajk4h6w2ytx	LOGIN	Admin Console	AUTH	\N	\N	2026-03-31 23:10:09.929
cmnf8dad6000310a9e3dlib7j	cmn6hij2x0001j5dqofhbi9sd	cmn6hij3j0003j5dqqixl4ge1	\N	USER_LOGIN	alex@brspark.com	AUTH	\N	\N	2026-03-31 23:10:53.37
cmnf8dhm5000k10a95b5e0cb1	\N	\N	\N	SYNC_OS_COMPLETED	ChecklistExecution	DATA	{"hasGps": false, "ownerEmail": "alex@brspark.com", "templateId": "chk_mncnb2te", "executionId": "cmnf5yihg00ecibkekx8ncpcy"}	\N	2026-03-31 23:11:02.765
cmnf8gov5000w10a9808bizsh	\N	\N	cmn3xhvkq0000dajk4h6w2ytx	LOGIN	Admin Console	AUTH	\N	\N	2026-03-31 23:13:32.123
cmnf8jf4u000x10a9kjs67kyk	\N	\N	\N	OS_CANCELLED	ChecklistExecution	DATA	{"ownerEmail": "alex@brspark.com", "executionId": "cmnf5yihg00ecibkekx8ncpcy", "previousStatus": "COMPLETED"}	\N	2026-03-31 23:15:39.487
cmnf8optx001310a9uhg9l10y	\N	\N	\N	SYNC_OS_COMPLETED	ChecklistExecution	DATA	{"hasGps": false, "ownerEmail": "alex@brspark.com", "templateId": "chk_mnf5iygw", "executionId": "cmnf5jetv00e7ibkef45xnoaw"}	\N	2026-03-31 23:19:46.629
cmnf8rbpu00062jj0g633bv4j	\N	\N	cmn3xhvkq0000dajk4h6w2ytx	LOGIN	Admin Console	AUTH	\N	\N	2026-03-31 23:21:48.306
cmnf93eqf000h2jj0cozmxz4l	\N	\N	\N	OS_CANCELLED	ChecklistExecution	DATA	{"ownerEmail": "alex@lansolver.com", "executionId": "cmnf5xpn500eaibkefxnwiipi", "previousStatus": "PENDING"}	\N	2026-03-31 23:31:12.087
cmnf93hij000i2jj0ud1viw0w	\N	\N	\N	OS_CANCELLED	ChecklistExecution	DATA	{"ownerEmail": "tecnico@empresa.com", "executionId": "cmncmuh1e000bgstiakvatblr", "previousStatus": "PENDING"}	\N	2026-03-31 23:31:15.691
cmnf9xxmv00132jj0kn3pdnh4	\N	\N	\N	SYNC_OS_COMPLETED	ChecklistExecution	DATA	{"hasGps": false, "ownerEmail": "alex@brspark.com", "templateId": "chk_mnb61qhk", "executionId": "cmne0i4r9005cz5l5taguxlda"}	\N	2026-03-31 23:54:56.261
cmnfe6cse005t2jj01pvmsd0c	\N	\N	\N	SYNC_OS_COMPLETED	ChecklistExecution	DATA	{"hasGps": false, "ownerEmail": "alex@brspark.com", "templateId": "chk_mnen95p1d55", "executionId": "cmnfe1k6z005h2jj01f18y64f"}	\N	2026-04-01 01:53:27.614
cmnfe6ct0005u2jj0yqgi7u9y	\N	\N	\N	SYNC_OS_COMPLETED	ChecklistExecution	DATA	{"hasGps": false, "ownerEmail": "alex@brspark.com", "templateId": "chk_mnen95p1d55", "executionId": "cmnfe1k6z005h2jj01f18y64f"}	\N	2026-04-01 01:53:27.636
cmnfe6crq005s2jj08m71tdo7	\N	\N	\N	SYNC_OS_COMPLETED	ChecklistExecution	DATA	{"hasGps": false, "ownerEmail": "alex@brspark.com", "templateId": "chk_mnen95p1d55", "executionId": "cmnfe1k6z005h2jj01f18y64f"}	\N	2026-04-01 01:53:27.588
cmnfe6d3s005v2jj0cjr6hys7	\N	\N	\N	SYNC_OS_COMPLETED	ChecklistExecution	DATA	{"hasGps": false, "ownerEmail": "alex@brspark.com", "templateId": "chk_mnen95p1d55", "executionId": "cmnfe1k6z005h2jj01f18y64f"}	\N	2026-04-01 01:53:28.024
cmnfe6d9o005w2jj0oglefrem	\N	\N	\N	SYNC_OS_COMPLETED	ChecklistExecution	DATA	{"hasGps": false, "ownerEmail": "alex@brspark.com", "templateId": "chk_mnen95p1d55", "executionId": "cmnfe1k6z005h2jj01f18y64f"}	\N	2026-04-01 01:53:28.237
cmnfe6dfy005x2jj08qxeqnwl	\N	\N	\N	SYNC_OS_COMPLETED	ChecklistExecution	DATA	{"hasGps": false, "ownerEmail": "alex@brspark.com", "templateId": "chk_mnen95p1d55", "executionId": "cmnfe1k6z005h2jj01f18y64f"}	\N	2026-04-01 01:53:28.462
cmnfe6dhg005y2jj089vrnlxv	\N	\N	\N	SYNC_OS_COMPLETED	ChecklistExecution	DATA	{"hasGps": false, "ownerEmail": "alex@brspark.com", "templateId": "chk_mnen95p1d55", "executionId": "cmnfe1k6z005h2jj01f18y64f"}	\N	2026-04-01 01:53:28.516
cmnfe6j8l005z2jj0kyn555y5	\N	\N	\N	SYNC_OS_COMPLETED	ChecklistExecution	DATA	{"hasGps": false, "ownerEmail": "alex@brspark.com", "templateId": "chk_mnen95p1d55", "executionId": "cmnfe1k6z005h2jj01f18y64f"}	\N	2026-04-01 01:53:35.973
cmnfe6jb600602jj0cl6cakx6	\N	\N	\N	SYNC_OS_COMPLETED	ChecklistExecution	DATA	{"hasGps": false, "ownerEmail": "alex@brspark.com", "templateId": "chk_mnen95p1d55", "executionId": "cmnfe1k6z005h2jj01f18y64f"}	\N	2026-04-01 01:53:36.067
cmnff9jk0000146dcs6oq78tb	\N	\N	cmn3xhvkq0000dajk4h6w2ytx	LOGIN	Admin Console	AUTH	\N	\N	2026-04-01 02:23:55.968
cmnffdq42000m46dccos77pal	\N	\N	\N	SYNC_OS_COMPLETED	ChecklistExecution	DATA	{"hasGps": false, "ownerEmail": "alex@brspark.com", "templateId": "chk_mnen95p1d55", "executionId": "cmnfe1i85005f2jj04it93pkp"}	\N	2026-04-01 02:27:11.087
cmnffdqvu000n46dcl7cjteuw	\N	\N	\N	SYNC_OS_COMPLETED	ChecklistExecution	DATA	{"hasGps": false, "ownerEmail": "alex@brspark.com", "templateId": "chk_mnen95p1d55", "executionId": "cmnfe1i85005f2jj04it93pkp"}	\N	2026-04-01 02:27:12.09
cmnfgjyvy00008mdmobupmzus	\N	\N	\N	OS_CANCELLED	ChecklistExecution	DATA	{"ownerEmail": "alex@brpark.com", "executionId": "cmnfe0rkj00512jj0gf5x8pne", "previousStatus": "PENDING"}	\N	2026-04-01 03:00:02.014
cmng2319y0001w00tmjl96cz0	cmn6hij2x0001j5dqofhbi9sd	cmn6hij3j0003j5dqqixl4ge1	\N	USER_LOGIN	alex@brspark.com	AUTH	\N	\N	2026-04-01 13:02:43.51
cmng23gxh000jw00tmpvecey0	\N	\N	cmn3xhvkq0000dajk4h6w2ytx	LOGIN	Admin Console	AUTH	\N	\N	2026-04-01 13:03:03.797
cmng2wr0o000blgofvjlb8h7e	\N	\N	cmn3xhvkq0000dajk4h6w2ytx	LOGIN	Admin Console	AUTH	\N	\N	2026-04-01 13:25:49.896
cmng4ygli000iz0j774fy8fel	\N	\N	cmn3xhvkq0000dajk4h6w2ytx	LOGIN	Admin Console	AUTH	\N	\N	2026-04-01 14:23:08.923
cmng4yvp0000kz0j7k199bm5q	\N	\N	cmn3xhvkq0000dajk4h6w2ytx	LOGIN	Admin Console	AUTH	\N	\N	2026-04-01 14:23:28.5
cmngf0dsd005crcies3tkup1v	\N	\N	\N	SYNC_OS_COMPLETED	ChecklistExecution	DATA	{"hasGps": false, "ownerEmail": "alex@brspark.com", "templateId": "chk_mnen95p1d55", "executionId": "cmngec9yb004rrcieg5ncha6o"}	\N	2026-04-01 19:04:34.765
cmnghan8w00015gk6pvtn0lht	\N	\N	cmn3xhvkq0000dajk4h6w2ytx	LOGIN	Admin Console	AUTH	\N	\N	2026-04-01 20:08:32.816
cmngkdn8500055gk6622pucj4	cmn6hij2x0001j5dqofhbi9sd	cmn6hij3j0003j5dqqixl4ge1	\N	USER_LOGIN	alex@brspark.com	AUTH	\N	\N	2026-04-01 21:34:51.604
cmngkgeo900085gk6avlr9uuz	\N	\N	\N	SYNC_OS_COMPLETED	ChecklistExecution	DATA	{"hasGps": false, "ownerEmail": "alex@brspark.com", "templateId": "chk_mngkermg", "executionId": "cmngkfnwf00075gk6atzq5j9u"}	\N	2026-04-01 21:37:00.49
cmngknnqr000v5gk6kpo9a8sx	\N	\N	\N	SYNC_OS_COMPLETED	ChecklistExecution	DATA	{"hasGps": false, "ownerEmail": "alex@brspark.com", "templateId": "chk_mngkermg", "executionId": "cmngkmiln000u5gk6a7qtr2jt"}	\N	2026-04-01 21:42:38.835
cmngkny8q000y5gk6c4k02vb6	\N	\N	\N	SYNC_OS_COMPLETED	ChecklistExecution	DATA	{"hasGps": false, "ownerEmail": "unknown@empresa.com", "templateId": "chk_mngeayfc", "executionId": "cmngkny8k000x5gk69yhpevul"}	\N	2026-04-01 21:42:52.442
cmngko31300115gk6nve95r0y	\N	\N	\N	SYNC_OS_COMPLETED	ChecklistExecution	DATA	{"hasGps": false, "ownerEmail": "unknown@empresa.com", "templateId": "chk_mngeayfc", "executionId": "cmngko31100105gk6415hhgot"}	\N	2026-04-01 21:42:58.647
cmngkqp8f00145gk6191zgt9r	\N	\N	\N	SYNC_OS_COMPLETED	ChecklistExecution	DATA	{"hasGps": false, "ownerEmail": "alex@brspark.com", "templateId": "chk_mngkermg", "executionId": "cmngkpafr00135gk6wnptki74"}	\N	2026-04-01 21:45:00.735
cmngksktk001e5gk62jjlmpve	\N	\N	\N	SYNC_OS_COMPLETED	ChecklistExecution	DATA	{"hasGps": false, "ownerEmail": "unknown@empresa.com", "templateId": "chk_mngkermg", "executionId": "cmngkskre001d5gk6f26zbwv8"}	\N	2026-04-01 21:46:28.329
cmngkspl3001h5gk6pcg17xed	\N	\N	\N	SYNC_OS_COMPLETED	ChecklistExecution	DATA	{"hasGps": false, "ownerEmail": "unknown@empresa.com", "templateId": "chk_mngkermg", "executionId": "cmngkspkn001g5gk67j3m8v4y"}	\N	2026-04-01 21:46:34.504
cmngkv6bl001t5gk6u4rz4mdd	\N	\N	cmn3xhvkq0000dajk4h6w2ytx	LOGIN	Admin Console	AUTH	\N	\N	2026-04-01 21:48:29.505
cmngoni7e004r5gk6b7p9ssrx	\N	\N	\N	SYNC_OS_COMPLETED	ChecklistExecution	DATA	{"hasGps": false, "ownerEmail": "alex@brspark.com", "templateId": "chk_mngeayfc", "executionId": "cmnghkvus00035gk6o1gpbwu4"}	\N	2026-04-01 23:34:30.122
cmngonwu7004s5gk6l3znagmj	\N	\N	\N	SYNC_OS_COMPLETED	ChecklistExecution	DATA	{"hasGps": false, "ownerEmail": "alex@brspark.com", "templateId": "chk_mnen95p1d55", "executionId": "cmng4w2zz000bz0j797zohnli"}	\N	2026-04-01 23:34:49.088
cmngoo3ta004t5gk6n1jr0ipa	\N	\N	\N	SYNC_OS_COMPLETED	ChecklistExecution	DATA	{"hasGps": false, "ownerEmail": "alex@brspark.com", "templateId": "chk_mnen95p1d55", "executionId": "cmnfe17d1005d2jj03wpq6n76"}	\N	2026-04-01 23:34:58.127
cmngoploi00515gk6jt5k56i3	\N	\N	\N	SYNC_OS_COMPLETED	ChecklistExecution	DATA	{"hasGps": false, "ownerEmail": "alex@brspark.com", "templateId": "chk_mngkermg", "executionId": "cmngkrsv400165gk6o4zger3j"}	\N	2026-04-01 23:36:07.938
cmngoqutu005c5gk6t8gwdgvu	\N	\N	\N	SYNC_OS_COMPLETED	ChecklistExecution	DATA	{"hasGps": false, "ownerEmail": "alex@brspark.com", "templateId": "chk_mngkermg", "executionId": "cmngopj6400505gk6wobkw5wa"}	\N	2026-04-01 23:37:06.45
cmngpkddq001lfsufcgc2a56p	\N	\N	\N	SYNC_OS_COMPLETED	ChecklistExecution	DATA	{"hasGps": false, "ownerEmail": "alex@brspark.com", "templateId": "chk_mngkermg", "executionId": "cmngowgfk0006fsuf9izpfj4k"}	\N	2026-04-02 00:00:03.518
cmngtv1ss00007y15tg1ivmo3	\N	\N	\N	SYNC_OS_COMPLETED	ChecklistExecution	DATA	{"hasGps": false, "ownerEmail": "alex@brspark.com", "templateId": "chk_mngkermg", "executionId": "cmngpvvmj000qs92habgi5b68"}	\N	2026-04-02 02:00:20.188
cmnguu4o3001w7y15scdxlp8z	\N	\N	\N	SYNC_OS_COMPLETED	ChecklistExecution	DATA	{"hasGps": false, "ownerEmail": "alex@brspark.com", "templateId": "chk_mngkermg", "executionId": "cmngu13j100117y15izmlasaw"}	\N	2026-04-02 02:27:36.867
cmngvhpcw003p7y154pfkqkp1	\N	\N	\N	SYNC_OS_COMPLETED	ChecklistExecution	DATA	{"hasGps": false, "ownerEmail": "alex@brspark.com", "templateId": "chk_mngkermg", "executionId": "cmnguurlj00237y151e1oi50r"}	\N	2026-04-02 02:45:56.768
cmngvon65003v7y157tgoebsw	\N	\N	\N	SYNC_OS_COMPLETED	ChecklistExecution	DATA	{"hasGps": false, "ownerEmail": "alex@brspark.com", "templateId": "chk_mngkermg", "executionId": "cmngvhh26003o7y156rnxr840"}	\N	2026-04-02 02:51:20.525
cmngvvz64004w7y15tjamdtxs	\N	\N	\N	SYNC_OS_COMPLETED	ChecklistExecution	DATA	{"hasGps": false, "ownerEmail": "alex@brspark.com", "templateId": "chk_mngkermg", "executionId": "cmngvpci8003x7y15c7574wv8"}	\N	2026-04-02 02:57:02.668
cmngw38e600527y15r78btysf	\N	\N	\N	SYNC_OS_COMPLETED	ChecklistExecution	DATA	{"hasGps": false, "ownerEmail": "alex@brspark.com", "templateId": "chk_mngkermg", "executionId": "cmngvvusi004v7y15iaa2csc1"}	\N	2026-04-02 03:02:41.213
cmngw637s005n7y15f93b0snr	\N	\N	\N	SYNC_OS_COMPLETED	ChecklistExecution	DATA	{"hasGps": false, "ownerEmail": "alex@brspark.com", "templateId": "chk_mngkermg", "executionId": "cmngvuqu5004t7y15hm81yb36"}	\N	2026-04-02 03:04:54.472
cmngx5qg9006f7y15ygbmqujb	\N	\N	\N	SYNC_OS_COMPLETED	ChecklistExecution	DATA	{"hasGps": false, "ownerEmail": "alex@brspark.com", "templateId": "chk_mngkermg", "executionId": "cmngw885r005p7y155oxu7qiw"}	\N	2026-04-02 03:32:37.545
\.


--
-- Data for Name: ChatContact; Type: TABLE DATA; Schema: public; Owner: alex
--

COPY public."ChatContact" (id, "requesterId", "addresseeId", status, "createdAt", "updatedAt") FROM stdin;
cmn7uspoz0010hxk5ret2qn3w	alex@brspark.com	luigi@lansolver.com	ACCEPTED	2026-03-26 19:16:35.219	2026-03-26 21:21:12.793
cmn7yir8l000k7d10ydexqhjp	luigi@lansolver.com	alex@brspark.com	ACCEPTED	2026-03-26 21:00:49.125	2026-03-26 21:21:12.806
\.


--
-- Data for Name: ChatMessage; Type: TABLE DATA; Schema: public; Owner: alex
--

COPY public."ChatMessage" (id, "roomId", "senderId", "senderName", type, content, "mediaUrl", "createdAt") FROM stdin;
cmn7z380c0008v0jj7l83mq6b	cmn7z31xm0004v0jjgs3ohtfa	alex@brspark.com	Usuário	text	Oi	\N	2026-03-26 21:16:43.98
cmn7z545e0009yc9q1e1ihlsr	cmn7z31xm0004v0jjgs3ohtfa	luigi@lansolver.com	Usuário	text	Belwza	\N	2026-03-26 21:18:12.29
cmn7z7rmy0001jwqb94zj6qi6	cmn7z31xm0004v0jjgs3ohtfa	alex@brspark.com	Usuário	text	Oi	\N	2026-03-26 21:20:16.042
cmn7za5mb0005146ysk7v57a8	cmn7z31xm0004v0jjgs3ohtfa	alex@brspark.com	Usuário	text	Oi	\N	2026-03-26 21:22:07.475
cmn7za8pd0007146ygr7w30up	cmn7z31xm0004v0jjgs3ohtfa	alex@brspark.com	Usuário	text	Tedte	\N	2026-03-26 21:22:11.474
cmn7zflpj000hacyvlvapu2h2	cmn7z31xm0004v0jjgs3ohtfa	alex@brspark.com	Usuário	text	Oi	\N	2026-03-26 21:26:21.607
cmn7zxau1000110hdw0joxm32	cmn7z31xm0004v0jjgs3ohtfa	luigi@lansolver.com	Usuário	audio	\N	file:///data/user/0/host.exp.exponent/cache/Audio/recording-51172591-836e-4192-813e-6464b54ec863.m4a	2026-03-26 21:40:07.32
cmn80ydmz000plh9d9zkyvzfh	cmn7z31xm0004v0jjgs3ohtfa	alex@brspark.com	Usuário	text	Oi	\N	2026-03-26 22:08:57.227
cmn80yk6v000rlh9d6li5uxuz	cmn7z31xm0004v0jjgs3ohtfa	alex@brspark.com	Usuário	text	Teste	\N	2026-03-26 22:09:05.72
cmn80ylni000tlh9dmrpqe5b1	cmn7z31xm0004v0jjgs3ohtfa	alex@brspark.com	Usuário	text	Teste	\N	2026-03-26 22:09:07.614
cmn81tcv80009hq7bnfdeg0e3	cmn7z31xm0004v0jjgs3ohtfa	alex@brspark.com	Usuário	text	Oi	\N	2026-03-26 22:33:02.563
cmn81term000bhq7bacwl1i55	cmn7z31xm0004v0jjgs3ohtfa	alex@brspark.com	Usuário	text	Teste	\N	2026-03-26 22:33:05.027
cmn81tfiy000dhq7bvi9npwnf	cmn7z31xm0004v0jjgs3ohtfa	alex@brspark.com	Usuário	text	Oi	\N	2026-03-26 22:33:06.011
cmn81tgzc000fhq7blkcnjd8d	cmn7z31xm0004v0jjgs3ohtfa	alex@brspark.com	Usuário	text	Oi	\N	2026-03-26 22:33:07.896
cmn81tifz000hhq7bw9mukg4y	cmn7z31xm0004v0jjgs3ohtfa	alex@brspark.com	Usuário	text	Oi	\N	2026-03-26 22:33:09.791
cmn81tj9k000jhq7bxo6x3cpe	cmn7z31xm0004v0jjgs3ohtfa	alex@brspark.com	Usuário	text	Oi	\N	2026-03-26 22:33:10.856
cmn81w9kz000thq7bvrxkfwtj	cmn7z31xm0004v0jjgs3ohtfa	alex@brspark.com	Usuário	text	Oi	\N	2026-03-26 22:35:18.276
cmn81wb9e000vhq7brq0mrjij	cmn7z31xm0004v0jjgs3ohtfa	alex@brspark.com	Usuário	text	Alou	\N	2026-03-26 22:35:20.45
cmn81wdai000xhq7bjq99mypc	cmn7z31xm0004v0jjgs3ohtfa	alex@brspark.com	Usuário	text	Ei	\N	2026-03-26 22:35:23.082
cmn82ulmb002jhq7bsfxr3c6r	cmn7z31xm0004v0jjgs3ohtfa	alex@brspark.com	Usuário	text	Oi	\N	2026-03-26 23:02:00.179
cmn86j0km0057hq7bs0ps09qc	cmn7z31xm0004v0jjgs3ohtfa	alex@brspark.com	Usuário	text	Oi	\N	2026-03-27 00:44:58.15
cmn86j27r0059hq7blqzluf7y	cmn7z31xm0004v0jjgs3ohtfa	alex@brspark.com	Usuário	text	Oi	\N	2026-03-27 00:45:00.279
cmn86j37b005bhq7b4q0k01z1	cmn7z31xm0004v0jjgs3ohtfa	alex@brspark.com	Usuário	text	Oi	\N	2026-03-27 00:45:01.559
cmn86j46n005dhq7be564ywif	cmn7z31xm0004v0jjgs3ohtfa	alex@brspark.com	Usuário	text	Oi	\N	2026-03-27 00:45:02.832
cmn86j5aw005fhq7b4q2t7cp6	cmn7z31xm0004v0jjgs3ohtfa	alex@brspark.com	Usuário	text	Oi	\N	2026-03-27 00:45:04.28
cmn86j6f5005hhq7bps3eod8t	cmn7z31xm0004v0jjgs3ohtfa	alex@brspark.com	Usuário	text	Oi	\N	2026-03-27 00:45:05.73
cmn86j7j5005jhq7bvc57n8ex	cmn7z31xm0004v0jjgs3ohtfa	alex@brspark.com	Usuário	text	Oi	\N	2026-03-27 00:45:07.168
cmn86j952005lhq7byj4o37sd	cmn7z31xm0004v0jjgs3ohtfa	alex@brspark.com	Usuário	text	Hughg	\N	2026-03-27 00:45:09.254
cmn86jvyu005vhq7bogp4lmf5	cmn7z31xm0004v0jjgs3ohtfa	alex@brspark.com	Usuário	text	Teste	\N	2026-03-27 00:45:38.838
cmn86jxjp005xhq7bmh54fen0	cmn7z31xm0004v0jjgs3ohtfa	alex@brspark.com	Usuário	text	Teste	\N	2026-03-27 00:45:40.886
cmn86jynz005zhq7bddohofyn	cmn7z31xm0004v0jjgs3ohtfa	alex@brspark.com	Usuário	text	1	\N	2026-03-27 00:45:42.335
cmn86jzm90061hq7bdas9mcpb	cmn7z31xm0004v0jjgs3ohtfa	alex@brspark.com	Usuário	text	2	\N	2026-03-27 00:45:43.569
cmn86k0nl0063hq7bnzdowl2d	cmn7z31xm0004v0jjgs3ohtfa	alex@brspark.com	Usuário	text	3	\N	2026-03-27 00:45:44.913
cmn86k1j50065hq7b5gagjf14	cmn7z31xm0004v0jjgs3ohtfa	alex@brspark.com	Usuário	text	4	\N	2026-03-27 00:45:46.049
cmn86k2cv0067hq7b0vx941m7	cmn7z31xm0004v0jjgs3ohtfa	alex@brspark.com	Usuário	text	5	\N	2026-03-27 00:45:47.119
cmn86l65q006phq7bo211w33m	cmn7z31xm0004v0jjgs3ohtfa	alex@brspark.com	Usuário	text	988	\N	2026-03-27 00:46:38.702
cmn86lhwy006rhq7beoj1wdo2	cmn7z31xm0004v0jjgs3ohtfa	luigi@lansolver.com	Usuário	text	Oiii	\N	2026-03-27 00:46:53.938
cmn86lnh7006thq7bvxazoq10	cmn7z31xm0004v0jjgs3ohtfa	alex@brspark.com	Usuário	text	Legal	\N	2026-03-27 00:47:01.148
cmn86lsbs006vhq7btgb69q5m	cmn7z31xm0004v0jjgs3ohtfa	luigi@lansolver.com	Usuário	text	Ai sim	\N	2026-03-27 00:47:07.432
cmn87hq500005lp8bqa912r1i	cmn7z31xm0004v0jjgs3ohtfa	alex@brspark.com	Usuário	text	Teste	\N	2026-03-27 01:11:57.589
cmnakolrd0011cjidmxjd038d	cmn7z31xm0004v0jjgs3ohtfa	luigi@lansolver.com	Usuário	text	Oi	\N	2026-03-28 16:56:45.866
cmnakp6f60017cjid6lwbsi3l	cmn7z31xm0004v0jjgs3ohtfa	alex@brspark.com	Usuário	text	Gala so	\N	2026-03-28 16:57:12.642
cmnakpgdu0019cjid1lvl1fjs	cmn7z31xm0004v0jjgs3ohtfa	alex@brspark.com	Usuário	text	Testa ai	\N	2026-03-28 16:57:25.555
cmnakpuj1001bcjidaa4pgaew	cmn7z31xm0004v0jjgs3ohtfa	luigi@lansolver.com	Usuário	text	1	\N	2026-03-28 16:57:43.885
cmnal7lac002bcjidw5i41bu4	cmn7z31xm0004v0jjgs3ohtfa	alex@brspark.com	Usuário	image	\N	file:///Users/alex/Library/Developer/CoreSimulator/Devices/6FA71D68-E528-4A18-9CB2-1B903E430B52/data/Containers/Data/Application/BB2B08B1-6919-4580-8D84-C5DEE3033C44/Library/Caches/ImagePicker/652B70DC-3558-4769-83F0-51990AAC91F5.jpg	2026-03-28 17:11:31.716
cmnalehia0033cjid96pip62e	cmn7z31xm0004v0jjgs3ohtfa	luigi@lansolver.com	Usuário	text	123	\N	2026-03-28 17:16:53.411
cmnalf3840035cjid2rwu2j3f	cmn7z31xm0004v0jjgs3ohtfa	alex@brspark.com	Usuário	image	\N	file:///Users/alex/Library/Developer/CoreSimulator/Devices/6FA71D68-E528-4A18-9CB2-1B903E430B52/data/Containers/Data/Application/BB2B08B1-6919-4580-8D84-C5DEE3033C44/Library/Caches/ImagePicker/171781B4-D684-4088-97BA-AE9B917A3453.jpg	2026-03-28 17:17:21.556
cmnalicy10037cjidtub0owjm	cmn7z31xm0004v0jjgs3ohtfa	alex@brspark.com	Usuário	image	\N	http://192.168.15.73:3001/uploads/storage/chat/1774718390545_5p86quqfirj.jpeg	2026-03-28 17:19:54.121
\.


--
-- Data for Name: ChatRoom; Type: TABLE DATA; Schema: public; Owner: alex
--

COPY public."ChatRoom" (id, name, description, "avatarColor", "isGroup", "creatorId", "createdAt", "updatedAt") FROM stdin;
cmn7z31xm0004v0jjgs3ohtfa	\N	\N	#2563EB	f	\N	2026-03-26 21:16:36.106	2026-03-28 17:19:54.126
\.


--
-- Data for Name: ChatRoomMember; Type: TABLE DATA; Schema: public; Owner: alex
--

COPY public."ChatRoomMember" (id, "roomId", "userId", role, "joinedAt", "lastReadAt") FROM stdin;
cmn7z31xm0005v0jju6o3czeq	cmn7z31xm0004v0jjgs3ohtfa	luigi@lansolver.com	ADMIN	2026-03-26 21:16:36.106	2026-03-28 17:21:15.52
cmn7z31xm0006v0jjsb7uokdo	cmn7z31xm0004v0jjgs3ohtfa	alex@brspark.com	ADMIN	2026-03-26 21:16:36.106	2026-03-28 23:11:13.478
\.


--
-- Data for Name: ChecklistExecution; Type: TABLE DATA; Schema: public; Owner: alex
--

COPY public."ChecklistExecution" (id, "templateId", "ownerEmail", "assetId", status, responses, metadata, "gpsLocation", "startedAt", "completedAt", "syncedAt", "createdAt", "locationAddress", "locationLat", "locationLng", "locationPolygon", "locationRadius", "locationZoneType") FROM stdin;
cmnemut6l0031mtd42528tc2a	chk_mne1dhzv	alex@brspark.com	\N	COMPLETED	{"field_3999": "file://mock_path/arquivo.ext", "field_35561": "file://mock_path/arquivo.ext", "field_38889": "{\\"action\\":\\"SAIDA\\",\\"timestamp\\":\\"2026-03-31T13:13:25.328Z\\",\\"coordinates\\":{\\"lat\\":37.33756603,\\"lng\\":-122.04120235},\\"address\\":\\"Homestead Rd, 695 - Santa Clara, Cupertino - CA\\"}", "field_69277": "{\\"action\\":\\"CHEGADA\\",\\"timestamp\\":\\"2026-03-31T13:13:27.425Z\\",\\"coordinates\\":{\\"lat\\":37.33756603,\\"lng\\":-122.04120235},\\"address\\":\\"Homestead Rd, 695 - Santa Clara, Cupertino - CA\\"}", "field_78600": "file://mock_path/arquivo.ext"}	{"icon": "", "refId": "chk_mne1dhzv", "title": "231", "acceptedAt": "2026-03-31T13:08:52.531Z", "appVersion": "1.0", "receivedAt": "2026-03-31T13:08:43.877Z", "description": "Enviado de forma manual para vistoria.", "devicePlatform": "AppMovel", "durationSeconds": 41}	null	2026-03-31 13:13:16.869	2026-03-31 13:13:58.055	2026-03-31 13:13:58.356	2026-03-31 13:08:39.357	\N	\N	\N	\N	\N	\N
cmnemvwzc003dmtd4gh1605ho	chk_mne1dhzv	alex@brspark.com	\N	COMPLETED	{"field_38889": "{\\"action\\":\\"SAIDA\\",\\"timestamp\\":\\"2026-03-31T13:16:52.267Z\\",\\"coordinates\\":{\\"lat\\":37.33194773,\\"lng\\":-122.03700933},\\"address\\":\\"Valley Green Dr, 20800 - Santa Clara, Cupertino - CA\\"}", "field_69277": "{\\"action\\":\\"CHEGADA\\",\\"timestamp\\":\\"2026-03-31T13:16:54.297Z\\",\\"coordinates\\":{\\"lat\\":37.33194907,\\"lng\\":-122.03695813},\\"address\\":\\"Valley Green Dr, 20800 - Santa Clara, Cupertino - CA\\"}", "field_71925": "SIG_V1|M225.33333333333331,149.66666793823242 L107.66666666666666,172.00000127156574 L57.33333333333333,165.33333460489905 L21.666666666666664,150.00000127156574 L0,131.00000127156574 L-8.666666666666668,103.00000127156574 L-4,64.00000127156574 L20,23.666667938232422 L54.66666666666666,-1.6666653951009494 L125.33333333333331,-9.333332061767578 L184.33333333333331,35.000001271565736 L195.66666666666666,57.66666793823242 L199.33333333333331,74.33333460489905 L183.33333333333331,103.66666793823242 L149.66666666666666,117.66666793823242 L106.66666666666666,125.33333460489905 L69.66666666666666,127.00000127156574 L46.66666666666666,126.66666793823242 L46.66666666666666,125.00000127156574 L48.66666666666666,114.00000127156574 L221.66666666666666,115.66666793823242 L229,128.33333460489905 L230.33333333333331,128.33333460489905 L231,126.66666793823242 L234,122.66666793823242 L237,120.00000127156574 L237.33333333333331,119.33333460489905 L235,126.66666793823242 L227,137.00000127156574 L214.33333333333331,159.66666793823242 L213,181.66666793823242 L239.33333333333331,254.66666793823242 L239.33333333333331,255.00000127156568 L236,256.0000012715657 L208.33333333333331,256.0000012715657 L173,254.66666793823242 L137.66666666666666,245.33333460489905 L123,238.33333460489905 L121.33333333333331,235.00000127156568 L132,226.33333460489905 L136.33333333333331,224.33333460489905 L149.33333333333331,226.66666793823242 L160.66666666666666,235.00000127156568 L171.66666666666666,239.33333460489905 L197.33333333333331,235.66666793823242 L201.66666666666666,231.66666793823242 L202.33333333333331,220.33333460489905 L201.33333333333331,219.66666793823242 L201.33333333333331,220.66666793823242 L202,224.00000127156568 L202.66666666666666,224.66666793823242 L209,224.33333460489905 L212.66666666666666,222.66666793823242 L212.66666666666666,222.33333460489905 L212.66666666666666,221.66666793823242 L212,221.33333460489905|M264.3333333333333,209.00000127156574 L265.3333333333333,209.00000127156574 L265.3333333333333,200.00000127156574 L265.3333333333333,185.33333460489905 L266.3333333333333,176.33333460489905 L269,161.66666793823242 L275.66666666666663,141.33333460489905 L299,103.00000127156574 L313,90.00000127156574 L313.66666666666663,89.33333460489905 L314,88.66666793823242 L314.66666666666663,84.66666793823242 L313.3333333333333,75.00000127156574 L312.3333333333333,73.33333460489905 L309,73.00000127156574 L296,73.00000127156574 L285,74.00000127156574 L274.3333333333333,76.00000127156574 L267,78.00000127156574 L263.66666666666663,79.66666793823242 L248.66666666666663,88.33333460489905 L243.33333333333331,90.66666793823242 L219.66666666666666,100.66666793823242 L215.33333333333331,104.33333460489905 L210.33333333333331,112.33333460489905 L207.66666666666666,118.66666793823242 L204.33333333333331,129.66666793823242 L203.33333333333331,143.66666793823242 L203.33333333333331,147.33333460489905 L206.66666666666666,160.00000127156574 L209.33333333333331,162.66666793823242 L215.33333333333331,158.00000127156574 L225.33333333333331,147.33333460489905 L232.33333333333331,134.33333460489905 L238.66666666666663,120.00000127156574 L238.66666666666663,118.00000127156574 L238.66666666666663,117.00000127156574 L235,115.33333460489905 L232.66666666666666,113.33333460489905 L231,112.33333460489905 L230.33333333333331,112.33333460489905|M249,162.00000127156574 L248,160.33333460489905 L247.66666666666663,159.66666793823242 L246.33333333333331,158.00000127156574 L246,157.66666793823242 L245.33333333333331,156.66666793823242 L244.33333333333331,155.33333460489905 L244,154.66666793823242 L246.66666666666663,162.00000127156574 L252,178.33333460489905 L254.33333333333331,198.33333460489905 L254.33333333333331,200.66666793823242 L254.33333333333331,202.33333460489905 L254,203.00000127156574 L253.33333333333331,203.33333460489905|M284,94.33333460489905 L285.3333333333333,96.33333460489905 L285.66666666666663,96.66666793823242 L287.66666666666663,96.66666793823242 L290.3333333333333,95.33333460489905 L291.66666666666663,93.66666793823242 L292.3333333333333,92.33333460489905 L292.66666666666663,91.33333460489905 L292.66666666666663,90.33333460489905 L292.66666666666663,90.00000127156574 L292,90.00000127156574 L291,90.33333460489905 L289,92.66666793823242 L287.3333333333333,95.66666793823242 L286.66666666666663,96.33333460489905|M265.3333333333333,125.33333460489905 L267,128.00000127156574 L267.3333333333333,128.66666793823242 L269,130.33333460489905 L271,131.33333460489905 L272.66666666666663,131.66666793823242 L273,131.66666793823242 L274,131.00000127156574|M253,106.00000127156574 L251.66666666666663,108.33333460489905 L250.33333333333331,110.66666793823242 L249,111.66666793823242 L248,113.33333460489905 L246.33333333333331,114.00000127156574 L246.33333333333331,114.33333460489905|M260.3333333333333,101.00000127156574 L263,103.33333460489905 L270,107.66666793823242 L276.3333333333333,112.00000127156574 L277.66666666666663,112.33333460489905 L278,112.66666793823242 L278,113.33333460489905 L278.3333333333333,113.66666793823242 L279.3333333333333,114.66666793823242"}	{"icon": "", "refId": "chk_mne1dhzv", "title": "231222", "acceptedAt": "2026-03-31T13:09:39.350Z", "appVersion": "1.0", "receivedAt": "2026-03-31T13:09:34.272Z", "description": "Enviado de forma manual para vistoria.", "devicePlatform": "AppMovel", "durationSeconds": 22}	null	2026-03-31 13:16:48.638	2026-03-31 13:17:10.659	2026-03-31 13:17:10.865	2026-03-31 13:09:30.936	\N	\N	\N	\N	\N	\N
cmndvqvv8004dkgy8sa3mwan7	chk_mnb61qhk	alex@brspark.com	\N	COMPLETED	{"field_36827": "{\\"action\\":\\"SAIDA\\",\\"timestamp\\":\\"2026-03-31T02:01:41.037Z\\",\\"coordinates\\":{\\"lat\\":37.33683958,\\"lng\\":-122.04161449},\\"address\\":\\"Homestead Rd, 21020 - Santa Clara, Cupertino - CA\\"}", "field_77672": "{\\"action\\":\\"CHEGADA\\",\\"timestamp\\":\\"2026-03-31T02:01:42.633Z\\",\\"coordinates\\":{\\"lat\\":37.33676622,\\"lng\\":-122.04160728},\\"address\\":\\"Homestead Rd, 21020 - Santa Clara, Cupertino - CA\\"}", "field_85539": ""}	{"icon": "build-outline", "refId": "chk_mnb61qhk", "title": "NOVO CHECKLIST", "acceptedAt": "2026-03-31T02:01:39.069Z", "appVersion": "1.0", "receivedAt": "2026-03-31T00:43:17.692Z", "description": "Tarefa de rotina despachada.", "devicePlatform": "AppMovel", "durationSeconds": 8}	null	2026-03-31 02:01:39.113	2026-03-31 02:01:47.618	2026-03-31 02:01:47.691	2026-03-31 00:29:46.578	\N	\N	\N	\N	\N	\N
cmnf5xpn500eaibkefxnwiipi	chk_mncnb2te	alex@lansolver.com	\N	CANCELLED	null	{"icon": "", "refId": "chk_mncnb2te", "title": "NOVO CHECKLISTee", "description": "Enviado de forma manual para vistoria."}	\N	\N	\N	\N	2026-03-31 22:02:47.441	\N	\N	\N	\N	\N	\N
cmncmuh1e000bgstiakvatblr	\N	tecnico@empresa.com	\N	CANCELLED	null	{"icon": "clipboard", "refId": "test-form-123", "title": "Teste OS", "description": "Ordem de Teste"}	\N	\N	\N	\N	2026-03-30 03:32:51.266	\N	\N	\N	\N	\N	\N
cmnfe0rkj00512jj0gf5x8pne	chk_mnen95p1d55	alex@brpark.com	\N	CANCELLED	null	{"icon": "", "refId": "chk_mnen95p1d55", "title": "231222a (Cópia)", "description": "Enviado de forma manual para vistoria."}	\N	\N	\N	\N	2026-04-01 01:49:06.835	\N	\N	\N	\N	\N	\N
cmngkny8k000x5gk69yhpevul	chk_mngeayfc	unknown@empresa.com	\N	COMPLETED	{"__section_end_page_1": "2026-04-01T21:42:52.224Z"}	{"appVersion": "1.0", "devicePlatform": "AppMovel", "durationSeconds": 1}	null	2026-04-01 21:42:51.082	2026-04-01 21:42:52.224	2026-04-01 21:42:52.435	2026-04-01 21:42:52.436	\N	\N	\N	\N	\N	\N
cmnd9ct7l0001h3vyuhei9gzs	chk_mnb61qhk	alex@brspark.com	\N	COMPLETED	{"field_3643": "23/10/1966", "field_30724": "343244444", "field_36827": "{\\"action\\":\\"SAIDA\\",\\"timestamp\\":\\"2026-03-30T15:23:22.750Z\\",\\"coordinates\\":{\\"lat\\":37.33233141,\\"lng\\":-122.0312186}}", "field_61552": 5, "field_77672": "{\\"action\\":\\"CHEGADA\\",\\"timestamp\\":\\"2026-03-30T15:23:24.669Z\\",\\"coordinates\\":{\\"lat\\":37.33233141,\\"lng\\":-122.0312186}}", "field_85539": "", "field_99284": "SIG_V1|M83.33333333333333,228.66666793823242 L90.66666666666666,199.00000127156574 L96.66666666666666,165.66666793823242 L102.33333333333333,135.66666793823242 L106,125.66666793823242 L106.66666666666666,126.66666793823242 L113.66666666666666,139.33333460489905 L122.66666666666666,156.33333460489905 L153.66666666666666,196.00000127156574 L158.33333333333331,187.33333460489905 L168.33333333333331,163.33333460489905 L185.33333333333331,129.33333460489905 L203.66666666666666,97.00000127156574 L217,80.66666793823242 L217.33333333333331,80.66666793823242 L221,88.33333460489905 L227.33333333333331,103.00000127156574 L240.33333333333331,129.33333460489905 L262.66666666666663,169.66666793823242 L277,191.00000127156574 L277.66666666666663,191.33333460489905"}	{"appVersion": "1.0", "devicePlatform": "AppMovel", "durationSeconds": 28}	null	2026-03-30 15:23:19.68	2026-03-30 15:23:47.824	2026-03-30 15:23:48.316	2026-03-30 14:02:58.401	\N	\N	\N	\N	\N	\N
cmnd9aekq0006jyvrk8rxw88o	chk_mnb61qhk	alex@brspark.com	\N	COMPLETED	{"field_3643": "333333", "field_30615": "file://mock_path/arquivo.ext", "field_30724": "333", "field_36827": "{\\"action\\":\\"SAIDA\\",\\"timestamp\\":\\"2026-03-30T17:35:14.370Z\\",\\"coordinates\\":{\\"lat\\":37.33233141,\\"lng\\":-122.0312186}}", "field_61552": 2, "field_77672": "{\\"action\\":\\"CHEGADA\\",\\"timestamp\\":\\"2026-03-30T17:35:16.027Z\\",\\"coordinates\\":{\\"lat\\":37.33233141,\\"lng\\":-122.0312186}}", "field_78643": "Opção 1", "field_85539": "", "field_99284": "SIG_V1|M30.666666666666664,130.66666793823242 L36.666666666666664,146.66666793823242 L53.33333333333333,177.00000127156574 L62,185.66666793823242 L69,189.00000127156574 L88.66666666666666,192.66666793823242 L129.33333333333331,192.66666793823242 L153.33333333333331,185.66666793823242 L174,174.33333460489905 L188.33333333333331,161.33333460489905 L195.66666666666666,149.66666793823242 L199,127.66666793823242 L199,109.33333460489905 L199,91.00000127156574 L197,79.33333460489905 L196,77.00000127156574 L195,75.33333460489905 L189.66666666666666,67.00000127156574 L183.66666666666666,63.33333460489905 L160.33333333333331,65.66666793823242 L156,69.00000127156574 L146.33333333333331,76.66666793823242 L142,83.00000127156574 L139,86.33333460489905 L137.66666666666666,88.66666793823242 L134,96.00000127156574 L132.33333333333331,103.00000127156574 L124.33333333333331,126.66666793823242 L116,149.33333460489905 L116,151.33333460489905 L116,148.00000127156574 L126.66666666666666,132.33333460489905 L140,123.66666793823242 L162,116.33333460489905 L184,113.66666793823242 L205.33333333333331,119.00000127156574 L213.33333333333331,129.33333460489905 L218.33333333333331,137.33333460489905 L221,135.66666793823242 L225.33333333333331,129.66666793823242 L228.33333333333331,127.33333460489905 L240.66666666666663,126.33333460489905 L247.66666666666663,129.33333460489905 L256.66666666666663,133.00000127156574 L262.3333333333333,134.33333460489905 L267.3333333333333,134.33333460489905 L272.66666666666663,134.33333460489905 L281.66666666666663,134.33333460489905 L288.66666666666663,133.66666793823242 L296,132.66666793823242 L301.3333333333333,130.66666793823242 L313.66666666666663,121.00000127156574 L333.3333333333333,29.666667938232422 L333,0.000001271565736260527 L321.66666666666663,5.000001271565736 L315.66666666666663,12.000001271565736 L310.3333333333333,23.000001271565736 L303.66666666666663,45.000001271565736 L305.3333333333333,95.33333460489905 L317.66666666666663,132.66666793823242 L349.3333333333333,190.00000127156574 L365.3333333333333,209.33333460489905"}	{"icon": "build", "refId": "chk_mnb61qhk", "title": "NOVO CHECKLIST", "acceptedAt": "2026-03-30T17:35:10.990Z", "appVersion": "1.0", "receivedAt": "2026-03-30T17:32:32.218Z", "description": "Enviado de forma manual para vistoria.", "devicePlatform": "AppMovel", "durationSeconds": 27}	null	2026-03-30 17:35:11.114	2026-03-30 17:35:38.387	2026-03-30 17:35:40.726	2026-03-30 14:01:06.123	\N	\N	\N	\N	\N	\N
cmnd9ewri0003h3vywuahnh9e	chk_mnb61qhk	alex@brspark.com	\N	COMPLETED	{"field_36827": "{\\"action\\":\\"SAIDA\\",\\"timestamp\\":\\"2026-03-30T22:16:37.661Z\\",\\"coordinates\\":{\\"lat\\":37.33743371,\\"lng\\":-122.02322184}}", "field_77672": "{\\"action\\":\\"CHEGADA\\",\\"timestamp\\":\\"2026-03-30T22:19:06.032Z\\",\\"coordinates\\":{\\"lat\\":37.33761367,\\"lng\\":-122.0344456},\\"address\\":\\"Homestead Rd, 20589 - Santa Clara, Cupertino - CA\\"}", "field_85539": "", "field_99284": "SIG_V1|M203.33333333333331,88.66666793823242 L140.66666666666666,91.66666793823242 L126,97.33333460489905 L122.66666666666666,102.66666793823242 L123.66666666666666,106.00000127156574 L138.33333333333331,119.00000127156574 L165,133.66666793823242 L182,143.00000127156574 L218.66666666666666,169.33333460489905 L225.66666666666666,181.00000127156574 L219,195.00000127156574 L191,208.33333460489905 L161.33333333333331,212.66666793823242 L129.33333333333331,209.66666793823242 L129.33333333333331,205.33333460489905 L132.66666666666666,194.33333460489905 L139.66666666666666,187.33333460489905 L158,172.00000127156574 L183.66666666666666,151.00000127156574 L224.66666666666666,117.33333460489905 L242.66666666666663,102.33333460489905 L251,96.00000127156574 L251,95.33333460489905 L249.66666666666663,94.33333460489905 L249,93.33333460489905 L232.66666666666666,89.66666793823242 L230.33333333333331,89.66666793823242 L229.33333333333331,90.00000127156574"}	{"icon": "build", "refId": "chk_mnb61qhk", "title": "NOVO CHECKLIST", "acceptedAt": "2026-03-30T22:16:28.161Z", "appVersion": "1.0", "receivedAt": "2026-03-30T21:53:50.572Z", "description": "Enviado de forma manual para vistoria.", "devicePlatform": "AppMovel", "durationSeconds": 17}	null	2026-03-30 22:18:57.437	2026-03-30 22:19:14.947	2026-03-30 22:19:15.215	2026-03-30 14:04:36.318	\N	\N	\N	\N	\N	\N
cmnd9izxq0001his9r35u7aab	chk_mnb61qhk	alex@brspark.com	\N	SYNCED	{"field_3643": "27111973", "field_17262": "file://mock_path/arquivo.ext", "field_19829": "Tests", "field_30615": "file://mock_path/arquivo.ext", "field_30724": "11996872542", "field_36827": "{\\"action\\":\\"SAIDA\\",\\"timestamp\\":\\"2026-03-30T14:29:05.809Z\\",\\"coordinates\\":{\\"lat\\":37.33233141,\\"lng\\":-122.0312186}}", "field_56249": "332", "field_61552": 3, "field_69614": "ALEX@BRSPARK.COM", "field_77672": "{\\"action\\":\\"CHEGADA\\",\\"timestamp\\":\\"2026-03-30T14:29:07.169Z\\",\\"coordinates\\":{\\"lat\\":37.33233141,\\"lng\\":-122.0312186}}", "field_78643": "Opção 1", "field_85539": "", "field_99284": "SIG_V1|M235.33333333333331,182.66666793823242 L226.33333333333331,182.66666793823242 L217.33333333333331,181.66666793823242 L191.66666666666666,177.33333460489905 L171,175.66666793823242 L137.66666666666666,171.00000127156574 L106.33333333333333,163.33333460489905 L87.66666666666666,155.66666793823242 L81.66666666666666,151.66666793823242 L80.66666666666666,144.33333460489905 L81.66666666666666,135.33333460489905 L89.33333333333333,125.66666793823242 L99,119.00000127156574 L125,110.33333460489905 L191.66666666666666,93.66666793823242 L227,89.33333460489905 L277.3333333333333,87.66666793823242 L305,89.00000127156574 L316.66666666666663,94.33333460489905 L318,97.66666793823242 L308,118.33333460489905 L301.66666666666663,125.00000127156574 L292,134.33333460489905 L269.66666666666663,147.00000127156574 L241.66666666666663,158.66666793823242 L178.66666666666666,179.66666793823242 L167.66666666666666,184.00000127156574 L145.66666666666666,189.33333460489905 L129,192.00000127156574 L125.66666666666666,192.00000127156574 L125.33333333333331,191.66666793823242 L125.33333333333331,191.00000127156574 L125.33333333333331,188.33333460489905 L132.66666666666666,175.00000127156574 L142.33333333333331,162.66666793823242 L161.66666666666666,149.00000127156574 L196,128.66666793823242 L235.66666666666666,109.66666793823242 L251,102.00000127156574 L286.66666666666663,83.00000127156574 L299,73.66666793823242 L299.3333333333333,72.33333460489905 L298.3333333333333,72.33333460489905 L296,74.00000127156574 L289,80.00000127156574 L274,96.00000127156574 L248,122.33333460489905 L210.66666666666666,158.00000127156574 L170,194.00000127156574 L50,242.66666793823242 L41,241.66666793823242 L39,240.33333460489905 L38,236.00000127156568 L38,227.00000127156568 L40.666666666666664,222.66666793823242 L61.33333333333333,216.00000127156574 L87,216.00000127156574 L103.66666666666666,217.33333460489905 L170.66666666666666,237.33333460489905 L233.33333333333331,257.6666679382324 L239.66666666666663,257.6666679382324 L240,257.6666679382324 L240,256.33333460489905 L240,255.00000127156568"}	{"acceptedAt": "2026-03-30T17:35:34.488Z", "appVersion": "1.0", "devicePlatform": "AppMovel", "durationSeconds": 51}	null	2026-03-30 14:29:03.445	2026-03-30 14:29:55.352	2026-03-30 14:38:47.874	2026-03-30 14:07:47.05	\N	\N	\N	\N	\N	\N
cmndnfcqy004exd9lmj5nib1k	chk_mnb61qhk	alex@brspark.com	\N	COMPLETED	{"field_3643": "333", "field_30724": "e3333", "field_36827": "{\\"action\\":\\"SAIDA\\",\\"timestamp\\":\\"2026-03-30T20:37:11.454Z\\",\\"coordinates\\":{\\"lat\\":37.33233141,\\"lng\\":-122.0312186}}", "field_77672": "{\\"action\\":\\"CHEGADA\\",\\"timestamp\\":\\"2026-03-30T20:38:01.064Z\\",\\"coordinates\\":{\\"lat\\":37.33165083,\\"lng\\":-122.03029752}}", "field_85539": "", "field_99284": "SIG_V1|M224.33333333333331,138.00000127156574 L224.33333333333331,139.00000127156574 L219.33333333333331,142.33333460489905 L204.66666666666666,147.00000127156574 L186.33333333333331,151.00000127156574 L162.33333333333331,151.00000127156574 L142,151.00000127156574 L124,149.66666793823242 L113,146.33333460489905 L98.33333333333333,141.33333460489905 L95,140.66666793823242 L94,140.00000127156574 L94,139.33333460489905 L94.66666666666666,127.00000127156574 L98,122.66666793823242 L105.66666666666666,116.00000127156574 L125.66666666666666,112.66666793823242 L137,111.33333460489905 L168.33333333333331,111.33333460489905 L201.66666666666666,111.33333460489905 L229.66666666666666,111.33333460489905 L249.66666666666663,111.33333460489905 L264.3333333333333,111.33333460489905 L284.3333333333333,111.33333460489905 L291.66666666666663,112.00000127156574 L295,114.33333460489905 L297,116.00000127156574 L298,117.66666793823242 L299.3333333333333,119.00000127156574 L300.3333333333333,121.33333460489905 L300.3333333333333,122.00000127156574 L300.3333333333333,123.66666793823242 L292.3333333333333,128.00000127156574 L270.66666666666663,135.00000127156574 L252.33333333333331,141.66666793823242 L233.66666666666666,148.33333460489905 L215.33333333333331,153.66666793823242 L180.66666666666666,164.00000127156574 L173.33333333333331,165.00000127156574 L155,167.33333460489905 L131.33333333333331,167.33333460489905 L124.33333333333331,167.00000127156574 L122.66666666666666,166.66666793823242 L122.33333333333331,166.00000127156574 L122.33333333333331,165.33333460489905 L126.33333333333331,159.33333460489905 L133.33333333333331,152.33333460489905 L143.66666666666666,144.00000127156574 L152.66666666666666,139.33333460489905 L167.33333333333331,132.00000127156574 L187.33333333333331,126.66666793823242 L211.33333333333331,118.33333460489905 L226,113.33333460489905 L231.33333333333331,110.33333460489905 L239.33333333333331,105.33333460489905 L248,98.66666793823242 L254,91.66666793823242 L254.33333333333331,90.66666793823242 L254.66666666666663,89.33333460489905 L254.66666666666663,88.66666793823242 L254.66666666666663,87.66666793823242 L252.33333333333331,87.66666793823242 L245.33333333333331,90.33333460489905 L238,93.00000127156574 L221.66666666666666,102.00000127156574 L188,128.33333460489905 L164.33333333333331,149.00000127156574 L154.33333333333331,159.00000127156574 L134.33333333333331,178.00000127156574 L116,196.33333460489905 L99.66666666666666,211.00000127156574 L84,223.00000127156574 L67,232.33333460489905 L54,236.66666793823242 L51.66666666666666,237.33333460489905 L51.33333333333333,237.33333460489905 L51.33333333333333,237.00000127156568 L51.33333333333333,236.66666793823242 L51.33333333333333,235.66666793823242 L57.66666666666666,231.66666793823242 L68.33333333333333,228.66666793823242 L92.33333333333333,227.33333460489905 L149.66666666666666,227.33333460489905 L162.66666666666666,227.33333460489905 L175.33333333333331,227.33333460489905 L193.66666666666666,227.33333460489905 L206.66666666666666,227.33333460489905 L215.66666666666666,227.33333460489905 L220.66666666666666,226.66666793823242 L225.33333333333331,226.00000127156568"}	{"icon": "build", "refId": "chk_mnb61qhk", "title": "NOVO CHECKLIST", "acceptedAt": "2026-03-30T20:37:08.954Z", "appVersion": "1.0", "receivedAt": "2026-03-30T20:36:59.603Z", "description": "Enviado de forma manual para vistoria.", "devicePlatform": "AppMovel", "durationSeconds": 70}	null	2026-03-30 20:37:08.986	2026-03-30 20:38:19.113	2026-03-30 20:38:19.256	2026-03-30 20:36:51.658	\N	\N	\N	\N	\N	\N
cmndwm9600076kgy8pumi8lwi	chk_mnb61qhk	alex@brspark.com	\N	COMPLETED	{"field_36827": "{\\"action\\":\\"SAIDA\\",\\"timestamp\\":\\"2026-03-31T02:01:26.311Z\\",\\"coordinates\\":{\\"lat\\":37.33757265,\\"lng\\":-122.04130388},\\"address\\":\\"Homestead Rd, 695 - Santa Clara, Sunnyvale - CA\\"}", "field_77672": "{\\"action\\":\\"CHEGADA\\",\\"timestamp\\":\\"2026-03-31T02:01:28.295Z\\",\\"coordinates\\":{\\"lat\\":37.33756255,\\"lng\\":-122.04141218},\\"address\\":\\"Homestead Rd,  - Santa Clara, Cupertino - CA\\"}", "field_85539": ""}	{"icon": "build-outline", "refId": "chk_mnb61qhk", "title": "NOVO CHECKLIST", "acceptedAt": "2026-03-31T02:01:23.922Z", "appVersion": "1.0", "receivedAt": "2026-03-31T01:08:11.935Z", "description": "12", "devicePlatform": "AppMovel", "durationSeconds": 11}	null	2026-03-31 02:01:23.958	2026-03-31 02:01:35.756	2026-03-31 02:01:36.275	2026-03-31 00:54:10.149	\N	\N	\N	\N	\N	\N
cmngkfnwf00075gk6atzq5j9u	chk_mngkermg	alex@brspark.com	\N	COMPLETED	{"field_29355": "{\\"action\\":\\"CHEGADA\\",\\"timestamp\\":\\"2026-04-01T21:36:58.311Z\\",\\"coordinates\\":{\\"lat\\":37.3347458,\\"lng\\":-122.04152572},\\"address\\":\\"N Stelling Rd, 10813 - Santa Clara, Cupertino - CA\\"}", "field_99100": "{\\"action\\":\\"SAIDA\\",\\"timestamp\\":\\"2026-04-01T21:36:37.714Z\\",\\"coordinates\\":{\\"lat\\":37.33607212,\\"lng\\":-122.04158551},\\"address\\":\\"N Stelling Rd, 10879 - Santa Clara, Cupertino - CA\\"}", "__time_field_29355": "2026-04-01T21:36:58.311Z", "__time_field_99100": "2026-04-01T21:36:37.714Z", "__section_end_page_1": "2026-04-01T21:37:00.350Z", "__section_start_page_1": "2026-04-01T21:36:37.725Z"}	{"icon": "build-outline", "refId": "chk_mngkermg", "title": "rota", "acceptedAt": "2026-04-01T21:36:32.395Z", "appVersion": "1.0", "receivedAt": "2026-04-01T21:36:26.934Z", "description": "Tarefa de rotina despachada.", "devicePlatform": "AppMovel", "durationSeconds": 27}	null	2026-04-01 21:36:32.459	2026-04-01 21:37:00.35	2026-04-01 21:37:00.463	2026-04-01 21:36:25.79	\N	-23.557814	-46.781074	[[-23.56923, -46.78897], [-23.56911, -46.78881], [-23.56911, -46.7888], [-23.56912, -46.7888], [-23.56912, -46.78879], [-23.56912, -46.78878], [-23.56912, -46.78877], [-23.56912, -46.78876], [-23.56912, -46.78875], [-23.56911, -46.78874], [-23.56911, -46.78873], [-23.5691, -46.78873], [-23.5691, -46.78872], [-23.56909, -46.78872], [-23.56909, -46.78871], [-23.56908, -46.78871], [-23.56907, -46.78871], [-23.56906, -46.78871], [-23.56905, -46.78871], [-23.56904, -46.78871], [-23.56902, -46.78872], [-23.56902, -46.78873], [-23.56901, -46.78873], [-23.56901, -46.78874], [-23.56901, -46.78875], [-23.569, -46.78875], [-23.569, -46.78876], [-23.569, -46.78877], [-23.569, -46.78878], [-23.5689, -46.78884], [-23.56876, -46.78895], [-23.56873, -46.78897], [-23.56871, -46.789], [-23.56865, -46.78906], [-23.56839, -46.78925], [-23.56826, -46.78935], [-23.56796, -46.78956], [-23.56777, -46.78972], [-23.56765, -46.78954], [-23.56761, -46.78949], [-23.56757, -46.78943], [-23.56752, -46.78937], [-23.56748, -46.78933], [-23.56744, -46.78926], [-23.56737, -46.78915], [-23.56729, -46.78897], [-23.56727, -46.78892], [-23.56718, -46.78874], [-23.5671, -46.78855], [-23.56708, -46.78853], [-23.56706, -46.7885], [-23.56703, -46.78845], [-23.567, -46.78841], [-23.56697, -46.78838], [-23.56692, -46.78835], [-23.56687, -46.78833], [-23.5668, -46.7883], [-23.56663, -46.78824], [-23.56643, -46.78817], [-23.5662, -46.78809], [-23.56601, -46.78803], [-23.56588, -46.78797], [-23.56576, -46.78793], [-23.56571, -46.78791], [-23.56537, -46.78779], [-23.56521, -46.78773], [-23.56515, -46.78771], [-23.56501, -46.78766], [-23.56492, -46.78763], [-23.56486, -46.78759], [-23.56483, -46.78758], [-23.56478, -46.78753], [-23.56473, -46.78748], [-23.56468, -46.78742], [-23.56461, -46.78732], [-23.56446, -46.78707], [-23.5644, -46.78697], [-23.56436, -46.7869], [-23.56431, -46.7868], [-23.56425, -46.78666], [-23.5642, -46.78653], [-23.56414, -46.7864], [-23.56409, -46.78631], [-23.56404, -46.78621], [-23.56403, -46.78617], [-23.56398, -46.78605], [-23.56396, -46.78599], [-23.5639, -46.78582], [-23.56382, -46.78563], [-23.56364, -46.78524], [-23.56354, -46.78504], [-23.56343, -46.7848], [-23.56332, -46.78456], [-23.56329, -46.7845], [-23.56301, -46.78385], [-23.56297, -46.78376], [-23.56291, -46.78362], [-23.56286, -46.78349], [-23.56284, -46.78331], [-23.56274, -46.78324], [-23.56264, -46.78318], [-23.5626, -46.78316], [-23.56253, -46.78312], [-23.56239, -46.78309], [-23.56223, -46.78307], [-23.56212, -46.78307], [-23.5618, -46.78306], [-23.56167, -46.78306], [-23.56147, -46.78305], [-23.56124, -46.78302], [-23.56117, -46.78301], [-23.5609, -46.78298], [-23.56048, -46.78289], [-23.56006, -46.78276], [-23.55988, -46.78271], [-23.55957, -46.78261], [-23.55934, -46.78252], [-23.55918, -46.78246], [-23.55902, -46.78239], [-23.55854, -46.78218], [-23.55831, -46.78207], [-23.55782, -46.78184], [-23.55764, -46.78176], [-23.55742, -46.78165], [-23.55715, -46.78152], [-23.55714, -46.78152], [-23.55661, -46.78127], [-23.55633, -46.78113], [-23.55616, -46.78105], [-23.55585, -46.7809], [-23.55578, -46.78087], [-23.55567, -46.78083], [-23.55558, -46.78079], [-23.55546, -46.78075], [-23.55517, -46.78063], [-23.55508, -46.78059], [-23.55499, -46.78055], [-23.5549, -46.7805], [-23.55484, -46.78046], [-23.55479, -46.78043], [-23.55472, -46.78039], [-23.55464, -46.78034], [-23.55453, -46.78026], [-23.55446, -46.7802], [-23.55437, -46.78012], [-23.55427, -46.78002], [-23.55413, -46.77987], [-23.55404, -46.77977], [-23.55393, -46.77962], [-23.55384, -46.7795], [-23.55375, -46.77934], [-23.55364, -46.77916], [-23.55348, -46.77893], [-23.55336, -46.77877], [-23.55323, -46.77862], [-23.55319, -46.77857], [-23.55308, -46.77845], [-23.55305, -46.77841], [-23.55294, -46.77828], [-23.55275, -46.77807], [-23.55262, -46.77793], [-23.55248, -46.77781], [-23.55235, -46.77767], [-23.55229, -46.7776], [-23.55213, -46.77746], [-23.55201, -46.77734], [-23.55187, -46.77724], [-23.55172, -46.77715], [-23.55146, -46.777], [-23.55124, -46.7769], [-23.55108, -46.77684], [-23.55094, -46.77678], [-23.55077, -46.77671], [-23.55063, -46.77666], [-23.55049, -46.77661], [-23.55035, -46.77656], [-23.5502, -46.77651], [-23.55002, -46.77646], [-23.54983, -46.77641], [-23.54979, -46.7764], [-23.5497, -46.77638], [-23.54962, -46.77635], [-23.54943, -46.77628], [-23.54864, -46.77593], [-23.54852, -46.77587], [-23.5483, -46.77578], [-23.54819, -46.7757], [-23.54809, -46.77562], [-23.54803, -46.77555], [-23.54796, -46.77547], [-23.54789, -46.77536], [-23.54784, -46.77525], [-23.5478, -46.77515], [-23.54776, -46.77503], [-23.54773, -46.77492], [-23.54772, -46.77489], [-23.54753, -46.77426], [-23.5474, -46.77378], [-23.54737, -46.77368], [-23.54729, -46.77341], [-23.54725, -46.77328], [-23.5472, -46.77315], [-23.54715, -46.77303], [-23.54708, -46.77292], [-23.547, -46.77278], [-23.54692, -46.77268], [-23.54682, -46.77257], [-23.5467, -46.77247], [-23.54659, -46.77238], [-23.54654, -46.77235], [-23.54655, -46.77227], [-23.54655, -46.77222], [-23.54654, -46.77217], [-23.54653, -46.77214], [-23.54674, -46.772], [-23.5468, -46.77197], [-23.54692, -46.77185], [-23.54698, -46.7717], [-23.547, -46.77165], [-23.54705, -46.77155], [-23.54708, -46.77149], [-23.54709, -46.77146], [-23.54718, -46.77133], [-23.54727, -46.77119], [-23.54734, -46.77111], [-23.54742, -46.77104], [-23.5475, -46.77094], [-23.54756, -46.77098], [-23.54761, -46.77099], [-23.54768, -46.77098], [-23.54784, -46.77095], [-23.54793, -46.77094], [-23.54807, -46.77087], [-23.54819, -46.7708], [-23.54825, -46.77077], [-23.54832, -46.77072], [-23.5483, -46.7707], [-23.54829, -46.77068], [-23.54829, -46.77065], [-23.54828, -46.77063], [-23.54828, -46.77059], [-23.54829, -46.77043], [-23.54829, -46.7703], [-23.54829, -46.77026], [-23.54828, -46.77015], [-23.54825, -46.77005], [-23.54821, -46.76992], [-23.54793, -46.77005], [-23.5478, -46.7701]]	\N	\N
cmndr0qws0079xd9ld66967uv	chk_mnb61qhk	alex@brspark.com	\N	COMPLETED	{"field_36827": "{\\"action\\":\\"SAIDA\\",\\"timestamp\\":\\"2026-03-31T02:01:53.064Z\\",\\"coordinates\\":{\\"lat\\":37.33600398,\\"lng\\":-122.04158528},\\"address\\":\\"N Stelling Rd, 10879 - Santa Clara, Cupertino - CA\\"}", "field_77672": "{\\"action\\":\\"CHEGADA\\",\\"timestamp\\":\\"2026-03-31T02:01:54.778Z\\",\\"coordinates\\":{\\"lat\\":37.33593628,\\"lng\\":-122.0415844},\\"address\\":\\"N Stelling Rd, 10879 - Santa Clara, Cupertino - CA\\"}", "field_85539": ""}	{"icon": "build", "refId": "chk_mnb61qhk", "title": "NOVO CHECKLIST", "acceptedAt": "2026-03-31T02:01:51.338Z", "appVersion": "1.0", "receivedAt": "2026-03-31T01:08:11.935Z", "description": "Enviado de forma manual para vistoria.", "devicePlatform": "AppMovel", "durationSeconds": 7}	null	2026-03-31 02:01:51.358	2026-03-31 02:01:59.133	2026-03-31 02:01:59.239	2026-03-30 22:17:28.637	\N	\N	\N	\N	\N	\N
cmngko31100105gk6415hhgot	chk_mngeayfc	unknown@empresa.com	\N	COMPLETED	{"__section_end_page_1": "2026-04-01T21:42:58.418Z"}	{"appVersion": "1.0", "devicePlatform": "AppMovel", "durationSeconds": 0}	null	2026-04-01 21:42:57.565	2026-04-01 21:42:58.418	2026-04-01 21:42:58.644	2026-04-01 21:42:58.645	\N	\N	\N	\N	\N	\N
cmndsfh9k0003kgy8tl8ljs8t	chk_mnb61qhk	alex@brspark.com	\N	COMPLETED	{"field_36827": "{\\"action\\":\\"SAIDA\\",\\"timestamp\\":\\"2026-03-30T22:59:54.844Z\\",\\"coordinates\\":{\\"lat\\":37.33023185,\\"lng\\":-122.02837143},\\"address\\":\\"Larry Way, 10511 - Santa Clara, Cupertino - CA\\"}", "field_77672": "{\\"action\\":\\"CHEGADA\\",\\"timestamp\\":\\"2026-03-30T23:00:01.192Z\\",\\"coordinates\\":{\\"lat\\":37.33019659,\\"lng\\":-122.0278974},\\"address\\":\\"Vista Dr, 10401 - Santa Clara, Cupertino - CA\\"}", "field_78643": "Opção 1", "field_85539": "", "field_99284": "SIG_V1|M259,57.000001271565736 L175.66666666666666,58.33333460489905 L133,69.66666793823242 L103.33333333333333,81.33333460489905 L78.33333333333333,103.33333460489905 L85,114.33333460489905 L99.33333333333333,127.33333460489905 L110,135.66666793823242 L132,155.33333460489905 L140.66666666666666,168.66666793823242 L142,181.66666793823242 L136.33333333333331,191.33333460489905 L118,199.00000127156574 L94,200.33333460489905 L62.66666666666666,192.33333460489905 L50.33333333333333,183.00000127156574 L48.66666666666666,178.66666793823242 L69.33333333333333,154.33333460489905 L143,120.00000127156574 L185.66666666666666,105.66666793823242 L252.33333333333331,86.00000127156574 L262.3333333333333,83.00000127156574 L262.3333333333333,82.33333460489905 L253.33333333333331,82.00000127156574 L240.66666666666663,82.00000127156574 L224,84.33333460489905 L217.66666666666666,89.33333460489905 L219,107.33333460489905 L250.66666666666663,150.66666793823242 L280.66666666666663,181.66666793823242 L280.66666666666663,185.00000127156574 L265.66666666666663,195.66666793823242 L253,198.33333460489905 L236.33333333333331,200.00000127156574 L191.66666666666666,200.00000127156574 L182,195.66666793823242 L184.33333333333331,186.66666793823242 L190.33333333333331,179.00000127156574 L207,162.33333460489905 L230.66666666666666,144.33333460489905 L266.66666666666663,124.00000127156574 L302.3333333333333,108.66666793823242 L345,89.33333460489905 L347,87.33333460489905 L347.66666666666663,87.00000127156574 L345.3333333333333,85.33333460489905 L336.3333333333333,82.33333460489905 L331.3333333333333,82.33333460489905 L328.66666666666663,82.00000127156574 L328,82.00000127156574 L327.3333333333333,82.00000127156574 L326.3333333333333,83.33333460489905 L326.3333333333333,85.66666793823242 L328.3333333333333,96.66666793823242 L334.3333333333333,110.00000127156574 L341.3333333333333,123.00000127156574 L345.3333333333333,132.00000127156574 L347,137.00000127156574 L347,166.33333460489905 L340.3333333333333,181.66666793823242 L327.66666666666663,194.33333460489905 L307.3333333333333,201.33333460489905 L294.66666666666663,202.66666793823242 L276,204.00000127156574 L270.3333333333333,201.00000127156574 L267.3333333333333,188.33333460489905 L268,177.33333460489905 L284,161.00000127156574 L301,151.66666793823242 L318.66666666666663,139.66666793823242 L338,125.66666793823242 L350.3333333333333,116.00000127156574 L351.66666666666663,111.00000127156574 L351.66666666666663,103.66666793823242 L350.66666666666663,101.66666793823242 L350.3333333333333,101.33333460489905 L349.66666666666663,101.00000127156574 L348.66666666666663,101.00000127156574 L348.3333333333333,100.66666793823242"}	{"icon": "build", "refId": "chk_mnb61qhk", "title": "NOVO CHECKLIST", "acceptedAt": "2026-03-30T22:59:50.960Z", "appVersion": "1.0", "receivedAt": "2026-03-30T22:59:46.872Z", "description": "Enviado de forma manual para vistoria.", "devicePlatform": "AppMovel", "durationSeconds": 22}	null	2026-03-30 22:59:51.005	2026-03-30 23:00:13.78	2026-03-30 23:00:13.867	2026-03-30 22:56:55.592	\N	\N	\N	\N	\N	\N
cmngxl67e006w7y15xr250ysm	chk_mngkermg	alex@brspark.com	\N	ACCEPTED	null	{"icon": "build-outline", "refId": "chk_mngkermg", "title": "rota", "acceptedAt": "2026-04-02T03:45:31.995Z", "receivedAt": "2026-04-02T03:44:41.475Z", "description": "Tarefa de rotina despachada."}	\N	\N	\N	\N	2026-04-02 03:44:37.801	\N	-23.570193	-46.786974	[[-23.571373, -46.788669], [-23.569013, -46.785278]]	150	segment
cmndsu7em0016kgy8ggodr7tm	chk_mnb61qhk	alex@brspark.com	\N	COMPLETED	{"field_36827": "{\\"action\\":\\"SAIDA\\",\\"timestamp\\":\\"2026-03-30T23:12:55.546Z\\",\\"coordinates\\":{\\"lat\\":37.33020269,\\"lng\\":-122.03352327},\\"address\\":\\"Mariani Ave, 20600 - Santa Clara, Cupertino - CA\\"}", "field_77672": "{\\"action\\":\\"CHEGADA\\",\\"timestamp\\":\\"2026-03-30T23:12:59.477Z\\",\\"coordinates\\":{\\"lat\\":37.33018237,\\"lng\\":-122.03321641},\\"address\\":\\"Mariani Ave, 20600 - Santa Clara, Cupertino - CA\\"}", "field_85539": "", "field_99284": "SIG_V1|M38.666666666666664,220.33333460489905 L41.666666666666664,211.00000127156574 L43.666666666666664,198.00000127156574 L50.66666666666666,177.66666793823242 L59.33333333333333,135.00000127156574 L65.33333333333333,101.66666793823242 L71.33333333333333,75.66666793823242 L74,64.33333460489905 L77,51.66666793823242 L92.66666666666666,19.666667938232422 L95,18.000001271565736 L95.66666666666666,18.000001271565736 L154,127.33333460489905 L166,157.00000127156574 L173,181.33333460489905 L180,216.33333460489905 L190.66666666666666,250.00000127156568 L195,272.0000012715657 L196,280.0000012715657 L196,282.6666679382324 L196,285.0000012715657 L196,286.0000012715657 L195.66666666666666,287.0000012715657 L194.66666666666666,287.0000012715657 L191.33333333333331,287.0000012715657 L182.33333333333331,282.0000012715657 L170.66666666666666,274.6666679382324 L160,268.33333460489905 L147,261.33333460489905 L136.33333333333331,256.6666679382324 L129,253.33333460489905 L120.33333333333331,246.66666793823242 L93.66666666666666,230.66666793823242 L78.33333333333333,222.00000127156574 L58.33333333333333,214.00000127156574 L41.666666666666664,210.00000127156574 L39.33333333333333,209.33333460489905 L39,209.00000127156574 L36.33333333333333,207.66666793823242 L33.666666666666664,206.33333460489905 L33,205.66666793823242 L33.33333333333333,205.33333460489905 L35,204.33333460489905 L40.33333333333333,202.00000127156574 L105,190.00000127156574 L254.66666666666663,171.00000127156574 L355,160.00000127156574|M170.66666666666666,159.33333460489905 L169,162.66666793823242 L169,169.66666793823242 L170,175.00000127156574 L171.33333333333331,178.33333460489905 L172,179.00000127156574 L173.33333333333331,179.00000127156574 L175.66666666666666,177.66666793823242 L183.33333333333331,170.00000127156574 L192.33333333333331,160.66666793823242 L198,152.66666793823242 L199.66666666666666,150.33333460489905 L199.66666666666666,145.00000127156574 L199.66666666666666,143.33333460489905 L195.66666666666666,129.33333460489905 L195,126.66666793823242 L194.33333333333331,125.33333460489905 L193.66666666666666,124.66666793823242 L192.33333333333331,122.00000127156574 L191,120.33333460489905 L190.33333333333331,121.33333460489905 L189.66666666666666,123.66666793823242 L187.33333333333331,138.00000127156574 L187.33333333333331,141.33333460489905 L187.33333333333331,148.33333460489905 L189.33333333333331,155.66666793823242 L190.66666666666666,160.66666793823242 L194.66666666666666,169.66666793823242 L196,172.00000127156574 L199,175.00000127156574 L200.33333333333331,175.33333460489905 L201,175.33333460489905 L203,175.33333460489905 L205.33333333333331,174.00000127156574 L208.33333333333331,171.00000127156574 L213,165.66666793823242 L214.66666666666666,163.66666793823242 L215,162.66666793823242 L215,161.00000127156574 L214.66666666666666,159.66666793823242 L214.33333333333331,159.00000127156574 L214.33333333333331,158.66666793823242 L214,158.33333460489905 L214,159.00000127156574 L213.33333333333331,162.66666793823242 L213,168.00000127156574 L214.33333333333331,171.33333460489905 L215.33333333333331,172.33333460489905 L215.66666666666666,172.33333460489905 L217,172.33333460489905 L219.66666666666666,171.66666793823242 L228.66666666666666,166.66666793823242 L238.33333333333331,160.00000127156574 L246,151.33333460489905 L252,136.66666793823242 L252,105.33333460489905 L247.66666666666663,81.33333460489905 L242.33333333333331,61.000001271565736 L239,53.000001271565736 L237.66666666666663,54.66666793823242 L237.66666666666663,63.66666793823242 L237.66666666666663,85.66666793823242 L236.33333333333331,117.33333460489905 L238,180.66666793823242 L245.66666666666663,225.66666793823242 L260,267.0000012715657 L267.66666666666663,284.0000012715657 L282.66666666666663,312.0000012715657 L283.66666666666663,314.0000012715657 L280.66666666666663,310.6666679382324 L272.3333333333333,302.33333460489905|M272,162.00000127156574 L272,161.33333460489905 L272,159.66666793823242 L272,158.66666793823242 L271,156.33333460489905 L269,153.33333460489905 L268.3333333333333,152.00000127156574 L267.66666666666663,151.33333460489905 L267.3333333333333,151.00000127156574 L266.3333333333333,151.00000127156574 L266,151.00000127156574 L265.66666666666663,151.00000127156574 L265,151.00000127156574 L264,151.66666793823242 L263.3333333333333,151.66666793823242 L261.3333333333333,153.33333460489905 L261,153.33333460489905 L260.3333333333333,154.00000127156574 L260.3333333333333,154.66666793823242 L260,155.66666793823242 L259.66666666666663,157.00000127156574 L259.66666666666663,158.00000127156574 L259.66666666666663,158.66666793823242 L259.66666666666663,159.33333460489905 L259.66666666666663,159.66666793823242 L259.66666666666663,161.00000127156574 L260.3333333333333,162.00000127156574 L261,162.66666793823242 L262.66666666666663,163.33333460489905 L263.66666666666663,163.66666793823242 L265.3333333333333,163.66666793823242 L266.66666666666663,163.66666793823242 L269.3333333333333,163.33333460489905 L270.66666666666663,162.00000127156574 L271.3333333333333,161.66666793823242 L271.3333333333333,161.33333460489905 L272,161.00000127156574 L272.66666666666663,159.66666793823242 L272.66666666666663,159.00000127156574 L272.66666666666663,158.66666793823242 L272.66666666666663,158.33333460489905 L272.3333333333333,158.33333460489905 L272.3333333333333,158.66666793823242 L273.3333333333333,160.66666793823242 L273.66666666666663,161.66666793823242 L274.66666666666663,163.00000127156574 L275,163.33333460489905 L277,163.33333460489905 L279.3333333333333,163.00000127156574 L280,161.66666793823242 L280.3333333333333,160.66666793823242 L280.66666666666663,159.33333460489905 L281.66666666666663,158.66666793823242 L282,158.00000127156574 L282,157.00000127156574 L282,156.33333460489905 L282,154.33333460489905 L282,153.66666793823242 L282,152.66666793823242 L281.66666666666663,152.33333460489905 L281.66666666666663,150.66666793823242 L281.3333333333333,150.00000127156574 L280.66666666666663,149.66666793823242 L280.66666666666663,149.00000127156574 L280.66666666666663,150.00000127156574 L282,153.33333460489905 L282.3333333333333,156.66666793823242 L284.3333333333333,162.00000127156574 L285,163.33333460489905 L285,164.33333460489905 L285.3333333333333,164.66666793823242 L285.3333333333333,165.33333460489905 L285.66666666666663,165.33333460489905 L286,165.33333460489905 L286.66666666666663,165.33333460489905 L288,163.33333460489905 L288.66666666666663,162.00000127156574 L289.3333333333333,156.66666793823242 L289.3333333333333,155.00000127156574 L289.3333333333333,154.33333460489905 L289.3333333333333,153.66666793823242 L289.3333333333333,152.66666793823242 L290.66666666666663,151.00000127156574 L291.66666666666663,149.66666793823242 L294,147.66666793823242 L297.3333333333333,146.00000127156574 L309,145.66666793823242 L309.66666666666663,146.00000127156574 L310.3333333333333,146.66666793823242 L310.66666666666663,146.66666793823242 L310.66666666666663,147.00000127156574 L310.3333333333333,147.00000127156574 L309,146.66666793823242 L308.66666666666663,146.33333460489905 L306.66666666666663,145.66666793823242 L306,145.66666793823242 L305.3333333333333,145.66666793823242 L305,145.00000127156574 L303.66666666666663,145.00000127156574 L302.66666666666663,145.66666793823242 L301.66666666666663,146.00000127156574 L301.3333333333333,146.00000127156574 L301,146.33333460489905 L300.66666666666663,146.66666793823242 L300.3333333333333,147.33333460489905 L300.3333333333333,148.66666793823242 L300,149.66666793823242 L300,151.33333460489905 L300.3333333333333,153.00000127156574 L300.66666666666663,154.66666793823242 L301,155.66666793823242 L301,156.66666793823242 L301.3333333333333,157.33333460489905 L301.66666666666663,158.00000127156574 L302.3333333333333,159.00000127156574 L303.3333333333333,159.33333460489905 L304.3333333333333,159.66666793823242 L305,160.00000127156574 L306.3333333333333,160.00000127156574 L307.66666666666663,160.00000127156574 L308.3333333333333,159.00000127156574 L309.66666666666663,156.33333460489905 L310.3333333333333,149.33333460489905 L310.3333333333333,147.66666793823242 L310.3333333333333,136.66666793823242 L310.3333333333333,125.66666793823242 L310.3333333333333,109.33333460489905 L309.66666666666663,100.33333460489905 L307.66666666666663,91.33333460489905 L307,89.33333460489905 L307,93.00000127156574 L307.66666666666663,98.00000127156574 L309.66666666666663,107.00000127156574 L310,111.33333460489905 L313,127.66666793823242 L315.66666666666663,135.00000127156574 L317.66666666666663,146.00000127156574 L319,152.33333460489905 L319.66666666666663,154.33333460489905 L320.66666666666663,154.33333460489905 L324.66666666666663,152.66666793823242 L330.66666666666663,151.00000127156574 L332.3333333333333,150.33333460489905 L333.3333333333333,149.33333460489905 L334.66666666666663,145.00000127156574 L334.66666666666663,144.00000127156574 L334.66666666666663,139.00000127156574 L332,132.00000127156574 L331,130.66666793823242 L330.66666666666663,130.33333460489905 L330.3333333333333,130.66666793823242 L329,131.66666793823242 L328.3333333333333,132.33333460489905 L328.3333333333333,133.66666793823242 L328.3333333333333,134.66666793823242 L328.3333333333333,135.33333460489905 L329.66666666666663,137.33333460489905 L330.3333333333333,138.33333460489905 L331.3333333333333,139.00000127156574 L333,139.00000127156574 L333.66666666666663,139.00000127156574 L338,139.00000127156574 L342,139.66666793823242 L343,140.00000127156574 L343.3333333333333,140.33333460489905 L343.3333333333333,140.66666793823242 L343.3333333333333,141.00000127156574 L343.3333333333333,141.33333460489905|M286,141.00000127156574"}	{"icon": "build", "refId": "chk_mnb61qhk", "title": "NOVO CHECKLIST", "acceptedAt": "2026-03-30T23:12:52.686Z", "appVersion": "1.0", "receivedAt": "2026-03-30T23:12:48.338Z", "description": "Enviado de forma manual para vistoria.", "devicePlatform": "AppMovel", "durationSeconds": 25}	null	2026-03-30 23:12:52.704	2026-03-30 23:13:18.038	2026-03-30 23:13:18.293	2026-03-30 23:08:22.654	\N	\N	\N	\N	\N	\N
cmndt63ma001wkgy87784o2mr	chk_mnb61qhk	alex@brspark.com	\N	COMPLETED	{"field_12415": "test"}	{}	null	\N	2026-03-30 23:17:37.617	2026-03-30 23:17:37.617	2026-03-30 23:17:37.617	\N	\N	\N	\N	\N	\N
cmndsu5oi0014kgy871qo1n2n	chk_mnb61qhk	alex@brspark.com	\N	COMPLETED	{"field_36827": "{\\"action\\":\\"SAIDA\\",\\"timestamp\\":\\"2026-03-30T23:45:56.129Z\\",\\"coordinates\\":{\\"lat\\":37.33159275,\\"lng\\":-122.03051033},\\"address\\":\\"Infinite Loop, 1 - Santa Clara, Cupertino - CA\\"}", "field_77672": "{\\"action\\":\\"CHEGADA\\",\\"timestamp\\":\\"2026-03-30T23:45:58.048Z\\",\\"coordinates\\":{\\"lat\\":37.33156519,\\"lng\\":-122.03057969},\\"address\\":\\"Infinite Loop, 1 - Santa Clara, Cupertino - CA\\"}", "field_85539": "", "field_99284": "SIG_V1|M175.66666666666666,222.33333460489905 L175.66666666666666,222.00000127156574 L175.66666666666666,218.66666793823242 L176.66666666666666,209.33333460489905 L178,198.66666793823242 L179,187.66666793823242 L182.33333333333331,176.66666793823242 L187.33333333333331,169.00000127156574 L194.33333333333331,161.66666793823242 L202.33333333333331,155.66666793823242 L210,150.66666793823242 L213.33333333333331,148.33333460489905 L217,145.33333460489905 L232,136.66666793823242 L235.66666666666666,135.00000127156574 L242.66666666666663,129.00000127156574 L247.66666666666663,122.66666793823242 L250,117.66666793823242 L251,114.33333460489905 L252,109.00000127156574 L252.33333333333331,105.66666793823242 L252.33333333333331,101.33333460489905 L251.33333333333331,94.33333460489905 L246,77.66666793823242 L242.33333333333331,71.66666793823242 L240.66666666666663,70.00000127156574 L226.66666666666666,66.66666793823242 L212,65.33333460489905 L188,62.66666793823242 L175,61.000001271565736 L151,58.33333460489905 L136.33333333333331,58.33333460489905 L125.33333333333331,58.33333460489905 L114.66666666666666,59.66666793823242 L105.66666666666666,62.66666793823242 L96.66666666666666,64.66666793823242 L82,68.33333460489905 L47.33333333333333,81.00000127156574 L37.666666666666664,87.33333460489905 L28,98.33333460489905 L25.666666666666664,101.66666793823242 L21,118.00000127156574 L21,127.00000127156574 L24,139.66666793823242 L27.666666666666664,148.66666793823242 L34.33333333333333,157.33333460489905 L38,161.66666793823242 L43,167.00000127156574 L47.33333333333333,171.00000127156574 L53.66666666666666,175.00000127156574 L62.66666666666666,179.33333460489905 L79,185.33333460489905 L114,189.33333460489905 L121,188.33333460489905 L124.33333333333331,182.66666793823242 L127.33333333333331,171.66666793823242 L129.66666666666666,161.00000127156574 L130.66666666666666,155.33333460489905 L130.66666666666666,139.00000127156574 L129.33333333333331,114.66666793823242 L125,92.66666793823242 L116.66666666666666,68.33333460489905 L108.33333333333331,48.33333460489905 L103.66666666666666,35.33333460489905 L103.66666666666666,35.000001271565736|M118.33333333333331,167.33333460489905 L119,167.66666793823242 L122.66666666666666,170.66666793823242 L131.66666666666666,180.00000127156574 L138.33333333333331,189.66666793823242 L147.66666666666666,206.66666793823242 L148.66666666666666,212.00000127156574 L149,215.33333460489905 L149,216.00000127156574 L148.66666666666666,216.33333460489905|M215.33333333333331,97.00000127156574 L215.33333333333331,98.66666793823242 L214.33333333333331,105.66666793823242 L213.66666666666666,109.00000127156574 L213.66666666666666,112.33333460489905 L214,116.00000127156574 L215.33333333333331,117.66666793823242 L219.66666666666666,119.66666793823242 L221.33333333333331,119.66666793823242 L237.33333333333331,118.00000127156574 L243.33333333333331,107.00000127156574 L244,98.00000127156574 L243,85.33333460489905 L241,80.00000127156574 L240,79.00000127156574 L239.33333333333331,78.66666793823242 L238.66666666666663,78.00000127156574 L237.33333333333331,78.00000127156574 L230.33333333333331,79.33333460489905 L223.33333333333331,81.00000127156574 L214.33333333333331,83.00000127156574 L209,84.00000127156574 L208.66666666666666,84.66666793823242 L208.33333333333331,84.66666793823242 L208.33333333333331,85.66666793823242 L208.33333333333331,86.66666793823242|M159.33333333333331,90.00000127156574 L158.66666666666666,91.66666793823242 L156,97.66666793823242 L153.66666666666666,101.00000127156574 L153,102.66666793823242 L150.66666666666666,107.00000127156574 L150.33333333333331,108.66666793823242 L150,109.33333460489905 L150,109.66666793823242|M183.66666666666666,86.33333460489905 L188,92.33333460489905 L189.33333333333331,94.00000127156574 L190,95.33333460489905 L190.66666666666666,96.00000127156574 L194,101.00000127156574 L195,102.33333460489905 L195.33333333333331,102.66666793823242 L195.33333333333331,103.33333460489905|M169,155.33333460489905 L170.33333333333331,155.66666793823242 L172.66666666666666,156.66666793823242 L174,157.33333460489905 L175.66666666666666,157.33333460489905 L177,157.33333460489905 L178.66666666666666,157.66666793823242 L179.33333333333331,157.66666793823242 L179.66666666666666,157.66666793823242 L181,157.66666793823242 L185.33333333333331,158.00000127156574"}	{"icon": "build", "refId": "chk_mnb61qhk", "title": "NOVO CHECKLIST", "acceptedAt": "2026-03-30T23:45:53.999Z", "appVersion": "1.0", "receivedAt": "2026-03-30T23:45:48.239Z", "description": "Enviado de forma manual para vistoria.", "devicePlatform": "AppMovel", "durationSeconds": 23}	null	2026-03-30 23:45:54.022	2026-03-30 23:46:17.515	2026-03-30 23:46:17.696	2026-03-30 23:08:20.418	\N	\N	\N	\N	\N	\N
cmndxkjba000vz5l5fi35a9uw	chk_mnb61qhk	alex@brspark.com	\N	COMPLETED	{"field_36827": "{\\"action\\":\\"SAIDA\\",\\"timestamp\\":\\"2026-03-31T01:21:12.913Z\\",\\"coordinates\\":{\\"lat\\":37.33019822,\\"lng\\":-122.02619962},\\"address\\":\\"Merritt Dr, 20188 - Santa Clara, Cupertino - CA\\"}", "field_77672": "{\\"action\\":\\"CHEGADA\\",\\"timestamp\\":\\"2026-03-31T01:21:15.732Z\\",\\"coordinates\\":{\\"lat\\":37.33019071,\\"lng\\":-122.02594601},\\"address\\":\\"Merritt Dr, 20172 - Santa Clara, Cupertino - CA\\"}", "field_85539": "", "field_99284": "SIG_V1|M179,62.000001271565736 L153.33333333333331,63.66666793823242 L127.33333333333331,68.00000127156574 L106.66666666666666,77.66666793823242 L99,85.66666793823242 L99,98.66666793823242 L109,121.33333460489905 L134.33333333333331,156.33333460489905 L161,189.33333460489905 L176,217.33333460489905 L178.33333333333331,236.00000127156568 L166,245.33333460489905 L136.33333333333331,246.66666793823242 L93.66666666666666,237.00000127156568 L55.66666666666666,218.33333460489905 L32,200.66666793823242 L29.666666666666664,187.66666793823242 L42.666666666666664,176.66666793823242 L87.33333333333333,165.66666793823242 L149,152.33333460489905 L214.33333333333331,135.33333460489905 L266.66666666666663,117.33333460489905 L297.3333333333333,99.00000127156574 L302.3333333333333,93.00000127156574 L297.3333333333333,87.00000127156574 L275.3333333333333,81.00000127156574 L251.33333333333331,79.66666793823242 L241.66666666666663,84.00000127156574 L239.66666666666663,89.33333460489905 L247,104.00000127156574 L261.66666666666663,130.33333460489905 L279,166.33333460489905 L281.66666666666663,184.66666793823242 L277.3333333333333,194.66666793823242 L255.33333333333331,201.33333460489905 L244.33333333333331,201.33333460489905 L203.33333333333331,188.33333460489905 L194.33333333333331,177.66666793823242 L193.33333333333331,165.00000127156574 L196.33333333333331,153.33333460489905 L210.33333333333331,143.00000127156574 L273.3333333333333,101.66666793823242 L302.3333333333333,72.33333460489905 L260,69.00000127156574 L224.66666666666666,75.00000127156574 L198,90.00000127156574 L182.66666666666666,111.00000127156574 L179.66666666666666,131.33333460489905 L192.33333333333331,152.00000127156574 L212.66666666666666,172.66666793823242 L224,184.33333460489905 L225.66666666666666,188.00000127156574 L220.33333333333331,194.66666793823242 L205,198.00000127156574 L162.33333333333331,198.00000127156574 L110,188.33333460489905 L69,174.00000127156574 L47,128.33333460489905 L68.66666666666666,101.33333460489905 L98.33333333333333,71.33333460489905 L121.33333333333331,43.66666793823242 L125,33.66666793823242 L116,31.666667938232422 L74,54.33333460489905 L60.33333333333333,84.33333460489905 L54.66666666666666,116.00000127156574 L53,147.66666793823242 L54.66666666666666,162.66666793823242 L56,188.33333460489905 L54.66666666666666,205.00000127156574 L50,213.00000127156574 L44.66666666666666,213.33333460489905 L33.666666666666664,203.66666793823242 L23.666666666666664,189.66666793823242 L16,173.00000127156574 L10.333333333333332,138.00000127156574 L15,125.00000127156574 L32,114.66666793823242 L61.66666666666666,105.66666793823242 L78.33333333333333,102.66666793823242 L119.33333333333331,94.66666793823242 L154.66666666666666,90.33333460489905 L190,88.66666793823242 L221.33333333333331,96.00000127156574 L247.66666666666663,109.33333460489905 L270,122.33333460489905 L273.3333333333333,123.00000127156574 L282.3333333333333,119.33333460489905 L292,106.00000127156574 L298.3333333333333,78.33333460489905 L299.66666666666663,48.66666793823242 L297,26.33333460489905 L293,16.666667938232422 L292.66666666666663,16.666667938232422 L292.66666666666663,21.000001271565736 L294.3333333333333,65.66666793823242 L314.3333333333333,142.00000127156574 L322,160.33333460489905 L322.66666666666663,162.33333460489905 L318.66666666666663,162.33333460489905 L304,162.33333460489905 L241,157.66666793823242 L202,154.66666793823242 L164.66666666666666,154.66666793823242 L146.33333333333331,158.33333460489905 L145.66666666666666,159.66666793823242 L145,162.00000127156574 L145.33333333333331,163.66666793823242 L147.66666666666666,168.66666793823242 L159,189.00000127156574 L172,202.33333460489905"}	{"icon": "build", "refId": "chk_mnb61qhk", "title": "NOVO CHECKLIST", "acceptedAt": "2026-03-31T01:21:10.002Z", "appVersion": "1.0", "receivedAt": "2026-03-31T01:20:53.238Z", "description": "Enviado de forma manual para vistoria.", "devicePlatform": "AppMovel", "durationSeconds": 15}	null	2026-03-31 01:21:10.074	2026-03-31 01:21:25.461	2026-03-31 01:21:25.562	2026-03-31 01:20:49.604	\N	\N	\N	\N	\N	\N
cmndstzfh000ykgy8ietsa2q7	chk_mnb61qhk	alex@brspark.com	\N	COMPLETED	{"field_36827": "{\\"action\\":\\"SAIDA\\",\\"timestamp\\":\\"2026-03-31T02:02:06.123Z\\",\\"coordinates\\":{\\"lat\\":37.33516574,\\"lng\\":-122.04154778},\\"address\\":\\"N Stelling Rd, 10851 - Santa Clara, Cupertino - CA\\"}", "field_77672": "{\\"action\\":\\"CHEGADA\\",\\"timestamp\\":\\"2026-03-31T02:02:07.782Z\\",\\"coordinates\\":{\\"lat\\":37.33510561,\\"lng\\":-122.04153972},\\"address\\":\\"N Stelling Rd, 10849 - Santa Clara, Cupertino - CA\\"}", "field_85539": "", "field_99284": "SIG_V1|M61,168.00000127156574 L163.66666666666666,89.33333460489905 L196.33333333333331,68.00000127156574 L196,68.66666793823242 L192,75.66666793823242 L178.66666666666666,93.33333460489905 L164.66666666666666,112.66666793823242 L137.66666666666666,143.00000127156574 L124.33333333333331,156.00000127156574 L121,157.66666793823242 L120.66666666666666,157.66666793823242 L118.33333333333331,151.66666793823242 L116.66666666666666,144.33333460489905 L114.33333333333331,129.66666793823242 L109.33333333333331,113.33333460489905 L108,110.66666793823242 L107.66666666666666,110.00000127156574 L106.66666666666666,109.66666793823242 L105.66666666666666,112.00000127156574 L105.66666666666666,113.66666793823242 L105.66666666666666,116.33333460489905 L105.66666666666666,117.33333460489905 L106.66666666666666,118.33333460489905 L107,119.66666793823242 L107.66666666666666,120.00000127156574 L109,120.33333460489905 L114,121.00000127156574 L141.66666666666666,123.66666793823242 L223.33333333333331,135.00000127156574 L240,136.33333460489905 L255.66666666666663,138.00000127156574 L247.66666666666663,139.33333460489905 L238.66666666666663,143.66666793823242 L222,151.33333460489905 L203.66666666666666,159.00000127156574 L179.66666666666666,167.66666793823242 L168.66666666666666,170.33333460489905 L144.66666666666666,173.33333460489905 L121,173.33333460489905 L120.33333333333331,173.33333460489905 L120,172.66666793823242 L120,172.33333460489905 L119.66666666666666,172.00000127156574 L119,171.66666793823242 L103.66666666666666,166.66666793823242 L94.66666666666666,163.66666793823242 L89.33333333333333,160.66666793823242 L89.33333333333333,158.66666793823242 L104,147.00000127156574 L252.33333333333331,103.66666793823242"}	{"icon": "build", "refId": "chk_mnb61qhk", "title": "NOVO CHECKLIST", "acceptedAt": "2026-03-31T02:01:18.094Z", "appVersion": "1.0", "receivedAt": "2026-03-31T01:08:11.935Z", "description": "Enviado de forma manual para vistoria.", "devicePlatform": "AppMovel", "durationSeconds": 13}	null	2026-03-31 02:02:03.959	2026-03-31 02:02:17.442	2026-03-31 02:02:17.752	2026-03-30 23:08:12.317	\N	\N	\N	\N	\N	\N
cmne0garp004vz5l5umk0v0m6	chk_mnb61qhk	alex@brspark.com	\N	COMPLETED	{"field_36827": "{\\"action\\":\\"SAIDA\\",\\"timestamp\\":\\"2026-03-31T02:43:17.846Z\\",\\"coordinates\\":{\\"lat\\":37.33768275,\\"lng\\":-122.02532213},\\"address\\":\\"E Homestead Rd, 591–599 - Ortega Park, Sunnyvale - CA\\"}", "field_77672": "{\\"action\\":\\"CHEGADA\\",\\"timestamp\\":\\"2026-03-31T02:43:20.517Z\\",\\"coordinates\\":{\\"lat\\":37.33765738,\\"lng\\":-122.02563954},\\"address\\":\\"E Homestead Rd, 585–587 - Ortega Park, Cupertino - CA\\"}", "field_85539": "", "field_99284": "SIG_V1|M151,92.33333460489905 L110.33333333333331,101.00000127156574 L91.66666666666666,109.00000127156574 L82.33333333333333,120.33333460489905 L87,132.00000127156574 L105.33333333333333,149.00000127156574 L169,192.66666793823242 L169,196.00000127156574 L133,206.33333460489905 L101.66666666666666,200.33333460489905 L80.33333333333333,187.66666793823242 L76.66666666666666,173.00000127156574 L93.33333333333333,146.33333460489905 L120.66666666666666,121.66666793823242 L160.66666666666666,97.66666793823242 L198.66666666666666,75.66666793823242 L221.66666666666666,58.000001271565736 L220.66666666666666,56.66666793823242 L219.33333333333331,56.33333460489905"}	{"icon": "build", "refId": "chk_mnb61qhk", "title": "NOVO CHECKLIST", "acceptedAt": "2026-03-31T02:43:15.123Z", "appVersion": "1.0", "receivedAt": "2026-03-31T02:42:22.044Z", "description": "Enviado de forma manual para vistoria.", "devicePlatform": "AppMovel", "durationSeconds": 16}	null	2026-03-31 02:43:15.176	2026-03-31 02:43:31.282	2026-03-31 02:43:32	2026-03-31 02:41:30.757	\N	\N	\N	\N	\N	\N
cmnelvood0018mtd4vlaxm8og	chk_mne1dhzv	alex@brspark.com	\N	COMPLETED	{"field_3999": "file://mock_path/arquivo.ext", "field_35561": "file://mock_path/arquivo.ext", "field_38889": "{\\"action\\":\\"SAIDA\\",\\"timestamp\\":\\"2026-03-31T13:31:00.393Z\\",\\"coordinates\\":{\\"lat\\":37.33456129,\\"lng\\":-122.04153329},\\"address\\":\\"N Stelling Rd, 10813 - Santa Clara, Cupertino - CA\\"}", "field_69277": "{\\"action\\":\\"CHEGADA\\",\\"timestamp\\":\\"2026-03-31T13:31:02.652Z\\",\\"coordinates\\":{\\"lat\\":37.33443281,\\"lng\\":-122.04153596},\\"address\\":\\"I-280,  - Santa Clara, Cupertino - CA\\"}", "field_71925": "SIG_V1|M133.66666666666666,180.66666793823242 L133,180.66666793823242 L129.66666666666666,181.00000127156574 L126.33333333333331,181.66666793823242 L117.33333333333331,181.66666793823242 L112,180.33333460489905 L104.66666666666666,176.66666793823242 L98.66666666666666,172.33333460489905 L98.33333333333333,172.33333460489905 L98.33333333333333,170.66666793823242 L99.33333333333333,165.33333460489905 L101,161.00000127156574 L105.33333333333333,157.33333460489905 L114.33333333333331,154.33333460489905 L127,152.00000127156574 L145,155.33333460489905 L153.66666666666666,163.00000127156574 L161.33333333333331,171.33333460489905 L161.66666666666666,172.33333460489905 L162,172.33333460489905 L217,112.33333460489905 L219.33333333333331,127.00000127156574 L220.66666666666666,151.00000127156574 L222,178.66666793823242 L222.33333333333331,178.66666793823242 L224.33333333333331,168.00000127156574 L235,104.66666793823242 L240.33333333333331,82.33333460489905 L241.33333333333331,82.66666793823242 L245.33333333333331,93.66666793823242 L251.66666666666663,110.33333460489905 L260.3333333333333,134.33333460489905 L264.3333333333333,152.33333460489905 L264.3333333333333,155.66666793823242 L263.3333333333333,158.33333460489905 L261.3333333333333,160.00000127156574 L257,162.33333460489905 L248,165.00000127156574 L239,168.00000127156574 L230,171.66666793823242 L221,173.66666793823242 L218.66666666666666,175.33333460489905 L210,179.00000127156574 L201,181.00000127156574 L192,182.33333460489905 L154.66666666666666,185.33333460489905 L108.33333333333331,188.33333460489905 L71,193.00000127156574 L47,198.66666793823242 L46.66666666666666,198.66666793823242 L47,198.66666793823242 L51,181.00000127156574 L57,151.33333460489905 L66,119.66666793823242 L95.66666666666666,74.66666793823242 L108.33333333333331,69.00000127156574 L134,95.66666793823242 L155,121.33333460489905 L175.33333333333331,142.00000127156574 L184,149.00000127156574 L187.33333333333331,149.33333460489905 L190,149.33333460489905 L191,149.33333460489905 L191.33333333333331,149.33333460489905", "field_78600": "file://mock_path/arquivo.ext", "__section_end_page_1": "2026-03-31T13:31:18.204Z", "__section_start_page_1": "2026-03-31T13:31:00.410Z"}	{"icon": "", "refId": "chk_mne1dhzv", "title": "231", "acceptedAt": "2026-03-31T13:09:52.267Z", "appVersion": "1.0", "receivedAt": "2026-03-31T12:41:24.288Z", "description": "Enviado de forma manual para vistoria.", "devicePlatform": "AppMovel", "durationSeconds": 20}	null	2026-03-31 13:30:57.918	2026-03-31 13:31:18.204	2026-03-31 13:31:18.565	2026-03-31 12:41:20.558	\N	\N	\N	\N	\N	\N
cmne1di3c000iokg0e6r6qeeh	chk_mne1dhzv	alex@brspark.com	\N	COMPLETED	{"field_3999": "file://mock_path/arquivo.ext", "field_35561": "file://mock_path/arquivo.ext", "field_38889": "{\\"action\\":\\"SAIDA\\",\\"timestamp\\":\\"2026-03-31T21:55:16.295Z\\",\\"coordinates\\":{\\"lat\\":37.33018628,\\"lng\\":-122.03260685},\\"address\\":\\"Mariani Ave, 20600 - Santa Clara, Cupertino - CA\\"}", "field_69277": "{\\"action\\":\\"CHEGADA\\",\\"timestamp\\":\\"2026-03-31T21:55:19.088Z\\",\\"coordinates\\":{\\"lat\\":37.33017704,\\"lng\\":-122.03255255},\\"address\\":\\"N De Anza Blvd, 10495 - Santa Clara, Cupertino - CA\\"}", "field_71925": "SIG_V1|M207,105.66666793823242 L207.66666666666666,107.33333460489905 L199.66666666666666,124.00000127156574 L180,139.66666793823242 L120,158.33333460489905 L75.33333333333333,163.00000127156574 L30.666666666666664,163.00000127156574 L-0.6666666666666679,155.66666793823242 L-13,146.00000127156574 L-16.333333333333332,135.00000127156574 L-14.666666666666668,111.00000127156574 L3.6666666666666643,78.33333460489905 L25.666666666666664,59.33333460489905 L68.66666666666666,45.33333460489905 L115,42.000001271565736 L169,54.000001271565736 L197.33333333333331,70.66666793823242 L219.33333333333331,89.66666793823242 L234,106.00000127156574 L242.66666666666663,119.33333460489905 L247.33333333333331,132.00000127156574 L247.33333333333331,143.00000127156574 L239.66666666666663,152.66666793823242 L215,165.66666793823242 L185.66666666666666,173.00000127156574 L156,176.00000127156574 L133.66666666666666,174.66666793823242 L115.33333333333331,166.66666793823242 L102.66666666666666,131.66666793823242 L105.66666666666666,103.66666793823242 L115.33333333333331,84.66666793823242 L151.66666666666666,67.33333460489905 L172,72.66666793823242 L190,88.00000127156574 L207,106.33333460489905 L222,124.33333460489905 L230.33333333333331,133.33333460489905 L237.33333333333331,136.00000127156574 L246.33333333333331,137.00000127156574 L251.33333333333331,136.00000127156574 L262,128.00000127156574 L268.66666666666663,118.33333460489905 L271.3333333333333,109.33333460489905 L271.3333333333333,104.00000127156574 L270.3333333333333,102.33333460489905 L268.66666666666663,101.00000127156574 L267.3333333333333,100.33333460489905|M268,138.66666793823242 L269,141.66666793823242", "field_78600": "file://mock_path/arquivo.ext", "__time_field_3999": "2026-03-31T21:55:23.745Z", "__time_field_35561": "2026-03-31T21:55:26.346Z", "__time_field_38889": "2026-03-31T21:55:16.295Z", "__time_field_69277": "2026-03-31T21:55:19.088Z", "__time_field_71925": "2026-03-31T21:55:34.245Z", "__time_field_78600": "2026-03-31T21:55:29.718Z", "__section_end_page_1": "2026-03-31T21:55:35.217Z", "__section_start_page_1": "2026-03-31T21:55:16.310Z"}	{"icon": "", "refId": "chk_mne1dhzv", "title": "231", "acceptedAt": "2026-03-31T03:07:41.681Z", "appVersion": "1.0", "receivedAt": "2026-03-31T03:07:24.938Z", "description": "Enviado de forma manual para vistoria.", "devicePlatform": "AppMovel", "durationSeconds": 21}	null	2026-03-31 21:55:13.848	2026-03-31 21:55:35.217	2026-03-31 21:55:35.329	2026-03-31 03:07:19.897	\N	\N	\N	\N	\N	\N
cmnf5yihg00ecibkekx8ncpcy	chk_mncnb2te	alex@brspark.com	\N	CANCELLED	{"field_48469": "SIG_V1|meta:{\\"lat\\":37.33017796,\\"lng\\":-122.03267412,\\"address\\":\\"N De Anza Blvd, 10495 - Cupertino, CA\\",\\"ip\\":\\"2804:7f0:9383:8b58:ac19:2d32:d4f4:239b\\"}|M189,51.33333460489905 L188,179.33333460489905 L190.33333333333331,210.66666793823242 L174.33333333333331,221.00000127156574 L148.66666666666666,225.33333460489905 L120.66666666666666,226.66666793823242 L81.33333333333333,214.00000127156574 L53,199.00000127156574 L49.66666666666666,194.66666793823242 L53.33333333333333,180.66666793823242 L63.33333333333333,168.33333460489905 L90.33333333333333,149.33333460489905 L149,119.33333460489905 L218.33333333333331,92.33333460489905 L218.66666666666666,92.00000127156574 L229.66666666666666,78.00000127156574 L230,78.00000127156574 L230.33333333333331,77.66666793823242 L238.33333333333331,74.33333460489905 L247.33333333333331,71.00000127156574 L261.66666666666663,66.33333460489905 L278.3333333333333,62.66666793823242 L286.3333333333333,61.000001271565736 L286.3333333333333,60.66666793823242 L287,61.33333460489905 L289,67.33333460489905 L293.3333333333333,83.66666793823242 L293.3333333333333,100.33333460489905 L284.66666666666663,133.33333460489905 L278.66666666666663,142.00000127156574 L269.66666666666663,147.00000127156574 L268.3333333333333,145.33333460489905 L264.66666666666663,140.66666793823242 L259.3333333333333,136.66666793823242 L243.66666666666663,125.66666793823242 L228.66666666666666,116.66666793823242 L178.66666666666666,99.66666793823242 L149,93.66666793823242 L121.33333333333331,87.66666793823242 L103,82.66666793823242 L99,81.66666793823242 L98.33333333333333,81.00000127156574 L98.33333333333333,83.00000127156574 L106.33333333333333,93.33333460489905 L115,99.33333460489905 L126,104.66666793823242 L176,123.33333460489905 L196,130.00000127156574", "__time_field_48469": "2026-03-31T22:41:50.180Z", "__section_end_field_93650": "2026-03-31T23:11:02.497Z", "__section_start_field_93650": "2026-03-31T22:41:50.209Z"}	{"icon": "", "refId": "chk_mncnb2te", "title": "NOVO CHECKLISTee", "acceptedAt": "2026-03-31T22:41:39.549Z", "appVersion": "1.0", "receivedAt": "2026-03-31T22:40:56.164Z", "description": "Enviado de forma manual para vistoria.", "devicePlatform": "AppMovel", "durationSeconds": 2}	null	2026-03-31 23:11:00.223	2026-03-31 23:11:02.497	2026-03-31 23:11:02.604	2026-03-31 22:03:24.821	\N	\N	\N	\N	\N	\N
cmnf5jetv00e7ibkef45xnoaw	chk_mnf5iygw	alex@brspark.com	\N	COMPLETED	{"field_96169": "file:///Users/alex/Library/Developer/CoreSimulator/Devices/6FA71D68-E528-4A18-9CB2-1B903E430B52/data/Containers/Data/Application/9983D353-E539-4BCC-BE09-41DFB8578B02/Library/Caches/ImagePicker/71D614E1-C248-445B-8677-112F3873F8D5.jpg", "__time_field_96169": "2026-03-31T23:14:25.494Z", "__section_end_field_44550": "2026-03-31T23:19:45.538Z", "__section_start_field_44550": "2026-03-31T23:14:25.557Z"}	{"icon": "", "refId": "chk_mnf5iygw", "title": "NOVO CHECKLISThhhh", "acceptedAt": "2026-03-31T23:13:53.355Z", "appVersion": "1.0", "receivedAt": "2026-03-31T22:40:56.163Z", "description": "Enviado de forma manual para vistoria.", "devicePlatform": "AppMovel", "durationSeconds": 351}	null	2026-03-31 23:13:53.572	2026-03-31 23:19:45.538	2026-03-31 23:19:46.128	2026-03-31 21:51:40.243	\N	\N	\N	\N	\N	\N
cmngkmiln000u5gk6a7qtr2jt	chk_mngkermg	alex@brspark.com	\N	COMPLETED	{"field_29355": "{\\"action\\":\\"CHEGADA\\",\\"timestamp\\":\\"2026-04-01T21:42:33.987Z\\",\\"coordinates\\":{\\"lat\\":37.33021434,\\"lng\\":-122.02806565},\\"address\\":\\"Merritt Dr,  - Santa Clara, Cupertino - CA\\"}", "field_99100": "{\\"action\\":\\"SAIDA\\",\\"timestamp\\":\\"2026-04-01T21:42:04.188Z\\",\\"coordinates\\":{\\"lat\\":37.3304337,\\"lng\\":-122.0301625},\\"address\\":\\"N De Anza Blvd, 10500 - Santa Clara, Cupertino - CA\\"}", "__time_field_29355": "2026-04-01T21:42:33.987Z", "__time_field_99100": "2026-04-01T21:42:04.188Z", "__section_end_page_1": "2026-04-01T21:42:38.415Z", "__section_start_page_1": "2026-04-01T21:42:04.199Z"}	{"icon": "build-outline", "refId": "chk_mngkermg", "title": "rota", "acceptedAt": "2026-04-01T21:42:00.309Z", "appVersion": "1.0", "receivedAt": "2026-04-01T21:41:46.570Z", "description": "teste", "devicePlatform": "AppMovel", "durationSeconds": 38}	null	2026-04-01 21:42:00.349	2026-04-01 21:42:38.415	2026-04-01 21:42:38.646	2026-04-01 21:41:45.515	\N	-23.557814	-46.781074	[[-23.56923, -46.78897], [-23.56911, -46.78881], [-23.56911, -46.7888], [-23.56912, -46.7888], [-23.56912, -46.78879], [-23.56912, -46.78878], [-23.56912, -46.78877], [-23.56912, -46.78876], [-23.56912, -46.78875], [-23.56911, -46.78874], [-23.56911, -46.78873], [-23.5691, -46.78873], [-23.5691, -46.78872], [-23.56909, -46.78872], [-23.56909, -46.78871], [-23.56908, -46.78871], [-23.56907, -46.78871], [-23.56906, -46.78871], [-23.56905, -46.78871], [-23.56904, -46.78871], [-23.56902, -46.78872], [-23.56902, -46.78873], [-23.56901, -46.78873], [-23.56901, -46.78874], [-23.56901, -46.78875], [-23.569, -46.78875], [-23.569, -46.78876], [-23.569, -46.78877], [-23.569, -46.78878], [-23.5689, -46.78884], [-23.56876, -46.78895], [-23.56873, -46.78897], [-23.56871, -46.789], [-23.56865, -46.78906], [-23.56839, -46.78925], [-23.56826, -46.78935], [-23.56796, -46.78956], [-23.56777, -46.78972], [-23.56765, -46.78954], [-23.56761, -46.78949], [-23.56757, -46.78943], [-23.56752, -46.78937], [-23.56748, -46.78933], [-23.56744, -46.78926], [-23.56737, -46.78915], [-23.56729, -46.78897], [-23.56727, -46.78892], [-23.56718, -46.78874], [-23.5671, -46.78855], [-23.56708, -46.78853], [-23.56706, -46.7885], [-23.56703, -46.78845], [-23.567, -46.78841], [-23.56697, -46.78838], [-23.56692, -46.78835], [-23.56687, -46.78833], [-23.5668, -46.7883], [-23.56663, -46.78824], [-23.56643, -46.78817], [-23.5662, -46.78809], [-23.56601, -46.78803], [-23.56588, -46.78797], [-23.56576, -46.78793], [-23.56571, -46.78791], [-23.56537, -46.78779], [-23.56521, -46.78773], [-23.56515, -46.78771], [-23.56501, -46.78766], [-23.56492, -46.78763], [-23.56486, -46.78759], [-23.56483, -46.78758], [-23.56478, -46.78753], [-23.56473, -46.78748], [-23.56468, -46.78742], [-23.56461, -46.78732], [-23.56446, -46.78707], [-23.5644, -46.78697], [-23.56436, -46.7869], [-23.56431, -46.7868], [-23.56425, -46.78666], [-23.5642, -46.78653], [-23.56414, -46.7864], [-23.56409, -46.78631], [-23.56404, -46.78621], [-23.56403, -46.78617], [-23.56398, -46.78605], [-23.56396, -46.78599], [-23.5639, -46.78582], [-23.56382, -46.78563], [-23.56364, -46.78524], [-23.56354, -46.78504], [-23.56343, -46.7848], [-23.56332, -46.78456], [-23.56329, -46.7845], [-23.56301, -46.78385], [-23.56297, -46.78376], [-23.56291, -46.78362], [-23.56286, -46.78349], [-23.56284, -46.78331], [-23.56274, -46.78324], [-23.56264, -46.78318], [-23.5626, -46.78316], [-23.56253, -46.78312], [-23.56239, -46.78309], [-23.56223, -46.78307], [-23.56212, -46.78307], [-23.5618, -46.78306], [-23.56167, -46.78306], [-23.56147, -46.78305], [-23.56124, -46.78302], [-23.56117, -46.78301], [-23.5609, -46.78298], [-23.56048, -46.78289], [-23.56006, -46.78276], [-23.55988, -46.78271], [-23.55957, -46.78261], [-23.55934, -46.78252], [-23.55918, -46.78246], [-23.55902, -46.78239], [-23.55854, -46.78218], [-23.55831, -46.78207], [-23.55782, -46.78184], [-23.55764, -46.78176], [-23.55742, -46.78165], [-23.55715, -46.78152], [-23.55714, -46.78152], [-23.55661, -46.78127], [-23.55633, -46.78113], [-23.55616, -46.78105], [-23.55585, -46.7809], [-23.55578, -46.78087], [-23.55567, -46.78083], [-23.55558, -46.78079], [-23.55546, -46.78075], [-23.55517, -46.78063], [-23.55508, -46.78059], [-23.55499, -46.78055], [-23.5549, -46.7805], [-23.55484, -46.78046], [-23.55479, -46.78043], [-23.55472, -46.78039], [-23.55464, -46.78034], [-23.55453, -46.78026], [-23.55446, -46.7802], [-23.55437, -46.78012], [-23.55427, -46.78002], [-23.55413, -46.77987], [-23.55404, -46.77977], [-23.55393, -46.77962], [-23.55384, -46.7795], [-23.55375, -46.77934], [-23.55364, -46.77916], [-23.55348, -46.77893], [-23.55336, -46.77877], [-23.55323, -46.77862], [-23.55319, -46.77857], [-23.55308, -46.77845], [-23.55305, -46.77841], [-23.55294, -46.77828], [-23.55275, -46.77807], [-23.55262, -46.77793], [-23.55248, -46.77781], [-23.55235, -46.77767], [-23.55229, -46.7776], [-23.55213, -46.77746], [-23.55201, -46.77734], [-23.55187, -46.77724], [-23.55172, -46.77715], [-23.55146, -46.777], [-23.55124, -46.7769], [-23.55108, -46.77684], [-23.55094, -46.77678], [-23.55077, -46.77671], [-23.55063, -46.77666], [-23.55049, -46.77661], [-23.55035, -46.77656], [-23.5502, -46.77651], [-23.55002, -46.77646], [-23.54983, -46.77641], [-23.54979, -46.7764], [-23.5497, -46.77638], [-23.54962, -46.77635], [-23.54943, -46.77628], [-23.54864, -46.77593], [-23.54852, -46.77587], [-23.5483, -46.77578], [-23.54819, -46.7757], [-23.54809, -46.77562], [-23.54803, -46.77555], [-23.54796, -46.77547], [-23.54789, -46.77536], [-23.54784, -46.77525], [-23.5478, -46.77515], [-23.54776, -46.77503], [-23.54773, -46.77492], [-23.54772, -46.77489], [-23.54753, -46.77426], [-23.5474, -46.77378], [-23.54737, -46.77368], [-23.54729, -46.77341], [-23.54725, -46.77328], [-23.5472, -46.77315], [-23.54715, -46.77303], [-23.54708, -46.77292], [-23.547, -46.77278], [-23.54692, -46.77268], [-23.54682, -46.77257], [-23.5467, -46.77247], [-23.54659, -46.77238], [-23.54654, -46.77235], [-23.54655, -46.77227], [-23.54655, -46.77222], [-23.54654, -46.77217], [-23.54653, -46.77214], [-23.54674, -46.772], [-23.5468, -46.77197], [-23.54692, -46.77185], [-23.54698, -46.7717], [-23.547, -46.77165], [-23.54705, -46.77155], [-23.54708, -46.77149], [-23.54709, -46.77146], [-23.54718, -46.77133], [-23.54727, -46.77119], [-23.54734, -46.77111], [-23.54742, -46.77104], [-23.5475, -46.77094], [-23.54756, -46.77098], [-23.54761, -46.77099], [-23.54768, -46.77098], [-23.54784, -46.77095], [-23.54793, -46.77094], [-23.54807, -46.77087], [-23.54819, -46.7708], [-23.54825, -46.77077], [-23.54832, -46.77072], [-23.5483, -46.7707], [-23.54829, -46.77068], [-23.54829, -46.77065], [-23.54828, -46.77063], [-23.54828, -46.77059], [-23.54829, -46.77043], [-23.54829, -46.7703], [-23.54829, -46.77026], [-23.54828, -46.77015], [-23.54825, -46.77005], [-23.54821, -46.76992], [-23.54793, -46.77005], [-23.5478, -46.7701]]	\N	\N
cmne0i4r9005cz5l5taguxlda	chk_mnb61qhk	alex@brspark.com	\N	COMPLETED	{"field_17262": "file:///Users/alex/Library/Developer/CoreSimulator/Devices/6FA71D68-E528-4A18-9CB2-1B903E430B52/data/Containers/Data/Application/9983D353-E539-4BCC-BE09-41DFB8578B02/Library/Caches/ImagePicker/095DB854-3791-4739-BBED-EE708248784A.jpg", "field_19829": "We’re are", "field_44585": "{\\"action\\":\\"CHEGADA\\",\\"timestamp\\":\\"2026-03-31T23:20:05.863Z\\",\\"coordinates\\":{\\"lat\\":37.33767789,\\"lng\\":-122.02666008},\\"address\\":\\"E Homestead Rd, 575 - Ortega Park, Sunnyvale - CA\\"}", "field_56249": "32434", "field_61552": 4, "field_72359": "{\\"action\\":\\"SAIDA\\",\\"timestamp\\":\\"2026-03-31T23:20:03.861Z\\",\\"coordinates\\":{\\"lat\\":37.33766087,\\"lng\\":-122.02649211},\\"address\\":\\"E Homestead Rd, 575 - Ortega Park, Cupertino - CA\\"}", "field_78643": "Opção 1", "field_85539": "", "field_99284": "SIG_V1|meta:{\\"lat\\":37.33756603,\\"lng\\":-122.04120235,\\"address\\":\\"Homestead Rd, 695 - Cupertino, CA\\",\\"ip\\":\\"2804:7f0:9383:8b58:ac19:2d32:d4f4:239b\\"}|M212.66666666666666,119.33333460489905 L188.33333333333331,161.33333460489905 L148.33333333333331,185.33333460489905 L99.66666666666666,203.00000127156574 L53.33333333333333,211.00000127156574 L10.333333333333332,214.33333460489905 L-4.333333333333334,211.66666793823242 L-6.333333333333334,204.66666793823242 L-6.333333333333334,186.00000127156574 L4.666666666666664,148.66666793823242 L28.666666666666664,126.00000127156574 L65.66666666666666,116.66666793823242 L112.33333333333331,124.66666793823242 L134.66666666666666,132.66666793823242 L172.33333333333331,151.66666793823242 L199.66666666666666,173.00000127156574 L223,190.66666793823242 L234.33333333333331,195.66666793823242 L245.66666666666663,174.33333460489905 L247,161.33333460489905 L248.66666666666663,129.66666793823242 L243,96.33333460489905 L241.66666666666663,95.33333460489905 L239.33333333333331,95.33333460489905 L235,103.33333460489905 L230,121.66666793823242 L222.66666666666666,151.66666793823242 L219.66666666666666,183.00000127156574 L219.66666666666666,207.00000127156574 L219.66666666666666,207.33333460489905 L218.66666666666666,207.33333460489905 L195.33333333333331,200.00000127156574 L183.66666666666666,193.33333460489905 L171.66666666666666,182.00000127156574 L169,179.33333460489905 L165.33333333333331,172.33333460489905 L165.33333333333331,170.66666793823242 L165.33333333333331,170.33333460489905", "__time_field_17262": "2026-03-31T23:45:14.172Z", "__time_field_19829": "2026-03-31T23:54:48.034Z", "__time_field_44585": "2026-03-31T23:20:05.863Z", "__time_field_56249": "2026-03-31T23:54:49.845Z", "__time_field_61552": "2026-03-31T23:21:03.532Z", "__time_field_72359": "2026-03-31T23:20:03.861Z", "__time_field_78643": "2026-03-31T23:21:00.898Z", "__time_field_99284": "2026-03-31T23:54:54.935Z", "__section_end_page_1": "2026-03-31T23:20:08.664Z", "__section_start_page_1": "2026-03-31T23:20:03.880Z", "__section_end_field_25157": "2026-03-31T23:54:55.998Z", "__section_end_field_37429": "2026-03-31T23:54:50.625Z", "__section_start_field_25157": "2026-03-31T23:54:50.649Z", "__section_start_field_37429": "2026-03-31T23:20:08.740Z"}	{"icon": "build", "refId": "chk_mnb61qhk", "title": "NOVO CHECKLIST", "acceptedAt": "2026-03-31T12:38:08.227Z", "appVersion": "1.0", "receivedAt": "2026-03-31T02:43:09.994Z", "description": "Enviado de forma manual para vistoria.", "devicePlatform": "AppMovel", "durationSeconds": 399}	null	2026-03-31 23:48:16.116	2026-03-31 23:54:55.998	2026-03-31 23:54:56.219	2026-03-31 02:42:56.276	\N	\N	\N	\N	\N	\N
cmnfe1i85005f2jj04it93pkp	chk_mnen95p1d55	alex@brspark.com	\N	COMPLETED	{"field_35561": "http://192.168.15.73:3001/uploads/storage/checklists/unknown_empresa_com/cmnfe1i85005f2jj04it93pkp_field_35561_1775010430355.jpg", "field_38889": "{\\"action\\":\\"SAIDA\\",\\"timestamp\\":\\"2026-04-01T02:26:25.951Z\\",\\"coordinates\\":{\\"lat\\":37.33694779,\\"lng\\":-122.02323042},\\"address\\":\\"E Homestead Rd, 19990 - Santa Clara, Cupertino - CA\\"}", "field_69277": "{\\"action\\":\\"CHEGADA\\",\\"timestamp\\":\\"2026-04-01T02:26:28.513Z\\",\\"coordinates\\":{\\"lat\\":37.33718079,\\"lng\\":-122.02322984},\\"address\\":\\"E Homestead Rd, 19998 - Santa Clara, Cupertino - CA\\"}", "field_71925": "SIG_V1|meta:{\\"lat\\":37.33743371,\\"lng\\":-122.02322184,\\"address\\":\\"E Homestead Rd, 19998 - Cupertino, CA\\",\\"ip\\":\\"2804:7f0:9383:8b58:2950:2f11:be08:520c\\"}|M111.66666666666666,188.00000127156574 L109.33333333333331,187.33333460489905 L101.33333333333333,176.00000127156574 L90,155.66666793823242 L86.33333333333333,118.66666793823242 L93.33333333333333,87.33333460489905 L101,83.33333460489905 L105,83.66666793823242 L106.33333333333333,85.33333460489905 L110,92.33333460489905 L114,101.33333460489905 L120.33333333333331,123.33333460489905 L121.66666666666666,137.66666793823242 L121.33333333333331,140.33333460489905 L121.33333333333331,141.33333460489905 L121.33333333333331,140.66666793823242 L121.66666666666666,131.66666793823242 L126.33333333333331,113.66666793823242 L132.33333333333331,102.00000127156574 L138.33333333333331,93.66666793823242 L147,93.33333460489905 L155.66666666666666,100.66666793823242 L162.33333333333331,110.66666793823242 L169.33333333333331,123.33333460489905 L172,130.33333460489905 L173.66666666666666,137.66666793823242 L173.66666666666666,144.66666793823242 L173.66666666666666,139.33333460489905 L173.66666666666666,128.33333460489905 L177.33333333333331,121.33333460489905 L198.33333333333331,94.00000127156574 L200.66666666666666,94.00000127156574 L202.33333333333331,94.66666793823242 L211,101.33333460489905 L217.33333333333331,110.66666793823242 L228.33333333333331,131.66666793823242 L242,181.33333460489905 L242,188.66666793823242 L236.33333333333331,198.66666793823242 L220,206.33333460489905 L181,210.33333460489905 L137,210.33333460489905 L135.66666666666666,210.33333460489905 L135.66666666666666,209.66666793823242 L134.33333333333331,204.00000127156574", "__time_field_35561": "2026-04-01T02:26:56.373Z", "__time_field_38889": "2026-04-01T02:26:25.951Z", "__time_field_69277": "2026-04-01T02:26:28.513Z", "__time_field_71925": "2026-04-01T02:27:04.111Z", "__section_end_field_68093": "2026-04-01T02:27:05.787Z", "__section_start_field_68093": "2026-04-01T02:26:25.965Z"}	{"icon": "", "refId": "chk_mnen95p1d55", "title": "231222a (Cópia)", "acceptedAt": "2026-04-01T02:26:22.013Z", "appVersion": "1.0", "receivedAt": "2026-04-01T01:49:43.831Z", "description": "Enviado de forma manual para vistoria.", "devicePlatform": "AppMovel", "durationSeconds": 43}	null	2026-04-01 02:26:22.072	2026-04-01 02:27:05.787	2026-04-01 02:27:12.058	2026-04-01 01:49:41.375	\N	\N	\N	\N	\N	\N
cmnfe1k6z005h2jj01f18y64f	chk_mnen95p1d55	alex@brspark.com	\N	COMPLETED	{"field_35561": "http://192.168.15.73:3001/uploads/storage/checklists/unknown_empresa_com/cmnfe1k6z005h2jj01f18y64f_field_35561_1775008403397.jpg", "field_38889": "{\\"action\\":\\"SAIDA\\",\\"timestamp\\":\\"2026-04-01T01:50:13.555Z\\",\\"coordinates\\":{\\"lat\\":37.33015535,\\"lng\\":-122.03227932},\\"address\\":\\"Mariani Ave,  - Santa Clara, Cupertino - CA\\"}", "field_69277": "{\\"action\\":\\"CHEGADA\\",\\"timestamp\\":\\"2026-04-01T01:50:17.783Z\\",\\"coordinates\\":{\\"lat\\":37.33014741,\\"lng\\":-122.03175785},\\"address\\":\\"Mariani Ave,  - Santa Clara, Cupertino - CA\\"}", "field_71925": "SIG_V1|meta:{\\"lat\\":37.33023144,\\"lng\\":-122.02349589,\\"address\\":\\"Merritt Dr, 20000–20048 - Cupertino, CA\\",\\"ip\\":\\"2804:7f0:9383:8b58:ac19:2d32:d4f4:239b\\"}|M218.33333333333331,193.66666793823242 L167.66666666666666,209.00000127156574 L143.66666666666666,207.66666793823242 L118,200.33333460489905 L102.66666666666666,192.66666793823242 L76.33333333333333,179.66666793823242 L44.33333333333333,153.00000127156574 L39,142.33333460489905 L37.666666666666664,131.33333460489905 L57,114.66666793823242 L103.33333333333333,110.66666793823242 L131,110.66666793823242 L155,110.66666793823242 L179,107.66666793823242 L190,105.00000127156574 L199,101.33333460489905 L201.33333333333331,99.33333460489905 L201.33333333333331,91.66666793823242 L198.33333333333331,84.66666793823242 L197.33333333333331,83.00000127156574 L193.66666666666666,79.66666793823242 L181.33333333333331,74.33333460489905 L164.33333333333331,78.66666793823242 L162.66666666666666,82.00000127156574 L161.66666666666666,85.66666793823242 L161.66666666666666,120.33333460489905 L164.66666666666666,146.33333460489905 L169,185.33333460489905 L169,194.66666793823242 L149,226.00000127156568 L130,235.33333460489905 L93.33333333333333,238.00000127156568 L86,237.00000127156568 L77.66666666666666,233.00000127156568 L75.66666666666666,231.66666793823242 L73.33333333333333,221.00000127156574 L75,206.66666793823242 L82,200.66666793823242 L91,197.33333460489905 L103.66666666666666,196.33333460489905 L140.33333333333331,198.66666793823242", "__time_field_35561": "2026-04-01T01:52:32.944Z", "__time_field_38889": "2026-04-01T01:50:13.555Z", "__time_field_69277": "2026-04-01T01:50:17.783Z", "__time_field_71925": "2026-04-01T01:53:05.291Z", "__section_end_field_68093": "2026-04-01T01:53:06.769Z", "__section_start_field_68093": "2026-04-01T01:50:13.573Z"}	{"icon": "", "refId": "chk_mnen95p1d55", "title": "231222a (Cópia)", "acceptedAt": "2026-04-01T01:50:04.960Z", "appVersion": "1.0", "receivedAt": "2026-04-01T01:49:44.732Z", "description": "Enviado de forma manual para vistoria.", "devicePlatform": "AppMovel", "durationSeconds": 181}	null	2026-04-01 01:50:05.367	2026-04-01 01:53:06.769	2026-04-01 01:53:35.506	2026-04-01 01:49:43.931	\N	\N	\N	\N	\N	\N
cmngec9yb004rrcieg5ncha6o	chk_mnen95p1d55	alex@brspark.com	\N	COMPLETED	{"field_38889": "{\\"action\\":\\"SAIDA\\",\\"timestamp\\":\\"2026-04-01T18:46:17.364Z\\",\\"coordinates\\":{\\"lat\\":37.33202296,\\"lng\\":-122.03478001},\\"address\\":\\"Bandley Dr, 10627 - Santa Clara, Cupertino - CA\\"}", "field_71925": "SIG_V1|meta:{\\"lat\\":37.3310798,\\"lng\\":-122.0307725,\\"address\\":\\"Infinite Loop, 1 - Cupertino, CA\\",\\"ip\\":\\"2804:7f0:9383:8b58:2950:2f11:be08:520c\\"}|M153,120.33333460489905 L113,158.33333460489905 L100.33333333333333,164.00000127156574 L76.33333333333333,172.66666793823242 L64.33333333333333,173.33333460489905 L62.66666666666666,169.66666793823242 L61.66666666666666,162.66666793823242 L59,140.33333460489905 L59,125.66666793823242 L61.66666666666666,101.66666793823242 L90.33333333333333,83.00000127156574 L96.33333333333333,86.00000127156574 L111.33333333333331,102.33333460489905 L182.33333333333331,119.33333460489905|M203.33333333333331,107.33333460489905", "__time_field_38889": "2026-04-01T18:46:17.365Z", "__time_field_71925": "2026-04-01T19:04:32.716Z", "__section_end_field_68093": "2026-04-01T19:04:34.283Z", "__section_start_field_68093": "2026-04-01T18:46:17.451Z"}	{"icon": "build-outline", "refId": "chk_mnen95p1d55", "title": "231222a (Cópia)", "acceptedAt": "2026-04-01T18:46:11.219Z", "appVersion": "1.0", "receivedAt": "2026-04-01T18:45:54.832Z", "description": "Tarefa de rotina despachada.", "devicePlatform": "AppMovel", "durationSeconds": 1102}	null	2026-04-01 18:46:11.827	2026-04-01 19:04:34.283	2026-04-01 19:04:34.537	2026-04-01 18:45:50.047	R	-23.567156	-46.786233	null	200	\N
cmngpvvmj000qs92habgi5b68	chk_mngkermg	alex@brspark.com	\N	COMPLETED	{"field_29355": "{\\"action\\":\\"CHEGADA\\",\\"timestamp\\":\\"2026-04-02T00:52:22.346Z\\",\\"coordinates\\":{\\"lat\\":-23.569983,\\"lng\\":-46.7851655},\\"address\\":\\"Parque Chico Mendes,  - Jd Bussocaba City, Osasco - SP\\"}", "field_99100": "{\\"action\\":\\"SAIDA\\",\\"timestamp\\":\\"2026-04-02T00:09:27.342Z\\",\\"coordinates\\":{\\"lat\\":-23.569983,\\"lng\\":-46.7851655},\\"address\\":\\"Parque Chico Mendes,  - Jd Bussocaba City, Osasco - SP\\"}", "__time_field_29355": "2026-04-02T00:52:22.346Z", "__time_field_99100": "2026-04-02T00:09:27.342Z", "__section_end_page_1": "2026-04-02T00:52:25.023Z", "__section_start_page_1": "2026-04-02T00:09:27.351Z"}	{"icon": "build-outline", "refId": "chk_mngkermg", "title": "rota", "acceptedAt": "2026-04-02T00:09:19.569Z", "appVersion": "1.0", "receivedAt": "2026-04-02T00:09:02.485Z", "description": "Tarefa de rotina despachada.", "devicePlatform": "AppMovel", "durationSeconds": 2578}	null	2026-04-02 00:09:27	2026-04-02 00:52:25.023	2026-04-02 02:00:20.156	2026-04-02 00:09:00.379	\N	-23.557814	-46.781074	[[-23.56923, -46.78897], [-23.56911, -46.78881], [-23.56911, -46.7888], [-23.56912, -46.7888], [-23.56912, -46.78879], [-23.56912, -46.78878], [-23.56912, -46.78877], [-23.56912, -46.78876], [-23.56912, -46.78875], [-23.56911, -46.78874], [-23.56911, -46.78873], [-23.5691, -46.78873], [-23.5691, -46.78872], [-23.56909, -46.78872], [-23.56909, -46.78871], [-23.56908, -46.78871], [-23.56907, -46.78871], [-23.56906, -46.78871], [-23.56905, -46.78871], [-23.56904, -46.78871], [-23.56902, -46.78872], [-23.56902, -46.78873], [-23.56901, -46.78873], [-23.56901, -46.78874], [-23.56901, -46.78875], [-23.569, -46.78875], [-23.569, -46.78876], [-23.569, -46.78877], [-23.569, -46.78878], [-23.5689, -46.78884], [-23.56876, -46.78895], [-23.56873, -46.78897], [-23.56871, -46.789], [-23.56865, -46.78906], [-23.56839, -46.78925], [-23.56826, -46.78935], [-23.56796, -46.78956], [-23.56777, -46.78972], [-23.56765, -46.78954], [-23.56761, -46.78949], [-23.56757, -46.78943], [-23.56752, -46.78937], [-23.56748, -46.78933], [-23.56744, -46.78926], [-23.56737, -46.78915], [-23.56729, -46.78897], [-23.56727, -46.78892], [-23.56718, -46.78874], [-23.5671, -46.78855], [-23.56708, -46.78853], [-23.56706, -46.7885], [-23.56703, -46.78845], [-23.567, -46.78841], [-23.56697, -46.78838], [-23.56692, -46.78835], [-23.56687, -46.78833], [-23.5668, -46.7883], [-23.56663, -46.78824], [-23.56643, -46.78817], [-23.5662, -46.78809], [-23.56601, -46.78803], [-23.56588, -46.78797], [-23.56576, -46.78793], [-23.56571, -46.78791], [-23.56537, -46.78779], [-23.56521, -46.78773], [-23.56515, -46.78771], [-23.56501, -46.78766], [-23.56492, -46.78763], [-23.56486, -46.78759], [-23.56483, -46.78758], [-23.56478, -46.78753], [-23.56473, -46.78748], [-23.56468, -46.78742], [-23.56461, -46.78732], [-23.56446, -46.78707], [-23.5644, -46.78697], [-23.56436, -46.7869], [-23.56431, -46.7868], [-23.56425, -46.78666], [-23.5642, -46.78653], [-23.56414, -46.7864], [-23.56409, -46.78631], [-23.56404, -46.78621], [-23.56403, -46.78617], [-23.56398, -46.78605], [-23.56396, -46.78599], [-23.5639, -46.78582], [-23.56382, -46.78563], [-23.56364, -46.78524], [-23.56354, -46.78504], [-23.56343, -46.7848], [-23.56332, -46.78456], [-23.56329, -46.7845], [-23.56301, -46.78385], [-23.56297, -46.78376], [-23.56291, -46.78362], [-23.56286, -46.78349], [-23.56284, -46.78331], [-23.56274, -46.78324], [-23.56264, -46.78318], [-23.5626, -46.78316], [-23.56253, -46.78312], [-23.56239, -46.78309], [-23.56223, -46.78307], [-23.56212, -46.78307], [-23.5618, -46.78306], [-23.56167, -46.78306], [-23.56147, -46.78305], [-23.56124, -46.78302], [-23.56117, -46.78301], [-23.5609, -46.78298], [-23.56048, -46.78289], [-23.56006, -46.78276], [-23.55988, -46.78271], [-23.55957, -46.78261], [-23.55934, -46.78252], [-23.55918, -46.78246], [-23.55902, -46.78239], [-23.55854, -46.78218], [-23.55831, -46.78207], [-23.55782, -46.78184], [-23.55764, -46.78176], [-23.55742, -46.78165], [-23.55715, -46.78152], [-23.55714, -46.78152], [-23.55661, -46.78127], [-23.55633, -46.78113], [-23.55616, -46.78105], [-23.55585, -46.7809], [-23.55578, -46.78087], [-23.55567, -46.78083], [-23.55558, -46.78079], [-23.55546, -46.78075], [-23.55517, -46.78063], [-23.55508, -46.78059], [-23.55499, -46.78055], [-23.5549, -46.7805], [-23.55484, -46.78046], [-23.55479, -46.78043], [-23.55472, -46.78039], [-23.55464, -46.78034], [-23.55453, -46.78026], [-23.55446, -46.7802], [-23.55437, -46.78012], [-23.55427, -46.78002], [-23.55413, -46.77987], [-23.55404, -46.77977], [-23.55393, -46.77962], [-23.55384, -46.7795], [-23.55375, -46.77934], [-23.55364, -46.77916], [-23.55348, -46.77893], [-23.55336, -46.77877], [-23.55323, -46.77862], [-23.55319, -46.77857], [-23.55308, -46.77845], [-23.55305, -46.77841], [-23.55294, -46.77828], [-23.55275, -46.77807], [-23.55262, -46.77793], [-23.55248, -46.77781], [-23.55235, -46.77767], [-23.55229, -46.7776], [-23.55213, -46.77746], [-23.55201, -46.77734], [-23.55187, -46.77724], [-23.55172, -46.77715], [-23.55146, -46.777], [-23.55124, -46.7769], [-23.55108, -46.77684], [-23.55094, -46.77678], [-23.55077, -46.77671], [-23.55063, -46.77666], [-23.55049, -46.77661], [-23.55035, -46.77656], [-23.5502, -46.77651], [-23.55002, -46.77646], [-23.54983, -46.77641], [-23.54979, -46.7764], [-23.5497, -46.77638], [-23.54962, -46.77635], [-23.54943, -46.77628], [-23.54864, -46.77593], [-23.54852, -46.77587], [-23.5483, -46.77578], [-23.54819, -46.7757], [-23.54809, -46.77562], [-23.54803, -46.77555], [-23.54796, -46.77547], [-23.54789, -46.77536], [-23.54784, -46.77525], [-23.5478, -46.77515], [-23.54776, -46.77503], [-23.54773, -46.77492], [-23.54772, -46.77489], [-23.54753, -46.77426], [-23.5474, -46.77378], [-23.54737, -46.77368], [-23.54729, -46.77341], [-23.54725, -46.77328], [-23.5472, -46.77315], [-23.54715, -46.77303], [-23.54708, -46.77292], [-23.547, -46.77278], [-23.54692, -46.77268], [-23.54682, -46.77257], [-23.5467, -46.77247], [-23.54659, -46.77238], [-23.54654, -46.77235], [-23.54655, -46.77227], [-23.54655, -46.77222], [-23.54654, -46.77217], [-23.54653, -46.77214], [-23.54674, -46.772], [-23.5468, -46.77197], [-23.54692, -46.77185], [-23.54698, -46.7717], [-23.547, -46.77165], [-23.54705, -46.77155], [-23.54708, -46.77149], [-23.54709, -46.77146], [-23.54718, -46.77133], [-23.54727, -46.77119], [-23.54734, -46.77111], [-23.54742, -46.77104], [-23.5475, -46.77094], [-23.54756, -46.77098], [-23.54761, -46.77099], [-23.54768, -46.77098], [-23.54784, -46.77095], [-23.54793, -46.77094], [-23.54807, -46.77087], [-23.54819, -46.7708], [-23.54825, -46.77077], [-23.54832, -46.77072], [-23.5483, -46.7707], [-23.54829, -46.77068], [-23.54829, -46.77065], [-23.54828, -46.77063], [-23.54828, -46.77059], [-23.54829, -46.77043], [-23.54829, -46.7703], [-23.54829, -46.77026], [-23.54828, -46.77015], [-23.54825, -46.77005], [-23.54821, -46.76992], [-23.54793, -46.77005], [-23.5478, -46.7701]]	\N	route
cmngkpafr00135gk6wnptki74	chk_mngkermg	alex@brspark.com	\N	COMPLETED	{"field_29355": "{\\"action\\":\\"CHEGADA\\",\\"timestamp\\":\\"2026-04-01T21:44:54.449Z\\",\\"coordinates\\":{\\"lat\\":37.33416947,\\"lng\\":-122.02356758},\\"address\\":\\"I-280,  - Santa Clara, Cupertino - CA\\"}", "field_99100": "{\\"action\\":\\"SAIDA\\",\\"timestamp\\":\\"2026-04-01T21:44:07.578Z\\",\\"coordinates\\":{\\"lat\\":37.3322178,\\"lng\\":-122.02331875},\\"address\\":\\"N Blaney Ave, 10614 - Santa Clara, Cupertino - CA\\"}", "__time_field_29355": "2026-04-01T21:44:54.449Z", "__time_field_99100": "2026-04-01T21:44:07.578Z", "__section_end_page_1": "2026-04-01T21:45:00.512Z", "__section_start_page_1": "2026-04-01T21:44:07.589Z"}	{"icon": "build-outline", "refId": "chk_mngkermg", "title": "rota", "acceptedAt": "2026-04-01T21:44:04.876Z", "appVersion": "1.0", "receivedAt": "2026-04-01T21:43:57.006Z", "description": "Tarefa de rotina despachada.", "devicePlatform": "AppMovel", "durationSeconds": 19}	null	2026-04-01 21:44:41.116	2026-04-01 21:45:00.512	2026-04-01 21:45:00.61	2026-04-01 21:43:54.903	\N	\N	\N	null	\N	\N
cmngkskre001d5gk6f26zbwv8	chk_mngkermg	unknown@empresa.com	\N	COMPLETED	{"field_29355": "{\\"action\\":\\"CHEGADA\\",\\"timestamp\\":\\"2026-04-01T21:46:26.734Z\\",\\"coordinates\\":{\\"lat\\":37.33770138,\\"lng\\":-122.02382892},\\"address\\":\\"E Homestead Rd, 637 - Ortega Park, Sunnyvale - CA\\"}", "field_99100": "{\\"action\\":\\"SAIDA\\",\\"timestamp\\":\\"2026-04-01T21:46:24.080Z\\",\\"coordinates\\":{\\"lat\\":37.33769414,\\"lng\\":-122.02354506},\\"address\\":\\"E Homestead Rd, 649 - Ortega Park, Sunnyvale - CA\\"}", "__time_field_29355": "2026-04-01T21:46:26.734Z", "__time_field_99100": "2026-04-01T21:46:24.080Z", "__section_end_page_1": "2026-04-01T21:46:28.166Z", "__section_start_page_1": "2026-04-01T21:46:24.090Z"}	{"appVersion": "1.0", "devicePlatform": "AppMovel", "durationSeconds": 6}	null	2026-04-01 21:46:22.135	2026-04-01 21:46:28.166	2026-04-01 21:46:28.243	2026-04-01 21:46:28.246	\N	\N	\N	\N	\N	\N
cmngkspkn001g5gk67j3m8v4y	chk_mngkermg	unknown@empresa.com	\N	COMPLETED	{"field_29355": "{\\"action\\":\\"CHEGADA\\",\\"timestamp\\":\\"2026-04-01T21:46:33.142Z\\",\\"coordinates\\":{\\"lat\\":37.33772285,\\"lng\\":-122.02448505},\\"address\\":\\"Langport Dr, 1672 - Ortega Park, Sunnyvale - CA\\"}", "field_99100": "{\\"action\\":\\"SAIDA\\",\\"timestamp\\":\\"2026-04-01T21:46:31.409Z\\",\\"coordinates\\":{\\"lat\\":37.3377228,\\"lng\\":-122.02430369},\\"address\\":\\"Langport Dr, 1672 - Ortega Park, Sunnyvale - CA\\"}", "__time_field_29355": "2026-04-01T21:46:33.142Z", "__time_field_99100": "2026-04-01T21:46:31.409Z", "__section_end_page_1": "2026-04-01T21:46:34.428Z", "__section_start_page_1": "2026-04-01T21:46:31.426Z"}	{"appVersion": "1.0", "devicePlatform": "AppMovel", "durationSeconds": 4}	null	2026-04-01 21:46:30.133	2026-04-01 21:46:34.428	2026-04-01 21:46:34.486	2026-04-01 21:46:34.487	\N	\N	\N	\N	\N	\N
cmngu13j100117y15izmlasaw	chk_mngkermg	alex@brspark.com	\N	COMPLETED	{"field_99100": "{\\"action\\":\\"SAIDA\\",\\"timestamp\\":\\"2026-04-02T02:06:11.381Z\\",\\"coordinates\\":{\\"lat\\":-23.569983,\\"lng\\":-46.7851655},\\"address\\":\\"Parque Chico Mendes,  - Jd Bussocaba City, Osasco - SP\\"}", "__time_field_99100": "2026-04-02T02:06:11.381Z", "__section_end_page_1": "2026-04-02T02:27:36.787Z", "__section_start_page_1": "2026-04-02T02:06:11.393Z"}	{"icon": "build-outline", "refId": "chk_mngkermg", "title": "rota", "acceptedAt": "2026-04-02T02:05:25.239Z", "appVersion": "1.0", "receivedAt": "2026-04-02T02:05:05.175Z", "description": "Tarefa de rotina despachada.", "devicePlatform": "AppMovel", "durationSeconds": 4}	null	2026-04-02 02:27:32.339	2026-04-02 02:27:36.787	2026-04-02 02:27:36.851	2026-04-02 02:05:02.365	\N	-23.557814	-46.781074	[[-23.56923, -46.78897], [-23.56911, -46.78881], [-23.56911, -46.7888], [-23.56912, -46.7888], [-23.56912, -46.78879], [-23.56912, -46.78878], [-23.56912, -46.78877], [-23.56912, -46.78876], [-23.56912, -46.78875], [-23.56911, -46.78874], [-23.56911, -46.78873], [-23.5691, -46.78873], [-23.5691, -46.78872], [-23.56909, -46.78872], [-23.56909, -46.78871], [-23.56908, -46.78871], [-23.56907, -46.78871], [-23.56906, -46.78871], [-23.56905, -46.78871], [-23.56904, -46.78871], [-23.56902, -46.78872], [-23.56902, -46.78873], [-23.56901, -46.78873], [-23.56901, -46.78874], [-23.56901, -46.78875], [-23.569, -46.78875], [-23.569, -46.78876], [-23.569, -46.78877], [-23.569, -46.78878], [-23.5689, -46.78884], [-23.56876, -46.78895], [-23.56873, -46.78897], [-23.56871, -46.789], [-23.56865, -46.78906], [-23.56839, -46.78925], [-23.56826, -46.78935], [-23.56796, -46.78956], [-23.56777, -46.78972], [-23.56765, -46.78954], [-23.56761, -46.78949], [-23.56757, -46.78943], [-23.56752, -46.78937], [-23.56748, -46.78933], [-23.56744, -46.78926], [-23.56737, -46.78915], [-23.56729, -46.78897], [-23.56727, -46.78892], [-23.56718, -46.78874], [-23.5671, -46.78855], [-23.56708, -46.78853], [-23.56706, -46.7885], [-23.56703, -46.78845], [-23.567, -46.78841], [-23.56697, -46.78838], [-23.56692, -46.78835], [-23.56687, -46.78833], [-23.5668, -46.7883], [-23.56663, -46.78824], [-23.56643, -46.78817], [-23.5662, -46.78809], [-23.56601, -46.78803], [-23.56588, -46.78797], [-23.56576, -46.78793], [-23.56571, -46.78791], [-23.56537, -46.78779], [-23.56521, -46.78773], [-23.56515, -46.78771], [-23.56501, -46.78766], [-23.56492, -46.78763], [-23.56486, -46.78759], [-23.56483, -46.78758], [-23.56478, -46.78753], [-23.56473, -46.78748], [-23.56468, -46.78742], [-23.56461, -46.78732], [-23.56446, -46.78707], [-23.5644, -46.78697], [-23.56436, -46.7869], [-23.56431, -46.7868], [-23.56425, -46.78666], [-23.5642, -46.78653], [-23.56414, -46.7864], [-23.56409, -46.78631], [-23.56404, -46.78621], [-23.56403, -46.78617], [-23.56398, -46.78605], [-23.56396, -46.78599], [-23.5639, -46.78582], [-23.56382, -46.78563], [-23.56364, -46.78524], [-23.56354, -46.78504], [-23.56343, -46.7848], [-23.56332, -46.78456], [-23.56329, -46.7845], [-23.56301, -46.78385], [-23.56297, -46.78376], [-23.56291, -46.78362], [-23.56286, -46.78349], [-23.56284, -46.78331], [-23.56274, -46.78324], [-23.56264, -46.78318], [-23.5626, -46.78316], [-23.56253, -46.78312], [-23.56239, -46.78309], [-23.56223, -46.78307], [-23.56212, -46.78307], [-23.5618, -46.78306], [-23.56167, -46.78306], [-23.56147, -46.78305], [-23.56124, -46.78302], [-23.56117, -46.78301], [-23.5609, -46.78298], [-23.56048, -46.78289], [-23.56006, -46.78276], [-23.55988, -46.78271], [-23.55957, -46.78261], [-23.55934, -46.78252], [-23.55918, -46.78246], [-23.55902, -46.78239], [-23.55854, -46.78218], [-23.55831, -46.78207], [-23.55782, -46.78184], [-23.55764, -46.78176], [-23.55742, -46.78165], [-23.55715, -46.78152], [-23.55714, -46.78152], [-23.55661, -46.78127], [-23.55633, -46.78113], [-23.55616, -46.78105], [-23.55585, -46.7809], [-23.55578, -46.78087], [-23.55567, -46.78083], [-23.55558, -46.78079], [-23.55546, -46.78075], [-23.55517, -46.78063], [-23.55508, -46.78059], [-23.55499, -46.78055], [-23.5549, -46.7805], [-23.55484, -46.78046], [-23.55479, -46.78043], [-23.55472, -46.78039], [-23.55464, -46.78034], [-23.55453, -46.78026], [-23.55446, -46.7802], [-23.55437, -46.78012], [-23.55427, -46.78002], [-23.55413, -46.77987], [-23.55404, -46.77977], [-23.55393, -46.77962], [-23.55384, -46.7795], [-23.55375, -46.77934], [-23.55364, -46.77916], [-23.55348, -46.77893], [-23.55336, -46.77877], [-23.55323, -46.77862], [-23.55319, -46.77857], [-23.55308, -46.77845], [-23.55305, -46.77841], [-23.55294, -46.77828], [-23.55275, -46.77807], [-23.55262, -46.77793], [-23.55248, -46.77781], [-23.55235, -46.77767], [-23.55229, -46.7776], [-23.55213, -46.77746], [-23.55201, -46.77734], [-23.55187, -46.77724], [-23.55172, -46.77715], [-23.55146, -46.777], [-23.55124, -46.7769], [-23.55108, -46.77684], [-23.55094, -46.77678], [-23.55077, -46.77671], [-23.55063, -46.77666], [-23.55049, -46.77661], [-23.55035, -46.77656], [-23.5502, -46.77651], [-23.55002, -46.77646], [-23.54983, -46.77641], [-23.54979, -46.7764], [-23.5497, -46.77638], [-23.54962, -46.77635], [-23.54943, -46.77628], [-23.54864, -46.77593], [-23.54852, -46.77587], [-23.5483, -46.77578], [-23.54819, -46.7757], [-23.54809, -46.77562], [-23.54803, -46.77555], [-23.54796, -46.77547], [-23.54789, -46.77536], [-23.54784, -46.77525], [-23.5478, -46.77515], [-23.54776, -46.77503], [-23.54773, -46.77492], [-23.54772, -46.77489], [-23.54753, -46.77426], [-23.5474, -46.77378], [-23.54737, -46.77368], [-23.54729, -46.77341], [-23.54725, -46.77328], [-23.5472, -46.77315], [-23.54715, -46.77303], [-23.54708, -46.77292], [-23.547, -46.77278], [-23.54692, -46.77268], [-23.54682, -46.77257], [-23.5467, -46.77247], [-23.54659, -46.77238], [-23.54654, -46.77235], [-23.54655, -46.77227], [-23.54655, -46.77222], [-23.54654, -46.77217], [-23.54653, -46.77214], [-23.54674, -46.772], [-23.5468, -46.77197], [-23.54692, -46.77185], [-23.54698, -46.7717], [-23.547, -46.77165], [-23.54705, -46.77155], [-23.54708, -46.77149], [-23.54709, -46.77146], [-23.54718, -46.77133], [-23.54727, -46.77119], [-23.54734, -46.77111], [-23.54742, -46.77104], [-23.5475, -46.77094], [-23.54756, -46.77098], [-23.54761, -46.77099], [-23.54768, -46.77098], [-23.54784, -46.77095], [-23.54793, -46.77094], [-23.54807, -46.77087], [-23.54819, -46.7708], [-23.54825, -46.77077], [-23.54832, -46.77072], [-23.5483, -46.7707], [-23.54829, -46.77068], [-23.54829, -46.77065], [-23.54828, -46.77063], [-23.54828, -46.77059], [-23.54829, -46.77043], [-23.54829, -46.7703], [-23.54829, -46.77026], [-23.54828, -46.77015], [-23.54825, -46.77005], [-23.54821, -46.76992], [-23.54793, -46.77005], [-23.5478, -46.7701]]	5	route
cmngvpci8003x7y15c7574wv8	chk_mngkermg	alex@brspark.com	\N	COMPLETED	{"field_29355": "{\\"action\\":\\"CHEGADA\\",\\"timestamp\\":\\"2026-04-02T02:56:59.893Z\\",\\"coordinates\\":{\\"lat\\":-23.569983,\\"lng\\":-46.7851655},\\"address\\":\\"Parque Chico Mendes,  - Jd Bussocaba City, Osasco - SP\\",\\"traversedPath\\":[[-23.569983,-46.7851655]]}", "field_99100": "{\\"action\\":\\"SAIDA\\",\\"timestamp\\":\\"2026-04-02T02:52:15.050Z\\",\\"coordinates\\":{\\"lat\\":-23.569983,\\"lng\\":-46.7851655},\\"address\\":\\"Parque Chico Mendes,  - Jd Bussocaba City, Osasco - SP\\"}", "__time_field_29355": "2026-04-02T02:56:59.893Z", "__time_field_99100": "2026-04-02T02:52:15.050Z", "__section_end_page_1": "2026-04-02T02:57:02.527Z", "__section_start_page_1": "2026-04-02T02:52:15.070Z"}	{"icon": "build-outline", "refId": "chk_mngkermg", "title": "rota", "acceptedAt": "2026-04-02T02:52:09.238Z", "appVersion": "1.0", "receivedAt": "2026-04-02T02:51:57.086Z", "description": "234", "devicePlatform": "AppMovel", "durationSeconds": 219}	null	2026-04-02 02:53:22.952	2026-04-02 02:57:02.527	2026-04-02 02:57:02.623	2026-04-02 02:51:53.36	\N	\N	\N	null	\N	\N
cmnghkvus00035gk6o1gpbwu4	chk_mngeayfc	alex@brspark.com	\N	COMPLETED	{"__section_end_page_1": "2026-04-01T23:34:29.390Z"}	{"icon": "build-outline", "refId": "chk_mngeayfc", "title": "NOVO CHECKLIST", "acceptedAt": "2026-04-01T21:35:08.425Z", "appVersion": "1.0", "receivedAt": "2026-04-01T21:34:52.483Z", "description": "Tarefa de rotina despachada.", "devicePlatform": "AppMovel", "durationSeconds": 1}	null	2026-04-01 23:34:27.45	2026-04-01 23:34:29.39	2026-04-01 23:34:29.527	2026-04-01 20:16:30.531	\N	-23.557814	-46.781074	[[-23.56923, -46.78897], [-23.56911, -46.78881], [-23.56911, -46.7888], [-23.56912, -46.7888], [-23.56912, -46.78879], [-23.56912, -46.78878], [-23.56912, -46.78877], [-23.56912, -46.78876], [-23.56912, -46.78875], [-23.56911, -46.78874], [-23.56911, -46.78873], [-23.5691, -46.78873], [-23.5691, -46.78872], [-23.56909, -46.78872], [-23.56909, -46.78871], [-23.56908, -46.78871], [-23.56907, -46.78871], [-23.56906, -46.78871], [-23.56905, -46.78871], [-23.56904, -46.78871], [-23.56902, -46.78872], [-23.56902, -46.78873], [-23.56901, -46.78873], [-23.56901, -46.78874], [-23.56901, -46.78875], [-23.569, -46.78875], [-23.569, -46.78876], [-23.569, -46.78877], [-23.569, -46.78878], [-23.5689, -46.78884], [-23.56876, -46.78895], [-23.56873, -46.78897], [-23.56871, -46.789], [-23.56865, -46.78906], [-23.56839, -46.78925], [-23.56826, -46.78935], [-23.56796, -46.78956], [-23.56777, -46.78972], [-23.56765, -46.78954], [-23.56761, -46.78949], [-23.56757, -46.78943], [-23.56752, -46.78937], [-23.56748, -46.78933], [-23.56744, -46.78926], [-23.56737, -46.78915], [-23.56729, -46.78897], [-23.56727, -46.78892], [-23.56718, -46.78874], [-23.5671, -46.78855], [-23.56708, -46.78853], [-23.56706, -46.7885], [-23.56703, -46.78845], [-23.567, -46.78841], [-23.56697, -46.78838], [-23.56692, -46.78835], [-23.56687, -46.78833], [-23.5668, -46.7883], [-23.56663, -46.78824], [-23.56643, -46.78817], [-23.5662, -46.78809], [-23.56601, -46.78803], [-23.56588, -46.78797], [-23.56576, -46.78793], [-23.56571, -46.78791], [-23.56537, -46.78779], [-23.56521, -46.78773], [-23.56515, -46.78771], [-23.56501, -46.78766], [-23.56492, -46.78763], [-23.56486, -46.78759], [-23.56483, -46.78758], [-23.56478, -46.78753], [-23.56473, -46.78748], [-23.56468, -46.78742], [-23.56461, -46.78732], [-23.56446, -46.78707], [-23.5644, -46.78697], [-23.56436, -46.7869], [-23.56431, -46.7868], [-23.56425, -46.78666], [-23.5642, -46.78653], [-23.56414, -46.7864], [-23.56409, -46.78631], [-23.56404, -46.78621], [-23.56403, -46.78617], [-23.56398, -46.78605], [-23.56396, -46.78599], [-23.5639, -46.78582], [-23.56382, -46.78563], [-23.56364, -46.78524], [-23.56354, -46.78504], [-23.56343, -46.7848], [-23.56332, -46.78456], [-23.56329, -46.7845], [-23.56301, -46.78385], [-23.56297, -46.78376], [-23.56291, -46.78362], [-23.56286, -46.78349], [-23.56284, -46.78331], [-23.56274, -46.78324], [-23.56264, -46.78318], [-23.5626, -46.78316], [-23.56253, -46.78312], [-23.56239, -46.78309], [-23.56223, -46.78307], [-23.56212, -46.78307], [-23.5618, -46.78306], [-23.56167, -46.78306], [-23.56147, -46.78305], [-23.56124, -46.78302], [-23.56117, -46.78301], [-23.5609, -46.78298], [-23.56048, -46.78289], [-23.56006, -46.78276], [-23.55988, -46.78271], [-23.55957, -46.78261], [-23.55934, -46.78252], [-23.55918, -46.78246], [-23.55902, -46.78239], [-23.55854, -46.78218], [-23.55831, -46.78207], [-23.55782, -46.78184], [-23.55764, -46.78176], [-23.55742, -46.78165], [-23.55715, -46.78152], [-23.55714, -46.78152], [-23.55661, -46.78127], [-23.55633, -46.78113], [-23.55616, -46.78105], [-23.55585, -46.7809], [-23.55578, -46.78087], [-23.55567, -46.78083], [-23.55558, -46.78079], [-23.55546, -46.78075], [-23.55517, -46.78063], [-23.55508, -46.78059], [-23.55499, -46.78055], [-23.5549, -46.7805], [-23.55484, -46.78046], [-23.55479, -46.78043], [-23.55472, -46.78039], [-23.55464, -46.78034], [-23.55453, -46.78026], [-23.55446, -46.7802], [-23.55437, -46.78012], [-23.55427, -46.78002], [-23.55413, -46.77987], [-23.55404, -46.77977], [-23.55393, -46.77962], [-23.55384, -46.7795], [-23.55375, -46.77934], [-23.55364, -46.77916], [-23.55348, -46.77893], [-23.55336, -46.77877], [-23.55323, -46.77862], [-23.55319, -46.77857], [-23.55308, -46.77845], [-23.55305, -46.77841], [-23.55294, -46.77828], [-23.55275, -46.77807], [-23.55262, -46.77793], [-23.55248, -46.77781], [-23.55235, -46.77767], [-23.55229, -46.7776], [-23.55213, -46.77746], [-23.55201, -46.77734], [-23.55187, -46.77724], [-23.55172, -46.77715], [-23.55146, -46.777], [-23.55124, -46.7769], [-23.55108, -46.77684], [-23.55094, -46.77678], [-23.55077, -46.77671], [-23.55063, -46.77666], [-23.55049, -46.77661], [-23.55035, -46.77656], [-23.5502, -46.77651], [-23.55002, -46.77646], [-23.54983, -46.77641], [-23.54979, -46.7764], [-23.5497, -46.77638], [-23.54962, -46.77635], [-23.54943, -46.77628], [-23.54864, -46.77593], [-23.54852, -46.77587], [-23.5483, -46.77578], [-23.54819, -46.7757], [-23.54809, -46.77562], [-23.54803, -46.77555], [-23.54796, -46.77547], [-23.54789, -46.77536], [-23.54784, -46.77525], [-23.5478, -46.77515], [-23.54776, -46.77503], [-23.54773, -46.77492], [-23.54772, -46.77489], [-23.54753, -46.77426], [-23.5474, -46.77378], [-23.54737, -46.77368], [-23.54729, -46.77341], [-23.54725, -46.77328], [-23.5472, -46.77315], [-23.54715, -46.77303], [-23.54708, -46.77292], [-23.547, -46.77278], [-23.54692, -46.77268], [-23.54682, -46.77257], [-23.5467, -46.77247], [-23.54659, -46.77238], [-23.54654, -46.77235], [-23.54655, -46.77227], [-23.54655, -46.77222], [-23.54654, -46.77217], [-23.54653, -46.77214], [-23.54674, -46.772], [-23.5468, -46.77197], [-23.54692, -46.77185], [-23.54698, -46.7717], [-23.547, -46.77165], [-23.54705, -46.77155], [-23.54708, -46.77149], [-23.54709, -46.77146], [-23.54718, -46.77133], [-23.54727, -46.77119], [-23.54734, -46.77111], [-23.54742, -46.77104], [-23.5475, -46.77094], [-23.54756, -46.77098], [-23.54761, -46.77099], [-23.54768, -46.77098], [-23.54784, -46.77095], [-23.54793, -46.77094], [-23.54807, -46.77087], [-23.54819, -46.7708], [-23.54825, -46.77077], [-23.54832, -46.77072], [-23.5483, -46.7707], [-23.54829, -46.77068], [-23.54829, -46.77065], [-23.54828, -46.77063], [-23.54828, -46.77059], [-23.54829, -46.77043], [-23.54829, -46.7703], [-23.54829, -46.77026], [-23.54828, -46.77015], [-23.54825, -46.77005], [-23.54821, -46.76992], [-23.54793, -46.77005], [-23.5478, -46.7701]]	\N	\N
cmng4w2zz000bz0j797zohnli	chk_mnen95p1d55	alex@brspark.com	\N	COMPLETED	{"field_38889": "{\\"action\\":\\"SAIDA\\",\\"timestamp\\":\\"2026-04-01T21:40:44.211Z\\",\\"coordinates\\":{\\"lat\\":37.33015896,\\"lng\\":-122.03149531},\\"address\\":\\"N De Anza Blvd, 10500 - Santa Clara, Cupertino - CA\\"}", "field_69277": "{\\"action\\":\\"CHEGADA\\",\\"timestamp\\":\\"2026-04-01T23:34:38.386Z\\",\\"coordinates\\":{\\"lat\\":37.3347473,\\"lng\\":-122.02357773},\\"address\\":\\"N Blaney Ave, 10860–10864 - Santa Clara, Cupertino - CA\\"}", "field_71925": "SIG_V1|meta:{\\"lat\\":37.33543519,\\"lng\\":-122.02351114,\\"address\\":\\"N Blaney Ave, 10860 - Cupertino, CA\\",\\"ip\\":\\"2804:7f0:9383:8b58:b9fe:d321:ec05:865c\\"}|M204,72.00000127156574 L180.66666666666666,83.66666793823242 L165,103.00000127156574 L164,114.66666793823242 L162.66666666666666,138.00000127156574 L156.66666666666666,149.66666793823242 L146.33333333333331,156.66666793823242 L134.66666666666666,157.66666793823242 L128.33333333333331,152.33333460489905 L126,142.66666793823242 L127.33333333333331,125.33333460489905 L140.33333333333331,106.66666793823242 L160.66666666666666,96.33333460489905 L178.33333333333331,92.33333460489905 L187,96.33333460489905 L190.33333333333331,101.00000127156574 L193.33333333333331,106.66666793823242 L194.66666666666666,109.33333460489905 L199.33333333333331,113.33333460489905", "__time_field_38889": "2026-04-01T21:40:44.211Z", "__time_field_69277": "2026-04-01T23:34:38.386Z", "__time_field_71925": "2026-04-01T23:34:47.403Z", "__section_end_field_68093": "2026-04-01T23:34:48.486Z", "__section_start_field_68093": "2026-04-01T21:40:44.223Z"}	{"icon": "", "refId": "chk_mnen95p1d55", "title": "231222a (Cópia)", "acceptedAt": "2026-04-01T21:40:42.028Z", "appVersion": "1.0", "receivedAt": "2026-04-01T14:21:22.596Z", "description": "Enviado de forma manual para vistoria.", "devicePlatform": "AppMovel", "durationSeconds": 16}	null	2026-04-01 23:34:32.242	2026-04-01 23:34:48.486	2026-04-01 23:34:48.736	2026-04-01 14:21:17.999	\N	\N	\N	null	\N	\N
cmnfe17d1005d2jj03wpq6n76	chk_mnen95p1d55	alex@brspark.com	\N	COMPLETED	{"field_38889": "{\\"action\\":\\"SAIDA\\",\\"timestamp\\":\\"2026-04-01T21:43:19.834Z\\",\\"coordinates\\":{\\"lat\\":37.33022749,\\"lng\\":-122.02401267},\\"address\\":\\"Merritt Dr, 20046 - Santa Clara, Cupertino - CA\\"}", "field_69277": "{\\"action\\":\\"CHEGADA\\",\\"timestamp\\":\\"2026-04-01T23:34:55.082Z\\",\\"coordinates\\":{\\"lat\\":37.33617936,\\"lng\\":-122.02327117},\\"address\\":\\"N Blaney Ave, 10900 - Santa Clara, Cupertino - CA\\"}", "__time_field_38889": "2026-04-01T21:43:19.834Z", "__time_field_69277": "2026-04-01T23:34:55.083Z", "__section_end_field_68093": "2026-04-01T23:34:57.967Z", "__section_start_field_68093": "2026-04-01T21:43:19.848Z"}	{"icon": "", "refId": "chk_mnen95p1d55", "title": "231222a (Cópia)", "acceptedAt": "2026-04-01T21:43:17.958Z", "appVersion": "1.0", "receivedAt": "2026-04-01T01:49:28.348Z", "description": "Enviado de forma manual para vistoria.", "devicePlatform": "AppMovel", "durationSeconds": 6}	null	2026-04-01 23:34:51.901	2026-04-01 23:34:57.967	2026-04-01 23:34:58.043	2026-04-01 01:49:27.296	\N	\N	\N	\N	\N	\N
cmnguurlj00237y151e1oi50r	chk_mngkermg	alex@brspark.com	\N	COMPLETED	{"field_29355": "{\\"action\\":\\"CHEGADA\\",\\"timestamp\\":\\"2026-04-02T02:45:53.593Z\\",\\"coordinates\\":{\\"lat\\":-23.569983,\\"lng\\":-46.7851655},\\"address\\":\\"Parque Chico Mendes,  - Jd Bussocaba City, Osasco - SP\\",\\"traversedPath\\":[[-23.569983,-46.7851655]]}", "field_99100": "{\\"action\\":\\"SAIDA\\",\\"timestamp\\":\\"2026-04-02T02:28:14.621Z\\",\\"coordinates\\":{\\"lat\\":-23.569983,\\"lng\\":-46.7851655},\\"address\\":\\"Parque Chico Mendes,  - Jd Bussocaba City, Osasco - SP\\"}", "__time_field_29355": "2026-04-02T02:45:53.593Z", "__time_field_99100": "2026-04-02T02:28:14.621Z", "__section_end_page_1": "2026-04-02T02:45:56.681Z", "__section_start_page_1": "2026-04-02T02:28:14.629Z"}	{"icon": "build-outline", "refId": "chk_mngkermg", "title": "rota", "acceptedAt": "2026-04-02T02:28:12.381Z", "appVersion": "1.0", "receivedAt": "2026-04-02T02:28:06.890Z", "description": "Tarefa de rotina despachada.", "devicePlatform": "AppMovel", "durationSeconds": 56}	null	2026-04-02 02:45:00.469	2026-04-02 02:45:56.681	2026-04-02 02:45:56.764	2026-04-02 02:28:06.583	\N	\N	\N	null	\N	\N
cmngvvusi004v7y15iaa2csc1	chk_mngkermg	alex@brspark.com	\N	COMPLETED	{"field_29355": "{\\"action\\":\\"CHEGADA\\",\\"timestamp\\":\\"2026-04-02T03:02:39.049Z\\",\\"coordinates\\":{\\"lat\\":-23.569983,\\"lng\\":-46.7851655},\\"address\\":\\"Parque Chico Mendes,  - Jd Bussocaba City, Osasco - SP\\"}", "field_99100": "{\\"action\\":\\"SAIDA\\",\\"timestamp\\":\\"2026-04-02T03:02:24.910Z\\",\\"coordinates\\":{\\"lat\\":-23.569983,\\"lng\\":-46.7851655},\\"address\\":\\"Parque Chico Mendes,  - Jd Bussocaba City, Osasco - SP\\"}", "__time_field_29355": "2026-04-02T03:02:39.049Z", "__time_field_99100": "2026-04-02T03:02:24.912Z", "__section_end_page_1": "2026-04-02T03:02:40.978Z", "__section_start_page_1": "2026-04-02T03:02:24.960Z"}	{"icon": "build-outline", "refId": "chk_mngkermg", "title": "rota", "acceptedAt": "2026-04-02T02:57:10.409Z", "appVersion": "1.0", "receivedAt": "2026-04-02T02:57:00.020Z", "description": "Tarefa de rotina despachada.", "devicePlatform": "AppMovel", "durationSeconds": 280}	null	2026-04-02 02:58:00.568	2026-04-02 03:02:40.978	2026-04-02 03:02:41.111	2026-04-02 02:56:56.993	\N	-23.557814	-46.781074	[[-23.56923, -46.78897], [-23.56911, -46.78881], [-23.56911, -46.7888], [-23.56912, -46.7888], [-23.56912, -46.78879], [-23.56912, -46.78878], [-23.56912, -46.78877], [-23.56912, -46.78876], [-23.56912, -46.78875], [-23.56911, -46.78874], [-23.56911, -46.78873], [-23.5691, -46.78873], [-23.5691, -46.78872], [-23.56909, -46.78872], [-23.56909, -46.78871], [-23.56908, -46.78871], [-23.56907, -46.78871], [-23.56906, -46.78871], [-23.56905, -46.78871], [-23.56904, -46.78871], [-23.56902, -46.78872], [-23.56902, -46.78873], [-23.56901, -46.78873], [-23.56901, -46.78874], [-23.56901, -46.78875], [-23.569, -46.78875], [-23.569, -46.78876], [-23.569, -46.78877], [-23.569, -46.78878], [-23.5689, -46.78884], [-23.56876, -46.78895], [-23.56873, -46.78897], [-23.56871, -46.789], [-23.56865, -46.78906], [-23.56839, -46.78925], [-23.56826, -46.78935], [-23.56796, -46.78956], [-23.56777, -46.78972], [-23.56765, -46.78954], [-23.56761, -46.78949], [-23.56757, -46.78943], [-23.56752, -46.78937], [-23.56748, -46.78933], [-23.56744, -46.78926], [-23.56737, -46.78915], [-23.56729, -46.78897], [-23.56727, -46.78892], [-23.56718, -46.78874], [-23.5671, -46.78855], [-23.56708, -46.78853], [-23.56706, -46.7885], [-23.56703, -46.78845], [-23.567, -46.78841], [-23.56697, -46.78838], [-23.56692, -46.78835], [-23.56687, -46.78833], [-23.5668, -46.7883], [-23.56663, -46.78824], [-23.56643, -46.78817], [-23.5662, -46.78809], [-23.56601, -46.78803], [-23.56588, -46.78797], [-23.56576, -46.78793], [-23.56571, -46.78791], [-23.56537, -46.78779], [-23.56521, -46.78773], [-23.56515, -46.78771], [-23.56501, -46.78766], [-23.56492, -46.78763], [-23.56486, -46.78759], [-23.56483, -46.78758], [-23.56478, -46.78753], [-23.56473, -46.78748], [-23.56468, -46.78742], [-23.56461, -46.78732], [-23.56446, -46.78707], [-23.5644, -46.78697], [-23.56436, -46.7869], [-23.56431, -46.7868], [-23.56425, -46.78666], [-23.5642, -46.78653], [-23.56414, -46.7864], [-23.56409, -46.78631], [-23.56404, -46.78621], [-23.56403, -46.78617], [-23.56398, -46.78605], [-23.56396, -46.78599], [-23.5639, -46.78582], [-23.56382, -46.78563], [-23.56364, -46.78524], [-23.56354, -46.78504], [-23.56343, -46.7848], [-23.56332, -46.78456], [-23.56329, -46.7845], [-23.56301, -46.78385], [-23.56297, -46.78376], [-23.56291, -46.78362], [-23.56286, -46.78349], [-23.56284, -46.78331], [-23.56274, -46.78324], [-23.56264, -46.78318], [-23.5626, -46.78316], [-23.56253, -46.78312], [-23.56239, -46.78309], [-23.56223, -46.78307], [-23.56212, -46.78307], [-23.5618, -46.78306], [-23.56167, -46.78306], [-23.56147, -46.78305], [-23.56124, -46.78302], [-23.56117, -46.78301], [-23.5609, -46.78298], [-23.56048, -46.78289], [-23.56006, -46.78276], [-23.55988, -46.78271], [-23.55957, -46.78261], [-23.55934, -46.78252], [-23.55918, -46.78246], [-23.55902, -46.78239], [-23.55854, -46.78218], [-23.55831, -46.78207], [-23.55782, -46.78184], [-23.55764, -46.78176], [-23.55742, -46.78165], [-23.55715, -46.78152], [-23.55714, -46.78152], [-23.55661, -46.78127], [-23.55633, -46.78113], [-23.55616, -46.78105], [-23.55585, -46.7809], [-23.55578, -46.78087], [-23.55567, -46.78083], [-23.55558, -46.78079], [-23.55546, -46.78075], [-23.55517, -46.78063], [-23.55508, -46.78059], [-23.55499, -46.78055], [-23.5549, -46.7805], [-23.55484, -46.78046], [-23.55479, -46.78043], [-23.55472, -46.78039], [-23.55464, -46.78034], [-23.55453, -46.78026], [-23.55446, -46.7802], [-23.55437, -46.78012], [-23.55427, -46.78002], [-23.55413, -46.77987], [-23.55404, -46.77977], [-23.55393, -46.77962], [-23.55384, -46.7795], [-23.55375, -46.77934], [-23.55364, -46.77916], [-23.55348, -46.77893], [-23.55336, -46.77877], [-23.55323, -46.77862], [-23.55319, -46.77857], [-23.55308, -46.77845], [-23.55305, -46.77841], [-23.55294, -46.77828], [-23.55275, -46.77807], [-23.55262, -46.77793], [-23.55248, -46.77781], [-23.55235, -46.77767], [-23.55229, -46.7776], [-23.55213, -46.77746], [-23.55201, -46.77734], [-23.55187, -46.77724], [-23.55172, -46.77715], [-23.55146, -46.777], [-23.55124, -46.7769], [-23.55108, -46.77684], [-23.55094, -46.77678], [-23.55077, -46.77671], [-23.55063, -46.77666], [-23.55049, -46.77661], [-23.55035, -46.77656], [-23.5502, -46.77651], [-23.55002, -46.77646], [-23.54983, -46.77641], [-23.54979, -46.7764], [-23.5497, -46.77638], [-23.54962, -46.77635], [-23.54943, -46.77628], [-23.54864, -46.77593], [-23.54852, -46.77587], [-23.5483, -46.77578], [-23.54819, -46.7757], [-23.54809, -46.77562], [-23.54803, -46.77555], [-23.54796, -46.77547], [-23.54789, -46.77536], [-23.54784, -46.77525], [-23.5478, -46.77515], [-23.54776, -46.77503], [-23.54773, -46.77492], [-23.54772, -46.77489], [-23.54753, -46.77426], [-23.5474, -46.77378], [-23.54737, -46.77368], [-23.54729, -46.77341], [-23.54725, -46.77328], [-23.5472, -46.77315], [-23.54715, -46.77303], [-23.54708, -46.77292], [-23.547, -46.77278], [-23.54692, -46.77268], [-23.54682, -46.77257], [-23.5467, -46.77247], [-23.54659, -46.77238], [-23.54654, -46.77235], [-23.54655, -46.77227], [-23.54655, -46.77222], [-23.54654, -46.77217], [-23.54653, -46.77214], [-23.54674, -46.772], [-23.5468, -46.77197], [-23.54692, -46.77185], [-23.54698, -46.7717], [-23.547, -46.77165], [-23.54705, -46.77155], [-23.54708, -46.77149], [-23.54709, -46.77146], [-23.54718, -46.77133], [-23.54727, -46.77119], [-23.54734, -46.77111], [-23.54742, -46.77104], [-23.5475, -46.77094], [-23.54756, -46.77098], [-23.54761, -46.77099], [-23.54768, -46.77098], [-23.54784, -46.77095], [-23.54793, -46.77094], [-23.54807, -46.77087], [-23.54819, -46.7708], [-23.54825, -46.77077], [-23.54832, -46.77072], [-23.5483, -46.7707], [-23.54829, -46.77068], [-23.54829, -46.77065], [-23.54828, -46.77063], [-23.54828, -46.77059], [-23.54829, -46.77043], [-23.54829, -46.7703], [-23.54829, -46.77026], [-23.54828, -46.77015], [-23.54825, -46.77005], [-23.54821, -46.76992], [-23.54793, -46.77005], [-23.5478, -46.7701]]	100	route
cmngkrsv400165gk6o4zger3j	chk_mngkermg	alex@brspark.com	\N	COMPLETED	{"field_99100": "{\\"action\\":\\"SAIDA\\",\\"timestamp\\":\\"2026-04-01T23:35:06.940Z\\",\\"coordinates\\":{\\"lat\\":37.33718079,\\"lng\\":-122.02322984},\\"address\\":\\"E Homestead Rd, 19998 - Santa Clara, Cupertino - CA\\"}", "__time_field_99100": "2026-04-01T23:35:06.940Z", "__section_end_page_1": "2026-04-01T23:36:07.815Z", "__section_start_page_1": "2026-04-01T23:35:06.950Z"}	{"icon": "build-outline", "refId": "chk_mngkermg", "title": "rota", "acceptedAt": "2026-04-01T23:35:04.588Z", "appVersion": "1.0", "receivedAt": "2026-04-01T21:45:52.370Z", "description": "Tarefa de rotina despachada.", "devicePlatform": "AppMovel", "durationSeconds": 63}	null	2026-04-01 23:35:04.62	2026-04-01 23:36:07.815	2026-04-01 23:36:07.889	2026-04-01 21:45:52.095	\N	\N	\N	null	\N	\N
cmngopj6400505gk6wobkw5wa	chk_mngkermg	alex@brspark.com	\N	COMPLETED	{"field_29355": "{\\"action\\":\\"CHEGADA\\",\\"timestamp\\":\\"2026-04-01T23:37:03.021Z\\",\\"coordinates\\":{\\"lat\\":37.3376901,\\"lng\\":-122.02894216},\\"address\\":\\"E Homestead Rd,  - Ortega Park, Sunnyvale - CA\\"}", "field_99100": "{\\"action\\":\\"SAIDA\\",\\"timestamp\\":\\"2026-04-01T23:36:29.832Z\\",\\"coordinates\\":{\\"lat\\":37.33764583,\\"lng\\":-122.02632513},\\"address\\":\\"E Homestead Rd, 573–579 - Ortega Park, Cupertino - CA\\"}", "__time_field_29355": "2026-04-01T23:37:03.021Z", "__time_field_99100": "2026-04-01T23:36:29.832Z", "__section_end_page_1": "2026-04-01T23:37:06.072Z", "__section_start_page_1": "2026-04-01T23:36:29.844Z"}	{"icon": "build-outline", "refId": "chk_mngkermg", "title": "rota", "acceptedAt": "2026-04-01T23:36:27.554Z", "appVersion": "1.0", "receivedAt": "2026-04-01T23:36:07.068Z", "description": "Tarefa de rotina despachada.", "devicePlatform": "AppMovel", "durationSeconds": 38}	null	2026-04-01 23:36:27.584	2026-04-01 23:37:06.072	2026-04-01 23:37:06.169	2026-04-01 23:36:04.683	\N	-23.557814	-46.781074	[[-23.56923, -46.78897], [-23.56911, -46.78881], [-23.56911, -46.7888], [-23.56912, -46.7888], [-23.56912, -46.78879], [-23.56912, -46.78878], [-23.56912, -46.78877], [-23.56912, -46.78876], [-23.56912, -46.78875], [-23.56911, -46.78874], [-23.56911, -46.78873], [-23.5691, -46.78873], [-23.5691, -46.78872], [-23.56909, -46.78872], [-23.56909, -46.78871], [-23.56908, -46.78871], [-23.56907, -46.78871], [-23.56906, -46.78871], [-23.56905, -46.78871], [-23.56904, -46.78871], [-23.56902, -46.78872], [-23.56902, -46.78873], [-23.56901, -46.78873], [-23.56901, -46.78874], [-23.56901, -46.78875], [-23.569, -46.78875], [-23.569, -46.78876], [-23.569, -46.78877], [-23.569, -46.78878], [-23.5689, -46.78884], [-23.56876, -46.78895], [-23.56873, -46.78897], [-23.56871, -46.789], [-23.56865, -46.78906], [-23.56839, -46.78925], [-23.56826, -46.78935], [-23.56796, -46.78956], [-23.56777, -46.78972], [-23.56765, -46.78954], [-23.56761, -46.78949], [-23.56757, -46.78943], [-23.56752, -46.78937], [-23.56748, -46.78933], [-23.56744, -46.78926], [-23.56737, -46.78915], [-23.56729, -46.78897], [-23.56727, -46.78892], [-23.56718, -46.78874], [-23.5671, -46.78855], [-23.56708, -46.78853], [-23.56706, -46.7885], [-23.56703, -46.78845], [-23.567, -46.78841], [-23.56697, -46.78838], [-23.56692, -46.78835], [-23.56687, -46.78833], [-23.5668, -46.7883], [-23.56663, -46.78824], [-23.56643, -46.78817], [-23.5662, -46.78809], [-23.56601, -46.78803], [-23.56588, -46.78797], [-23.56576, -46.78793], [-23.56571, -46.78791], [-23.56537, -46.78779], [-23.56521, -46.78773], [-23.56515, -46.78771], [-23.56501, -46.78766], [-23.56492, -46.78763], [-23.56486, -46.78759], [-23.56483, -46.78758], [-23.56478, -46.78753], [-23.56473, -46.78748], [-23.56468, -46.78742], [-23.56461, -46.78732], [-23.56446, -46.78707], [-23.5644, -46.78697], [-23.56436, -46.7869], [-23.56431, -46.7868], [-23.56425, -46.78666], [-23.5642, -46.78653], [-23.56414, -46.7864], [-23.56409, -46.78631], [-23.56404, -46.78621], [-23.56403, -46.78617], [-23.56398, -46.78605], [-23.56396, -46.78599], [-23.5639, -46.78582], [-23.56382, -46.78563], [-23.56364, -46.78524], [-23.56354, -46.78504], [-23.56343, -46.7848], [-23.56332, -46.78456], [-23.56329, -46.7845], [-23.56301, -46.78385], [-23.56297, -46.78376], [-23.56291, -46.78362], [-23.56286, -46.78349], [-23.56284, -46.78331], [-23.56274, -46.78324], [-23.56264, -46.78318], [-23.5626, -46.78316], [-23.56253, -46.78312], [-23.56239, -46.78309], [-23.56223, -46.78307], [-23.56212, -46.78307], [-23.5618, -46.78306], [-23.56167, -46.78306], [-23.56147, -46.78305], [-23.56124, -46.78302], [-23.56117, -46.78301], [-23.5609, -46.78298], [-23.56048, -46.78289], [-23.56006, -46.78276], [-23.55988, -46.78271], [-23.55957, -46.78261], [-23.55934, -46.78252], [-23.55918, -46.78246], [-23.55902, -46.78239], [-23.55854, -46.78218], [-23.55831, -46.78207], [-23.55782, -46.78184], [-23.55764, -46.78176], [-23.55742, -46.78165], [-23.55715, -46.78152], [-23.55714, -46.78152], [-23.55661, -46.78127], [-23.55633, -46.78113], [-23.55616, -46.78105], [-23.55585, -46.7809], [-23.55578, -46.78087], [-23.55567, -46.78083], [-23.55558, -46.78079], [-23.55546, -46.78075], [-23.55517, -46.78063], [-23.55508, -46.78059], [-23.55499, -46.78055], [-23.5549, -46.7805], [-23.55484, -46.78046], [-23.55479, -46.78043], [-23.55472, -46.78039], [-23.55464, -46.78034], [-23.55453, -46.78026], [-23.55446, -46.7802], [-23.55437, -46.78012], [-23.55427, -46.78002], [-23.55413, -46.77987], [-23.55404, -46.77977], [-23.55393, -46.77962], [-23.55384, -46.7795], [-23.55375, -46.77934], [-23.55364, -46.77916], [-23.55348, -46.77893], [-23.55336, -46.77877], [-23.55323, -46.77862], [-23.55319, -46.77857], [-23.55308, -46.77845], [-23.55305, -46.77841], [-23.55294, -46.77828], [-23.55275, -46.77807], [-23.55262, -46.77793], [-23.55248, -46.77781], [-23.55235, -46.77767], [-23.55229, -46.7776], [-23.55213, -46.77746], [-23.55201, -46.77734], [-23.55187, -46.77724], [-23.55172, -46.77715], [-23.55146, -46.777], [-23.55124, -46.7769], [-23.55108, -46.77684], [-23.55094, -46.77678], [-23.55077, -46.77671], [-23.55063, -46.77666], [-23.55049, -46.77661], [-23.55035, -46.77656], [-23.5502, -46.77651], [-23.55002, -46.77646], [-23.54983, -46.77641], [-23.54979, -46.7764], [-23.5497, -46.77638], [-23.54962, -46.77635], [-23.54943, -46.77628], [-23.54864, -46.77593], [-23.54852, -46.77587], [-23.5483, -46.77578], [-23.54819, -46.7757], [-23.54809, -46.77562], [-23.54803, -46.77555], [-23.54796, -46.77547], [-23.54789, -46.77536], [-23.54784, -46.77525], [-23.5478, -46.77515], [-23.54776, -46.77503], [-23.54773, -46.77492], [-23.54772, -46.77489], [-23.54753, -46.77426], [-23.5474, -46.77378], [-23.54737, -46.77368], [-23.54729, -46.77341], [-23.54725, -46.77328], [-23.5472, -46.77315], [-23.54715, -46.77303], [-23.54708, -46.77292], [-23.547, -46.77278], [-23.54692, -46.77268], [-23.54682, -46.77257], [-23.5467, -46.77247], [-23.54659, -46.77238], [-23.54654, -46.77235], [-23.54655, -46.77227], [-23.54655, -46.77222], [-23.54654, -46.77217], [-23.54653, -46.77214], [-23.54674, -46.772], [-23.5468, -46.77197], [-23.54692, -46.77185], [-23.54698, -46.7717], [-23.547, -46.77165], [-23.54705, -46.77155], [-23.54708, -46.77149], [-23.54709, -46.77146], [-23.54718, -46.77133], [-23.54727, -46.77119], [-23.54734, -46.77111], [-23.54742, -46.77104], [-23.5475, -46.77094], [-23.54756, -46.77098], [-23.54761, -46.77099], [-23.54768, -46.77098], [-23.54784, -46.77095], [-23.54793, -46.77094], [-23.54807, -46.77087], [-23.54819, -46.7708], [-23.54825, -46.77077], [-23.54832, -46.77072], [-23.5483, -46.7707], [-23.54829, -46.77068], [-23.54829, -46.77065], [-23.54828, -46.77063], [-23.54828, -46.77059], [-23.54829, -46.77043], [-23.54829, -46.7703], [-23.54829, -46.77026], [-23.54828, -46.77015], [-23.54825, -46.77005], [-23.54821, -46.76992], [-23.54793, -46.77005], [-23.5478, -46.7701]]	\N	\N
cmngowgfk0006fsuf9izpfj4k	chk_mngkermg	alex@brspark.com	\N	COMPLETED	{"field_29355": "{\\"action\\":\\"CHEGADA\\",\\"timestamp\\":\\"2026-04-02T00:00:01.105Z\\",\\"coordinates\\":{\\"lat\\":-23.569983,\\"lng\\":-46.7851655},\\"address\\":\\"Parque Chico Mendes,  - Jd Bussocaba City, Osasco - SP\\"}", "field_99100": "{\\"action\\":\\"SAIDA\\",\\"timestamp\\":\\"2026-04-01T23:47:23.650Z\\",\\"coordinates\\":{\\"lat\\":-23.569983,\\"lng\\":-46.7851655},\\"address\\":\\"Parque Chico Mendes,  - Jd Bussocaba City, Osasco - SP\\"}", "__time_field_29355": "2026-04-02T00:00:01.105Z", "__time_field_99100": "2026-04-01T23:47:23.650Z", "__section_end_page_1": "2026-04-02T00:00:03.285Z", "__section_start_page_1": "2026-04-01T23:47:23.665Z"}	{"icon": "build-outline", "refId": "chk_mngkermg", "title": "rota", "acceptedAt": "2026-04-01T23:41:59.408Z", "appVersion": "1.0", "receivedAt": "2026-04-01T23:41:27.951Z", "description": "Tarefa de rotina despachada.", "devicePlatform": "AppMovel", "durationSeconds": 368}	null	2026-04-01 23:53:54.542	2026-04-02 00:00:03.286	2026-04-02 00:00:03.493	2026-04-01 23:41:27.728	\N	-23.557814	-46.781074	[[-23.56923, -46.78897], [-23.56911, -46.78881], [-23.56911, -46.7888], [-23.56912, -46.7888], [-23.56912, -46.78879], [-23.56912, -46.78878], [-23.56912, -46.78877], [-23.56912, -46.78876], [-23.56912, -46.78875], [-23.56911, -46.78874], [-23.56911, -46.78873], [-23.5691, -46.78873], [-23.5691, -46.78872], [-23.56909, -46.78872], [-23.56909, -46.78871], [-23.56908, -46.78871], [-23.56907, -46.78871], [-23.56906, -46.78871], [-23.56905, -46.78871], [-23.56904, -46.78871], [-23.56902, -46.78872], [-23.56902, -46.78873], [-23.56901, -46.78873], [-23.56901, -46.78874], [-23.56901, -46.78875], [-23.569, -46.78875], [-23.569, -46.78876], [-23.569, -46.78877], [-23.569, -46.78878], [-23.5689, -46.78884], [-23.56876, -46.78895], [-23.56873, -46.78897], [-23.56871, -46.789], [-23.56865, -46.78906], [-23.56839, -46.78925], [-23.56826, -46.78935], [-23.56796, -46.78956], [-23.56777, -46.78972], [-23.56765, -46.78954], [-23.56761, -46.78949], [-23.56757, -46.78943], [-23.56752, -46.78937], [-23.56748, -46.78933], [-23.56744, -46.78926], [-23.56737, -46.78915], [-23.56729, -46.78897], [-23.56727, -46.78892], [-23.56718, -46.78874], [-23.5671, -46.78855], [-23.56708, -46.78853], [-23.56706, -46.7885], [-23.56703, -46.78845], [-23.567, -46.78841], [-23.56697, -46.78838], [-23.56692, -46.78835], [-23.56687, -46.78833], [-23.5668, -46.7883], [-23.56663, -46.78824], [-23.56643, -46.78817], [-23.5662, -46.78809], [-23.56601, -46.78803], [-23.56588, -46.78797], [-23.56576, -46.78793], [-23.56571, -46.78791], [-23.56537, -46.78779], [-23.56521, -46.78773], [-23.56515, -46.78771], [-23.56501, -46.78766], [-23.56492, -46.78763], [-23.56486, -46.78759], [-23.56483, -46.78758], [-23.56478, -46.78753], [-23.56473, -46.78748], [-23.56468, -46.78742], [-23.56461, -46.78732], [-23.56446, -46.78707], [-23.5644, -46.78697], [-23.56436, -46.7869], [-23.56431, -46.7868], [-23.56425, -46.78666], [-23.5642, -46.78653], [-23.56414, -46.7864], [-23.56409, -46.78631], [-23.56404, -46.78621], [-23.56403, -46.78617], [-23.56398, -46.78605], [-23.56396, -46.78599], [-23.5639, -46.78582], [-23.56382, -46.78563], [-23.56364, -46.78524], [-23.56354, -46.78504], [-23.56343, -46.7848], [-23.56332, -46.78456], [-23.56329, -46.7845], [-23.56301, -46.78385], [-23.56297, -46.78376], [-23.56291, -46.78362], [-23.56286, -46.78349], [-23.56284, -46.78331], [-23.56274, -46.78324], [-23.56264, -46.78318], [-23.5626, -46.78316], [-23.56253, -46.78312], [-23.56239, -46.78309], [-23.56223, -46.78307], [-23.56212, -46.78307], [-23.5618, -46.78306], [-23.56167, -46.78306], [-23.56147, -46.78305], [-23.56124, -46.78302], [-23.56117, -46.78301], [-23.5609, -46.78298], [-23.56048, -46.78289], [-23.56006, -46.78276], [-23.55988, -46.78271], [-23.55957, -46.78261], [-23.55934, -46.78252], [-23.55918, -46.78246], [-23.55902, -46.78239], [-23.55854, -46.78218], [-23.55831, -46.78207], [-23.55782, -46.78184], [-23.55764, -46.78176], [-23.55742, -46.78165], [-23.55715, -46.78152], [-23.55714, -46.78152], [-23.55661, -46.78127], [-23.55633, -46.78113], [-23.55616, -46.78105], [-23.55585, -46.7809], [-23.55578, -46.78087], [-23.55567, -46.78083], [-23.55558, -46.78079], [-23.55546, -46.78075], [-23.55517, -46.78063], [-23.55508, -46.78059], [-23.55499, -46.78055], [-23.5549, -46.7805], [-23.55484, -46.78046], [-23.55479, -46.78043], [-23.55472, -46.78039], [-23.55464, -46.78034], [-23.55453, -46.78026], [-23.55446, -46.7802], [-23.55437, -46.78012], [-23.55427, -46.78002], [-23.55413, -46.77987], [-23.55404, -46.77977], [-23.55393, -46.77962], [-23.55384, -46.7795], [-23.55375, -46.77934], [-23.55364, -46.77916], [-23.55348, -46.77893], [-23.55336, -46.77877], [-23.55323, -46.77862], [-23.55319, -46.77857], [-23.55308, -46.77845], [-23.55305, -46.77841], [-23.55294, -46.77828], [-23.55275, -46.77807], [-23.55262, -46.77793], [-23.55248, -46.77781], [-23.55235, -46.77767], [-23.55229, -46.7776], [-23.55213, -46.77746], [-23.55201, -46.77734], [-23.55187, -46.77724], [-23.55172, -46.77715], [-23.55146, -46.777], [-23.55124, -46.7769], [-23.55108, -46.77684], [-23.55094, -46.77678], [-23.55077, -46.77671], [-23.55063, -46.77666], [-23.55049, -46.77661], [-23.55035, -46.77656], [-23.5502, -46.77651], [-23.55002, -46.77646], [-23.54983, -46.77641], [-23.54979, -46.7764], [-23.5497, -46.77638], [-23.54962, -46.77635], [-23.54943, -46.77628], [-23.54864, -46.77593], [-23.54852, -46.77587], [-23.5483, -46.77578], [-23.54819, -46.7757], [-23.54809, -46.77562], [-23.54803, -46.77555], [-23.54796, -46.77547], [-23.54789, -46.77536], [-23.54784, -46.77525], [-23.5478, -46.77515], [-23.54776, -46.77503], [-23.54773, -46.77492], [-23.54772, -46.77489], [-23.54753, -46.77426], [-23.5474, -46.77378], [-23.54737, -46.77368], [-23.54729, -46.77341], [-23.54725, -46.77328], [-23.5472, -46.77315], [-23.54715, -46.77303], [-23.54708, -46.77292], [-23.547, -46.77278], [-23.54692, -46.77268], [-23.54682, -46.77257], [-23.5467, -46.77247], [-23.54659, -46.77238], [-23.54654, -46.77235], [-23.54655, -46.77227], [-23.54655, -46.77222], [-23.54654, -46.77217], [-23.54653, -46.77214], [-23.54674, -46.772], [-23.5468, -46.77197], [-23.54692, -46.77185], [-23.54698, -46.7717], [-23.547, -46.77165], [-23.54705, -46.77155], [-23.54708, -46.77149], [-23.54709, -46.77146], [-23.54718, -46.77133], [-23.54727, -46.77119], [-23.54734, -46.77111], [-23.54742, -46.77104], [-23.5475, -46.77094], [-23.54756, -46.77098], [-23.54761, -46.77099], [-23.54768, -46.77098], [-23.54784, -46.77095], [-23.54793, -46.77094], [-23.54807, -46.77087], [-23.54819, -46.7708], [-23.54825, -46.77077], [-23.54832, -46.77072], [-23.5483, -46.7707], [-23.54829, -46.77068], [-23.54829, -46.77065], [-23.54828, -46.77063], [-23.54828, -46.77059], [-23.54829, -46.77043], [-23.54829, -46.7703], [-23.54829, -46.77026], [-23.54828, -46.77015], [-23.54825, -46.77005], [-23.54821, -46.76992], [-23.54793, -46.77005], [-23.5478, -46.7701]]	\N	route
cmngvhh26003o7y156rnxr840	chk_mngkermg	alex@brspark.com	\N	COMPLETED	{"field_29355": "{\\"action\\":\\"CHEGADA\\",\\"timestamp\\":\\"2026-04-02T02:51:09.630Z\\",\\"coordinates\\":{\\"lat\\":-23.569983,\\"lng\\":-46.7851655},\\"address\\":\\"Parque Chico Mendes,  - Jd Bussocaba City, Osasco - SP\\",\\"traversedPath\\":[[-23.569983,-46.7851655]]}", "field_99100": "{\\"action\\":\\"SAIDA\\",\\"timestamp\\":\\"2026-04-02T02:46:37.864Z\\",\\"coordinates\\":{\\"lat\\":-23.569983,\\"lng\\":-46.7851655},\\"address\\":\\"Parque Chico Mendes,  - Jd Bussocaba City, Osasco - SP\\"}", "__time_field_29355": "2026-04-02T02:51:09.630Z", "__time_field_99100": "2026-04-02T02:46:37.865Z", "__section_end_page_1": "2026-04-02T02:51:20.381Z", "__section_start_page_1": "2026-04-02T02:46:37.881Z"}	{"icon": "build-outline", "refId": "chk_mngkermg", "title": "rota", "acceptedAt": "2026-04-02T02:46:03.070Z", "appVersion": "1.0", "receivedAt": "2026-04-02T02:45:51.027Z", "description": "Tarefa de rotina despachada.", "devicePlatform": "AppMovel", "durationSeconds": 161}	null	2026-04-02 02:48:39.29	2026-04-02 02:51:20.381	2026-04-02 02:51:20.498	2026-04-02 02:45:46.012	\N	-23.557814	-46.781074	[[-23.56923, -46.78897], [-23.56911, -46.78881], [-23.56911, -46.7888], [-23.56912, -46.7888], [-23.56912, -46.78879], [-23.56912, -46.78878], [-23.56912, -46.78877], [-23.56912, -46.78876], [-23.56912, -46.78875], [-23.56911, -46.78874], [-23.56911, -46.78873], [-23.5691, -46.78873], [-23.5691, -46.78872], [-23.56909, -46.78872], [-23.56909, -46.78871], [-23.56908, -46.78871], [-23.56907, -46.78871], [-23.56906, -46.78871], [-23.56905, -46.78871], [-23.56904, -46.78871], [-23.56902, -46.78872], [-23.56902, -46.78873], [-23.56901, -46.78873], [-23.56901, -46.78874], [-23.56901, -46.78875], [-23.569, -46.78875], [-23.569, -46.78876], [-23.569, -46.78877], [-23.569, -46.78878], [-23.5689, -46.78884], [-23.56876, -46.78895], [-23.56873, -46.78897], [-23.56871, -46.789], [-23.56865, -46.78906], [-23.56839, -46.78925], [-23.56826, -46.78935], [-23.56796, -46.78956], [-23.56777, -46.78972], [-23.56765, -46.78954], [-23.56761, -46.78949], [-23.56757, -46.78943], [-23.56752, -46.78937], [-23.56748, -46.78933], [-23.56744, -46.78926], [-23.56737, -46.78915], [-23.56729, -46.78897], [-23.56727, -46.78892], [-23.56718, -46.78874], [-23.5671, -46.78855], [-23.56708, -46.78853], [-23.56706, -46.7885], [-23.56703, -46.78845], [-23.567, -46.78841], [-23.56697, -46.78838], [-23.56692, -46.78835], [-23.56687, -46.78833], [-23.5668, -46.7883], [-23.56663, -46.78824], [-23.56643, -46.78817], [-23.5662, -46.78809], [-23.56601, -46.78803], [-23.56588, -46.78797], [-23.56576, -46.78793], [-23.56571, -46.78791], [-23.56537, -46.78779], [-23.56521, -46.78773], [-23.56515, -46.78771], [-23.56501, -46.78766], [-23.56492, -46.78763], [-23.56486, -46.78759], [-23.56483, -46.78758], [-23.56478, -46.78753], [-23.56473, -46.78748], [-23.56468, -46.78742], [-23.56461, -46.78732], [-23.56446, -46.78707], [-23.5644, -46.78697], [-23.56436, -46.7869], [-23.56431, -46.7868], [-23.56425, -46.78666], [-23.5642, -46.78653], [-23.56414, -46.7864], [-23.56409, -46.78631], [-23.56404, -46.78621], [-23.56403, -46.78617], [-23.56398, -46.78605], [-23.56396, -46.78599], [-23.5639, -46.78582], [-23.56382, -46.78563], [-23.56364, -46.78524], [-23.56354, -46.78504], [-23.56343, -46.7848], [-23.56332, -46.78456], [-23.56329, -46.7845], [-23.56301, -46.78385], [-23.56297, -46.78376], [-23.56291, -46.78362], [-23.56286, -46.78349], [-23.56284, -46.78331], [-23.56274, -46.78324], [-23.56264, -46.78318], [-23.5626, -46.78316], [-23.56253, -46.78312], [-23.56239, -46.78309], [-23.56223, -46.78307], [-23.56212, -46.78307], [-23.5618, -46.78306], [-23.56167, -46.78306], [-23.56147, -46.78305], [-23.56124, -46.78302], [-23.56117, -46.78301], [-23.5609, -46.78298], [-23.56048, -46.78289], [-23.56006, -46.78276], [-23.55988, -46.78271], [-23.55957, -46.78261], [-23.55934, -46.78252], [-23.55918, -46.78246], [-23.55902, -46.78239], [-23.55854, -46.78218], [-23.55831, -46.78207], [-23.55782, -46.78184], [-23.55764, -46.78176], [-23.55742, -46.78165], [-23.55715, -46.78152], [-23.55714, -46.78152], [-23.55661, -46.78127], [-23.55633, -46.78113], [-23.55616, -46.78105], [-23.55585, -46.7809], [-23.55578, -46.78087], [-23.55567, -46.78083], [-23.55558, -46.78079], [-23.55546, -46.78075], [-23.55517, -46.78063], [-23.55508, -46.78059], [-23.55499, -46.78055], [-23.5549, -46.7805], [-23.55484, -46.78046], [-23.55479, -46.78043], [-23.55472, -46.78039], [-23.55464, -46.78034], [-23.55453, -46.78026], [-23.55446, -46.7802], [-23.55437, -46.78012], [-23.55427, -46.78002], [-23.55413, -46.77987], [-23.55404, -46.77977], [-23.55393, -46.77962], [-23.55384, -46.7795], [-23.55375, -46.77934], [-23.55364, -46.77916], [-23.55348, -46.77893], [-23.55336, -46.77877], [-23.55323, -46.77862], [-23.55319, -46.77857], [-23.55308, -46.77845], [-23.55305, -46.77841], [-23.55294, -46.77828], [-23.55275, -46.77807], [-23.55262, -46.77793], [-23.55248, -46.77781], [-23.55235, -46.77767], [-23.55229, -46.7776], [-23.55213, -46.77746], [-23.55201, -46.77734], [-23.55187, -46.77724], [-23.55172, -46.77715], [-23.55146, -46.777], [-23.55124, -46.7769], [-23.55108, -46.77684], [-23.55094, -46.77678], [-23.55077, -46.77671], [-23.55063, -46.77666], [-23.55049, -46.77661], [-23.55035, -46.77656], [-23.5502, -46.77651], [-23.55002, -46.77646], [-23.54983, -46.77641], [-23.54979, -46.7764], [-23.5497, -46.77638], [-23.54962, -46.77635], [-23.54943, -46.77628], [-23.54864, -46.77593], [-23.54852, -46.77587], [-23.5483, -46.77578], [-23.54819, -46.7757], [-23.54809, -46.77562], [-23.54803, -46.77555], [-23.54796, -46.77547], [-23.54789, -46.77536], [-23.54784, -46.77525], [-23.5478, -46.77515], [-23.54776, -46.77503], [-23.54773, -46.77492], [-23.54772, -46.77489], [-23.54753, -46.77426], [-23.5474, -46.77378], [-23.54737, -46.77368], [-23.54729, -46.77341], [-23.54725, -46.77328], [-23.5472, -46.77315], [-23.54715, -46.77303], [-23.54708, -46.77292], [-23.547, -46.77278], [-23.54692, -46.77268], [-23.54682, -46.77257], [-23.5467, -46.77247], [-23.54659, -46.77238], [-23.54654, -46.77235], [-23.54655, -46.77227], [-23.54655, -46.77222], [-23.54654, -46.77217], [-23.54653, -46.77214], [-23.54674, -46.772], [-23.5468, -46.77197], [-23.54692, -46.77185], [-23.54698, -46.7717], [-23.547, -46.77165], [-23.54705, -46.77155], [-23.54708, -46.77149], [-23.54709, -46.77146], [-23.54718, -46.77133], [-23.54727, -46.77119], [-23.54734, -46.77111], [-23.54742, -46.77104], [-23.5475, -46.77094], [-23.54756, -46.77098], [-23.54761, -46.77099], [-23.54768, -46.77098], [-23.54784, -46.77095], [-23.54793, -46.77094], [-23.54807, -46.77087], [-23.54819, -46.7708], [-23.54825, -46.77077], [-23.54832, -46.77072], [-23.5483, -46.7707], [-23.54829, -46.77068], [-23.54829, -46.77065], [-23.54828, -46.77063], [-23.54828, -46.77059], [-23.54829, -46.77043], [-23.54829, -46.7703], [-23.54829, -46.77026], [-23.54828, -46.77015], [-23.54825, -46.77005], [-23.54821, -46.76992], [-23.54793, -46.77005], [-23.5478, -46.7701]]	3	route
cmngvuqu5004t7y15hm81yb36	chk_mngkermg	alex@brspark.com	\N	COMPLETED	{"field_99100": "{\\"action\\":\\"SAIDA\\",\\"timestamp\\":\\"2026-04-02T03:04:45.602Z\\",\\"coordinates\\":{\\"lat\\":-23.569983,\\"lng\\":-46.7851655},\\"address\\":\\"Parque Chico Mendes,  - Jd Bussocaba City, Osasco - SP\\"}", "__time_field_99100": "2026-04-02T03:04:45.602Z", "__section_end_page_1": "2026-04-02T03:04:54.399Z", "__section_start_page_1": "2026-04-02T03:04:45.624Z"}	{"icon": "build-outline", "refId": "chk_mngkermg", "title": "rota", "acceptedAt": "2026-04-02T03:04:43.146Z", "appVersion": "1.0", "receivedAt": "2026-04-02T02:56:09.919Z", "description": "Tarefa de rotina despachada.", "devicePlatform": "AppMovel", "durationSeconds": 10}	null	2026-04-02 03:04:43.452	2026-04-02 03:04:54.399	2026-04-02 03:04:54.464	2026-04-02 02:56:05.194	\N	\N	\N	null	\N	\N
cmngw885r005p7y155oxu7qiw	chk_mngkermg	alex@brspark.com	\N	COMPLETED	{"field_29355": "{\\"action\\":\\"CHEGADA\\",\\"timestamp\\":\\"2026-04-02T03:32:35.709Z\\",\\"coordinates\\":{\\"lat\\":-23.569983,\\"lng\\":-46.7851655},\\"address\\":\\"Parque Chico Mendes,  - Jd Bussocaba City, Osasco - SP\\",\\"traversedPath\\":[[-23.569983,-46.7851655]]}", "field_99100": "{\\"action\\":\\"SAIDA\\",\\"timestamp\\":\\"2026-04-02T03:32:31.715Z\\",\\"coordinates\\":{\\"lat\\":-23.569983,\\"lng\\":-46.7851655},\\"address\\":\\"Parque Chico Mendes,  - Jd Bussocaba City, Osasco - SP\\"}", "__time_field_29355": "2026-04-02T03:32:35.709Z", "__time_field_99100": "2026-04-02T03:32:31.715Z", "__section_end_page_1": "2026-04-02T03:32:37.338Z", "__section_start_page_1": "2026-04-02T03:32:31.731Z"}	{"icon": "build-outline", "refId": "chk_mngkermg", "title": "rota", "acceptedAt": "2026-04-02T03:06:45.038Z", "appVersion": "1.0", "receivedAt": "2026-04-02T03:06:38.703Z", "description": "Tarefa de rotina despachada.", "devicePlatform": "AppMovel", "durationSeconds": 1552}	null	2026-04-02 03:06:45.052	2026-04-02 03:32:37.338	2026-04-02 03:32:37.402	2026-04-02 03:06:34.191	\N	-23.557814	-46.781074	[[-23.56923, -46.78897], [-23.56911, -46.78881], [-23.56911, -46.7888], [-23.56912, -46.7888], [-23.56912, -46.78879], [-23.56912, -46.78878], [-23.56912, -46.78877], [-23.56912, -46.78876], [-23.56912, -46.78875], [-23.56911, -46.78874], [-23.56911, -46.78873], [-23.5691, -46.78873], [-23.5691, -46.78872], [-23.56909, -46.78872], [-23.56909, -46.78871], [-23.56908, -46.78871], [-23.56907, -46.78871], [-23.56906, -46.78871], [-23.56905, -46.78871], [-23.56904, -46.78871], [-23.56902, -46.78872], [-23.56902, -46.78873], [-23.56901, -46.78873], [-23.56901, -46.78874], [-23.56901, -46.78875], [-23.569, -46.78875], [-23.569, -46.78876], [-23.569, -46.78877], [-23.569, -46.78878], [-23.5689, -46.78884], [-23.56876, -46.78895], [-23.56873, -46.78897], [-23.56871, -46.789], [-23.56865, -46.78906], [-23.56839, -46.78925], [-23.56826, -46.78935], [-23.56796, -46.78956], [-23.56777, -46.78972], [-23.56765, -46.78954], [-23.56761, -46.78949], [-23.56757, -46.78943], [-23.56752, -46.78937], [-23.56748, -46.78933], [-23.56744, -46.78926], [-23.56737, -46.78915], [-23.56729, -46.78897], [-23.56727, -46.78892], [-23.56718, -46.78874], [-23.5671, -46.78855], [-23.56708, -46.78853], [-23.56706, -46.7885], [-23.56703, -46.78845], [-23.567, -46.78841], [-23.56697, -46.78838], [-23.56692, -46.78835], [-23.56687, -46.78833], [-23.5668, -46.7883], [-23.56663, -46.78824], [-23.56643, -46.78817], [-23.5662, -46.78809], [-23.56601, -46.78803], [-23.56588, -46.78797], [-23.56576, -46.78793], [-23.56571, -46.78791], [-23.56537, -46.78779], [-23.56521, -46.78773], [-23.56515, -46.78771], [-23.56501, -46.78766], [-23.56492, -46.78763], [-23.56486, -46.78759], [-23.56483, -46.78758], [-23.56478, -46.78753], [-23.56473, -46.78748], [-23.56468, -46.78742], [-23.56461, -46.78732], [-23.56446, -46.78707], [-23.5644, -46.78697], [-23.56436, -46.7869], [-23.56431, -46.7868], [-23.56425, -46.78666], [-23.5642, -46.78653], [-23.56414, -46.7864], [-23.56409, -46.78631], [-23.56404, -46.78621], [-23.56403, -46.78617], [-23.56398, -46.78605], [-23.56396, -46.78599], [-23.5639, -46.78582], [-23.56382, -46.78563], [-23.56364, -46.78524], [-23.56354, -46.78504], [-23.56343, -46.7848], [-23.56332, -46.78456], [-23.56329, -46.7845], [-23.56301, -46.78385], [-23.56297, -46.78376], [-23.56291, -46.78362], [-23.56286, -46.78349], [-23.56284, -46.78331], [-23.56274, -46.78324], [-23.56264, -46.78318], [-23.5626, -46.78316], [-23.56253, -46.78312], [-23.56239, -46.78309], [-23.56223, -46.78307], [-23.56212, -46.78307], [-23.5618, -46.78306], [-23.56167, -46.78306], [-23.56147, -46.78305], [-23.56124, -46.78302], [-23.56117, -46.78301], [-23.5609, -46.78298], [-23.56048, -46.78289], [-23.56006, -46.78276], [-23.55988, -46.78271], [-23.55957, -46.78261], [-23.55934, -46.78252], [-23.55918, -46.78246], [-23.55902, -46.78239], [-23.55854, -46.78218], [-23.55831, -46.78207], [-23.55782, -46.78184], [-23.55764, -46.78176], [-23.55742, -46.78165], [-23.55715, -46.78152], [-23.55714, -46.78152], [-23.55661, -46.78127], [-23.55633, -46.78113], [-23.55616, -46.78105], [-23.55585, -46.7809], [-23.55578, -46.78087], [-23.55567, -46.78083], [-23.55558, -46.78079], [-23.55546, -46.78075], [-23.55517, -46.78063], [-23.55508, -46.78059], [-23.55499, -46.78055], [-23.5549, -46.7805], [-23.55484, -46.78046], [-23.55479, -46.78043], [-23.55472, -46.78039], [-23.55464, -46.78034], [-23.55453, -46.78026], [-23.55446, -46.7802], [-23.55437, -46.78012], [-23.55427, -46.78002], [-23.55413, -46.77987], [-23.55404, -46.77977], [-23.55393, -46.77962], [-23.55384, -46.7795], [-23.55375, -46.77934], [-23.55364, -46.77916], [-23.55348, -46.77893], [-23.55336, -46.77877], [-23.55323, -46.77862], [-23.55319, -46.77857], [-23.55308, -46.77845], [-23.55305, -46.77841], [-23.55294, -46.77828], [-23.55275, -46.77807], [-23.55262, -46.77793], [-23.55248, -46.77781], [-23.55235, -46.77767], [-23.55229, -46.7776], [-23.55213, -46.77746], [-23.55201, -46.77734], [-23.55187, -46.77724], [-23.55172, -46.77715], [-23.55146, -46.777], [-23.55124, -46.7769], [-23.55108, -46.77684], [-23.55094, -46.77678], [-23.55077, -46.77671], [-23.55063, -46.77666], [-23.55049, -46.77661], [-23.55035, -46.77656], [-23.5502, -46.77651], [-23.55002, -46.77646], [-23.54983, -46.77641], [-23.54979, -46.7764], [-23.5497, -46.77638], [-23.54962, -46.77635], [-23.54943, -46.77628], [-23.54864, -46.77593], [-23.54852, -46.77587], [-23.5483, -46.77578], [-23.54819, -46.7757], [-23.54809, -46.77562], [-23.54803, -46.77555], [-23.54796, -46.77547], [-23.54789, -46.77536], [-23.54784, -46.77525], [-23.5478, -46.77515], [-23.54776, -46.77503], [-23.54773, -46.77492], [-23.54772, -46.77489], [-23.54753, -46.77426], [-23.5474, -46.77378], [-23.54737, -46.77368], [-23.54729, -46.77341], [-23.54725, -46.77328], [-23.5472, -46.77315], [-23.54715, -46.77303], [-23.54708, -46.77292], [-23.547, -46.77278], [-23.54692, -46.77268], [-23.54682, -46.77257], [-23.5467, -46.77247], [-23.54659, -46.77238], [-23.54654, -46.77235], [-23.54655, -46.77227], [-23.54655, -46.77222], [-23.54654, -46.77217], [-23.54653, -46.77214], [-23.54674, -46.772], [-23.5468, -46.77197], [-23.54692, -46.77185], [-23.54698, -46.7717], [-23.547, -46.77165], [-23.54705, -46.77155], [-23.54708, -46.77149], [-23.54709, -46.77146], [-23.54718, -46.77133], [-23.54727, -46.77119], [-23.54734, -46.77111], [-23.54742, -46.77104], [-23.5475, -46.77094], [-23.54756, -46.77098], [-23.54761, -46.77099], [-23.54768, -46.77098], [-23.54784, -46.77095], [-23.54793, -46.77094], [-23.54807, -46.77087], [-23.54819, -46.7708], [-23.54825, -46.77077], [-23.54832, -46.77072], [-23.5483, -46.7707], [-23.54829, -46.77068], [-23.54829, -46.77065], [-23.54828, -46.77063], [-23.54828, -46.77059], [-23.54829, -46.77043], [-23.54829, -46.7703], [-23.54829, -46.77026], [-23.54828, -46.77015], [-23.54825, -46.77005], [-23.54821, -46.76992], [-23.54793, -46.77005], [-23.5478, -46.7701]]	100	route
\.


--
-- Data for Name: ChecklistTemplate; Type: TABLE DATA; Schema: public; Owner: alex
--

COPY public."ChecklistTemplate" (id, "tenantId", title, description, settings, "schemaData", metadata, version, "isActive", "createdAt", "updatedAt") FROM stdin;
chk_mncnb2te	\N	NOVO CHECKLISTee		{"rules": [], "globalGeofenceRadius": 200, "requireGlobalGeofence": false}	[{"id": "field_93650", "icon": "", "type": "section_break", "label": "Separador de Etapa / Página", "options": null, "required": false, "textMask": null, "calcFormula": null, "dependsOnId": "", "description": "", "defaultValue": "", "dependsOnValue": "", "geofenceRadius": null, "dependsOnOperator": "=="}, {"id": "field_48469", "icon": "", "type": "signature", "label": "Assinatura", "options": null, "required": false, "textMask": null, "calcFormula": null, "dependsOnId": "", "description": "", "defaultValue": "", "dependsOnValue": "", "geofenceRadius": null, "dependsOnOperator": "=="}, {"id": "field_58006", "icon": "", "type": "section_break", "label": "Separador de Etapa / Página", "options": null, "required": false, "textMask": null, "calcFormula": null, "dependsOnId": "", "description": "", "defaultValue": "", "dependsOnValue": "", "geofenceRadius": null, "dependsOnOperator": "=="}]	{"icon": ""}	1	t	2026-03-30 03:45:46.156	2026-03-31 22:03:24.791
chk_mne0b9vu	\N	NOVO CHECKLIST		{"globalGeofenceRadius": 200, "requireGlobalGeofence": false}	[]	{"icon": ""}	1	f	2026-03-31 02:37:36.362	2026-03-31 03:04:08.064
chk_mne01caj	\N	NOVO CHECKLIST		{"globalGeofenceRadius": 200, "requireGlobalGeofence": false}	[{"id": "field_7809", "icon": "", "type": "text", "label": "Resposta em Texto", "options": null, "required": false, "textMask": "", "calcFormula": null, "dependsOnId": "", "description": "", "defaultValue": "", "dependsOnValue": "", "geofenceRadius": null, "dependsOnOperator": "=="}]	{"icon": ""}	1	f	2026-03-31 02:29:52.916	2026-03-31 13:15:34.9
chk_mnen95p1d55	\N	231222a (Cópia)		{"globalGeofenceRadius": 200, "requireGlobalGeofence": false}	[{"id": "field_68093", "icon": "", "type": "section_break", "label": "Separador de Etapa / Página", "options": null, "required": false, "textMask": null, "calcFormula": null, "dependsOnId": "", "description": "", "defaultValue": "", "dependsOnValue": "", "geofenceRadius": null, "dependsOnOperator": "=="}, {"id": "field_38889", "icon": "", "type": "transit_start", "label": "Iniciar Deslocamento", "options": null, "required": false, "textMask": null, "calcFormula": null, "dependsOnId": "", "description": "", "defaultValue": "", "dependsOnValue": "", "geofenceRadius": null, "dependsOnOperator": "=="}, {"id": "field_69277", "icon": "", "type": "transit_end", "label": "Finalizar Deslocamento", "options": null, "required": false, "textMask": null, "calcFormula": null, "dependsOnId": "", "description": "", "defaultValue": "", "dependsOnValue": "", "geofenceRadius": null, "dependsOnOperator": "=="}, {"id": "field_13790", "icon": "", "type": "barcode_scan", "label": "Escanear Etiqueta / Bem", "options": null, "required": false, "textMask": null, "calcFormula": null, "dependsOnId": "", "description": "", "defaultValue": "", "dependsOnValue": "", "geofenceRadius": null, "dependsOnOperator": "=="}, {"id": "field_3999", "icon": "", "type": "file_upload", "label": "Enviar PDF/Doc", "options": null, "required": false, "textMask": null, "calcFormula": null, "dependsOnId": "", "description": "", "defaultValue": "", "dependsOnValue": "", "geofenceRadius": null, "dependsOnOperator": "=="}, {"id": "field_35561", "icon": "", "type": "photo", "label": "Foto (Galeria Livre)", "options": null, "required": false, "textMask": null, "calcFormula": null, "dependsOnId": "", "description": "", "defaultValue": "", "dependsOnValue": "", "geofenceRadius": null, "dependsOnOperator": "=="}, {"id": "field_78600", "icon": "", "type": "photo_stamped", "label": "Foto Carimbada (Ao Vivo)", "options": null, "required": false, "textMask": null, "calcFormula": null, "dependsOnId": "", "description": "", "defaultValue": "", "dependsOnValue": "", "geofenceRadius": null, "dependsOnOperator": "=="}, {"id": "field_71925", "icon": "", "type": "signature", "label": "Assinatura", "options": null, "required": false, "textMask": null, "calcFormula": null, "dependsOnId": "", "description": "", "defaultValue": "", "dependsOnValue": "", "geofenceRadius": null, "dependsOnOperator": "=="}, {"id": "field_99419", "icon": "", "type": "section_break", "label": "Separador de Etapa / Página", "options": null, "required": false, "textMask": null, "calcFormula": null, "dependsOnId": "", "description": "", "defaultValue": "", "dependsOnValue": "", "geofenceRadius": null, "dependsOnOperator": "=="}]	{"icon": ""}	1	t	2026-03-31 13:19:48.791	2026-04-01 14:21:17.944
chk_mnb61qhk	\N	NOVO CHECKLIST		{"rules": [{"id": "rule_262953", "name": "Nova Automação", "actions": [{"type": "SET_VALUE", "value": "", "targetId": "field_85539"}], "condValue": "", "condFieldId": "field_36827", "condOperator": "contains"}, {"id": "rule_269716", "name": "Nova Automação", "actions": [], "condValue": "", "condFieldId": "", "condOperator": "=="}], "globalGeofenceRadius": 200, "requireGlobalGeofence": false}	[{"id": "field_72359", "icon": "arrow-forward", "type": "transit_start", "label": "Iniciar Deslocamento", "rules": [{"value": "", "actions": [], "operator": "=="}], "options": null, "required": false, "textMask": null, "iconColor": "#0F172A", "calcFormula": null, "dependsOnId": "", "description": "", "iconLibrary": "Ionicons", "defaultValue": "", "dependsOnValue": "", "geofenceRadius": null, "dependsOnOperator": "=="}, {"id": "field_44585", "icon": "arrow-down-sharp", "type": "transit_end", "label": "Finalizar Deslocamento", "options": null, "required": false, "textMask": null, "iconColor": "#0F172A", "calcFormula": null, "dependsOnId": "", "description": "", "iconLibrary": "Ionicons", "defaultValue": "", "dependsOnValue": "", "geofenceRadius": null, "dependsOnOperator": "=="}, {"id": "field_30724", "icon": "navigate", "type": "phone", "label": "Telefone / Celular", "options": null, "required": false, "textMask": "", "calcFormula": null, "dependsOnId": "", "description": "", "defaultValue": "", "dependsOnValue": "", "geofenceRadius": null, "dependsOnOperator": "=="}, {"id": "field_3643", "icon": "cut", "type": "date", "label": "Data / Hora", "options": null, "required": false, "textMask": null, "calcFormula": null, "dependsOnId": "", "description": "", "defaultValue": "", "dependsOnValue": "", "geofenceRadius": null, "dependsOnOperator": "=="}, {"id": "field_37429", "type": "section_break", "label": "Separador de Etapa / Página", "options": null, "required": false, "textMask": null, "calcFormula": null, "dependsOnId": "", "description": "", "defaultValue": "", "dependsOnValue": "", "geofenceRadius": null, "dependsOnOperator": "=="}, {"id": "field_45423", "type": "calculated", "label": "Campo Calculado (Math)", "options": null, "required": false, "textMask": null, "calcFormula": "", "dependsOnId": "", "description": "", "defaultValue": "", "dependsOnValue": "", "geofenceRadius": null, "dependsOnOperator": "=="}, {"id": "field_30615", "type": "file_upload", "label": "Enviar PDF/Doc", "options": null, "required": false, "textMask": null, "calcFormula": null, "dependsOnId": "", "description": "", "defaultValue": "", "dependsOnValue": "", "geofenceRadius": null, "dependsOnOperator": "=="}, {"id": "field_85539", "type": "photo_stamped", "label": "Foto Carimbada (Ao Vivo)", "options": null, "required": false, "textMask": null, "calcFormula": null, "dependsOnId": "", "description": "", "defaultValue": "", "dependsOnValue": "", "geofenceRadius": null, "dependsOnOperator": "=="}, {"id": "field_78643", "type": "dropdown", "label": "Lista (Dropdown)", "options": "Opção 1, Opção 2", "required": false, "textMask": null, "calcFormula": null, "dependsOnId": "", "description": "", "defaultValue": "", "dependsOnValue": "", "geofenceRadius": null, "dependsOnOperator": "=="}, {"id": "field_61552", "icon": "", "type": "rating", "label": "Avaliação (Estrelas)", "options": null, "required": false, "textMask": null, "calcFormula": null, "dependsOnId": "", "description": "", "defaultValue": "", "dependsOnValue": "", "geofenceRadius": null, "dependsOnOperator": "=="}, {"id": "field_71281", "icon": "", "type": "calculated", "label": "Campo Calculado (Math)", "options": null, "required": false, "textMask": null, "calcFormula": "", "dependsOnId": "", "description": "", "defaultValue": "", "dependsOnValue": "", "geofenceRadius": null, "dependsOnOperator": "=="}, {"id": "field_17262", "type": "photo", "label": "Foto (Galeria Livre)", "options": null, "required": false, "textMask": null, "calcFormula": null, "dependsOnId": "", "description": "", "defaultValue": "", "dependsOnValue": "", "geofenceRadius": null, "dependsOnOperator": "=="}, {"id": "field_19829", "type": "text", "label": "Resposta em Texto", "options": null, "required": false, "textMask": "", "calcFormula": null, "dependsOnId": "", "dependsOnValue": "", "geofenceRadius": null, "dependsOnOperator": "=="}, {"id": "field_56249", "type": "number", "label": "Input Numérico", "options": null, "required": false, "textMask": "", "calcFormula": null, "dependsOnId": "", "dependsOnValue": "", "geofenceRadius": null, "dependsOnOperator": "=="}, {"id": "field_69614", "type": "email", "label": "E-mail", "options": null, "required": false, "textMask": null, "calcFormula": null, "dependsOnId": "", "dependsOnValue": "", "geofenceRadius": null, "dependsOnOperator": "=="}, {"id": "field_25157", "type": "section_break", "label": "Separador de Etapa / Página", "options": null, "required": false, "textMask": null, "calcFormula": null, "dependsOnId": "", "dependsOnValue": "", "geofenceRadius": null, "dependsOnOperator": "=="}, {"id": "field_99284", "type": "signature", "label": "Assinatura", "options": null, "required": false, "textMask": null, "calcFormula": null, "dependsOnId": "", "description": "", "defaultValue": "", "dependsOnValue": "", "geofenceRadius": null, "dependsOnOperator": "=="}]	{"icon": "build"}	1	f	2026-03-29 23:50:27.654	2026-03-31 03:04:45.914
chk_mngeayfc	\N	NOVO CHECKLIST		{"rules": [], "globalGeofenceRadius": 200, "requireGlobalGeofence": false}	[]	{"icon": ""}	1	t	2026-04-01 18:44:49.967	2026-04-01 18:44:49.967
chk_mne1dhzv	\N	231222a		{"globalGeofenceRadius": 200, "requireGlobalGeofence": false}	[{"id": "field_38889", "icon": "", "type": "transit_start", "label": "Iniciar Deslocamento", "options": null, "required": false, "textMask": null, "calcFormula": null, "dependsOnId": "", "description": "", "defaultValue": "", "dependsOnValue": "", "geofenceRadius": null, "dependsOnOperator": "=="}, {"id": "field_69277", "icon": "", "type": "transit_end", "label": "Finalizar Deslocamento", "options": null, "required": false, "textMask": null, "calcFormula": null, "dependsOnId": "", "description": "", "defaultValue": "", "dependsOnValue": "", "geofenceRadius": null, "dependsOnOperator": "=="}, {"id": "field_13790", "icon": "", "type": "barcode_scan", "label": "Escanear Etiqueta / Bem", "options": null, "required": false, "textMask": null, "calcFormula": null, "dependsOnId": "", "description": "", "defaultValue": "", "dependsOnValue": "", "geofenceRadius": null, "dependsOnOperator": "=="}, {"id": "field_3999", "icon": "", "type": "file_upload", "label": "Enviar PDF/Doc", "options": null, "required": false, "textMask": null, "calcFormula": null, "dependsOnId": "", "description": "", "defaultValue": "", "dependsOnValue": "", "geofenceRadius": null, "dependsOnOperator": "=="}, {"id": "field_35561", "icon": "", "type": "photo", "label": "Foto (Galeria Livre)", "options": null, "required": false, "textMask": null, "calcFormula": null, "dependsOnId": "", "description": "", "defaultValue": "", "dependsOnValue": "", "geofenceRadius": null, "dependsOnOperator": "=="}, {"id": "field_78600", "icon": "", "type": "photo_stamped", "label": "Foto Carimbada (Ao Vivo)", "options": null, "required": false, "textMask": null, "calcFormula": null, "dependsOnId": "", "description": "", "defaultValue": "", "dependsOnValue": "", "geofenceRadius": null, "dependsOnOperator": "=="}, {"id": "field_71925", "icon": "", "type": "signature", "label": "Assinatura", "options": null, "required": false, "textMask": null, "calcFormula": null, "dependsOnId": "", "description": "", "defaultValue": "", "dependsOnValue": "", "geofenceRadius": null, "dependsOnOperator": "=="}]	{"icon": ""}	1	t	2026-03-31 03:07:19.825	2026-03-31 13:15:58.915
chk_mngkermg	\N	rota		{"rules": [], "globalGeofenceRadius": 200, "requireGlobalGeofence": false}	[{"id": "field_99100", "icon": "", "type": "transit_start", "label": "Iniciar Deslocamento", "options": null, "required": false, "textMask": null, "calcFormula": null, "dependsOnId": "", "description": "", "defaultValue": "", "dependsOnValue": "", "geofenceRadius": null, "dependsOnOperator": "=="}, {"id": "field_29355", "icon": "", "type": "transit_end", "label": "Finalizar Deslocamento", "options": null, "required": false, "textMask": null, "calcFormula": null, "dependsOnId": "", "description": "", "defaultValue": "", "dependsOnValue": "", "geofenceRadius": null, "dependsOnOperator": "=="}]	{"icon": ""}	1	t	2026-04-01 21:35:43.977	2026-04-01 21:35:43.977
chk_mnf5iygw	\N	NOVO CHECKLISThhhh		{"rules": [], "globalGeofenceRadius": 200, "requireGlobalGeofence": false}	[{"id": "field_44550", "icon": "", "type": "section_break", "label": "Separador de Etapa / Página", "options": null, "required": false, "textMask": null, "calcFormula": null, "dependsOnId": "", "description": "", "defaultValue": "", "dependsOnValue": "", "geofenceRadius": null, "dependsOnOperator": "=="}, {"id": "field_96169", "icon": "", "type": "photo", "label": "Foto (Galeria Livre)", "options": null, "required": false, "textMask": null, "calcFormula": null, "dependsOnId": "", "description": "", "defaultValue": "", "dependsOnValue": "", "geofenceRadius": null, "dependsOnOperator": "=="}, {"id": "field_61072", "icon": "", "type": "photo_stamped", "label": "Foto Carimbada (Ao Vivo)", "options": null, "required": false, "textMask": null, "calcFormula": null, "dependsOnId": "", "description": "", "defaultValue": "", "dependsOnValue": "", "geofenceRadius": null, "dependsOnOperator": "=="}, {"id": "field_43581", "icon": "", "type": "section_break", "label": "Separador de Etapa / Página", "rules": [], "options": null, "required": false, "textMask": null, "calcFormula": null, "dependsOnId": "", "description": "", "defaultValue": "", "dependsOnValue": "", "geofenceRadius": null, "dependsOnOperator": "=="}]	{"icon": ""}	1	t	2026-03-31 21:51:19.262	2026-03-31 21:51:40.192
\.


--
-- Data for Name: ComplianceAcceptance; Type: TABLE DATA; Schema: public; Owner: alex
--

COPY public."ComplianceAcceptance" (id, "docId", "userId", "tenantId", "ipAddress", "acceptedAt") FROM stdin;
\.


--
-- Data for Name: ComplianceDoc; Type: TABLE DATA; Schema: public; Owner: alex
--

COPY public."ComplianceDoc" (id, type, version, title, content, "isActive", "publishedAt", "createdBy", "createdAt", "updatedAt") FROM stdin;
terms-v1	TERMS_OF_USE	1.0	Termos de Uso — Plataforma BrSpark	# Termos de Uso da Plataforma BrSpark\n\n**Versão 1.0 — Vigência a partir de 23 de março de 2025**\n\nBem-vindo à BrSpark. Ao criar uma conta e utilizar nossos serviços, você concorda com estes Termos de Uso.\n\n---\n\n## 1. Aceitação dos Termos\n\nO acesso e uso da plataforma BrSpark estão condicionados à aceitação e ao cumprimento destes termos.\n\n## 2. Descrição do Serviço\n\nA BrSpark é uma plataforma SaaS para gestão de patrimônio pessoal e empresarial, incluindo:\n\n- **Cadastro e rastreamento de bens**: imóveis, veículos, equipamentos e outros ativos;\n- **Gestão de estoque**: controle de entradas, saídas e inventário;\n- **Vault de documentos**: armazenamento seguro de arquivos e credenciais;\n- **Gestão de seguros**: controle de apólices e coberturas;\n- **Consultor AI**: assistente inteligente integrado à conta do usuário.\n\n## 3. Cadastro e Conta\n\n3.1. Para utilizar a plataforma, você deve criar uma conta com informações verdadeiras e atualizadas.\n\n3.2. Você é responsável pela confidencialidade de sua senha e por todas as atividades realizadas em sua conta.\n\n3.3. Notifique-nos imediatamente em caso de uso não autorizado: **suporte@brspark.com**.\n\n## 4. Uso Aceitável\n\nAo utilizar a plataforma, você concorda em **não**:\n\n- Cadastrar informações falsas ou fraudulentas;\n- Tentar acessar dados de outros usuários;\n- Realizar engenharia reversa ou extrair o código-fonte;\n- Utilizar a plataforma para fins ilegais;\n- Transmitir vírus ou código malicioso.\n\n## 5. Planos e Pagamentos\n\n5.1. A plataforma oferece planos pagos (Basic, Pro, Enterprise) e um período de avaliação gratuita.\n\n5.2. Os valores podem ser alterados mediante aviso prévio de 30 dias.\n\n5.3. Não há reembolso por períodos parciais utilizados, salvo exigido por lei.\n\n## 6. Dados e Privacidade\n\nO tratamento dos seus dados pessoais é regido pela nossa **Política de Privacidade**, em conformidade com a LGPD (Lei nº 13.709/2018) e o GDPR (EU 2016/679).\n\n## 7. Propriedade Intelectual\n\nTodo o conteúdo da plataforma BrSpark é de propriedade exclusiva da BrSpark Tecnologia Ltda. Os dados que você cadastra continuam sendo de sua propriedade.\n\n## 8. Limitação de Responsabilidade\n\nA responsabilidade total da BrSpark, em qualquer hipótese, é limitada ao valor pago nos últimos 3 meses de assinatura.\n\n## 9. Rescisão\n\n9.1. Você pode encerrar sua conta a qualquer momento nas configurações do aplicativo.\n\n9.2. Após o encerramento, seus dados são retidos por 90 dias e depois excluídos definitivamente.\n\n## 10. Legislação Aplicável\n\nEstes Termos são regidos pelas leis do Brasil. Foro: Comarca de São Paulo/SP.\n\n---\n\n📧 **Contato**: suporte@brspark.com | 🌐 https://www.brspark.com	t	2026-03-24 01:21:03.861	admin@brspark.com	2026-03-24 01:21:03.862	2026-03-24 01:21:03.862
privacy-v1	PRIVACY_POLICY	1.0	Política de Privacidade — BrSpark	# Política de Privacidade da BrSpark\n\n**Versão 1.0 — Vigência a partir de 23 de março de 2025**\n\nA BrSpark Tecnologia Ltda. tem o compromisso de proteger sua privacidade. Esta Política descreve como coletamos, usamos e protegemos seus dados pessoais, em conformidade com a **LGPD (Lei 13.709/2018)** e o **GDPR (EU 2016/679)**.\n\n## 1. Controlador dos Dados\n\n**BrSpark Tecnologia Ltda.**\nEndereço: São Paulo, SP — Brasil\nEncarregado de Dados (DPO): dpo@brspark.com\n\n## 2. Dados que Coletamos\n\n### 2.1 Dados fornecidos por você:\n- **Dados de cadastro**: nome completo, e-mail, senha (armazenada com hash bcrypt);\n- **Dados de bens**: informações sobre seus ativos cadastrados;\n- **Documentos**: arquivos armazenados no Vault.\n\n### 2.2 Dados coletados automaticamente:\n- Endereço IP e localização aproximada;\n- Tipo de dispositivo e versão do app;\n- Logs de acesso para segurança.\n\n## 3. Finalidades do Tratamento\n\n| Finalidade | Base Legal (LGPD) |\n|---|---|\n| Criação e gerenciamento de conta | Execução de contrato |\n| Prestação dos serviços | Execução de contrato |\n| Segurança e prevenção a fraudes | Interesse legítimo |\n| Conformidade LGPD/GDPR | Obrigação legal |\n| Notificações push | Consentimento |\n\n## 4. Compartilhamento de Dados\n\n**Não vendemos seus dados.** Compartilhamos apenas com provedores de infraestrutura (ex: AWS) e quando exigido por lei.\n\n## 5. Armazenamento e Segurança\n\n- Criptografia em trânsito (TLS 1.3) e em repouso (AES-256);\n- Senhas armazenadas exclusivamente sob hash bcrypt;\n- Incidentes notificados em até **72 horas** conforme exigido por lei.\n\n## 6. Retenção de Dados\n\n| Tipo | Prazo |\n|---|---|\n| Conta ativa | Enquanto durar a conta |\n| Conta encerrada | 90 dias após encerramento |\n| Logs de acesso | 12 meses |\n| Dados fiscais | 5 anos (obrigação legal) |\n\n## 7. Seus Direitos (LGPD/GDPR)\n\nVocê tem direito a: **acesso, correção, exclusão ("direito ao esquecimento"), portabilidade, oposição e revogação de consentimento**.\n\nPara exercer esses direitos: **dpo@brspark.com** ou Conta → Privacidade → Gerenciar Meus Dados.\n\n## 8. Cookies e Armazenamento Local\n\nO app móvel usa AsyncStorage (no próprio dispositivo) apenas para manter sua sessão. Não utilizamos cookies de rastreamento.\n\n## 9. Alterações\n\nNotificaremos sobre mudanças materiais com pelo menos 30 dias de antecedência.\n\n---\n\n📧 **DPO**: dpo@brspark.com | 🌐 https://www.brspark.com/privacidade	t	2026-03-24 01:21:03.864	admin@brspark.com	2026-03-24 01:21:03.865	2026-03-24 01:21:03.865
lgpd-v1	LGPD_DPA	1.0	DPA — Acordo de Processamento de Dados (LGPD)	# Acordo de Processamento de Dados (DPA)\n\n**Conforme a Lei 13.709/2018 — LGPD**\n\n## 1. Partes\n- **Controlador**: O usuário que contrata os serviços da BrSpark.\n- **Operador**: BrSpark Tecnologia Ltda.\n\n## 2. Obrigações do Operador\n- Tratar dados apenas conforme instruções documentadas;\n- Garantir confidencialidade;\n- Notificar incidentes em até 72 horas;\n- Excluir dados ao término do contrato.\n\n## 3. Vigência\nEste DPA vigora enquanto durar a relação contratual.	t	2026-03-24 01:21:03.865	admin@brspark.com	2026-03-24 01:21:03.865	2026-03-24 01:21:03.865
\.


--
-- Data for Name: FeatureFlag; Type: TABLE DATA; Schema: public; Owner: alex
--

COPY public."FeatureFlag" (id, key, label, description, icon, enabled, "tenantId", "updatedAt") FROM stdin;
cmn3xhvmh0005dajk600ltvea	stock	Módulo de Estoque	Gestão de almoxarifado e movimentações	cube-outline	t	\N	2026-03-24 01:21:03.834
cmn3xhvmk0007dajk0qsxwjtv	insurance	Módulo de Seguros	Apólices e cobertura de bens	shield-checkmark-outline	t	\N	2026-03-24 01:21:03.837
cmn3xhvml0009dajkzqaq313a	vault	Cofre (Vault)	Armazenamento de credenciais seguras	lock-closed-outline	t	\N	2026-03-24 01:21:03.837
cmn3xhvml000bdajkdo8bc9sl	ai	Consultor AI	Assistente inteligente por bem	sparkles-outline	t	\N	2026-03-24 01:21:03.838
cmn3xhvmm000ddajke75afqbk	documents	Módulo de Documentos	Upload e gestão de arquivos por bem	document-text-outline	t	\N	2026-03-24 01:21:03.839
cmn3xhvmn000fdajkayzr6bzp	reports	Relatórios Avançados	Exportação CSV e análise de custos	stats-chart-outline	f	\N	2026-03-24 01:21:03.84
cmn3xhvmo000jdajk7nhhzzdx	i18n	Multi-idioma	Suporte a EN, ES e PT-BR	globe-outline	t	\N	2026-03-24 01:21:03.841
cmn3xhvmo000hdajkdn4fpdew	realtime	Sync em Tempo Real	Sincronização cloud em tempo real	sync-outline	t	\N	2026-03-24 13:25:14.836
\.


--
-- Data for Name: Integration; Type: TABLE DATA; Schema: public; Owner: alex
--

COPY public."Integration" (id, name, type, icon, "apiKey", "baseUrl", "webhookUrl", "lastTestedAt", metadata, "createdAt", "updatedAt", description, status) FROM stdin;
cmn6gys74005pcta0yp594h7d	Office 365	EMAIL	\N	\N	\N	\N	\N	\N	2026-03-25 20:01:37.6	2026-03-25 20:01:37.6	\N	ACTIVE
cmn6qhwg000145epynb1opcoe	OpenAI	AI_LLM	\N	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	\N	\N	2026-03-26 00:28:28.361	\N	2026-03-26 00:28:26.111	2026-03-26 00:28:28.366	\N	ACTIVE
cmn7hu70u0000yy95q18ih5i6	Dropbox	STORAGE	\N	ne4t0os2lmrrlz3:ii6n3pcm3b0qux5	/BrSpark	\N	2026-03-26 13:24:24.865	\N	2026-03-26 13:13:49.326	2026-03-26 13:24:24.867	refresh_token:kSUlB_aJkzYAAAAAAAAAAQTwmnAGpNOxFElbLCav3Dvficl1vY6Vd6bXWxMu4KhU	ACTIVE
cmn8xpvrv000013y47mgdv874	Bluesoft Cosmos	ERP	\N	BO4PybchezDaegmlUyLXUA	https://api.cosmos.bluesoft.com.br	\N	2026-03-27 13:26:09.845	\N	2026-03-27 13:26:08.155	2026-03-27 13:26:09.846	\N	ACTIVE
\.


--
-- Data for Name: Invoice; Type: TABLE DATA; Schema: public; Owner: alex
--

COPY public."Invoice" (id, "subscriptionId", amount, status, "dueDate", "paidAt", "externalId", "createdAt") FROM stdin;
\.


--
-- Data for Name: LocaleProfile; Type: TABLE DATA; Schema: public; Owner: alex
--

COPY public."LocaleProfile" (id, "countryCode", name, language, currency, "currencySymbol", "dateFormat", "numberFormat", timezone, "taxIdLabel", "postalCodeLabel", "measureSystem", "isActive", "createdAt", "updatedAt") FROM stdin;
cmn3vyg7a0000124fc64ebh01	BR	Brasil	pt-BR	BRL	R$	DD/MM/YYYY	PT_STYLE	America/Sao_Paulo	CPF/CNPJ	CEP	METRIC	t	2026-03-24 00:37:57.766	2026-03-24 02:01:45.523
cmn3vyg8e0001124fmm7itdof	US	United States	en-US	USD	$	MM/DD/YYYY	US_STYLE	America/New_York	SSN/EIN	ZIP Code	IMPERIAL	t	2026-03-24 00:37:57.806	2026-03-24 02:01:45.533
cmn3vyg8g0002124f5eqzqfhe	ES	España	es-ES	EUR	€	DD/MM/YYYY	PT_STYLE	Europe/Madrid	NIF/NIE	Código Postal	METRIC	t	2026-03-24 00:37:57.808	2026-03-24 02:01:45.535
cmn3yy7nk0000pwwgzjok9ovu	AR	Argentina	es-AR	ARS	$	DD/MM/YYYY	PT_STYLE	America/Argentina/Buenos_Aires	Tax ID	Postal Code	METRIC	t	2026-03-24 02:01:45.537	2026-03-24 02:07:31.534
\.


--
-- Data for Name: Location; Type: TABLE DATA; Schema: public; Owner: alex
--

COPY public."Location" (id, "tenantId", name, type, address, floor, room, icon, latitude, longitude, "parentId", "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: Metatag; Type: TABLE DATA; Schema: public; Owner: alex
--

COPY public."Metatag" (id, type, key, "ptBr", "enUs", "esEs", icon, color, "isActive", "sortOrder", "createdAt", "updatedAt") FROM stdin;
cmn3xhvmp000kdajktso0x1w7	ASSET_TYPE	real_estate	Imóvel	Real Estate	Inmueble	home-outline	#3B82F6	t	0	2026-03-24 01:21:03.841	2026-03-24 01:21:03.841
cmn3xhvn2000ldajk1zm1snuz	ASSET_TYPE	terrestrial	Veículo	Vehicle	Vehículo	car-outline	#F97316	t	1	2026-03-24 01:21:03.855	2026-03-24 01:21:03.855
cmn3xhvn3000mdajkk5h5cyiz	ASSET_TYPE	aquatic	Embarcação	Vessel	Embarcación	boat-outline	#06B6D4	t	2	2026-03-24 01:21:03.855	2026-03-24 01:21:03.855
cmn3xhvn4000ndajkh6f6bym3	ASSET_TYPE	special	Equipamento	Equipment	Equipamiento	construct-outline	#8B5CF6	t	3	2026-03-24 01:21:03.856	2026-03-24 01:21:03.856
cmn3xhvn4000odajkphelcitk	ASSET_STATUS	operational	Operacional	Operational	Operacional	ellipse-outline	#10B981	t	4	2026-03-24 01:21:03.857	2026-03-24 01:21:03.857
cmn3xhvn5000pdajknaf0fesi	ASSET_STATUS	maintenance	Em Manutenção	In Maintenance	En Mantenimiento	ellipse-outline	#F59E0B	t	5	2026-03-24 01:21:03.857	2026-03-24 01:21:03.857
cmn3xhvn5000qdajkxxjkntaa	ASSET_STATUS	inactive	Inativo	Inactive	Inactivo	ellipse-outline	#EF4444	t	6	2026-03-24 01:21:03.858	2026-03-24 01:21:03.858
cmn3xhvn6000rdajkhr96du6q	SERVICE_CATEGORY	eletrica	Elétrica	Electrical	Eléctrica	flash-outline	#F59E0B	t	7	2026-03-24 01:21:03.858	2026-03-24 01:21:03.858
cmn3xhvn6000sdajkqnucvvgy	SERVICE_CATEGORY	hidraulica	Hidráulica	Hydraulic	Hidráulica	water-outline	#3B82F6	t	8	2026-03-24 01:21:03.858	2026-03-24 01:21:03.858
cmn3xhvn6000tdajk5s3glzz2	SERVICE_CATEGORY	limpeza	Limpeza	Cleaning	Limpieza	sparkles-outline	#10B981	t	9	2026-03-24 01:21:03.859	2026-03-24 01:21:03.859
cmn3xhvn7000udajkt2nv0i0t	SERVICE_CATEGORY	reformas	Reformas	Renovation	Reformas	hammer-outline	#8B5CF6	t	10	2026-03-24 01:21:03.859	2026-03-24 01:21:03.859
cmn3xhvn7000vdajkxwenf0em	SERVICE_CATEGORY	jardinagem	Jardinagem	Gardening	Jardinería	leaf-outline	#22C55E	t	11	2026-03-24 01:21:03.86	2026-03-24 01:21:03.86
cmn3xhvn7000wdajkmop7jlfy	SERVICE_CATEGORY	seguranca	Segurança	Security	Seguridad	shield-checkmark-outline	#EF4444	t	12	2026-03-24 01:21:03.86	2026-03-24 01:21:03.86
cmn3xhvn8000xdajk9hbr40ki	SERVICE_CATEGORY	tecnologia	Tecnologia	Technology	Tecnología	laptop-outline	#6366F1	t	13	2026-03-24 01:21:03.86	2026-03-24 01:21:03.86
cmn3xhvn8000ydajkg02kmobm	SERVICE_CATEGORY	mudanca	Mudança	Moving	Mudanza	cube-outline	#EC4899	t	14	2026-03-24 01:21:03.861	2026-03-24 01:21:03.861
cmn4wbq6u0000wmuzn5m7rsda	STOCK_CATEGORY	pecas_reposicao	Peças de Reposição	Spare Parts	Repuestos	build-outline	#F97316	t	1	2026-03-24 17:36:03.414	2026-03-24 17:36:03.414
cmn4wbq6u0001wmuzgxzpslan	STOCK_CATEGORY	consumiveis	Consumíveis	Consumables	Consumibles	flash-outline	#EAB308	t	2	2026-03-24 17:36:03.414	2026-03-24 17:36:03.414
cmn4wbq6u0002wmuz3g4tzy6n	STOCK_CATEGORY	epi	EPIs	PPE	EPP	shield-outline	#10B981	t	3	2026-03-24 17:36:03.414	2026-03-24 17:36:03.414
cmn4wbq6u0003wmuz3tkylhaa	STOCK_CATEGORY	ferramentas	Ferramentas	Tools	Herramientas	hammer-outline	#6366F1	t	4	2026-03-24 17:36:03.414	2026-03-24 17:36:03.414
cmn4wbq6u0004wmuzf6yuwir3	STOCK_CATEGORY	materiais_limpeza	Mat. de Limpeza	Cleaning Supplies	Mat. de Limpieza	water-outline	#3B82F6	t	5	2026-03-24 17:36:03.414	2026-03-24 17:36:03.414
cmn4wbq6u0005wmuzkr6g2l1l	STOCK_CATEGORY	escritorio	Material de Escritório	Office Supplies	Mat. de Oficina	document-outline	#8B5CF6	t	6	2026-03-24 17:36:03.414	2026-03-24 17:36:03.414
cmn4wbq6u0006wmuzpq4jfbrp	STOCK_CATEGORY	combustivel	Combustível	Fuel	Combustible	flame-outline	#EF4444	t	7	2026-03-24 17:36:03.414	2026-03-24 17:36:03.414
cmn4wbq6u0007wmuz63apzd1s	STOCK_CATEGORY	outros_estoque	Outros	Other	Otros	cube-outline	#64748B	t	99	2026-03-24 17:36:03.414	2026-03-24 17:36:03.414
cmn4wbq6u0008wmuzldu9zn55	EXPENSE_CATEGORY	manutencao	Manutenção	Maintenance	Mantenimiento	construct-outline	#F97316	t	1	2026-03-24 17:36:03.414	2026-03-24 17:36:03.414
cmn4wbq6u0009wmuz0rgnfkhh	EXPENSE_CATEGORY	seguro	Seguro	Insurance	Seguro	shield-checkmark-outline	#10B981	t	2	2026-03-24 17:36:03.414	2026-03-24 17:36:03.414
cmn4wbq6u000awmuz4a08mde0	EXPENSE_CATEGORY	iptu	IPTU / Impostos	Property Tax	Impuesto Predial	receipt-outline	#EF4444	t	3	2026-03-24 17:36:03.414	2026-03-24 17:36:03.414
cmn4wbq6u000bwmuzx3sre93f	EXPENSE_CATEGORY	condominio	Condomínio	Condo Fee	Condominio	business-outline	#3B82F6	t	4	2026-03-24 17:36:03.414	2026-03-24 17:36:03.414
cmn4wbq6u000cwmuze3lzqs8d	EXPENSE_CATEGORY	combustivel_exp	Combustível	Fuel	Combustible	flame-outline	#EAB308	t	5	2026-03-24 17:36:03.414	2026-03-24 17:36:03.414
cmn4wbq6u000dwmuzqbkbk6d0	EXPENSE_CATEGORY	reforma	Reforma / Obra	Renovation	Renovación	hammer-outline	#8B5CF6	t	6	2026-03-24 17:36:03.414	2026-03-24 17:36:03.414
cmn4wbq6u000ewmuz08sy3s5s	EXPENSE_CATEGORY	conta_agua	Água / Luz / Gás	Utilities	Servicios	water-outline	#06B6D4	t	7	2026-03-24 17:36:03.414	2026-03-24 17:36:03.414
cmn4wbq6v000fwmuzlgas7obj	EXPENSE_CATEGORY	outros_exp	Outros	Other	Otros	ellipsis-horizontal-outline	#64748B	t	99	2026-03-24 17:36:03.414	2026-03-24 17:36:03.414
cmn4wbq6v000gwmuzlbsahiki	REVENUE_CATEGORY	aluguel	Aluguel	Rent	Alquiler	home-outline	#10B981	t	1	2026-03-24 17:36:03.414	2026-03-24 17:36:03.414
cmn4wbq6v000hwmuze3crnkeq	REVENUE_CATEGORY	venda	Venda	Sale	Venta	cash-outline	#3B82F6	t	2	2026-03-24 17:36:03.414	2026-03-24 17:36:03.414
cmn4wbq6v000iwmuz0tc6wke3	REVENUE_CATEGORY	dividendos	Dividendos	Dividends	Dividendos	trending-up-outline	#6366F1	t	3	2026-03-24 17:36:03.414	2026-03-24 17:36:03.414
cmn4wbq6v000jwmuzmpq3nypm	REVENUE_CATEGORY	servico_prestado	Serviço Prestado	Service Revenue	Ingreso de Servicio	briefcase-outline	#F97316	t	4	2026-03-24 17:36:03.414	2026-03-24 17:36:03.414
cmn4wbq6v000kwmuz3rwo9bf6	REVENUE_CATEGORY	outros_rev	Outros	Other	Otros	ellipsis-horizontal-outline	#64748B	t	99	2026-03-24 17:36:03.414	2026-03-24 17:36:03.414
cmn6nq8bb0000sn7dxgvqfa65	MEDIA_CATEGORY	foto	Foto	Foto	Foto	camera-outline	#3B82F6	t	0	2026-03-25 23:10:55.895	2026-03-25 23:10:55.895
cmn6nq8ht0001sn7drkm65utm	MEDIA_CATEGORY	video	Vídeo	Vídeo	Vídeo	videocam-outline	#8B5CF6	t	1	2026-03-25 23:10:56.13	2026-03-25 23:10:56.13
cmn6nq8hw0002sn7d7xljotci	MEDIA_CATEGORY	documento	Documento	Documento	Documento	document-text-outline	#F59E0B	t	2	2026-03-25 23:10:56.132	2026-03-25 23:10:56.132
cmn6nq8i10003sn7dd7nsscxc	MEDIA_CATEGORY	planta_baixa	Planta Baixa	Planta Baixa	Planta Baixa	map-outline	#10B981	t	3	2026-03-25 23:10:56.137	2026-03-25 23:10:56.137
cmn6nq8i40004sn7dg6i5sf16	MEDIA_CATEGORY	nota_fiscal	Nota Fiscal	Nota Fiscal	Nota Fiscal	receipt-outline	#EF4444	t	4	2026-03-25 23:10:56.14	2026-03-25 23:10:56.14
cmn6nq8i60005sn7d3nl9yked	MEDIA_CATEGORY	contrato	Contrato	Contrato	Contrato	reader-outline	#6366F1	t	5	2026-03-25 23:10:56.142	2026-03-25 23:10:56.142
cmn6nq8i80006sn7dhgnkg73m	MEDIA_CATEGORY	laudo	Laudo / Relatório	Laudo / Relatório	Laudo / Relatório	clipboard-outline	#F97316	t	6	2026-03-25 23:10:56.144	2026-03-25 23:10:56.144
cmn6nq8lb0009sn7dwx3ruevw	MEDIA_CATEGORY	outro	Outro	Outro	Outro	ellipsis-horizontal-outline	#9CA3AF	t	9	2026-03-25 23:10:56.256	2026-03-25 23:10:56.256
\.


--
-- Data for Name: NotificationLog; Type: TABLE DATA; Schema: public; Owner: alex
--

COPY public."NotificationLog" (id, "templateId", recipient, channel, status, "sentAt", metadata) FROM stdin;
\.


--
-- Data for Name: NotificationTemplate; Type: TABLE DATA; Schema: public; Owner: alex
--

COPY public."NotificationTemplate" (id, key, label, channel, subject, body, variables, "isActive", "createdAt", "updatedAt") FROM stdin;
cmn3xhvne000zdajkrzl6l62p	welcome	Boas-vindas	EMAIL	Bem-vindo à BrSpark, {{name}}!	Olá {{name}},\n\nSeu acesso foi criado com sucesso.\n\nE-mail: {{email}}\nSenha temporária: {{password}}\n\nAcesse: {{loginUrl}}	{"name": "string", "email": "string", "loginUrl": "string", "password": "string"}	t	2026-03-24 01:21:03.867	2026-03-24 01:21:03.867
cmn3xhvni0010dajkkui4tyhq	stock_low	Estoque Crítico	PUSH	\N	⚠️ {{itemName}} atingiu nível crítico no {{assetName}} ({{currentStock}} {{unit}} restantes)	{"unit": "string", "itemName": "string", "assetName": "string", "currentStock": "string"}	t	2026-03-24 01:21:03.87	2026-03-24 01:21:03.87
cmn3xhvni0011dajkttz8ouzl	policy_expiring	Apólice Vencendo	EMAIL	Apólice vencendo em {{days}} dias	Sua apólice {{policyName}} vence em {{dueDate}}.	{"dueDate": "string", "policyName": "string"}	t	2026-03-24 01:21:03.871	2026-03-24 01:21:03.871
cmn3xhvnj0012dajkxchvr72i	trial_ending	Trial Encerrando	EMAIL	Seu período trial encerra em {{days}} dias	Olá {{tenantName}},\n\nSeu trial encerra em {{days}} dias. Escolha um plano para continuar usando.	{"days": "string", "tenantName": "string"}	t	2026-03-24 01:21:03.872	2026-03-24 01:21:03.872
\.


--
-- Data for Name: Plan; Type: TABLE DATA; Schema: public; Owner: alex
--

COPY public."Plan" (id, name, "priceMonthly", "priceYearly", "maxAssets", "maxUsers", "storageGb", features, "isActive", "createdAt", "updatedAt") FROM stdin;
cmn3xhvm00001dajksgpasg5e	Pro	399.00	3990.00	500	20	50	{"ai": true, "stock": true, "vault": true, "documents": true, "insurance": true}	t	2026-03-24 01:21:03.817	2026-03-24 01:21:03.817
cmn3xhvmb0003dajk7rnd1j9t	Enterprise	2400.00	24000.00	-1	-1	500	{"ai": true, "stock": true, "vault": true, "reports": true, "realtime": true, "documents": true, "insurance": true}	t	2026-03-24 01:21:03.817	2026-03-24 01:21:03.817
cmn3xhvma0002dajkn01kcgec	Basic	99.00	990.00	50	5	5	{"ai": false, "stock": true, "vault": false, "documents": true, "insurance": false}	t	2026-03-24 01:21:03.817	2026-03-24 01:21:03.817
\.


--
-- Data for Name: PushToken; Type: TABLE DATA; Schema: public; Owner: alex
--

COPY public."PushToken" (id, "userId", token, device, "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: ServiceProvider; Type: TABLE DATA; Schema: public; Owner: alex
--

COPY public."ServiceProvider" (id, name, category, rating, reviews, photo, tags, keywords, phone, email, city, state, verified, "isActive", "createdAt", "updatedAt") FROM stdin;
cmn3y6wju0000kqjya2y617lh	Carlos Andrade	Elétrica	4.4	278	https://randomuser.me/api/portraits/men/1.jpg	"[\\"Industrial\\",\\"Residencial\\",\\"Urgência\\"]"	eletrica instalacao quadro tomada luz iluminacao spda gerador urgencia emergencia	(11) 98847-6576	\N	Bauru	SP	t	t	2026-03-24 01:40:31.434	2026-03-24 01:40:31.434
cmn3y6wkf0001kqjyy8hz5u5d	Roberto Ferreira	Elétrica	3.9	251	https://randomuser.me/api/portraits/men/2.jpg	"[\\"Instalação\\",\\"Quadro\\",\\"SPDA\\"]"	eletrica instalacao quadro tomada luz iluminacao spda gerador urgencia emergencia	(11) 95831-1173	\N	Jundiaí	SP	t	t	2026-03-24 01:40:31.455	2026-03-24 01:40:31.455
cmn3y6wki0002kqjym95hnn9j	José Oliveira	Elétrica	4.7	43	https://randomuser.me/api/portraits/men/3.jpg	"[\\"Gerador\\",\\"Painel\\",\\"Certificado\\"]"	eletrica instalacao quadro tomada luz iluminacao spda gerador urgencia emergencia	(15) 91026-9317	\N	Jundiaí	SP	t	t	2026-03-24 01:40:31.459	2026-03-24 01:40:31.459
cmn3y6wl00003kqjyy1tfuac2	Marcos Santos	Elétrica	4.8	216	https://randomuser.me/api/portraits/men/4.jpg	"[\\"Instalação\\",\\"Quadro\\",\\"SPDA\\"]"	eletrica instalacao quadro tomada luz iluminacao spda gerador urgencia emergencia	(11) 95583-7535	\N	Bauru	SP	f	t	2026-03-24 01:40:31.476	2026-03-24 01:40:31.476
cmn3y6wl40004kqjyok7521r5	Paulo Rodrigues	Elétrica	4.6	15	https://randomuser.me/api/portraits/men/5.jpg	"[\\"Gerador\\",\\"Painel\\",\\"Certificado\\"]"	eletrica instalacao quadro tomada luz iluminacao spda gerador urgencia emergencia	(11) 97018-1468	\N	São Paulo	SP	f	t	2026-03-24 01:40:31.481	2026-03-24 01:40:31.481
cmn3y6wl50005kqjy31cars6f	Fernando Lima	Hidráulica	4	38	https://randomuser.me/api/portraits/men/6.jpg	"[\\"Fossa\\",\\"Desentupimento\\",\\"Bomba\\"]"	hidraulica encanamento cano vazamento desentupimento fossa bomba agua aquecedor	(11) 99153-9938	\N	Osasco	SP	t	t	2026-03-24 01:40:31.482	2026-03-24 01:40:31.482
cmn3y6wl60006kqjyxvfsyxfi	Antônio Araújo	Hidráulica	4.4	23	https://randomuser.me/api/portraits/men/7.jpg	"[\\"Caixa d'Água\\",\\"Encanamento\\",\\"Rápido\\"]"	hidraulica encanamento cano vazamento desentupimento fossa bomba agua aquecedor	(13) 93074-6879	\N	Santo André	SP	t	t	2026-03-24 01:40:31.483	2026-03-24 01:40:31.483
cmn3y6wl80007kqjymkparapr	Ricardo Alves	Hidráulica	4.1	130	https://randomuser.me/api/portraits/men/8.jpg	"[\\"Fossa\\",\\"Desentupimento\\",\\"Bomba\\"]"	hidraulica encanamento cano vazamento desentupimento fossa bomba agua aquecedor	(11) 91570-2463	\N	Sorocaba	SP	t	t	2026-03-24 01:40:31.484	2026-03-24 01:40:31.484
cmn3y6wl80008kqjy2ursw6zh	Eduardo Costa	Hidráulica	4.9	199	https://randomuser.me/api/portraits/men/9.jpg	"[\\"Aquecimento\\",\\"Chuveiro\\",\\"Infiltração\\"]"	hidraulica encanamento cano vazamento desentupimento fossa bomba agua aquecedor	(11) 99162-1619	\N	Osasco	SP	f	t	2026-03-24 01:40:31.485	2026-03-24 01:40:31.485
cmn3y6wlc0009kqjyspwywcdn	Renato Barbosa	Hidráulica	4.4	199	https://randomuser.me/api/portraits/men/10.jpg	"[\\"Vazamento\\",\\"Registro\\",\\"Urgência\\"]"	hidraulica encanamento cano vazamento desentupimento fossa bomba agua aquecedor	(13) 96039-8361	\N	Santo André	SP	t	t	2026-03-24 01:40:31.488	2026-03-24 01:40:31.488
cmn3y6wlc000akqjyky4d1q0k	Gustavo Carvalho	Limpeza	4.4	146	https://randomuser.me/api/portraits/men/11.jpg	"[\\"Pós Obra\\",\\"Profissional\\",\\"Rápido\\"]"	limpeza faxina residencial comercial predial condominio pos obra vidros fachada	(11) 96976-1218	\N	São Bernardo do Campo	SP	f	t	2026-03-24 01:40:31.489	2026-03-24 01:40:31.489
cmn3y6wld000bkqjyj64hut60	Leonardo Sousa	Limpeza	4.5	16	https://randomuser.me/api/portraits/men/12.jpg	"[\\"Fim de Obra\\",\\"Vidros\\",\\"Fachada\\"]"	limpeza faxina residencial comercial predial condominio pos obra vidros fachada	(11) 92432-3100	\N	Mogi das Cruzes	SP	t	t	2026-03-24 01:40:31.489	2026-03-24 01:40:31.489
cmn3y6wld000ckqjyl67fjewz	Alexandre Martins	Limpeza	4.3	306	https://randomuser.me/api/portraits/men/13.jpg	"[\\"Residencial\\",\\"Periódica\\",\\"Confiável\\"]"	limpeza faxina residencial comercial predial condominio pos obra vidros fachada	(11) 97385-1952	\N	São Paulo	SP	t	t	2026-03-24 01:40:31.49	2026-03-24 01:40:31.49
cmn3y6wle000dkqjyh4rhhx47	Bruno Pereira	Limpeza	3.9	89	https://randomuser.me/api/portraits/men/14.jpg	"[\\"Fim de Obra\\",\\"Vidros\\",\\"Fachada\\"]"	limpeza faxina residencial comercial predial condominio pos obra vidros fachada	(19) 92177-3800	\N	São Paulo	SP	t	t	2026-03-24 01:40:31.49	2026-03-24 01:40:31.49
cmn3y6wmb000ekqjy6i5qxbfm	Daniel Ribeiro	Limpeza	4.2	39	https://randomuser.me/api/portraits/men/15.jpg	"[\\"Residencial\\",\\"Periódica\\",\\"Confiável\\"]"	limpeza faxina residencial comercial predial condominio pos obra vidros fachada	(11) 96888-7675	\N	Bauru	SP	t	t	2026-03-24 01:40:31.523	2026-03-24 01:40:31.523
cmn3y6wms000fkqjyp0wrojqq	Lucas Azevedo	Reformas	4.3	272	https://randomuser.me/api/portraits/men/16.jpg	"[\\"Banheiro\\",\\"Cozinha\\",\\"Design\\"]"	reforma alvenaria construcao acabamento banheiro cozinha azulejo porcelanato gesseiro	(11) 98962-5755	\N	São Bernardo do Campo	SP	t	t	2026-03-24 01:40:31.54	2026-03-24 01:40:31.54
cmn3y6wnf000gkqjyr0yh93ur	Rodrigo Monteiro	Reformas	4.2	53	https://randomuser.me/api/portraits/men/17.jpg	"[\\"Banheiro\\",\\"Cozinha\\",\\"Design\\"]"	reforma alvenaria construcao acabamento banheiro cozinha azulejo porcelanato gesseiro	(11) 99888-3309	\N	Guarulhos	SP	t	t	2026-03-24 01:40:31.563	2026-03-24 01:40:31.563
cmn3y6wnn000hkqjyq8o6hmxn	Felipe Correia	Reformas	4.2	129	https://randomuser.me/api/portraits/men/18.jpg	"[\\"Banheiro\\",\\"Cozinha\\",\\"Design\\"]"	reforma alvenaria construcao acabamento banheiro cozinha azulejo porcelanato gesseiro	(11) 95948-5591	\N	Piracicaba	SP	t	t	2026-03-24 01:40:31.572	2026-03-24 01:40:31.572
cmn3y6wnp000ikqjyvmemyx1m	Thiago Nascimento	Reformas	4.1	237	https://randomuser.me/api/portraits/men/19.jpg	"[\\"Gesseiro\\",\\"Forro de Gesso\\",\\"Acabamento\\"]"	reforma alvenaria construcao acabamento banheiro cozinha azulejo porcelanato gesseiro	(13) 98449-4313	\N	São Paulo	SP	t	t	2026-03-24 01:40:31.574	2026-03-24 01:40:31.574
cmn3y6wnq000jkqjy6zuzqpd4	Mateus Medeiros	Reformas	4.8	62	https://randomuser.me/api/portraits/men/20.jpg	"[\\"Banheiro\\",\\"Cozinha\\",\\"Design\\"]"	reforma alvenaria construcao acabamento banheiro cozinha azulejo porcelanato gesseiro	(11) 99864-9959	\N	São Paulo	SP	f	t	2026-03-24 01:40:31.574	2026-03-24 01:40:31.574
cmn3y6wnr000kkqjynzfj93p2	Aline Silveira	Jardinagem	4.5	188	https://randomuser.me/api/portraits/men/21.jpg	"[\\"Jardim\\",\\"Horta\\",\\"Orgânico\\"]"	jardinagem poda paisagismo jardim grama adubacao irrigacao arvore horta organico	(11) 96078-7267	\N	São Bernardo do Campo	SP	t	t	2026-03-24 01:40:31.575	2026-03-24 01:40:31.575
cmn3y6wnr000lkqjym5y6pm84	Fernanda Gomes	Jardinagem	4.6	9	https://randomuser.me/api/portraits/men/22.jpg	"[\\"Grama\\",\\"Adubação\\",\\"Irrigação\\"]"	jardinagem poda paisagismo jardim grama adubacao irrigacao arvore horta organico	(13) 95999-9525	\N	Santo André	SP	t	t	2026-03-24 01:40:31.576	2026-03-24 01:40:31.576
cmn3y6wns000mkqjyk7mqdn6i	Juliana Castro	Jardinagem	4.8	94	https://randomuser.me/api/portraits/men/23.jpg	"[\\"Árvores\\",\\"Poda\\",\\"Certificado\\"]"	jardinagem poda paisagismo jardim grama adubacao irrigacao arvore horta organico	(15) 96044-7193	\N	Sorocaba	SP	f	t	2026-03-24 01:40:31.576	2026-03-24 01:40:31.576
cmn3y6wns000nkqjynenjul19	Camila Moreira	Jardinagem	4	315	https://randomuser.me/api/portraits/men/24.jpg	"[\\"Árvores\\",\\"Poda\\",\\"Certificado\\"]"	jardinagem poda paisagismo jardim grama adubacao irrigacao arvore horta organico	(19) 92625-9977	\N	Ribeirão Preto	SP	f	t	2026-03-24 01:40:31.577	2026-03-24 01:40:31.577
cmn3y6wnt000okqjystc22dm5	Patricia Nunes	Jardinagem	4.8	18	https://randomuser.me/api/portraits/men/25.jpg	"[\\"Vasos\\",\\"Decoração\\",\\"Projeto\\"]"	jardinagem poda paisagismo jardim grama adubacao irrigacao arvore horta organico	(11) 93565-8088	\N	São Paulo	SP	t	t	2026-03-24 01:40:31.577	2026-03-24 01:40:31.577
cmn3y6wnt000pkqjyl80prkm7	Sandra Rocha	Segurança	4.7	268	https://randomuser.me/api/portraits/men/26.jpg	"[\\"Câmeras\\",\\"CFTV\\",\\"24h\\"]"	seguranca cameras alarme monitoramento cftv cerca eletrica portao residencial	(11) 98240-9940	\N	Jundiaí	SP	t	t	2026-03-24 01:40:31.578	2026-03-24 01:40:31.578
cmn3y6wnu000qkqjyzqbu9rdp	Luciana Pinto	Segurança	4.5	281	https://randomuser.me/api/portraits/men/27.jpg	"[\\"Alarme\\",\\"Monitoramento\\",\\"Residencial\\"]"	seguranca cameras alarme monitoramento cftv cerca eletrica portao residencial	(13) 95735-7329	\N	Santo André	SP	t	t	2026-03-24 01:40:31.578	2026-03-24 01:40:31.578
cmn3y6wnu000rkqjyeitzv73r	Claudia Mendes	Segurança	5	107	https://randomuser.me/api/portraits/men/28.jpg	"[\\"Câmeras\\",\\"CFTV\\",\\"24h\\"]"	seguranca cameras alarme monitoramento cftv cerca eletrica portao residencial	(11) 99719-6235	\N	São Bernardo do Campo	SP	t	t	2026-03-24 01:40:31.579	2026-03-24 01:40:31.579
cmn3y6wnv000skqjy22fn14bf	Beatriz Ramos	Climatização	5	98	https://randomuser.me/api/portraits/men/29.jpg	"[\\"Ar Condicionado\\",\\"Instalação\\",\\"Manutenção\\"]"	ar condicionado split inverter climatizacao limpeza instalacao manutencao central	(11) 96229-3435	\N	Jundiaí	SP	t	t	2026-03-24 01:40:31.579	2026-03-24 01:40:31.579
cmn3y6wnv000tkqjym9up3eow	Gabriela Cardoso	Climatização	4	199	https://randomuser.me/api/portraits/men/30.jpg	"[\\"Central\\",\\"Comercial\\",\\"Certificado\\"]"	ar condicionado split inverter climatizacao limpeza instalacao manutencao central	(11) 96236-4258	\N	São Paulo	SP	t	t	2026-03-24 01:40:31.579	2026-03-24 01:40:31.579
cmn3y6wnv000ukqjy4lb4boky	Eletro Rápido SP	Climatização	4.9	305	https://randomuser.me/api/portraits/men/31.jpg	"[\\"Central\\",\\"Comercial\\",\\"Certificado\\"]"	ar condicionado split inverter climatizacao limpeza instalacao manutencao central	(11) 94048-9163	\N	São Bernardo do Campo	SP	t	t	2026-03-24 01:40:31.58	2026-03-24 01:40:31.58
cmn3y6wnw000vkqjywzotpa8a	Hidro Fix Encanamentos	Tecnologia	4.5	276	https://randomuser.me/api/portraits/men/32.jpg	"[\\"Redes\\",\\"Wi-Fi\\",\\"Cabeamento\\"]"	tecnologia rede wifi cabeamento computador notebook formatacao servidor cftv backup	(11) 94048-3176	\N	São Bernardo do Campo	SP	t	t	2026-03-24 01:40:31.58	2026-03-24 01:40:31.58
cmn3y6wnx000wkqjylr58raxg	Spick & Span Limpeza	Tecnologia	4.1	148	https://randomuser.me/api/portraits/men/33.jpg	"[\\"Computadores\\",\\"Formatação\\",\\"Suporte\\"]"	tecnologia rede wifi cabeamento computador notebook formatacao servidor cftv backup	(15) 95883-8077	\N	Jundiaí	SP	t	t	2026-03-24 01:40:31.581	2026-03-24 01:40:31.581
cmn3y6wnx000xkqjyzoa4jou5	ReformaMax SP	Tecnologia	4.7	177	https://randomuser.me/api/portraits/men/34.jpg	"[\\"CFTV\\",\\"Servidor\\",\\"Backup\\"]"	tecnologia rede wifi cabeamento computador notebook formatacao servidor cftv backup	(11) 97227-1046	\N	Santos	SP	t	t	2026-03-24 01:40:31.582	2026-03-24 01:40:31.582
cmn3y6wny000ykqjya510sact	Verde Jardins	Dedetização	4.4	257	https://randomuser.me/api/portraits/men/35.jpg	"[\\"Formigas\\",\\"Mosquitos\\",\\"Certificado\\"]"	dedetizacao cupim rato barata formiga mosquito certificado controle pragas	(19) 98943-6406	\N	Campinas	SP	f	t	2026-03-24 01:40:31.582	2026-03-24 01:40:31.582
cmn3y6wny000zkqjy0dodh9si	SecureHome SP	Dedetização	4.6	298	https://randomuser.me/api/portraits/men/36.jpg	"[\\"Cupim\\",\\"Baratas\\",\\"Ratos\\"]"	dedetizacao cupim rato barata formiga mosquito certificado controle pragas	(11) 91500-4874	\N	Mogi das Cruzes	SP	t	t	2026-03-24 01:40:31.583	2026-03-24 01:40:31.583
cmn3y6wnz0010kqjymaielmkm	ClimaTech SP	Mudança	4	144	https://randomuser.me/api/portraits/men/37.jpg	"[\\"Guarda Móveis\\",\\"Seguro\\",\\"Rápido\\"]"	mudanca transporte caminhao embalar desmontar guarda moveis comercial residencial	(11) 97275-6584	\N	Ribeirão Preto	SP	t	t	2026-03-24 01:40:31.583	2026-03-24 01:40:31.583
cmn3y6wo00011kqjy05arqocg	TechSupport Brasil	Mudança	4.7	220	https://randomuser.me/api/portraits/men/38.jpg	"[\\"Comercial\\",\\"Piano\\",\\"Desmontagem\\"]"	mudanca transporte caminhao embalar desmontar guarda moveis comercial residencial	(11) 93718-5028	\N	Mogi das Cruzes	SP	t	t	2026-03-24 01:40:31.585	2026-03-24 01:40:31.585
cmn3y6wo10012kqjy3j4mtjn8	Dedetizadora Alpha SP	Mudança	4.1	240	https://randomuser.me/api/portraits/men/39.jpg	"[\\"Residencial\\",\\"Caminhão\\",\\"Embalagem\\"]"	mudanca transporte caminhao embalar desmontar guarda moveis comercial residencial	(15) 97451-1527	\N	Bauru	SP	t	t	2026-03-24 01:40:31.586	2026-03-24 01:40:31.586
cmn3y6wo10013kqjy7lfy85co	Mudança Fácil SP	Gás	4.5	225	https://randomuser.me/api/portraits/men/40.jpg	"[\\"Botijão\\",\\"Encanamento\\",\\"Urgência\\"]"	gas gasoducto instalacao vazamento botijao encanamento regulagem urgencia	(11) 97775-3652	\N	São Bernardo do Campo	SP	t	t	2026-03-24 01:40:31.586	2026-03-24 01:40:31.586
cmn3y6wo20014kqjyyu14e6gz	Gastech Instalações	Gás	4	275	https://randomuser.me/api/portraits/men/41.jpg	"[\\"Instalação\\",\\"Vazamento\\",\\"Regulagem\\"]"	gas gasoducto instalacao vazamento botijao encanamento regulagem urgencia	(11) 97048-6670	\N	Santos	SP	t	t	2026-03-24 01:40:31.587	2026-03-24 01:40:31.587
cmn3y6wo30015kqjyuf0l83qi	Pintor Pro SP	Pintura	4.7	143	https://randomuser.me/api/portraits/men/42.jpg	"[\\"Fachada\\",\\"Predial\\",\\"CertificadoMaestria\\"]"	pintura tinta parede textura interna externa fachada predial epóxi piso	(15) 96683-9420	\N	Campinas	SP	t	t	2026-03-24 01:40:31.588	2026-03-24 01:40:31.588
cmn3y6wo30016kqjy3pkiketm	Elétrica 24h Santos	Pintura	3.8	260	https://randomuser.me/api/portraits/men/43.jpg	"[\\"Epóxi\\",\\"Piso\\",\\"Especializado\\"]"	pintura tinta parede textura interna externa fachada predial epóxi piso	(13) 96407-4145	\N	Piracicaba	SP	t	t	2026-03-24 01:40:31.588	2026-03-24 01:40:31.588
cmn3y6wo40017kqjy34yrrpdz	AquaPro Hidráulica	Pintura	4.1	138	https://randomuser.me/api/portraits/men/44.jpg	"[\\"Epóxi\\",\\"Piso\\",\\"Especializado\\"]"	pintura tinta parede textura interna externa fachada predial epóxi piso	(11) 98014-9411	\N	São Paulo	SP	t	t	2026-03-24 01:40:31.588	2026-03-24 01:40:31.588
cmn3y6wo40018kqjy1i245p9o	CleanSpace SP	Elétrica	4.1	154	https://randomuser.me/api/portraits/men/45.jpg	"[\\"Gerador\\",\\"Painel\\",\\"Certificado\\"]"	eletrica instalacao quadro tomada luz iluminacao spda gerador urgencia emergencia	(11) 96591-4748	\N	Santo André	SP	f	t	2026-03-24 01:40:31.589	2026-03-24 01:40:31.589
cmn3y6wo60019kqjy2m5ewfh6	Miguel Torres	Elétrica	4.2	20	https://randomuser.me/api/portraits/men/46.jpg	"[\\"Tomadas\\",\\"Iluminação\\",\\"Rápido\\"]"	eletrica instalacao quadro tomada luz iluminacao spda gerador urgencia emergencia	(11) 91704-6613	\N	Ribeirão Preto	SP	f	t	2026-03-24 01:40:31.591	2026-03-24 01:40:31.591
cmn3y6wo9001akqjya9f8y2c4	Henrique Campos	Elétrica	4.3	81	https://randomuser.me/api/portraits/men/47.jpg	"[\\"Tomadas\\",\\"Iluminação\\",\\"Rápido\\"]"	eletrica instalacao quadro tomada luz iluminacao spda gerador urgencia emergencia	(13) 99790-9130	\N	São Paulo	SP	t	t	2026-03-24 01:40:31.593	2026-03-24 01:40:31.593
cmn3y6won001bkqjyri19e4xu	Gabriel Vieira	Elétrica	4.4	48	https://randomuser.me/api/portraits/men/48.jpg	"[\\"Instalação\\",\\"Quadro\\",\\"SPDA\\"]"	eletrica instalacao quadro tomada luz iluminacao spda gerador urgencia emergencia	(15) 98439-9230	\N	Mogi das Cruzes	SP	t	t	2026-03-24 01:40:31.607	2026-03-24 01:40:31.607
cmn3y6wpm001ckqjyjdx3j2uk	Vinicius Santana	Elétrica	3.8	36	https://randomuser.me/api/portraits/men/49.jpg	"[\\"24h\\",\\"Emergência\\",\\"Confiável\\"]"	eletrica instalacao quadro tomada luz iluminacao spda gerador urgencia emergencia	(13) 96688-2620	\N	Sorocaba	SP	f	t	2026-03-24 01:40:31.643	2026-03-24 01:40:31.643
cmn3y6wpz001dkqjy7j6jx65n	Diego Teixeira	Hidráulica	4	72	https://randomuser.me/api/portraits/men/50.jpg	"[\\"Fossa\\",\\"Desentupimento\\",\\"Bomba\\"]"	hidraulica encanamento cano vazamento desentupimento fossa bomba agua aquecedor	(11) 97300-5574	\N	São Paulo	SP	t	t	2026-03-24 01:40:31.655	2026-03-24 01:40:31.655
cmn3y6wpz001ekqjy5mvms1lx	Andréia Lopes	Hidráulica	3.9	236	https://randomuser.me/api/portraits/women/1.jpg	"[\\"Aquecimento\\",\\"Chuveiro\\",\\"Infiltração\\"]"	hidraulica encanamento cano vazamento desentupimento fossa bomba agua aquecedor	(15) 99168-2887	\N	Osasco	SP	f	t	2026-03-24 01:40:31.656	2026-03-24 01:40:31.656
cmn3y6wq0001fkqjyp1budjnv	Mariana Freitas	Hidráulica	4.5	284	https://randomuser.me/api/portraits/women/2.jpg	"[\\"Fossa\\",\\"Desentupimento\\",\\"Bomba\\"]"	hidraulica encanamento cano vazamento desentupimento fossa bomba agua aquecedor	(11) 98570-8732	\N	Mogi das Cruzes	SP	t	t	2026-03-24 01:40:31.657	2026-03-24 01:40:31.657
cmn3y6wq1001gkqjyhqswtn58	Rafaela Macedo	Hidráulica	4.9	317	https://randomuser.me/api/portraits/women/3.jpg	"[\\"Fossa\\",\\"Desentupimento\\",\\"Bomba\\"]"	hidraulica encanamento cano vazamento desentupimento fossa bomba agua aquecedor	(11) 94586-3949	\N	Guarulhos	SP	t	t	2026-03-24 01:40:31.657	2026-03-24 01:40:31.657
cmn3y6wq1001hkqjybvg2unzj	Tatiane Borges	Hidráulica	4.9	67	https://randomuser.me/api/portraits/women/4.jpg	"[\\"Caixa d'Água\\",\\"Encanamento\\",\\"Rápido\\"]"	hidraulica encanamento cano vazamento desentupimento fossa bomba agua aquecedor	(13) 92687-3949	\N	Ribeirão Preto	SP	t	t	2026-03-24 01:40:31.658	2026-03-24 01:40:31.658
cmn3y6wq2001ikqjyc3jhofdo	Priscila Cunha	Limpeza	4.3	277	https://randomuser.me/api/portraits/women/5.jpg	"[\\"Condomínio\\",\\"Predial\\",\\"Empresa\\"]"	limpeza faxina residencial comercial predial condominio pos obra vidros fachada	(13) 94117-9011	\N	Piracicaba	SP	t	t	2026-03-24 01:40:31.659	2026-03-24 01:40:31.659
cmn3y6wq2001jkqjyhps44e07	MultiServ Elétrica	Limpeza	3.9	171	https://randomuser.me/api/portraits/women/6.jpg	"[\\"Pós Obra\\",\\"Profissional\\",\\"Rápido\\"]"	limpeza faxina residencial comercial predial condominio pos obra vidros fachada	(13) 98047-7129	\N	Campinas	SP	t	t	2026-03-24 01:40:31.659	2026-03-24 01:40:31.659
cmn3y6wq3001kkqjyu1sv49bc	HidroMestre	Limpeza	3.9	274	https://randomuser.me/api/portraits/women/7.jpg	"[\\"Residencial\\",\\"Periódica\\",\\"Confiável\\"]"	limpeza faxina residencial comercial predial condominio pos obra vidros fachada	(11) 93811-9490	\N	São Paulo	SP	t	t	2026-03-24 01:40:31.659	2026-03-24 01:40:31.659
cmn3y6wq3001lkqjya4khd2cm	LimpaMax	Limpeza	4.7	33	https://randomuser.me/api/portraits/women/8.jpg	"[\\"Residencial\\",\\"Periódica\\",\\"Confiável\\"]"	limpeza faxina residencial comercial predial condominio pos obra vidros fachada	(13) 93178-4921	\N	São Paulo	SP	t	t	2026-03-24 01:40:31.66	2026-03-24 01:40:31.66
cmn3y6wq4001mkqjy0b0qdbke	ConstruFácil	Limpeza	4.5	120	https://randomuser.me/api/portraits/women/9.jpg	"[\\"Fim de Obra\\",\\"Vidros\\",\\"Fachada\\"]"	limpeza faxina residencial comercial predial condominio pos obra vidros fachada	(11) 93251-8733	\N	Bauru	SP	f	t	2026-03-24 01:40:31.66	2026-03-24 01:40:31.66
cmn3y6wq4001nkqjyoa8u6pwp	JardimVerde	Reformas	4.5	94	https://randomuser.me/api/portraits/women/10.jpg	"[\\"Banheiro\\",\\"Cozinha\\",\\"Design\\"]"	reforma alvenaria construcao acabamento banheiro cozinha azulejo porcelanato gesseiro	(15) 97867-3427	\N	Osasco	SP	t	t	2026-03-24 01:40:31.661	2026-03-24 01:40:31.661
cmn3y6wq5001okqjy274aam32	GuardaSeuLar	Reformas	4.8	54	https://randomuser.me/api/portraits/women/11.jpg	"[\\"Banheiro\\",\\"Cozinha\\",\\"Design\\"]"	reforma alvenaria construcao acabamento banheiro cozinha azulejo porcelanato gesseiro	(11) 91275-2479	\N	Piracicaba	SP	t	t	2026-03-24 01:40:31.661	2026-03-24 01:40:31.661
cmn3y6wq5001pkqjylyb4rjn1	FrioCerto	Reformas	4.2	203	https://randomuser.me/api/portraits/women/12.jpg	"[\\"Gesseiro\\",\\"Forro de Gesso\\",\\"Acabamento\\"]"	reforma alvenaria construcao acabamento banheiro cozinha azulejo porcelanato gesseiro	(11) 93196-2850	\N	Osasco	SP	t	t	2026-03-24 01:40:31.662	2026-03-24 01:40:31.662
cmn3y6wq6001qkqjy7p9pu3oi	NetFix TI	Reformas	4.3	97	https://randomuser.me/api/portraits/women/13.jpg	"[\\"Banheiro\\",\\"Cozinha\\",\\"Design\\"]"	reforma alvenaria construcao acabamento banheiro cozinha azulejo porcelanato gesseiro	(11) 96327-4757	\N	Santos	SP	f	t	2026-03-24 01:40:31.662	2026-03-24 01:40:31.662
cmn3y6wq6001rkqjy2rdtiw6z	PragaZero	Reformas	4.6	55	https://randomuser.me/api/portraits/women/14.jpg	"[\\"Azulejo\\",\\"Porcelanato\\",\\"Assentamento\\"]"	reforma alvenaria construcao acabamento banheiro cozinha azulejo porcelanato gesseiro	(19) 92167-4103	\N	São Paulo	SP	t	t	2026-03-24 01:40:31.663	2026-03-24 01:40:31.663
cmn3y6wq7001skqjytxqy0vby	CarregaFácil	Jardinagem	4	141	https://randomuser.me/api/portraits/women/15.jpg	"[\\"Grama\\",\\"Adubação\\",\\"Irrigação\\"]"	jardinagem poda paisagismo jardim grama adubacao irrigacao arvore horta organico	(11) 96800-3156	\N	Piracicaba	SP	t	t	2026-03-24 01:40:31.663	2026-03-24 01:40:31.663
cmn3y6wq7001tkqjyfuci03d4	Anderson Melo	Jardinagem	4.3	253	https://randomuser.me/api/portraits/women/16.jpg	"[\\"Grama\\",\\"Adubação\\",\\"Irrigação\\"]"	jardinagem poda paisagismo jardim grama adubacao irrigacao arvore horta organico	(19) 91017-7839	\N	São Paulo	SP	t	t	2026-03-24 01:40:31.663	2026-03-24 01:40:31.663
cmn3y6wq7001ukqjy015uey2d	Peterson Cruz	Jardinagem	4.4	208	https://randomuser.me/api/portraits/women/17.jpg	"[\\"Vasos\\",\\"Decoração\\",\\"Projeto\\"]"	jardinagem poda paisagismo jardim grama adubacao irrigacao arvore horta organico	(11) 97039-7780	\N	Campinas	SP	t	t	2026-03-24 01:40:31.664	2026-03-24 01:40:31.664
cmn3y6wq8001vkqjy1ww4o6jj	Júnior Pacheco	Jardinagem	4.9	25	https://randomuser.me/api/portraits/women/18.jpg	"[\\"Vasos\\",\\"Decoração\\",\\"Projeto\\"]"	jardinagem poda paisagismo jardim grama adubacao irrigacao arvore horta organico	(13) 95283-7954	\N	Osasco	SP	f	t	2026-03-24 01:40:31.664	2026-03-24 01:40:31.664
cmn3y6wq8001wkqjyzsk2c7o4	Sandro Nogueira	Jardinagem	5	56	https://randomuser.me/api/portraits/women/19.jpg	"[\\"Grama\\",\\"Adubação\\",\\"Irrigação\\"]"	jardinagem poda paisagismo jardim grama adubacao irrigacao arvore horta organico	(15) 92049-7917	\N	Sorocaba	SP	t	t	2026-03-24 01:40:31.665	2026-03-24 01:40:31.665
cmn3y6wq8001xkqjyx8hy6gdr	Gilson Farias	Segurança	4.7	269	https://randomuser.me/api/portraits/women/20.jpg	"[\\"Câmeras\\",\\"CFTV\\",\\"24h\\"]"	seguranca cameras alarme monitoramento cftv cerca eletrica portao residencial	(15) 98646-9913	\N	Jundiaí	SP	t	t	2026-03-24 01:40:31.665	2026-03-24 01:40:31.665
cmn3y6wq9001ykqjy0tgdgjqv	Vera Paixão	Segurança	3.8	144	https://randomuser.me/api/portraits/women/21.jpg	"[\\"Alarme\\",\\"Monitoramento\\",\\"Residencial\\"]"	seguranca cameras alarme monitoramento cftv cerca eletrica portao residencial	(11) 94295-7210	\N	Ribeirão Preto	SP	t	t	2026-03-24 01:40:31.665	2026-03-24 01:40:31.665
cmn3y6wq9001zkqjywxgepvbb	Sônia Moura	Segurança	5	182	https://randomuser.me/api/portraits/women/22.jpg	"[\\"Portão\\",\\"Cerca Elétrica\\",\\"Instalação\\"]"	seguranca cameras alarme monitoramento cftv cerca eletrica portao residencial	(11) 92318-8879	\N	Osasco	SP	t	t	2026-03-24 01:40:31.666	2026-03-24 01:40:31.666
cmn3y6wq90020kqjy66itd7zh	Cilene Barros	Climatização	4.9	59	https://randomuser.me/api/portraits/women/23.jpg	"[\\"Split\\",\\"Inverter\\",\\"Limpeza\\"]"	ar condicionado split inverter climatizacao limpeza instalacao manutencao central	(15) 95944-1468	\N	Campinas	SP	t	t	2026-03-24 01:40:31.666	2026-03-24 01:40:31.666
cmn3y6wqa0021kqjyum2zb5hx	Denise Cavalcanti	Climatização	4.4	219	https://randomuser.me/api/portraits/women/24.jpg	"[\\"Ar Condicionado\\",\\"Instalação\\",\\"Manutenção\\"]"	ar condicionado split inverter climatizacao limpeza instalacao manutencao central	(13) 93498-9294	\N	Osasco	SP	t	t	2026-03-24 01:40:31.666	2026-03-24 01:40:31.666
cmn3y6wqa0022kqjyjrt98t0s	Elaine Brito	Climatização	4.6	123	https://randomuser.me/api/portraits/women/25.jpg	"[\\"Central\\",\\"Comercial\\",\\"Certificado\\"]"	ar condicionado split inverter climatizacao limpeza instalacao manutencao central	(19) 99600-9941	\N	São Paulo	SP	t	t	2026-03-24 01:40:31.667	2026-03-24 01:40:31.667
cmn3y6wqa0023kqjybo09waxl	Eletro Norte SP	Tecnologia	4.7	123	https://randomuser.me/api/portraits/women/26.jpg	"[\\"Redes\\",\\"Wi-Fi\\",\\"Cabeamento\\"]"	tecnologia rede wifi cabeamento computador notebook formatacao servidor cftv backup	(15) 98811-3229	\N	Piracicaba	SP	t	t	2026-03-24 01:40:31.667	2026-03-24 01:40:31.667
cmn3y6wqb0024kqjy48qywahp	CanoMestre	Tecnologia	4.6	165	https://randomuser.me/api/portraits/women/27.jpg	"[\\"Computadores\\",\\"Formatação\\",\\"Suporte\\"]"	tecnologia rede wifi cabeamento computador notebook formatacao servidor cftv backup	(11) 92372-4878	\N	São Paulo	SP	f	t	2026-03-24 01:40:31.667	2026-03-24 01:40:31.667
cmn3y6wqb0025kqjy0j6t4k47	BrilhoTotal	Tecnologia	4.3	96	https://randomuser.me/api/portraits/women/28.jpg	"[\\"CFTV\\",\\"Servidor\\",\\"Backup\\"]"	tecnologia rede wifi cabeamento computador notebook formatacao servidor cftv backup	(11) 94206-4262	\N	Osasco	SP	f	t	2026-03-24 01:40:31.667	2026-03-24 01:40:31.667
cmn3y6wqc0026kqjycxpp9nt9	AlvenariaMax	Dedetização	4.4	107	https://randomuser.me/api/portraits/women/29.jpg	"[\\"Cupim\\",\\"Baratas\\",\\"Ratos\\"]"	dedetizacao cupim rato barata formiga mosquito certificado controle pragas	(11) 95399-7991	\N	Sorocaba	SP	t	t	2026-03-24 01:40:31.668	2026-03-24 01:40:31.668
cmn3y6wqc0027kqjykqf4quai	EcoJardim	Dedetização	4.6	83	https://randomuser.me/api/portraits/women/30.jpg	"[\\"Formigas\\",\\"Mosquitos\\",\\"Certificado\\"]"	dedetizacao cupim rato barata formiga mosquito certificado controle pragas	(19) 97832-4865	\N	Ribeirão Preto	SP	t	t	2026-03-24 01:40:31.669	2026-03-24 01:40:31.669
cmn3y6wqd0028kqjyc2z4sbv1	VisionSeg	Mudança	4.5	105	https://randomuser.me/api/portraits/women/31.jpg	"[\\"Comercial\\",\\"Piano\\",\\"Desmontagem\\"]"	mudanca transporte caminhao embalar desmontar guarda moveis comercial residencial	(11) 91232-4722	\N	Osasco	SP	t	t	2026-03-24 01:40:31.669	2026-03-24 01:40:31.669
cmn3y6wqd0029kqjy21zi18qz	ClimateMax	Mudança	4.8	124	https://randomuser.me/api/portraits/women/32.jpg	"[\\"Guarda Móveis\\",\\"Seguro\\",\\"Rápido\\"]"	mudanca transporte caminhao embalar desmontar guarda moveis comercial residencial	(11) 93002-3993	\N	Sorocaba	SP	t	t	2026-03-24 01:40:31.67	2026-03-24 01:40:31.67
cmn3y6wqe002akqjypbtsdpi8	DataFix	Mudança	4	100	https://randomuser.me/api/portraits/women/33.jpg	"[\\"Guarda Móveis\\",\\"Seguro\\",\\"Rápido\\"]"	mudanca transporte caminhao embalar desmontar guarda moveis comercial residencial	(15) 93738-1563	\N	São Bernardo do Campo	SP	t	t	2026-03-24 01:40:31.67	2026-03-24 01:40:31.67
cmn3y6wqe002bkqjyuqcvbsis	BioControl	Gás	4.1	161	https://randomuser.me/api/portraits/women/34.jpg	"[\\"Instalação\\",\\"Vazamento\\",\\"Regulagem\\"]"	gas gasoducto instalacao vazamento botijao encanamento regulagem urgencia	(11) 98526-2289	\N	São Bernardo do Campo	SP	t	t	2026-03-24 01:40:31.67	2026-03-24 01:40:31.67
cmn3y6wqe002ckqjyvp5w3dd0	MudaFácil	Gás	4.3	21	https://randomuser.me/api/portraits/women/35.jpg	"[\\"Botijão\\",\\"Encanamento\\",\\"Urgência\\"]"	gas gasoducto instalacao vazamento botijao encanamento regulagem urgencia	(13) 98251-8433	\N	Santo André	SP	t	t	2026-03-24 01:40:31.671	2026-03-24 01:40:31.671
cmn3y6wqf002dkqjylsqkaeh2	GasSeguro	Pintura	5	53	https://randomuser.me/api/portraits/women/36.jpg	"[\\"Fachada\\",\\"Predial\\",\\"CertificadoMaestria\\"]"	pintura tinta parede textura interna externa fachada predial epóxi piso	(11) 99949-6389	\N	Guarulhos	SP	f	t	2026-03-24 01:40:31.671	2026-03-24 01:40:31.671
cmn3y6wqf002ekqjyz2eh4732	ColorMax Pinturas	Pintura	4.1	256	https://randomuser.me/api/portraits/women/37.jpg	"[\\"Interna\\",\\"Externa\\",\\"Textura\\"]"	pintura tinta parede textura interna externa fachada predial epóxi piso	(13) 91972-9763	\N	Mogi das Cruzes	SP	t	t	2026-03-24 01:40:31.672	2026-03-24 01:40:31.672
cmn3y6wqg002fkqjyy33tg6bj	Amper Elétrica	Pintura	4.4	68	https://randomuser.me/api/portraits/women/38.jpg	"[\\"Epóxi\\",\\"Piso\\",\\"Especializado\\"]"	pintura tinta parede textura interna externa fachada predial epóxi piso	(11) 95315-9468	\N	São Paulo	SP	t	t	2026-03-24 01:40:31.672	2026-03-24 01:40:31.672
cmn3y6wqg002gkqjyridhkfg3	FluxoHidro	Elétrica	4.1	22	https://randomuser.me/api/portraits/women/39.jpg	"[\\"Industrial\\",\\"Residencial\\",\\"Urgência\\"]"	eletrica instalacao quadro tomada luz iluminacao spda gerador urgencia emergencia	(13) 92862-4328	\N	Santo André	SP	t	t	2026-03-24 01:40:31.672	2026-03-24 01:40:31.672
cmn3y6wqg002hkqjy27hquf8h	WhiteClean	Elétrica	3.8	23	https://randomuser.me/api/portraits/women/40.jpg	"[\\"Gerador\\",\\"Painel\\",\\"Certificado\\"]"	eletrica instalacao quadro tomada luz iluminacao spda gerador urgencia emergencia	(19) 93615-7433	\N	São Paulo	SP	t	t	2026-03-24 01:40:31.673	2026-03-24 01:40:31.673
cmn3y6wqh002ikqjyiksf4csg	StructMax Reformas	Elétrica	4.8	41	https://randomuser.me/api/portraits/women/41.jpg	"[\\"24h\\",\\"Emergência\\",\\"Confiável\\"]"	eletrica instalacao quadro tomada luz iluminacao spda gerador urgencia emergencia	(15) 98223-5269	\N	Santos	SP	t	t	2026-03-24 01:40:31.673	2026-03-24 01:40:31.673
cmn3y6wqh002jkqjygyv5hdte	GreenLand Jardins	Elétrica	4.6	187	https://randomuser.me/api/portraits/women/42.jpg	"[\\"24h\\",\\"Emergência\\",\\"Confiável\\"]"	eletrica instalacao quadro tomada luz iluminacao spda gerador urgencia emergencia	(13) 99690-6191	\N	São Paulo	SP	f	t	2026-03-24 01:40:31.674	2026-03-24 01:40:31.674
cmn3y6wqi002kkqjylw3ceoxk	SafeGroup	Elétrica	4.9	283	https://randomuser.me/api/portraits/women/43.jpg	"[\\"24h\\",\\"Emergência\\",\\"Confiável\\"]"	eletrica instalacao quadro tomada luz iluminacao spda gerador urgencia emergencia	(19) 93641-3327	\N	Santo André	SP	t	t	2026-03-24 01:40:31.674	2026-03-24 01:40:31.674
cmn3y6wqi002lkqjym8863b2d	ArcticAir	Hidráulica	4.4	124	https://randomuser.me/api/portraits/women/44.jpg	"[\\"Caixa d'Água\\",\\"Encanamento\\",\\"Rápido\\"]"	hidraulica encanamento cano vazamento desentupimento fossa bomba agua aquecedor	(15) 99507-7103	\N	São Paulo	SP	t	t	2026-03-24 01:40:31.675	2026-03-24 01:40:31.675
cmn3y6wqj002mkqjydswjdd9v	SpeedTech	Hidráulica	4	148	https://randomuser.me/api/portraits/women/45.jpg	"[\\"Aquecimento\\",\\"Chuveiro\\",\\"Infiltração\\"]"	hidraulica encanamento cano vazamento desentupimento fossa bomba agua aquecedor	(11) 96269-3590	\N	Osasco	SP	t	t	2026-03-24 01:40:31.675	2026-03-24 01:40:31.675
cmn3y6wqj002nkqjy002c74ug	NoPragas	Hidráulica	5	284	https://randomuser.me/api/portraits/women/46.jpg	"[\\"Vazamento\\",\\"Registro\\",\\"Urgência\\"]"	hidraulica encanamento cano vazamento desentupimento fossa bomba agua aquecedor	(13) 99221-3300	\N	Bauru	SP	t	t	2026-03-24 01:40:31.676	2026-03-24 01:40:31.676
cmn3y6wqj002okqjy2wx2ux40	TransporteMax	Hidráulica	4.3	187	https://randomuser.me/api/portraits/women/47.jpg	"[\\"Caixa d'Água\\",\\"Encanamento\\",\\"Rápido\\"]"	hidraulica encanamento cano vazamento desentupimento fossa bomba agua aquecedor	(15) 98564-4094	\N	Santos	SP	t	t	2026-03-24 01:40:31.676	2026-03-24 01:40:31.676
cmn3y6wqk002pkqjyizk074x2	GásMais	Hidráulica	4	289	https://randomuser.me/api/portraits/women/48.jpg	"[\\"Esgoto\\",\\"Residencial\\",\\"Vistoria\\"]"	hidraulica encanamento cano vazamento desentupimento fossa bomba agua aquecedor	(15) 93713-8183	\N	Santo André	SP	t	t	2026-03-24 01:40:31.676	2026-03-24 01:40:31.676
cmn3y6wqk002qkqjyptp3i08t	PincelMestre	Limpeza	4.4	158	https://randomuser.me/api/portraits/women/49.jpg	"[\\"Condomínio\\",\\"Predial\\",\\"Empresa\\"]"	limpeza faxina residencial comercial predial condominio pos obra vidros fachada	(11) 92725-7808	\N	São Paulo	SP	t	t	2026-03-24 01:40:31.677	2026-03-24 01:40:31.677
cmn3y6wqk002rkqjy8mxij6wb	ElétricaVIP	Limpeza	5	102	https://randomuser.me/api/portraits/women/50.jpg	"[\\"Residencial\\",\\"Periódica\\",\\"Confiável\\"]"	limpeza faxina residencial comercial predial condominio pos obra vidros fachada	(11) 99909-3890	\N	Piracicaba	SP	t	t	2026-03-24 01:40:31.677	2026-03-24 01:40:31.677
\.


--
-- Data for Name: StockItem; Type: TABLE DATA; Schema: public; Owner: alex
--

COPY public."StockItem" (id, "assetId", name, sku, "currentStock", "minStock", unit, "subLocation", "unitPrice", "createdAt", "updatedAt") FROM stdin;
cmn3xwgtm00098gtlegbjwzp0	cmn3xwgtj00078gtly9ejtlxj	Item A	SKU-brspark-br-cmn3xwgtj00078gtly9ejtlxj-A	10	5	un	\N	\N	2026-03-24 01:32:24.49	2026-03-24 01:32:24.49
cmn3xwgtt000b8gtld22q0udc	cmn3xwgtj00078gtly9ejtlxj	Item Crítico	SKU-brspark-br-cmn3xwgtj00078gtly9ejtlxj-B	2	5	un	\N	\N	2026-03-24 01:32:24.498	2026-03-24 01:32:24.498
cmn3xwgtw000f8gtlfb5981rd	cmn3xwgtv000d8gtlsiwqien4	Item A	SKU-brspark-br-cmn3xwgtv000d8gtlsiwqien4-A	10	5	un	\N	\N	2026-03-24 01:32:24.5	2026-03-24 01:32:24.5
cmn3xwgtx000h8gtlv8z824rc	cmn3xwgtv000d8gtlsiwqien4	Item Crítico	SKU-brspark-br-cmn3xwgtv000d8gtlsiwqien4-B	2	5	un	\N	\N	2026-03-24 01:32:24.501	2026-03-24 01:32:24.501
cmn3xwgty000l8gtl416plf7z	cmn3xwgtx000j8gtlf0vw1qok	Item A	SKU-brspark-br-cmn3xwgtx000j8gtlf0vw1qok-A	10	5	un	\N	\N	2026-03-24 01:32:24.502	2026-03-24 01:32:24.502
cmn3xwgtz000n8gtlowqnxx3x	cmn3xwgtx000j8gtlf0vw1qok	Item Crítico	SKU-brspark-br-cmn3xwgtx000j8gtlf0vw1qok-B	2	5	un	\N	\N	2026-03-24 01:32:24.503	2026-03-24 01:32:24.503
cmn3xwgu9000z8gtlz7oshky7	cmn3xwgu8000x8gtlixouh8pm	Item A	SKU-solaris-us-cmn3xwgu8000x8gtlixouh8pm-A	10	5	un	\N	\N	2026-03-24 01:32:24.513	2026-03-24 01:32:24.513
cmn3xwgu900118gtl49y9gjj3	cmn3xwgu8000x8gtlixouh8pm	Item Crítico	SKU-solaris-us-cmn3xwgu8000x8gtlixouh8pm-B	2	5	un	\N	\N	2026-03-24 01:32:24.514	2026-03-24 01:32:24.514
cmn3xwgua00158gtl1a8hwys9	cmn3xwgua00138gtlgxlzuqfm	Item A	SKU-solaris-us-cmn3xwgua00138gtlgxlzuqfm-A	10	5	un	\N	\N	2026-03-24 01:32:24.515	2026-03-24 01:32:24.515
cmn3xwgub00178gtlgvn5zymz	cmn3xwgua00138gtlgxlzuqfm	Item Crítico	SKU-solaris-us-cmn3xwgua00138gtlgxlzuqfm-B	2	5	un	\N	\N	2026-03-24 01:32:24.515	2026-03-24 01:32:24.515
cmn3xwguc001b8gtld8rr55bp	cmn3xwgub00198gtlm6juwtim	Item A	SKU-solaris-us-cmn3xwgub00198gtlm6juwtim-A	10	5	un	\N	\N	2026-03-24 01:32:24.516	2026-03-24 01:32:24.516
cmn3xwguc001d8gtlcdrziopy	cmn3xwgub00198gtlm6juwtim	Item Crítico	SKU-solaris-us-cmn3xwgub00198gtlm6juwtim-B	2	5	un	\N	\N	2026-03-24 01:32:24.517	2026-03-24 01:32:24.517
cmn3xwguk001p8gtlh57eem05	cmn3xwguj001n8gtlutpesgpc	Item A	SKU-iberia-es-cmn3xwguj001n8gtlutpesgpc-A	10	5	un	\N	\N	2026-03-24 01:32:24.524	2026-03-24 01:32:24.524
cmn3xwguk001r8gtln60aal8g	cmn3xwguj001n8gtlutpesgpc	Item Crítico	SKU-iberia-es-cmn3xwguj001n8gtlutpesgpc-B	2	5	un	\N	\N	2026-03-24 01:32:24.524	2026-03-24 01:32:24.524
cmn3xwgul001v8gtlhwja740x	cmn3xwguk001t8gtluwfugchd	Item A	SKU-iberia-es-cmn3xwguk001t8gtluwfugchd-A	10	5	un	\N	\N	2026-03-24 01:32:24.525	2026-03-24 01:32:24.525
cmn3xwgum001x8gtl5j4xqj05	cmn3xwguk001t8gtluwfugchd	Item Crítico	SKU-iberia-es-cmn3xwguk001t8gtluwfugchd-B	2	5	un	\N	\N	2026-03-24 01:32:24.527	2026-03-24 01:32:24.527
cmn3xwguo00218gtlo05vs3rc	cmn3xwgun001z8gtlncywzd8z	Item A	SKU-iberia-es-cmn3xwgun001z8gtlncywzd8z-A	10	5	un	\N	\N	2026-03-24 01:32:24.528	2026-03-24 01:32:24.528
cmn3xwgup00238gtlma4f4l45	cmn3xwgun001z8gtlncywzd8z	Item Crítico	SKU-iberia-es-cmn3xwgun001z8gtlncywzd8z-B	2	5	un	\N	\N	2026-03-24 01:32:24.529	2026-03-24 01:32:24.529
\.


--
-- Data for Name: StockMovement; Type: TABLE DATA; Schema: public; Owner: alex
--

COPY public."StockMovement" (id, "itemId", type, quantity, reason, "fromAssetId", "toAssetId", "createdAt") FROM stdin;
\.


--
-- Data for Name: Subscription; Type: TABLE DATA; Schema: public; Owner: alex
--

COPY public."Subscription" (id, "tenantId", "planId", "billingCycle", status, "currentStart", "currentEnd", "cancelledAt", "trialEndsAt", "externalId", "createdAt", "updatedAt") FROM stdin;
cmn3xv66a0005a0ses6mrkhfp	cmn3xud9y0001kldgdiksukq5	cmn3xhvm00001dajksgpasg5e	MONTHLY	ACTIVE	2026-03-24 01:31:24.034	2026-04-23 01:31:24.034	\N	\N	\N	2026-03-24 01:31:24.035	2026-03-24 01:31:24.035
cmn3xwgu6000v8gtlzcupv5nf	cmn3xwgu1000r8gtl768s8zcj	cmn3xhvmb0003dajk7rnd1j9t	MONTHLY	ACTIVE	2026-03-24 01:32:24.51	2026-04-23 01:32:24.51	\N	\N	\N	2026-03-24 01:32:24.51	2026-03-24 01:32:24.51
cmn3xwgug001l8gtly6fzxjix	cmn3xwgue001h8gtlfcskpc0d	cmn3xhvma0002dajkn01kcgec	MONTHLY	ACTIVE	2026-03-24 01:32:24.52	2026-04-23 01:32:24.52	\N	\N	\N	2026-03-24 01:32:24.52	2026-03-24 01:32:24.52
cmn3y22oa0004ez5ccxkx7bnj	cmn3y22nk0000ez5ct3cd9uja	cmn3xhvm00001dajksgpasg5e	MONTHLY	ACTIVE	2026-03-24 01:36:46.086	2027-03-24 01:36:46.086	\N	\N	\N	2026-03-24 01:36:46.091	2026-03-24 01:36:46.091
\.


--
-- Data for Name: Tenant; Type: TABLE DATA; Schema: public; Owner: alex
--

COPY public."Tenant" (id, name, slug, email, phone, "taxId", "defaultLang", status, "createdAt", "updatedAt", "avatarUrl", "localeId", "ownerName") FROM stdin;
cmn3xud9y0001kldgdiksukq5	Brspark Global Brazil	brspark-br	contato@brspark.br	\N	\N	pt-BR	ACTIVE	2026-03-24 01:30:46.582	2026-03-24 01:30:46.582	\N	cmn3vyg7a0000124fc64ebh01	Brspark
cmn3xwgu1000r8gtl768s8zcj	Solaris Energy US	solaris-us	operations@solaris.us	\N	\N	pt-BR	ACTIVE	2026-03-24 01:32:24.506	2026-03-24 01:32:24.506	\N	cmn3vyg8e0001124fmm7itdof	Solaris
cmn3xwgue001h8gtlfcskpc0d	Iberia Logistics	iberia-es	info@iberia.es	\N	\N	pt-BR	ACTIVE	2026-03-24 01:32:24.518	2026-03-24 01:32:24.518	\N	cmn3vyg8g0002124f5eqzqfhe	Iberia
cmn3y22nk0000ez5ct3cd9uja	João Silva	joao-silva	joao.silva@brspark.com	(11) 99999-1234	\N	pt-BR	ACTIVE	2026-03-24 01:36:46.065	2026-03-24 01:36:46.065	\N	\N	João
cmn3y2uck0000sfjubh0n7z5o	João Teste	joao-teste	joao@teste.com	\N	\N	pt-BR	ACTIVE	2026-03-24 01:37:21.957	2026-03-24 01:38:37.735	\N	\N	João
cmn6hij2x0001j5dqofhbi9sd	Alex	alex	alex@brspark.com	\N	\N	pt-BR	TRIAL	2026-03-25 20:16:58.905	2026-03-25 20:16:58.905	\N	\N	Alex
cmn6sf2we004g5epyw7uxjo73	Luigi Marchetti	luigi	luigi@lansolver.com	\N	\N	pt-BR	TRIAL	2026-03-26 01:22:13.741	2026-03-26 01:22:13.741	\N	\N	Luigi Marchetti
\.


--
-- Data for Name: TranslationOverride; Type: TABLE DATA; Schema: public; Owner: alex
--

COPY public."TranslationOverride" (id, "tenantId", key, language, value, "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: User; Type: TABLE DATA; Schema: public; Owner: alex
--

COPY public."User" (id, "tenantId", email, name, password, role, "isActive", "lastLogin", "createdAt", "updatedAt", "avatarUrl") FROM stdin;
cmn6hij3j0003j5dqqixl4ge1	cmn6hij2x0001j5dqofhbi9sd	alex@brspark.com	Alex	$2a$10$LYCgB7c2fXOd22UjngG/ZO4yhfDVGSLbYBYSOYPkkzYxo6oFclgVO	ADMIN	t	2026-04-01 21:34:51.585	2026-03-25 20:16:58.927	2026-04-01 21:34:51.588	http://192.168.15.73:3001/uploads/storage/avatars/cmn6hij3j0003j5dqqixl4ge1_1774563015508.jpg
cmn6sf2wq004i5epyd58t8qn2	cmn6sf2we004g5epyw7uxjo73	luigi@lansolver.com	Luigi Marchetti	$2a$10$0oLzyiB0Z74/AxFJ7Lxny.p6fgG3kXUbjTHU7qVo5CpdP/9yLovf6	ADMIN	t	2026-03-28 16:56:36.81	2026-03-26 01:22:13.753	2026-03-28 16:56:36.81	http://192.168.15.73:3001/uploads/storage/avatars/cmn6sf2wq004i5epyd58t8qn2_1774563105054.jpeg
cmn3xwgu3000t8gtlvhuyyizu	cmn3xwgu1000r8gtl768s8zcj	operations@solaris.us	Solaris Energy US Admin	$2a$10$MY.3mTkx6.rc9xTDwrJ90OygdfQ5FUF8UTPIgP1TjhAQjFyVVyxwO	ADMIN	t	\N	2026-03-24 01:32:24.507	2026-03-26 21:51:12.903	https://randomuser.me/api/portraits/men/4.jpg
cmn3xwguf001j8gtlbxs9yzx9	cmn3xwgue001h8gtlfcskpc0d	info@iberia.es	Iberia Logistics Admin	$2a$10$MY.3mTkx6.rc9xTDwrJ90OygdfQ5FUF8UTPIgP1TjhAQjFyVVyxwO	ADMIN	t	\N	2026-03-24 01:32:24.519	2026-03-26 21:51:12.903	https://randomuser.me/api/portraits/men/4.jpg
cmn3y22nz0002ez5c1hzi6chf	cmn3y22nk0000ez5ct3cd9uja	joao.silva@brspark.com	João Silva	$2a$10$iNyp0KtfS4tN5C6ShHb2W.XTfTngHsrIoSgwoUadURrUmmUQ2b9j2	ADMIN	t	\N	2026-03-24 01:36:46.08	2026-03-26 21:51:12.903	https://randomuser.me/api/portraits/men/4.jpg
cmn3y2ucr0002sfju83h732a4	cmn3y2uck0000sfjubh0n7z5o	joao@teste.com	João Teste	$2a$10$4nhrqJ2uw8qX3Sf1OFl9M.GgSIFTFkU3PLEtkG8npP7CQuIssF3fO	ADMIN	t	2026-03-25 19:43:56.542	2026-03-24 01:37:21.963	2026-03-26 21:51:12.903	https://randomuser.me/api/portraits/men/4.jpg
cmn3xuq0c0003aufuay5elb67	cmn3xud9y0001kldgdiksukq5	contato@brspark.br	Brspark Global Brazil Admin	$2a$10$MDkv.akxEovWisetwTn1ie.RcE/YLAUdb0FEH5vgfcUj1nhwvKczC	ADMIN	t	\N	2026-03-24 01:31:03.085	2026-03-26 21:52:09.712	SUCCESS
\.


--
-- Data for Name: UserModuleData; Type: TABLE DATA; Schema: public; Owner: alex
--

COPY public."UserModuleData" (id, "ownerEmail", module, data, "updatedAt", "createdAt") FROM stdin;
cmn6numgk000bsn7dio7u4kgb	alex@brspark.com	costs_expenses	[{"id": "exp-mn67vmfh-dy607", "date": "2026-03-25", "type": "EXPENSE", "amount": 532, "status": "PENDING", "assetId": "brsp-215880", "category": "OUTROS", "ownerEmail": "alex@brspark.com", "description": "Pneu"}, {"id": "exp-mn67xbkl-2bu76", "date": "2026-03-25", "type": "EXPENSE", "amount": 523.87, "status": "PENDING", "assetId": "brsp-585500", "category": "OUTROS", "ownerEmail": "alex@brspark.com", "description": "Pneu"}, {"id": "exp-mn684uwl-189lr", "date": "2026-03-25", "type": "EXPENSE", "amount": 582, "status": "PENDING", "assetId": "brsp-585500", "category": "OUTROS", "ownerEmail": "alex@brspark.com", "description": "Pmeu"}, {"id": "exp-mn68cwe3-e1zb0", "date": "2026-03-25", "type": "EXPENSE", "amount": 235, "status": "PENDING", "assetId": "brsp-215880", "category": "OUTROS", "ownerEmail": "alex@brspark.com", "description": "Pneu"}, {"id": "exp-mn6hn1bs-ka6kt", "date": "2026-03-25", "type": "EXPENSE", "amount": 152, "status": "PENDING", "assetId": "brsp-190135", "category": "OUTROS", "ownerEmail": "alex@brspark.com", "description": "Luz"}, {"id": "exp-mn6hp6c6-u9q2w", "date": "2026-03-25", "type": "EXPENSE", "amount": 500, "status": "PENDING", "assetId": "brsp-628386", "category": "OUTROS", "ownerEmail": "alex@brspark.com", "description": "Pmeu"}, {"id": "exp-mn7gcdd2-74nic", "date": "2026-03-26", "type": "REVENUE", "amount": 100, "status": "PENDING", "assetId": "brsp-756993", "category": "OUTROS", "ownerEmail": "alex@brspark.com", "description": "Testw"}, {"id": "exp-mn8wkyku-t309v", "date": "2026-03-27", "type": "REVENUE", "amount": 100, "status": "PENDING", "assetId": "brsp-134786", "category": "OUTROS", "ownerEmail": "alex@brspark.com", "description": "Teste"}, {"id": "exp-mn8wuoci-3bvk6", "date": "2026-03-27", "type": "EXPENSE", "amount": 25, "status": "PENDING", "assetId": "brsp-134786", "category": "OUTROS", "ownerEmail": "alex@brspark.com", "description": "Teste22"}]	2026-04-02 03:44:33.428	2026-03-25 23:14:20.765
cmn6numhy000dsn7dd1oeoyke	alex@brspark.com	asset_docs	[{"id": "qdce4o", "uri": "https://pub-5fc6db4a467f3070a46bf138e5b79edb.r2.dev/docs/alex_brspark_com/qdce4o.pdf", "type": "pdf", "title": "NF-e - Nota Fiscal Eletrônica de Serviços - São Paulo.pdf", "assetId": "brsp-190135", "version": 1, "category": "general", "createdAt": "2026-03-25T23:39:27.408Z", "description": ""}, {"id": "5b8tw4", "uri": "https://pub-5fc6db4a467f3070a46bf138e5b79edb.r2.dev/docs/alex_brspark_com/5b8tw4.pdf", "type": "pdf", "title": "Currículo Thais 2025.pdf", "assetId": "brsp-190135", "version": 1, "category": "general", "createdAt": "2026-03-25T23:39:33.198Z", "description": ""}, {"id": "nmft9b", "uri": "", "type": "folder", "title": "Teste", "assetId": "brsp-756993", "version": 1, "category": "general", "createdAt": "2026-03-26T18:13:09.048Z"}, {"id": "4oc4kl", "uri": "/BrSpark/docs/alex_brspark_com/4oc4kl.pdf", "type": "pdf", "title": "NF-e - Nota Fiscal Eletrônica de Serviços - São Paulo.pdf", "assetId": "brsp-756993", "version": 1, "category": "general", "parentId": "nmft9b", "createdAt": "2026-03-26T18:13:15.140Z", "description": ""}, {"id": "wf9ejb", "uri": "", "type": "folder", "title": "123", "assetId": "brsp-756993", "version": 1, "category": "general", "createdAt": "2026-03-26T18:16:09.617Z"}, {"id": "krsucl", "uri": "", "type": "folder", "title": "1", "assetId": "brsp-756993", "version": 1, "category": "general", "parentId": "nmft9b", "createdAt": "2026-03-26T18:20:06.259Z"}]	2026-04-02 03:44:33.435	2026-03-25 23:14:20.902
cmn6u4n3i0005e0hkjsplnzl4	luigi@lansolver.com	costs_expenses	[]	2026-03-28 23:54:13.48	2026-03-26 02:10:05.935
cmn6u4n3x0007e0hknad8z47c	luigi@lansolver.com	insurance_policies	[]	2026-03-28 23:54:13.486	2026-03-26 02:10:05.949
cmn6u4n3z0009e0hkhxc1lj0k	luigi@lansolver.com	asset_docs	[{"id": "jrsu5w", "uri": "file:///var/mobile/Containers/Data/Application/B49F90C2-F617-4081-910B-D71CE9F435F3/Library/Caches/ExponentExperienceData/@anonymous/BrsparkMobile-be63636c-8058-4d28-bef6-7ebf19f8191b/DocumentPicker/5F6E3240-CAC6-4BC7-9A6C-16396ABD4B28.pdf", "type": "pdf", "title": "NF-e - Nota Fiscal Eletrônica de Serviços - São Paulo.pdf", "assetId": "brsp-314572", "version": 1, "category": "general", "createdAt": "2026-03-26T13:28:02.961Z", "description": ""}]	2026-03-28 23:54:13.511	2026-03-26 02:10:05.952
cmn6u4n3x0008e0hkq2f8eeac	luigi@lansolver.com	costs_recurring	[]	2026-03-28 23:54:13.482	2026-03-26 02:10:05.95
cmn6numgb000asn7d7mmll21z	alex@brspark.com	costs_recurring	[{"id": "rec-mn69xf9l-h54zj", "type": "REVENUE", "amount": 2500, "status": "ACTIVE", "assetId": "brsp-215880", "frequency": "MONTHLY", "ownerEmail": "alex@brspark.com", "description": "Tedte", "nextDueDate": "2026-03-25", "alertDaysBefore": 1, "totalInstallments": 2, "remainingInstallments": 2}, {"id": "ins_cost_ins_1774477825766_cwk5h", "type": "EXPENSE", "amount": 0, "status": "ACTIVE", "assetId": "brsp-190135", "category": "SEGURO", "frequency": "YEARLY", "ownerEmail": "alex@brspark.com", "description": "Seguro Residencial — Teste", "nextDueDate": "209383", "alertDaysBefore": 10}, {"id": "ins_cost_ins_1774477826163_pyzx0", "type": "EXPENSE", "amount": 0, "status": "ACTIVE", "assetId": "brsp-190135", "category": "SEGURO", "frequency": "YEARLY", "ownerEmail": "alex@brspark.com", "description": "Seguro Residencial — Teste", "nextDueDate": "209383", "alertDaysBefore": 10}, {"id": "rec-mn8wim0o-uh9wo", "type": "REVENUE", "amount": 1000, "status": "ACTIVE", "assetId": "brsp-756993", "frequency": "MONTHLY", "ownerEmail": "alex@brspark.com", "description": "Aluguel", "nextDueDate": "2026-03-28", "alertDaysBefore": 1, "totalInstallments": 12, "remainingInstallments": 12}, {"id": "rec-mn8wlgmp-owx71", "type": "REVENUE", "amount": 300, "status": "ACTIVE", "assetId": "brsp-134786", "frequency": "MONTHLY", "ownerEmail": "alex@brspark.com", "description": "Aluguel", "nextDueDate": "2026-03-27", "alertDaysBefore": 1, "totalInstallments": 12, "remainingInstallments": 12}, {"id": "rec-mn8wma7d-j64lj", "type": "REVENUE", "amount": 50, "status": "ACTIVE", "assetId": "brsp-756993", "frequency": "MONTHLY", "ownerEmail": "alex@brspark.com", "description": "Teste", "nextDueDate": "2026-03-27", "alertDaysBefore": 1, "totalInstallments": 12, "remainingInstallments": 12}, {"id": "rec-mn8wmvf1-vx666", "type": "EXPENSE", "amount": 300, "status": "ACTIVE", "assetId": "brsp-756993", "frequency": "MONTHLY", "ownerEmail": "alex@brspark.com", "description": "Teste rec", "nextDueDate": "2026-03-27", "alertDaysBefore": 1, "totalInstallments": 12, "remainingInstallments": 12}, {"id": "rec-mn8wn9yc-roy0r", "type": "EXPENSE", "amount": 50, "status": "ACTIVE", "assetId": "brsp-756993", "frequency": "MONTHLY", "ownerEmail": "alex@brspark.com", "description": "2", "nextDueDate": "2026-03-27", "alertDaysBefore": 1, "totalInstallments": 12, "remainingInstallments": 12}, {"id": "rec-mn8wnmsw-3nbph", "type": "REVENUE", "amount": 100, "status": "ACTIVE", "assetId": "brsp-756993", "frequency": "MONTHLY", "ownerEmail": "alex@brspark.com", "description": "3", "nextDueDate": "2026-03-27", "alertDaysBefore": 1, "totalInstallments": 12, "remainingInstallments": 12}, {"id": "rec-mn8wo9xg-olj46", "type": "REVENUE", "amount": 100, "status": "ACTIVE", "assetId": "brsp-134786", "frequency": "MONTHLY", "ownerEmail": "alex@brspark.com", "description": "1", "nextDueDate": "2026-03-27", "alertDaysBefore": 1, "totalInstallments": 12, "remainingInstallments": 12}, {"id": "rec-mn8wolzq-k0t6i", "type": "EXPENSE", "amount": 200, "status": "ACTIVE", "assetId": "brsp-134786", "frequency": "MONTHLY", "ownerEmail": "alex@brspark.com", "description": "2", "nextDueDate": "2026-03-27", "alertDaysBefore": 1, "totalInstallments": 12, "remainingInstallments": 12}, {"id": "rec-mn8wwasg-y98d3", "type": "EXPENSE", "amount": 50, "status": "ACTIVE", "assetId": "brsp-134786", "frequency": "MONTHLY", "ownerEmail": "alex@brspark.com", "description": "Netflix", "nextDueDate": "2026-03-27", "alertDaysBefore": 1}, {"id": "ins_cost_ins_1774648334205_drxzi", "type": "EXPENSE", "amount": 0, "status": "ACTIVE", "assetId": "brsp-134786", "category": "SEGURO", "frequency": "YEARLY", "ownerEmail": "alex@brspark.com", "description": "Seguro Residencial — Teste", "nextDueDate": "2026-04-27", "alertDaysBefore": 1}, {"id": "ins_cost_ins_1774648335970_y32ey", "type": "EXPENSE", "amount": 0, "status": "ACTIVE", "assetId": "brsp-134786", "category": "SEGURO", "frequency": "YEARLY", "ownerEmail": "alex@brspark.com", "description": "Seguro Residencial — Teste", "nextDueDate": "2026-04-27", "alertDaysBefore": 1}, {"id": "ins_cost_ins_1774648337353_bjq8z", "type": "EXPENSE", "amount": 0, "status": "ACTIVE", "assetId": "brsp-134786", "category": "SEGURO", "frequency": "YEARLY", "ownerEmail": "alex@brspark.com", "description": "Seguro Residencial — Teste", "nextDueDate": "2026-04-27", "alertDaysBefore": 1}, {"id": "ins_cost_ins_1774648337620_kuvjy", "type": "EXPENSE", "amount": 0, "status": "ACTIVE", "assetId": "brsp-134786", "category": "SEGURO", "frequency": "YEARLY", "ownerEmail": "alex@brspark.com", "description": "Seguro Residencial — Teste", "nextDueDate": "2026-04-27", "alertDaysBefore": 1}, {"id": "ins_cost_ins_1774648337870_l14de", "type": "EXPENSE", "amount": 0, "status": "ACTIVE", "assetId": "brsp-134786", "category": "SEGURO", "frequency": "YEARLY", "ownerEmail": "alex@brspark.com", "description": "Seguro Residencial — Teste", "nextDueDate": "2026-04-27", "alertDaysBefore": 1}, {"id": "ins_cost_ins_1774648441070_05axk", "type": "EXPENSE", "amount": 0, "status": "ACTIVE", "assetId": "brsp-134786", "category": "SEGURO", "frequency": "YEARLY", "ownerEmail": "alex@brspark.com", "description": "Seguro Residencial — Teste", "nextDueDate": "2026-04-27", "alertDaysBefore": 1}]	2026-04-02 03:44:33.434	2026-03-25 23:14:20.765
cmnau4wdt00hqcjid7kadjbqy	alex@brspark.com	stock_items	[{"id": "local_stock_1774732811358", "sku": "Qwewqe", "name": "Wqewq", "unit": "un", "category": "Suprimentos", "minStock": 2, "costPrice": 0, "locationId": null, "owner_email": "alex@brspark.com", "subLocation": null, "currentStock": 1, "asset_location_id": null}]	2026-04-02 03:44:33.413	2026-03-28 21:21:22.672
cmn6numhk000csn7daaw45e16	alex@brspark.com	insurance_policies	[{"id": "ins_1774477825766_cwk5h", "type": "RESIDENTIAL", "status": "ACTIVE", "assetId": "brsp-190135", "endDate": "209383", "insurer": "Teste", "createdAt": "2026-03-25T22:30:25.766Z", "startDate": "2026-03-25", "brokerName": "", "deductible": 0, "ownerEmail": "alex@brspark.com", "brokerPhone": "", "documentUri": "file:///var/mobile/Containers/Data/Application/B49F90C2-F617-4081-910B-D71CE9F435F3/Library/Caches/ExponentExperienceData/@anonymous/BrsparkMobile-be63636c-8058-4d28-bef6-7ebf19f8191b/DocumentPicker/F0257E79-A544-48D8-AEC0-14D3CE2AB092.pages", "policyNumber": "123", "premiumValue": 0, "coverageAmount": 0, "alertDaysBefore": 10, "coverageDetails": ""}, {"id": "ins_1774477826163_pyzx0", "type": "RESIDENTIAL", "status": "ACTIVE", "assetId": "brsp-190135", "endDate": "209383", "insurer": "Teste", "createdAt": "2026-03-25T22:30:26.163Z", "startDate": "2026-03-25", "brokerName": "", "deductible": 0, "ownerEmail": "alex@brspark.com", "brokerPhone": "", "documentUri": "file:///var/mobile/Containers/Data/Application/B49F90C2-F617-4081-910B-D71CE9F435F3/Library/Caches/ExponentExperienceData/@anonymous/BrsparkMobile-be63636c-8058-4d28-bef6-7ebf19f8191b/DocumentPicker/F0257E79-A544-48D8-AEC0-14D3CE2AB092.pages", "policyNumber": "123", "premiumValue": 0, "coverageAmount": 0, "alertDaysBefore": 10, "coverageDetails": ""}, {"id": "ins_1774648334205_drxzi", "type": "RESIDENTIAL", "status": "ACTIVE", "assetId": "brsp-134786", "endDate": "2026-04-27", "insurer": "Teste", "createdAt": "2026-03-27T21:52:14.205Z", "startDate": "2026-03-27", "brokerName": "", "deductible": 0, "ownerEmail": "alex@brspark.com", "brokerPhone": "", "documentUri": "http://192.168.15.73:3001/uploads/storage/docs/alex_brspark_com/ins_1774648334205_drxzi.insurance_355", "policyNumber": "355", "premiumValue": 0, "coverageAmount": 0, "alertDaysBefore": 1, "coverageDetails": ""}, {"id": "ins_1774648335970_y32ey", "type": "RESIDENTIAL", "status": "ACTIVE", "assetId": "brsp-134786", "endDate": "2026-04-27", "insurer": "Teste", "createdAt": "2026-03-27T21:52:15.970Z", "startDate": "2026-03-27", "brokerName": "", "deductible": 0, "ownerEmail": "alex@brspark.com", "brokerPhone": "", "documentUri": "http://192.168.15.73:3001/uploads/storage/docs/alex_brspark_com/ins_1774648335970_y32ey.insurance_355", "policyNumber": "355", "premiumValue": 0, "coverageAmount": 0, "alertDaysBefore": 1, "coverageDetails": ""}, {"id": "ins_1774648337353_bjq8z", "type": "RESIDENTIAL", "status": "ACTIVE", "assetId": "brsp-134786", "endDate": "2026-04-27", "insurer": "Teste", "createdAt": "2026-03-27T21:52:17.353Z", "startDate": "2026-03-27", "brokerName": "", "deductible": 0, "ownerEmail": "alex@brspark.com", "brokerPhone": "", "documentUri": "http://192.168.15.73:3001/uploads/storage/docs/alex_brspark_com/ins_1774648337353_bjq8z.insurance_355", "policyNumber": "355", "premiumValue": 0, "coverageAmount": 0, "alertDaysBefore": 1, "coverageDetails": ""}, {"id": "ins_1774648337620_kuvjy", "type": "RESIDENTIAL", "status": "ACTIVE", "assetId": "brsp-134786", "endDate": "2026-04-27", "insurer": "Teste", "createdAt": "2026-03-27T21:52:17.620Z", "startDate": "2026-03-27", "brokerName": "", "deductible": 0, "ownerEmail": "alex@brspark.com", "brokerPhone": "", "documentUri": "http://192.168.15.73:3001/uploads/storage/docs/alex_brspark_com/ins_1774648337620_kuvjy.insurance_355", "policyNumber": "355", "premiumValue": 0, "coverageAmount": 0, "alertDaysBefore": 1, "coverageDetails": ""}, {"id": "ins_1774648337870_l14de", "type": "RESIDENTIAL", "status": "ACTIVE", "assetId": "brsp-134786", "endDate": "2026-04-27", "insurer": "Teste", "createdAt": "2026-03-27T21:52:17.870Z", "startDate": "2026-03-27", "brokerName": "", "deductible": 0, "ownerEmail": "alex@brspark.com", "brokerPhone": "", "documentUri": "http://192.168.15.73:3001/uploads/storage/docs/alex_brspark_com/ins_1774648337870_l14de.insurance_355", "policyNumber": "355", "premiumValue": 0, "coverageAmount": 0, "alertDaysBefore": 1, "coverageDetails": ""}]	2026-04-02 03:44:33.434	2026-03-25 23:14:20.765
\.


--
-- Data for Name: _prisma_migrations; Type: TABLE DATA; Schema: public; Owner: alex
--

COPY public._prisma_migrations (id, checksum, finished_at, migration_name, logs, rolled_back_at, started_at, applied_steps_count) FROM stdin;
88e7ba54-b943-4298-b4a2-ea8b736a2125	73224fe465c7de5be1d4f58cef71fe703fb824623c5ac8e5cb2f2f6321e13618	2026-03-23 21:13:49.442506-03	20260323143455_init	\N	\N	2026-03-23 21:13:49.40633-03	1
327e5d1e-7f12-4b6c-9086-c7ea2cdae478	b00868e21b0ca2a3323cd88c3837296362a8462505fcd8fd176873fdd031d0e0	2026-03-23 21:14:07.840326-03	20260324001407_add_locale_profiles	\N	\N	2026-03-23 21:14:07.701459-03	1
c5d144ad-13c5-42f5-b9d0-828474b0ded4	4aee8126753b087ae1d49fcb712baf2e1c6e24482a4c62352b79d536d572e4fe	2026-03-23 21:55:28.879335-03	20260324005528_add_translation_overrides	\N	\N	2026-03-23 21:55:28.871565-03	1
971d38b9-d917-4ca4-8fc8-9cd12cafcf46	9d60239b46e3f387ba472534b063e7b1ec3b3261abed0fc6518319807e150d9f	2026-03-24 14:35:11.484744-03	20260324173511_add_expense_revenue_metatag_types	\N	\N	2026-03-24 14:35:11.455941-03	1
0547e099-2b1f-4aaf-9f64-ce245c08121b	589531bd1df68a2b7555da033cb015bbcbd21f47a34108adc3062f3239503fdd	2026-03-25 19:50:08.669677-03	20260325225008_add_user_module_data	\N	\N	2026-03-25 19:50:08.659308-03	1
d8b0d2ea-4184-464b-9423-9900865a2bea	69261f245187956b568acf26c08edaaa8f37d68a4f7837d767ad498780c8045e	2026-03-25 20:03:53.367647-03	20260325230353_add_media_category	\N	\N	2026-03-25 20:03:53.305337-03	1
ee0003b9-d3d3-4fec-a918-8e6e5e3e04f2	78071a54b17cd3c1f7831a52989a8e4b26c043c6761ea11357637c77c6134b4e	2026-03-25 21:53:47.510058-03	20260326005347_init_asset_shares	\N	\N	2026-03-25 21:53:47.487591-03	1
\.


--
-- Name: Admin Admin_pkey; Type: CONSTRAINT; Schema: public; Owner: alex
--

ALTER TABLE ONLY public."Admin"
    ADD CONSTRAINT "Admin_pkey" PRIMARY KEY (id);


--
-- Name: AssetShare AssetShare_pkey; Type: CONSTRAINT; Schema: public; Owner: alex
--

ALTER TABLE ONLY public."AssetShare"
    ADD CONSTRAINT "AssetShare_pkey" PRIMARY KEY (id);


--
-- Name: Asset Asset_pkey; Type: CONSTRAINT; Schema: public; Owner: alex
--

ALTER TABLE ONLY public."Asset"
    ADD CONSTRAINT "Asset_pkey" PRIMARY KEY (id);


--
-- Name: AuditLog AuditLog_pkey; Type: CONSTRAINT; Schema: public; Owner: alex
--

ALTER TABLE ONLY public."AuditLog"
    ADD CONSTRAINT "AuditLog_pkey" PRIMARY KEY (id);


--
-- Name: ChatContact ChatContact_pkey; Type: CONSTRAINT; Schema: public; Owner: alex
--

ALTER TABLE ONLY public."ChatContact"
    ADD CONSTRAINT "ChatContact_pkey" PRIMARY KEY (id);


--
-- Name: ChatMessage ChatMessage_pkey; Type: CONSTRAINT; Schema: public; Owner: alex
--

ALTER TABLE ONLY public."ChatMessage"
    ADD CONSTRAINT "ChatMessage_pkey" PRIMARY KEY (id);


--
-- Name: ChatRoomMember ChatRoomMember_pkey; Type: CONSTRAINT; Schema: public; Owner: alex
--

ALTER TABLE ONLY public."ChatRoomMember"
    ADD CONSTRAINT "ChatRoomMember_pkey" PRIMARY KEY (id);


--
-- Name: ChatRoom ChatRoom_pkey; Type: CONSTRAINT; Schema: public; Owner: alex
--

ALTER TABLE ONLY public."ChatRoom"
    ADD CONSTRAINT "ChatRoom_pkey" PRIMARY KEY (id);


--
-- Name: ChecklistExecution ChecklistExecution_pkey; Type: CONSTRAINT; Schema: public; Owner: alex
--

ALTER TABLE ONLY public."ChecklistExecution"
    ADD CONSTRAINT "ChecklistExecution_pkey" PRIMARY KEY (id);


--
-- Name: ChecklistTemplate ChecklistTemplate_pkey; Type: CONSTRAINT; Schema: public; Owner: alex
--

ALTER TABLE ONLY public."ChecklistTemplate"
    ADD CONSTRAINT "ChecklistTemplate_pkey" PRIMARY KEY (id);


--
-- Name: ComplianceAcceptance ComplianceAcceptance_pkey; Type: CONSTRAINT; Schema: public; Owner: alex
--

ALTER TABLE ONLY public."ComplianceAcceptance"
    ADD CONSTRAINT "ComplianceAcceptance_pkey" PRIMARY KEY (id);


--
-- Name: ComplianceDoc ComplianceDoc_pkey; Type: CONSTRAINT; Schema: public; Owner: alex
--

ALTER TABLE ONLY public."ComplianceDoc"
    ADD CONSTRAINT "ComplianceDoc_pkey" PRIMARY KEY (id);


--
-- Name: FeatureFlag FeatureFlag_pkey; Type: CONSTRAINT; Schema: public; Owner: alex
--

ALTER TABLE ONLY public."FeatureFlag"
    ADD CONSTRAINT "FeatureFlag_pkey" PRIMARY KEY (id);


--
-- Name: Integration Integration_pkey; Type: CONSTRAINT; Schema: public; Owner: alex
--

ALTER TABLE ONLY public."Integration"
    ADD CONSTRAINT "Integration_pkey" PRIMARY KEY (id);


--
-- Name: Invoice Invoice_pkey; Type: CONSTRAINT; Schema: public; Owner: alex
--

ALTER TABLE ONLY public."Invoice"
    ADD CONSTRAINT "Invoice_pkey" PRIMARY KEY (id);


--
-- Name: LocaleProfile LocaleProfile_pkey; Type: CONSTRAINT; Schema: public; Owner: alex
--

ALTER TABLE ONLY public."LocaleProfile"
    ADD CONSTRAINT "LocaleProfile_pkey" PRIMARY KEY (id);


--
-- Name: Location Location_pkey; Type: CONSTRAINT; Schema: public; Owner: alex
--

ALTER TABLE ONLY public."Location"
    ADD CONSTRAINT "Location_pkey" PRIMARY KEY (id);


--
-- Name: Metatag Metatag_pkey; Type: CONSTRAINT; Schema: public; Owner: alex
--

ALTER TABLE ONLY public."Metatag"
    ADD CONSTRAINT "Metatag_pkey" PRIMARY KEY (id);


--
-- Name: NotificationLog NotificationLog_pkey; Type: CONSTRAINT; Schema: public; Owner: alex
--

ALTER TABLE ONLY public."NotificationLog"
    ADD CONSTRAINT "NotificationLog_pkey" PRIMARY KEY (id);


--
-- Name: NotificationTemplate NotificationTemplate_pkey; Type: CONSTRAINT; Schema: public; Owner: alex
--

ALTER TABLE ONLY public."NotificationTemplate"
    ADD CONSTRAINT "NotificationTemplate_pkey" PRIMARY KEY (id);


--
-- Name: Plan Plan_pkey; Type: CONSTRAINT; Schema: public; Owner: alex
--

ALTER TABLE ONLY public."Plan"
    ADD CONSTRAINT "Plan_pkey" PRIMARY KEY (id);


--
-- Name: PushToken PushToken_pkey; Type: CONSTRAINT; Schema: public; Owner: alex
--

ALTER TABLE ONLY public."PushToken"
    ADD CONSTRAINT "PushToken_pkey" PRIMARY KEY (id);


--
-- Name: ServiceProvider ServiceProvider_pkey; Type: CONSTRAINT; Schema: public; Owner: alex
--

ALTER TABLE ONLY public."ServiceProvider"
    ADD CONSTRAINT "ServiceProvider_pkey" PRIMARY KEY (id);


--
-- Name: StockItem StockItem_pkey; Type: CONSTRAINT; Schema: public; Owner: alex
--

ALTER TABLE ONLY public."StockItem"
    ADD CONSTRAINT "StockItem_pkey" PRIMARY KEY (id);


--
-- Name: StockMovement StockMovement_pkey; Type: CONSTRAINT; Schema: public; Owner: alex
--

ALTER TABLE ONLY public."StockMovement"
    ADD CONSTRAINT "StockMovement_pkey" PRIMARY KEY (id);


--
-- Name: Subscription Subscription_pkey; Type: CONSTRAINT; Schema: public; Owner: alex
--

ALTER TABLE ONLY public."Subscription"
    ADD CONSTRAINT "Subscription_pkey" PRIMARY KEY (id);


--
-- Name: Tenant Tenant_pkey; Type: CONSTRAINT; Schema: public; Owner: alex
--

ALTER TABLE ONLY public."Tenant"
    ADD CONSTRAINT "Tenant_pkey" PRIMARY KEY (id);


--
-- Name: TranslationOverride TranslationOverride_pkey; Type: CONSTRAINT; Schema: public; Owner: alex
--

ALTER TABLE ONLY public."TranslationOverride"
    ADD CONSTRAINT "TranslationOverride_pkey" PRIMARY KEY (id);


--
-- Name: UserModuleData UserModuleData_pkey; Type: CONSTRAINT; Schema: public; Owner: alex
--

ALTER TABLE ONLY public."UserModuleData"
    ADD CONSTRAINT "UserModuleData_pkey" PRIMARY KEY (id);


--
-- Name: User User_pkey; Type: CONSTRAINT; Schema: public; Owner: alex
--

ALTER TABLE ONLY public."User"
    ADD CONSTRAINT "User_pkey" PRIMARY KEY (id);


--
-- Name: _prisma_migrations _prisma_migrations_pkey; Type: CONSTRAINT; Schema: public; Owner: alex
--

ALTER TABLE ONLY public._prisma_migrations
    ADD CONSTRAINT _prisma_migrations_pkey PRIMARY KEY (id);


--
-- Name: Admin_email_key; Type: INDEX; Schema: public; Owner: alex
--

CREATE UNIQUE INDEX "Admin_email_key" ON public."Admin" USING btree (email);


--
-- Name: AssetShare_assetId_sharedWithEmail_key; Type: INDEX; Schema: public; Owner: alex
--

CREATE UNIQUE INDEX "AssetShare_assetId_sharedWithEmail_key" ON public."AssetShare" USING btree ("assetId", "sharedWithEmail");


--
-- Name: ChatContact_requesterId_addresseeId_key; Type: INDEX; Schema: public; Owner: alex
--

CREATE UNIQUE INDEX "ChatContact_requesterId_addresseeId_key" ON public."ChatContact" USING btree ("requesterId", "addresseeId");


--
-- Name: ChatRoomMember_roomId_userId_key; Type: INDEX; Schema: public; Owner: alex
--

CREATE UNIQUE INDEX "ChatRoomMember_roomId_userId_key" ON public."ChatRoomMember" USING btree ("roomId", "userId");


--
-- Name: ChecklistExecution_ownerEmail_idx; Type: INDEX; Schema: public; Owner: alex
--

CREATE INDEX "ChecklistExecution_ownerEmail_idx" ON public."ChecklistExecution" USING btree ("ownerEmail");


--
-- Name: ChecklistExecution_ownerEmail_status_idx; Type: INDEX; Schema: public; Owner: alex
--

CREATE INDEX "ChecklistExecution_ownerEmail_status_idx" ON public."ChecklistExecution" USING btree ("ownerEmail", status);


--
-- Name: ChecklistExecution_status_idx; Type: INDEX; Schema: public; Owner: alex
--

CREATE INDEX "ChecklistExecution_status_idx" ON public."ChecklistExecution" USING btree (status);


--
-- Name: FeatureFlag_key_tenantId_key; Type: INDEX; Schema: public; Owner: alex
--

CREATE UNIQUE INDEX "FeatureFlag_key_tenantId_key" ON public."FeatureFlag" USING btree (key, "tenantId");


--
-- Name: LocaleProfile_countryCode_key; Type: INDEX; Schema: public; Owner: alex
--

CREATE UNIQUE INDEX "LocaleProfile_countryCode_key" ON public."LocaleProfile" USING btree ("countryCode");


--
-- Name: Metatag_key_key; Type: INDEX; Schema: public; Owner: alex
--

CREATE UNIQUE INDEX "Metatag_key_key" ON public."Metatag" USING btree (key);


--
-- Name: NotificationTemplate_key_key; Type: INDEX; Schema: public; Owner: alex
--

CREATE UNIQUE INDEX "NotificationTemplate_key_key" ON public."NotificationTemplate" USING btree (key);


--
-- Name: Plan_name_key; Type: INDEX; Schema: public; Owner: alex
--

CREATE UNIQUE INDEX "Plan_name_key" ON public."Plan" USING btree (name);


--
-- Name: PushToken_token_key; Type: INDEX; Schema: public; Owner: alex
--

CREATE UNIQUE INDEX "PushToken_token_key" ON public."PushToken" USING btree (token);


--
-- Name: StockItem_assetId_sku_key; Type: INDEX; Schema: public; Owner: alex
--

CREATE UNIQUE INDEX "StockItem_assetId_sku_key" ON public."StockItem" USING btree ("assetId", sku);


--
-- Name: Subscription_tenantId_key; Type: INDEX; Schema: public; Owner: alex
--

CREATE UNIQUE INDEX "Subscription_tenantId_key" ON public."Subscription" USING btree ("tenantId");


--
-- Name: Tenant_email_key; Type: INDEX; Schema: public; Owner: alex
--

CREATE UNIQUE INDEX "Tenant_email_key" ON public."Tenant" USING btree (email);


--
-- Name: Tenant_slug_key; Type: INDEX; Schema: public; Owner: alex
--

CREATE UNIQUE INDEX "Tenant_slug_key" ON public."Tenant" USING btree (slug);


--
-- Name: TranslationOverride_tenantId_key_language_key; Type: INDEX; Schema: public; Owner: alex
--

CREATE UNIQUE INDEX "TranslationOverride_tenantId_key_language_key" ON public."TranslationOverride" USING btree ("tenantId", key, language);


--
-- Name: UserModuleData_ownerEmail_idx; Type: INDEX; Schema: public; Owner: alex
--

CREATE INDEX "UserModuleData_ownerEmail_idx" ON public."UserModuleData" USING btree ("ownerEmail");


--
-- Name: UserModuleData_ownerEmail_module_key; Type: INDEX; Schema: public; Owner: alex
--

CREATE UNIQUE INDEX "UserModuleData_ownerEmail_module_key" ON public."UserModuleData" USING btree ("ownerEmail", module);


--
-- Name: User_email_tenantId_key; Type: INDEX; Schema: public; Owner: alex
--

CREATE UNIQUE INDEX "User_email_tenantId_key" ON public."User" USING btree (email, "tenantId");


--
-- Name: Asset Asset_locationId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: alex
--

ALTER TABLE ONLY public."Asset"
    ADD CONSTRAINT "Asset_locationId_fkey" FOREIGN KEY ("locationId") REFERENCES public."Location"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: Asset Asset_parentId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: alex
--

ALTER TABLE ONLY public."Asset"
    ADD CONSTRAINT "Asset_parentId_fkey" FOREIGN KEY ("parentId") REFERENCES public."Asset"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: Asset Asset_tenantId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: alex
--

ALTER TABLE ONLY public."Asset"
    ADD CONSTRAINT "Asset_tenantId_fkey" FOREIGN KEY ("tenantId") REFERENCES public."Tenant"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: AuditLog AuditLog_adminId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: alex
--

ALTER TABLE ONLY public."AuditLog"
    ADD CONSTRAINT "AuditLog_adminId_fkey" FOREIGN KEY ("adminId") REFERENCES public."Admin"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: AuditLog AuditLog_tenantId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: alex
--

ALTER TABLE ONLY public."AuditLog"
    ADD CONSTRAINT "AuditLog_tenantId_fkey" FOREIGN KEY ("tenantId") REFERENCES public."Tenant"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: AuditLog AuditLog_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: alex
--

ALTER TABLE ONLY public."AuditLog"
    ADD CONSTRAINT "AuditLog_userId_fkey" FOREIGN KEY ("userId") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: ChatMessage ChatMessage_roomId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: alex
--

ALTER TABLE ONLY public."ChatMessage"
    ADD CONSTRAINT "ChatMessage_roomId_fkey" FOREIGN KEY ("roomId") REFERENCES public."ChatRoom"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: ChatRoomMember ChatRoomMember_roomId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: alex
--

ALTER TABLE ONLY public."ChatRoomMember"
    ADD CONSTRAINT "ChatRoomMember_roomId_fkey" FOREIGN KEY ("roomId") REFERENCES public."ChatRoom"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: ChecklistExecution ChecklistExecution_templateId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: alex
--

ALTER TABLE ONLY public."ChecklistExecution"
    ADD CONSTRAINT "ChecklistExecution_templateId_fkey" FOREIGN KEY ("templateId") REFERENCES public."ChecklistTemplate"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: ComplianceAcceptance ComplianceAcceptance_docId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: alex
--

ALTER TABLE ONLY public."ComplianceAcceptance"
    ADD CONSTRAINT "ComplianceAcceptance_docId_fkey" FOREIGN KEY ("docId") REFERENCES public."ComplianceDoc"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: FeatureFlag FeatureFlag_tenantId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: alex
--

ALTER TABLE ONLY public."FeatureFlag"
    ADD CONSTRAINT "FeatureFlag_tenantId_fkey" FOREIGN KEY ("tenantId") REFERENCES public."Tenant"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: Invoice Invoice_subscriptionId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: alex
--

ALTER TABLE ONLY public."Invoice"
    ADD CONSTRAINT "Invoice_subscriptionId_fkey" FOREIGN KEY ("subscriptionId") REFERENCES public."Subscription"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: Location Location_parentId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: alex
--

ALTER TABLE ONLY public."Location"
    ADD CONSTRAINT "Location_parentId_fkey" FOREIGN KEY ("parentId") REFERENCES public."Location"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: Location Location_tenantId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: alex
--

ALTER TABLE ONLY public."Location"
    ADD CONSTRAINT "Location_tenantId_fkey" FOREIGN KEY ("tenantId") REFERENCES public."Tenant"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: NotificationLog NotificationLog_templateId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: alex
--

ALTER TABLE ONLY public."NotificationLog"
    ADD CONSTRAINT "NotificationLog_templateId_fkey" FOREIGN KEY ("templateId") REFERENCES public."NotificationTemplate"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: PushToken PushToken_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: alex
--

ALTER TABLE ONLY public."PushToken"
    ADD CONSTRAINT "PushToken_userId_fkey" FOREIGN KEY ("userId") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: StockItem StockItem_assetId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: alex
--

ALTER TABLE ONLY public."StockItem"
    ADD CONSTRAINT "StockItem_assetId_fkey" FOREIGN KEY ("assetId") REFERENCES public."Asset"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: StockMovement StockMovement_itemId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: alex
--

ALTER TABLE ONLY public."StockMovement"
    ADD CONSTRAINT "StockMovement_itemId_fkey" FOREIGN KEY ("itemId") REFERENCES public."StockItem"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: Subscription Subscription_planId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: alex
--

ALTER TABLE ONLY public."Subscription"
    ADD CONSTRAINT "Subscription_planId_fkey" FOREIGN KEY ("planId") REFERENCES public."Plan"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: Subscription Subscription_tenantId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: alex
--

ALTER TABLE ONLY public."Subscription"
    ADD CONSTRAINT "Subscription_tenantId_fkey" FOREIGN KEY ("tenantId") REFERENCES public."Tenant"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: Tenant Tenant_localeId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: alex
--

ALTER TABLE ONLY public."Tenant"
    ADD CONSTRAINT "Tenant_localeId_fkey" FOREIGN KEY ("localeId") REFERENCES public."LocaleProfile"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: TranslationOverride TranslationOverride_tenantId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: alex
--

ALTER TABLE ONLY public."TranslationOverride"
    ADD CONSTRAINT "TranslationOverride_tenantId_fkey" FOREIGN KEY ("tenantId") REFERENCES public."Tenant"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: User User_tenantId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: alex
--

ALTER TABLE ONLY public."User"
    ADD CONSTRAINT "User_tenantId_fkey" FOREIGN KEY ("tenantId") REFERENCES public."Tenant"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- PostgreSQL database dump complete
--

\unrestrict COg3jD0b5hpDSjHu9RKrqK0e9kOop76ldCFol3enPPFdhDJeVoTDdP1U7cuBk24

