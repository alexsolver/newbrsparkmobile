--
-- PostgreSQL database dump
--

\restrict uviTvDjTCrJDfV4MBzM51iv8NIyhE2abBfHMNsyCalIdkAz6dZeyfsAx1duPum2

-- Dumped from database version 14.20 (Homebrew)
-- Dumped by pg_dump version 14.20 (Homebrew)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: AssetType; Type: TYPE; Schema: public; Owner: alex
--

CREATE TYPE public."AssetType" AS ENUM (
    'REAL_ESTATE',
    'TERRESTRIAL',
    'AQUATIC',
    'SPECIAL',
    'OTHER'
);


ALTER TYPE public."AssetType" OWNER TO alex;

--
-- Name: AuditCategory; Type: TYPE; Schema: public; Owner: alex
--

CREATE TYPE public."AuditCategory" AS ENUM (
    'AUTH',
    'DATA',
    'ADMIN',
    'SYSTEM'
);


ALTER TYPE public."AuditCategory" OWNER TO alex;

--
-- Name: BillingCycle; Type: TYPE; Schema: public; Owner: alex
--

CREATE TYPE public."BillingCycle" AS ENUM (
    'MONTHLY',
    'YEARLY'
);


ALTER TYPE public."BillingCycle" OWNER TO alex;

--
-- Name: Channel; Type: TYPE; Schema: public; Owner: alex
--

CREATE TYPE public."Channel" AS ENUM (
    'EMAIL',
    'PUSH',
    'WHATSAPP',
    'SMS'
);


ALTER TYPE public."Channel" OWNER TO alex;

--
-- Name: DocType; Type: TYPE; Schema: public; Owner: alex
--

CREATE TYPE public."DocType" AS ENUM (
    'TERMS_OF_USE',
    'PRIVACY_POLICY',
    'LGPD_DPA',
    'COOKIE_POLICY'
);


ALTER TYPE public."DocType" OWNER TO alex;

--
-- Name: IntType; Type: TYPE; Schema: public; Owner: alex
--

CREATE TYPE public."IntType" AS ENUM (
    'AI_LLM',
    'EMAIL',
    'PUSH',
    'STORAGE',
    'WEBHOOK',
    'ERP',
    'PAYMENT',
    'MAPS'
);


ALTER TYPE public."IntType" OWNER TO alex;

--
-- Name: InvoiceStatus; Type: TYPE; Schema: public; Owner: alex
--

CREATE TYPE public."InvoiceStatus" AS ENUM (
    'PENDING',
    'PAID',
    'OVERDUE',
    'VOID'
);


ALTER TYPE public."InvoiceStatus" OWNER TO alex;

--
-- Name: LocationType; Type: TYPE; Schema: public; Owner: alex
--

CREATE TYPE public."LocationType" AS ENUM (
    'BUILDING',
    'FLOOR',
    'ROOM',
    'AREA',
    'WAREHOUSE',
    'OTHER'
);


ALTER TYPE public."LocationType" OWNER TO alex;

--
-- Name: MetatagType; Type: TYPE; Schema: public; Owner: alex
--

CREATE TYPE public."MetatagType" AS ENUM (
    'ASSET_TYPE',
    'STOCK_CATEGORY',
    'SERVICE_CATEGORY',
    'ASSET_STATUS',
    'GLOBAL_TAG',
    'EXPENSE_CATEGORY',
    'REVENUE_CATEGORY',
    'MEDIA_CATEGORY'
);


ALTER TYPE public."MetatagType" OWNER TO alex;

--
-- Name: MovementType; Type: TYPE; Schema: public; Owner: alex
--

CREATE TYPE public."MovementType" AS ENUM (
    'IN',
    'OUT',
    'TRANSFER'
);


ALTER TYPE public."MovementType" OWNER TO alex;

--
-- Name: NotifStatus; Type: TYPE; Schema: public; Owner: alex
--

CREATE TYPE public."NotifStatus" AS ENUM (
    'SENT',
    'DELIVERED',
    'FAILED',
    'BOUNCED'
);


ALTER TYPE public."NotifStatus" OWNER TO alex;

--
-- Name: SubStatus; Type: TYPE; Schema: public; Owner: alex
--

CREATE TYPE public."SubStatus" AS ENUM (
    'ACTIVE',
    'PAST_DUE',
    'CANCELLED',
    'TRIALING'
);


ALTER TYPE public."SubStatus" OWNER TO alex;

--
-- Name: TenantStatus; Type: TYPE; Schema: public; Owner: alex
--

CREATE TYPE public."TenantStatus" AS ENUM (
    'TRIAL',
    'ACTIVE',
    'SUSPENDED',
    'CANCELLED'
);


ALTER TYPE public."TenantStatus" OWNER TO alex;

--
-- Name: UserRole; Type: TYPE; Schema: public; Owner: alex
--

CREATE TYPE public."UserRole" AS ENUM (
    'ADMIN',
    'MANAGER',
    'USER'
);


ALTER TYPE public."UserRole" OWNER TO alex;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: Admin; Type: TABLE; Schema: public; Owner: alex
--

CREATE TABLE public."Admin" (
    id text NOT NULL,
    email text NOT NULL,
    name text NOT NULL,
    password text NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public."Admin" OWNER TO alex;

--
-- Name: Asset; Type: TABLE; Schema: public; Owner: alex
--

CREATE TABLE public."Asset" (
    id text NOT NULL,
    "tenantId" text NOT NULL,
    "parentId" text,
    title text NOT NULL,
    type public."AssetType" NOT NULL,
    status text DEFAULT 'Operacional'::text NOT NULL,
    description text,
    "imageUrl" text,
    "locationId" text,
    metadata jsonb,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL,
    "deletedAt" timestamp(3) without time zone
);


ALTER TABLE public."Asset" OWNER TO alex;

--
-- Name: AssetShare; Type: TABLE; Schema: public; Owner: alex
--

CREATE TABLE public."AssetShare" (
    id text NOT NULL,
    "assetId" text NOT NULL,
    "ownerEmail" text NOT NULL,
    "sharedWithEmail" text NOT NULL,
    permission text NOT NULL,
    modules jsonb NOT NULL,
    status text DEFAULT 'PENDING'::text NOT NULL,
    "invitedAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "expiresAt" timestamp(3) without time zone
);


ALTER TABLE public."AssetShare" OWNER TO alex;

--
-- Name: AuditLog; Type: TABLE; Schema: public; Owner: alex
--

CREATE TABLE public."AuditLog" (
    id text NOT NULL,
    "tenantId" text,
    "userId" text,
    "adminId" text,
    action text NOT NULL,
    resource text NOT NULL,
    category public."AuditCategory" NOT NULL,
    metadata jsonb,
    "ipAddress" text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public."AuditLog" OWNER TO alex;

--
-- Name: ChatContact; Type: TABLE; Schema: public; Owner: alex
--

CREATE TABLE public."ChatContact" (
    id text NOT NULL,
    "requesterId" text NOT NULL,
    "addresseeId" text NOT NULL,
    status text DEFAULT 'PENDING'::text NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public."ChatContact" OWNER TO alex;

--
-- Name: ChatMessage; Type: TABLE; Schema: public; Owner: alex
--

CREATE TABLE public."ChatMessage" (
    id text NOT NULL,
    "roomId" text NOT NULL,
    "senderId" text NOT NULL,
    "senderName" text NOT NULL,
    type text DEFAULT 'text'::text NOT NULL,
    content text,
    "mediaUrl" text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public."ChatMessage" OWNER TO alex;

--
-- Name: ChatRoom; Type: TABLE; Schema: public; Owner: alex
--

CREATE TABLE public."ChatRoom" (
    id text NOT NULL,
    name text,
    description text,
    "avatarColor" text DEFAULT '#2563EB'::text,
    "isGroup" boolean DEFAULT false NOT NULL,
    "creatorId" text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public."ChatRoom" OWNER TO alex;

--
-- Name: ChatRoomMember; Type: TABLE; Schema: public; Owner: alex
--

CREATE TABLE public."ChatRoomMember" (
    id text NOT NULL,
    "roomId" text NOT NULL,
    "userId" text NOT NULL,
    role text DEFAULT 'MEMBER'::text NOT NULL,
    "joinedAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "lastReadAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public."ChatRoomMember" OWNER TO alex;

--
-- Name: ComplianceAcceptance; Type: TABLE; Schema: public; Owner: alex
--

CREATE TABLE public."ComplianceAcceptance" (
    id text NOT NULL,
    "docId" text NOT NULL,
    "userId" text,
    "tenantId" text,
    "ipAddress" text,
    "acceptedAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public."ComplianceAcceptance" OWNER TO alex;

--
-- Name: ComplianceDoc; Type: TABLE; Schema: public; Owner: alex
--

CREATE TABLE public."ComplianceDoc" (
    id text NOT NULL,
    type public."DocType" NOT NULL,
    version text NOT NULL,
    title text NOT NULL,
    content text NOT NULL,
    "isActive" boolean DEFAULT false NOT NULL,
    "publishedAt" timestamp(3) without time zone,
    "createdBy" text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public."ComplianceDoc" OWNER TO alex;

--
-- Name: FeatureFlag; Type: TABLE; Schema: public; Owner: alex
--

CREATE TABLE public."FeatureFlag" (
    id text NOT NULL,
    key text NOT NULL,
    label text NOT NULL,
    description text NOT NULL,
    icon text,
    enabled boolean DEFAULT true NOT NULL,
    "tenantId" text,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public."FeatureFlag" OWNER TO alex;

--
-- Name: Integration; Type: TABLE; Schema: public; Owner: alex
--

CREATE TABLE public."Integration" (
    id text NOT NULL,
    name text NOT NULL,
    type public."IntType" NOT NULL,
    icon text,
    "apiKey" text,
    "baseUrl" text,
    "webhookUrl" text,
    "lastTestedAt" timestamp(3) without time zone,
    metadata jsonb,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL,
    description text,
    status text DEFAULT 'ACTIVE'::text NOT NULL
);


ALTER TABLE public."Integration" OWNER TO alex;

--
-- Name: Invoice; Type: TABLE; Schema: public; Owner: alex
--

CREATE TABLE public."Invoice" (
    id text NOT NULL,
    "subscriptionId" text NOT NULL,
    amount numeric(10,2) NOT NULL,
    status public."InvoiceStatus" DEFAULT 'PENDING'::public."InvoiceStatus" NOT NULL,
    "dueDate" timestamp(3) without time zone NOT NULL,
    "paidAt" timestamp(3) without time zone,
    "externalId" text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public."Invoice" OWNER TO alex;

--
-- Name: LocaleProfile; Type: TABLE; Schema: public; Owner: alex
--

CREATE TABLE public."LocaleProfile" (
    id text NOT NULL,
    "countryCode" text NOT NULL,
    name text NOT NULL,
    language text DEFAULT 'pt-BR'::text NOT NULL,
    currency text DEFAULT 'BRL'::text NOT NULL,
    "currencySymbol" text DEFAULT 'R$'::text NOT NULL,
    "dateFormat" text DEFAULT 'DD/MM/YYYY'::text NOT NULL,
    "numberFormat" text DEFAULT 'PT_STYLE'::text NOT NULL,
    timezone text DEFAULT 'UTC'::text NOT NULL,
    "taxIdLabel" text DEFAULT 'Tax ID'::text NOT NULL,
    "postalCodeLabel" text DEFAULT 'Postal Code'::text NOT NULL,
    "measureSystem" text DEFAULT 'METRIC'::text NOT NULL,
    "isActive" boolean DEFAULT true NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public."LocaleProfile" OWNER TO alex;

--
-- Name: Location; Type: TABLE; Schema: public; Owner: alex
--

CREATE TABLE public."Location" (
    id text NOT NULL,
    "tenantId" text NOT NULL,
    name text NOT NULL,
    type public."LocationType" DEFAULT 'BUILDING'::public."LocationType" NOT NULL,
    address text,
    floor text,
    room text,
    icon text,
    latitude double precision,
    longitude double precision,
    "parentId" text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public."Location" OWNER TO alex;

--
-- Name: Metatag; Type: TABLE; Schema: public; Owner: alex
--

CREATE TABLE public."Metatag" (
    id text NOT NULL,
    type public."MetatagType" NOT NULL,
    key text NOT NULL,
    "ptBr" text NOT NULL,
    "enUs" text NOT NULL,
    "esEs" text NOT NULL,
    icon text,
    color text,
    "isActive" boolean DEFAULT true NOT NULL,
    "sortOrder" integer DEFAULT 0 NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public."Metatag" OWNER TO alex;

--
-- Name: NotificationLog; Type: TABLE; Schema: public; Owner: alex
--

CREATE TABLE public."NotificationLog" (
    id text NOT NULL,
    "templateId" text NOT NULL,
    recipient text NOT NULL,
    channel public."Channel" NOT NULL,
    status public."NotifStatus" DEFAULT 'SENT'::public."NotifStatus" NOT NULL,
    "sentAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    metadata jsonb
);


ALTER TABLE public."NotificationLog" OWNER TO alex;

--
-- Name: NotificationTemplate; Type: TABLE; Schema: public; Owner: alex
--

CREATE TABLE public."NotificationTemplate" (
    id text NOT NULL,
    key text NOT NULL,
    label text NOT NULL,
    channel public."Channel" NOT NULL,
    subject text,
    body text NOT NULL,
    variables jsonb,
    "isActive" boolean DEFAULT true NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public."NotificationTemplate" OWNER TO alex;

--
-- Name: Plan; Type: TABLE; Schema: public; Owner: alex
--

CREATE TABLE public."Plan" (
    id text NOT NULL,
    name text NOT NULL,
    "priceMonthly" numeric(10,2) NOT NULL,
    "priceYearly" numeric(10,2) NOT NULL,
    "maxAssets" integer NOT NULL,
    "maxUsers" integer NOT NULL,
    "storageGb" integer NOT NULL,
    features jsonb NOT NULL,
    "isActive" boolean DEFAULT true NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public."Plan" OWNER TO alex;

--
-- Name: PushToken; Type: TABLE; Schema: public; Owner: alex
--

CREATE TABLE public."PushToken" (
    id text NOT NULL,
    "userId" text NOT NULL,
    token text NOT NULL,
    device text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public."PushToken" OWNER TO alex;

--
-- Name: ServiceProvider; Type: TABLE; Schema: public; Owner: alex
--

CREATE TABLE public."ServiceProvider" (
    id text NOT NULL,
    name text NOT NULL,
    category text NOT NULL,
    rating double precision DEFAULT 0 NOT NULL,
    reviews integer DEFAULT 0 NOT NULL,
    photo text,
    tags jsonb,
    keywords text,
    phone text,
    email text,
    city text,
    state text DEFAULT 'SP'::text NOT NULL,
    verified boolean DEFAULT false NOT NULL,
    "isActive" boolean DEFAULT true NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public."ServiceProvider" OWNER TO alex;

--
-- Name: StockItem; Type: TABLE; Schema: public; Owner: alex
--

CREATE TABLE public."StockItem" (
    id text NOT NULL,
    "assetId" text NOT NULL,
    name text NOT NULL,
    sku text NOT NULL,
    "currentStock" integer DEFAULT 0 NOT NULL,
    "minStock" integer DEFAULT 1 NOT NULL,
    unit text DEFAULT 'un'::text NOT NULL,
    "subLocation" text,
    "unitPrice" numeric(10,2),
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public."StockItem" OWNER TO alex;

--
-- Name: StockMovement; Type: TABLE; Schema: public; Owner: alex
--

CREATE TABLE public."StockMovement" (
    id text NOT NULL,
    "itemId" text NOT NULL,
    type public."MovementType" NOT NULL,
    quantity integer NOT NULL,
    reason text,
    "fromAssetId" text,
    "toAssetId" text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public."StockMovement" OWNER TO alex;

--
-- Name: Subscription; Type: TABLE; Schema: public; Owner: alex
--

CREATE TABLE public."Subscription" (
    id text NOT NULL,
    "tenantId" text NOT NULL,
    "planId" text NOT NULL,
    "billingCycle" public."BillingCycle" DEFAULT 'MONTHLY'::public."BillingCycle" NOT NULL,
    status public."SubStatus" DEFAULT 'ACTIVE'::public."SubStatus" NOT NULL,
    "currentStart" timestamp(3) without time zone NOT NULL,
    "currentEnd" timestamp(3) without time zone NOT NULL,
    "cancelledAt" timestamp(3) without time zone,
    "trialEndsAt" timestamp(3) without time zone,
    "externalId" text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public."Subscription" OWNER TO alex;

--
-- Name: Tenant; Type: TABLE; Schema: public; Owner: alex
--

CREATE TABLE public."Tenant" (
    id text NOT NULL,
    name text NOT NULL,
    slug text NOT NULL,
    email text NOT NULL,
    phone text,
    "taxId" text,
    "defaultLang" text DEFAULT 'pt-BR'::text NOT NULL,
    status public."TenantStatus" DEFAULT 'TRIAL'::public."TenantStatus" NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL,
    "avatarUrl" text,
    "localeId" text,
    "ownerName" text NOT NULL
);


ALTER TABLE public."Tenant" OWNER TO alex;

--
-- Name: TranslationOverride; Type: TABLE; Schema: public; Owner: alex
--

CREATE TABLE public."TranslationOverride" (
    id text NOT NULL,
    "tenantId" text NOT NULL,
    key text NOT NULL,
    language text NOT NULL,
    value text NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public."TranslationOverride" OWNER TO alex;

--
-- Name: User; Type: TABLE; Schema: public; Owner: alex
--

CREATE TABLE public."User" (
    id text NOT NULL,
    "tenantId" text NOT NULL,
    email text NOT NULL,
    name text NOT NULL,
    password text NOT NULL,
    role public."UserRole" DEFAULT 'USER'::public."UserRole" NOT NULL,
    "isActive" boolean DEFAULT true NOT NULL,
    "lastLogin" timestamp(3) without time zone,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL,
    "avatarUrl" text
);


ALTER TABLE public."User" OWNER TO alex;

--
-- Name: UserModuleData; Type: TABLE; Schema: public; Owner: alex
--

CREATE TABLE public."UserModuleData" (
    id text NOT NULL,
    "ownerEmail" text NOT NULL,
    module text NOT NULL,
    data jsonb NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public."UserModuleData" OWNER TO alex;

--
-- Name: _prisma_migrations; Type: TABLE; Schema: public; Owner: alex
--

CREATE TABLE public._prisma_migrations (
    id character varying(36) NOT NULL,
    checksum character varying(64) NOT NULL,
    finished_at timestamp with time zone,
    migration_name character varying(255) NOT NULL,
    logs text,
    rolled_back_at timestamp with time zone,
    started_at timestamp with time zone DEFAULT now() NOT NULL,
    applied_steps_count integer DEFAULT 0 NOT NULL
);


ALTER TABLE public._prisma_migrations OWNER TO alex;

--
-- Data for Name: Admin; Type: TABLE DATA; Schema: public; Owner: alex
--

COPY public."Admin" (id, email, name, password, "createdAt", "updatedAt") FROM stdin;
cmn3xhvkq0000dajk4h6w2ytx	admin@brspark.com	BrSpark Admin	$2a$10$EVbJ098xpx0567OJhWzuC.h/7F.JAJh2ew6C9nAj3wPB/ApbTlHO2	2026-03-24 01:21:03.767	2026-03-24 01:21:03.767
\.


--
-- Data for Name: Asset; Type: TABLE DATA; Schema: public; Owner: alex
--

COPY public."Asset" (id, "tenantId", "parentId", title, type, status, description, "imageUrl", "locationId", metadata, "createdAt", "updatedAt", "deletedAt") FROM stdin;
cmn3xvxdk0007yjhblgorv4aw	cmn3xud9y0001kldgdiksukq5	\N	Asset 1 - Brspark Global Brazil	REAL_ESTATE	Operacional	Demo asset for Brspark Global Brazil	\N	\N	\N	2026-03-24 01:31:59.289	2026-03-24 01:31:59.289	\N
cmn3xwgtj00078gtly9ejtlxj	cmn3xud9y0001kldgdiksukq5	\N	Asset 1 - Brspark Global Brazil	REAL_ESTATE	Operacional	Demo asset for Brspark Global Brazil	\N	\N	\N	2026-03-24 01:32:24.487	2026-03-24 01:32:24.487	\N
cmn3xwgtv000d8gtlsiwqien4	cmn3xud9y0001kldgdiksukq5	\N	Asset 2 - Brspark Global Brazil	TERRESTRIAL	Operacional	Demo asset for Brspark Global Brazil	\N	\N	\N	2026-03-24 01:32:24.5	2026-03-24 01:32:24.5	\N
cmn3xwgtx000j8gtlf0vw1qok	cmn3xud9y0001kldgdiksukq5	\N	Asset 3 - Brspark Global Brazil	TERRESTRIAL	Operacional	Demo asset for Brspark Global Brazil	\N	\N	\N	2026-03-24 01:32:24.502	2026-03-24 01:32:24.502	\N
cmn3xwgu8000x8gtlixouh8pm	cmn3xwgu1000r8gtl768s8zcj	\N	Asset 1 - Solaris Energy US	REAL_ESTATE	Operacional	Demo asset for Solaris Energy US	\N	\N	\N	2026-03-24 01:32:24.513	2026-03-24 01:32:24.513	\N
cmn3xwgua00138gtlgxlzuqfm	cmn3xwgu1000r8gtl768s8zcj	\N	Asset 2 - Solaris Energy US	TERRESTRIAL	Operacional	Demo asset for Solaris Energy US	\N	\N	\N	2026-03-24 01:32:24.514	2026-03-24 01:32:24.514	\N
cmn3xwgub00198gtlm6juwtim	cmn3xwgu1000r8gtl768s8zcj	\N	Asset 3 - Solaris Energy US	TERRESTRIAL	Operacional	Demo asset for Solaris Energy US	\N	\N	\N	2026-03-24 01:32:24.516	2026-03-24 01:32:24.516	\N
cmn3xwguj001n8gtlutpesgpc	cmn3xwgue001h8gtlfcskpc0d	\N	Asset 1 - Iberia Logistics	REAL_ESTATE	Operacional	Demo asset for Iberia Logistics	\N	\N	\N	2026-03-24 01:32:24.523	2026-03-24 01:32:24.523	\N
cmn3xwguk001t8gtluwfugchd	cmn3xwgue001h8gtlfcskpc0d	\N	Asset 2 - Iberia Logistics	TERRESTRIAL	Operacional	Demo asset for Iberia Logistics	\N	\N	\N	2026-03-24 01:32:24.525	2026-03-24 01:32:24.525	\N
cmn3xwgun001z8gtlncywzd8z	cmn3xwgue001h8gtlfcskpc0d	\N	Asset 3 - Iberia Logistics	TERRESTRIAL	Operacional	Demo asset for Iberia Logistics	\N	\N	\N	2026-03-24 01:32:24.528	2026-03-24 01:32:24.528	\N
brsp-454019	cmn6sf2we004g5epyw7uxjo73	\N	Test Asset Luigi	TERRESTRIAL	OPERACIONAL	\N	\N	\N	{"brand": "Teste"}	2026-03-26 13:39:17.791	2026-03-26 14:05:32.026	2026-03-26 14:05:32.025
joao-asset-casa	cmn3y2uck0000sfjubh0n7z5o	\N	Casa Residencial — Morumbi	REAL_ESTATE	Operacional	\N	\N	\N	{"cep": "", "area": "180m²", "city": "", "iptu": "SP-2024-00123456", "brand": "", "model": "", "owner": "", "state": "", "photos": [], "street": "", "address": "Rua das Palmeiras, 142 — Morumbi, São Paulo/SP", "bedrooms": 3, "bathrooms": 2, "yearBuilt": 2005, "complement": "", "costCenter": "", "customIcon": "home-outline", "department": "", "customColor": "#3B82F6", "inventoryId": "", "marketValue": 950000, "customFields": [], "neighborhood": "", "serialNumber": "", "streetNumber": "", "gpsCoordinates": "", "acquisitionValue": "2596"}	2026-03-24 02:31:34.832	2026-03-24 19:56:35.639	\N
brsp-315981	cmn6sf2we004g5epyw7uxjo73	\N	Carro	TERRESTRIAL	OPERACIONAL	\N	\N	\N	{"cep": "", "city": "", "brand": "", "model": "", "owner": "", "state": "", "photos": [], "street": "", "complement": "", "costCenter": "", "department": "", "inventoryId": "", "customFields": [], "neighborhood": "", "serialNumber": "", "streetNumber": "", "gpsCoordinates": "", "acquisitionValue": ""}	2026-03-26 17:50:21.359	2026-03-26 17:50:21.359	\N
brsp-756993	cmn6hij2x0001j5dqofhbi9sd	\N	Chacara	REAL_ESTATE	OPERACIONAL	\N	\N	\N	{"cep": "", "city": "", "brand": "", "model": "", "owner": "", "state": "", "photos": [], "street": "", "complement": "", "costCenter": "", "department": "", "inventoryId": "", "customFields": [], "neighborhood": "", "serialNumber": "", "streetNumber": "", "gpsCoordinates": "", "acquisitionValue": ""}	2026-03-26 12:30:14.369	2026-03-26 12:30:14.369	\N
brsp-569392	cmn6sf2we004g5epyw7uxjo73	\N	Test Asset Luigi	TERRESTRIAL	OPERACIONAL	\N	\N	\N	{"brand": "Teste"}	2026-03-26 13:39:04.75	2026-03-26 13:39:04.75	\N
brsp-468315	cmn6sf2we004g5epyw7uxjo73	\N	Carlin	TERRESTRIAL	OPERACIONAL	\N	\N	\N	{"cep": "", "city": "", "brand": "", "model": "", "owner": "", "state": "", "photos": [], "street": "", "complement": "", "costCenter": "", "customIcon": "car-outline", "department": "", "inventoryId": "", "customFields": [], "neighborhood": "", "serialNumber": "", "streetNumber": "", "gpsCoordinates": "", "acquisitionValue": ""}	2026-03-26 17:53:45.852	2026-03-26 17:53:45.852	\N
brsp-123456	cmn6hij2x0001j5dqofhbi9sd	\N	Test Luigi Console	TERRESTRIAL	OPERACIONAL	\N	\N	\N	{"cep": "", "city": "", "brand": "", "model": "", "owner": "", "state": "", "photos": [], "street": "", "complement": "", "costCenter": "", "department": "", "inventoryId": "", "customFields": [], "neighborhood": "", "serialNumber": "", "streetNumber": "", "gpsCoordinates": "", "acquisitionValue": ""}	2026-03-26 02:52:31.417	2026-03-26 13:40:34.553	\N
brsp-999999	cmn6hij2x0001j5dqofhbi9sd	brsp-756993	Test Asset Script 2	TERRESTRIAL	OPERACIONAL	\N	\N	\N	{}	2026-03-26 02:54:55.144	2026-03-26 18:33:49.458	\N
brsp-134786	cmn6hij2x0001j5dqofhbi9sd	\N	Casa doi	REAL_ESTATE	OPERACIONAL	\N	\N	\N	{"cep": "", "city": "", "brand": "", "model": "", "owner": "", "state": "", "photos": [], "street": "", "complement": "", "costCenter": "", "department": "", "inventoryId": "", "customFields": [], "neighborhood": "", "serialNumber": "", "streetNumber": "", "gpsCoordinates": "", "acquisitionValue": ""}	2026-03-27 02:29:15.372	2026-03-27 02:29:15.372	\N
\.


--
-- Data for Name: AssetShare; Type: TABLE DATA; Schema: public; Owner: alex
--

COPY public."AssetShare" (id, "assetId", "ownerEmail", "sharedWithEmail", permission, modules, status, "invitedAt", "expiresAt") FROM stdin;
cmn6ub1vr000he0hkccbq9l5r	brsp-190135	alex@brspark.com	luigi@lansolver.com	WRITE	["*"]	ACCEPTED	2026-03-26 02:15:05.031	\N
cmn6vojq5002ev9sm2l49qwoi	brsp-513662	alex@brspark.com	luigi@lansolver.com	WRITE	["*"]	ACCEPTED	2026-03-26 02:53:34.3	\N
cmn7s1jxw0018x0k1c0msjmey	brsp-756993	alex@brspark.com	luigi@lansolver.com	WRITE	["*"]	ACCEPTED	2026-03-26 17:59:28.819	\N
\.


--
-- Data for Name: AuditLog; Type: TABLE DATA; Schema: public; Owner: alex
--

COPY public."AuditLog" (id, "tenantId", "userId", "adminId", action, resource, category, metadata, "ipAddress", "createdAt") FROM stdin;
cmn3xienb0001v6cye54kqi4i	\N	\N	cmn3xhvkq0000dajk4h6w2ytx	LOGIN	Admin Console	AUTH	\N	\N	2026-03-24 01:21:28.487
cmn3xnw300003v6cyi7piq4c8	\N	\N	cmn3xhvkq0000dajk4h6w2ytx	LOGIN	Admin Console	AUTH	\N	\N	2026-03-24 01:25:44.364
cmn3xwgu0000p8gtl28h8ej5c	cmn3xud9y0001kldgdiksukq5	\N	\N	TENANT_PROVISIONED	System	SYSTEM	\N	\N	2026-03-24 01:32:24.504
cmn3xwgud001f8gtl1g4696h3	cmn3xwgu1000r8gtl768s8zcj	\N	\N	TENANT_PROVISIONED	System	SYSTEM	\N	\N	2026-03-24 01:32:24.517
cmn3xwgup00258gtlag0vgwnf	cmn3xwgue001h8gtlfcskpc0d	\N	\N	TENANT_PROVISIONED	System	SYSTEM	\N	\N	2026-03-24 01:32:24.53
cmn3y388e0001y0zeh9wkf8wb	cmn3y2uck0000sfjubh0n7z5o	cmn3y2ucr0002sfju83h732a4	\N	USER_LOGIN	joao@teste.com	AUTH	\N	\N	2026-03-24 01:37:39.95
cmn3y4m8j0001sxxf7u2ahh6d	cmn3y2uck0000sfjubh0n7z5o	cmn3y2ucr0002sfju83h732a4	\N	USER_LOGIN	joao@teste.com	AUTH	\N	\N	2026-03-24 01:38:44.756
cmn3yg4u70001gv21xg5fgyeu	\N	\N	cmn3xhvkq0000dajk4h6w2ytx	LOGIN	Admin Console	AUTH	\N	\N	2026-03-24 01:47:42.079
cmn3yrrwo0001y3d4q2nbenm4	\N	\N	cmn3xhvkq0000dajk4h6w2ytx	LOGIN	Admin Console	AUTH	\N	\N	2026-03-24 01:56:45.192
cmn3zmulh0001iw22z73m11se	cmn3y2uck0000sfjubh0n7z5o	cmn3y2ucr0002sfju83h732a4	\N	USER_LOGIN	joao@teste.com	AUTH	\N	\N	2026-03-24 02:20:55.013
cmn3zoqnd0003iw22ry0ed2il	cmn3y2uck0000sfjubh0n7z5o	cmn3y2ucr0002sfju83h732a4	\N	USER_LOGIN	joao@teste.com	AUTH	\N	\N	2026-03-24 02:22:23.209
cmn400kan000112ywd11ceant	cmn3y2uck0000sfjubh0n7z5o	cmn3y2ucr0002sfju83h732a4	\N	SYNC_PUSH	1 itens	DATA	{"total": 1, "processed": 1}	\N	2026-03-24 02:31:34.847
cmn4lwqs20001j7uwjzy4bsm9	cmn3y2uck0000sfjubh0n7z5o	cmn3y2ucr0002sfju83h732a4	\N	USER_LOGIN	joao@teste.com	AUTH	\N	\N	2026-03-24 12:44:28.177
cmn4n4rwd0003j7uwdl5bi7jg	\N	\N	cmn3xhvkq0000dajk4h6w2ytx	LOGIN	Admin Console	AUTH	\N	\N	2026-03-24 13:18:42.491
cmn4nd6n70005j7uwlm31kv8g	\N	\N	cmn3xhvkq0000dajk4h6w2ytx	FLAG_ON	realtime	ADMIN	\N	\N	2026-03-24 13:25:14.851
cmn4vcamh0007j7uwts3aylje	\N	\N	cmn3xhvkq0000dajk4h6w2ytx	LOGIN	Admin Console	AUTH	\N	\N	2026-03-24 17:08:30.281
cmn4vmbj00009j7uwbg5ckkal	cmn3y2uck0000sfjubh0n7z5o	cmn3y2ucr0002sfju83h732a4	\N	SYNC_PUSH	1 itens	DATA	{"total": 1, "processed": 1}	\N	2026-03-24 17:16:18.012
cmn4xtndn000bj7uwmg4i1cdi	cmn3y2uck0000sfjubh0n7z5o	cmn3y2ucr0002sfju83h732a4	\N	SYNC_PUSH	1 itens	DATA	{"total": 1, "processed": 1}	\N	2026-03-24 18:17:59.194
cmn4xu0c5000dj7uwucyt38r1	cmn3y2uck0000sfjubh0n7z5o	cmn3y2ucr0002sfju83h732a4	\N	SYNC_PUSH	1 itens	DATA	{"total": 1, "processed": 1}	\N	2026-03-24 18:18:15.989
cmn4xwocl000fj7uwoyja8php	cmn3y2uck0000sfjubh0n7z5o	cmn3y2ucr0002sfju83h732a4	\N	SYNC_PUSH	1 itens	DATA	{"total": 1, "processed": 1}	\N	2026-03-24 18:20:20.421
cmn4xznm6000hj7uwoy67w1ck	cmn3y2uck0000sfjubh0n7z5o	cmn3y2ucr0002sfju83h732a4	\N	SYNC_PUSH	1 itens	DATA	{"total": 1, "processed": 1}	\N	2026-03-24 18:22:39.438
cmn4zjid6000jj7uw1ja7wk4p	cmn3y2uck0000sfjubh0n7z5o	cmn3y2ucr0002sfju83h732a4	\N	SYNC_PUSH	1 itens	DATA	{"total": 1, "processed": 1}	\N	2026-03-24 19:06:05.367
cmn512t4k000lj7uww37y24hx	cmn3y2uck0000sfjubh0n7z5o	cmn3y2ucr0002sfju83h732a4	\N	SYNC_PUSH	1 itens	DATA	{"total": 1, "processed": 1}	\N	2026-03-24 19:49:05.395
cmn512yoq000nj7uwja2lltra	cmn3y2uck0000sfjubh0n7z5o	cmn3y2ucr0002sfju83h732a4	\N	SYNC_PUSH	1 itens	DATA	{"total": 1, "processed": 1}	\N	2026-03-24 19:49:12.603
cmn51376i000pj7uwysuyqzdv	cmn3y2uck0000sfjubh0n7z5o	cmn3y2ucr0002sfju83h732a4	\N	SYNC_PUSH	1 itens	DATA	{"total": 1, "processed": 1}	\N	2026-03-24 19:49:23.61
cmn51cgof000rj7uwhdvcgzy1	cmn3y2uck0000sfjubh0n7z5o	cmn3y2ucr0002sfju83h732a4	\N	SYNC_PUSH	1 itens	DATA	{"total": 1, "processed": 1}	\N	2026-03-24 19:56:35.823
cmn53kr1d000tj7uwguuga34e	cmn3y2uck0000sfjubh0n7z5o	cmn3y2ucr0002sfju83h732a4	\N	USER_LOGIN	joao@teste.com	AUTH	\N	\N	2026-03-24 20:59:01.73
cmn5dhc6u000vj7uwveya1vf5	\N	\N	cmn3xhvkq0000dajk4h6w2ytx	LOGIN	Admin Console	AUTH	\N	\N	2026-03-25 01:36:18.677
cmn6gc1hn0001cta04ubr07vl	cmn3y2uck0000sfjubh0n7z5o	cmn3y2ucr0002sfju83h732a4	\N	USER_LOGIN	joao@teste.com	AUTH	\N	\N	2026-03-25 19:43:56.556
cmn6gd2w30003cta0mfzk0wx5	\N	\N	cmn3xhvkq0000dajk4h6w2ytx	LOGIN	Admin Console	AUTH	\N	\N	2026-03-25 19:44:45.027
cmn6gkxs0002rcta0dcgzjji6	\N	\N	cmn3xhvkq0000dajk4h6w2ytx	LOGIN	Admin Console	AUTH	\N	\N	2026-03-25 19:50:51.647
cmn6gswn5005icta0fsgul4z9	\N	\N	cmn3xhvkq0000dajk4h6w2ytx	INTEGRATION_ADD	Dropbox	ADMIN	\N	\N	2026-03-25 19:57:03.425
cmn6gynvl005lcta02lxw0nd8	\N	\N	cmn3xhvkq0000dajk4h6w2ytx	INTEGRATION_ADD	OpenAI	ADMIN	\N	\N	2026-03-25 20:01:32.002
cmn6gyqxu005octa0qr9cstds	\N	\N	cmn3xhvkq0000dajk4h6w2ytx	INTEGRATION_ADD	Office 365	ADMIN	\N	\N	2026-03-25 20:01:35.971
cmn6gys76005rcta0wvsxw975	\N	\N	cmn3xhvkq0000dajk4h6w2ytx	INTEGRATION_ADD	Office 365	ADMIN	\N	\N	2026-03-25 20:01:37.602
cmn6h61r600024l14l0eo6c5k	\N	\N	cmn3xhvkq0000dajk4h6w2ytx	INTEGRATION_ADD	Dropbox	ADMIN	\N	\N	2026-03-25 20:07:16.578
cmn6h67pd00054l14ahbxmcgo	\N	\N	cmn3xhvkq0000dajk4h6w2ytx	INTEGRATION_ADD	Dropbox	ADMIN	\N	\N	2026-03-25 20:07:24.289
cmn6hij3n0005j5dqqty570ar	cmn6hij2x0001j5dqofhbi9sd	cmn6hij3j0003j5dqqixl4ge1	\N	USER_REGISTER	alex@brspark.com	AUTH	\N	\N	2026-03-25 20:16:58.932
cmn6hjol40007j5dqt2kyabrj	cmn6hij2x0001j5dqofhbi9sd	cmn6hij3j0003j5dqqixl4ge1	\N	USER_LOGIN	alex@brspark.com	AUTH	\N	\N	2026-03-25 20:17:52.696
cmn6hno0l0009j5dq1bej2ui2	cmn6hij2x0001j5dqofhbi9sd	cmn6hij3j0003j5dqqixl4ge1	\N	SYNC_PUSH	1 itens	DATA	{"total": 1, "processed": 1}	\N	2026-03-25 20:20:58.581
cmn6hq4h7000bj5dqwm1dh5yo	cmn6hij2x0001j5dqofhbi9sd	cmn6hij3j0003j5dqqixl4ge1	\N	SYNC_PUSH	1 itens	DATA	{"total": 1, "processed": 1}	\N	2026-03-25 20:22:53.053
cmn6hxjii000dj5dqszmxy8oh	cmn6hij2x0001j5dqofhbi9sd	cmn6hij3j0003j5dqqixl4ge1	\N	USER_LOGIN	alex@brspark.com	AUTH	\N	\N	2026-03-25 20:28:39.305
cmn6i0qh3000110amx61lf8zf	cmn6hij2x0001j5dqofhbi9sd	cmn6hij3j0003j5dqqixl4ge1	\N	USER_LOGIN	alex@brspark.com	AUTH	\N	\N	2026-03-25 20:31:08.295
cmn6i30zk000410amzjlro6bw	\N	\N	cmn3xhvkq0000dajk4h6w2ytx	INTEGRATION_ADD	Dropbox	ADMIN	\N	\N	2026-03-25 20:32:55.232
cmn6i3j4b000610am8gjmkmjo	cmn6hij2x0001j5dqofhbi9sd	cmn6hij3j0003j5dqqixl4ge1	\N	USER_LOGIN	alex@brspark.com	AUTH	\N	\N	2026-03-25 20:33:18.731
cmn6ib89v000910am16xop6b1	\N	\N	cmn3xhvkq0000dajk4h6w2ytx	INTEGRATION_ADD	Dropbox	ADMIN	\N	\N	2026-03-25 20:39:17.923
cmn6ibgb4000c10amauugfoo6	\N	\N	cmn3xhvkq0000dajk4h6w2ytx	INTEGRATION_ADD	Dropbox	ADMIN	\N	\N	2026-03-25 20:39:28.336
cmn6ic136000f10amd03yh4vh	\N	\N	cmn3xhvkq0000dajk4h6w2ytx	INTEGRATION_ADD	Dropbox	ADMIN	\N	\N	2026-03-25 20:39:55.267
cmn6idb46000i10amstbusyjy	\N	\N	cmn3xhvkq0000dajk4h6w2ytx	INTEGRATION_ADD	Dropbox	ADMIN	\N	\N	2026-03-25 20:40:54.918
cmn6idivg000l10amezf3bdzu	\N	\N	cmn3xhvkq0000dajk4h6w2ytx	INTEGRATION_ADD	Dropbox	ADMIN	\N	\N	2026-03-25 20:41:04.972
cmn6idp4q000o10amzub519at	\N	\N	cmn3xhvkq0000dajk4h6w2ytx	INTEGRATION_ADD	Dropbox	ADMIN	\N	\N	2026-03-25 20:41:13.083
cmn6idqam000r10amnt2y1u6g	\N	\N	cmn3xhvkq0000dajk4h6w2ytx	INTEGRATION_ADD	Dropbox	ADMIN	\N	\N	2026-03-25 20:41:14.591
cmn6iebsk000t10am8jdne7pl	cmn6hij2x0001j5dqofhbi9sd	cmn6hij3j0003j5dqqixl4ge1	\N	USER_LOGIN	alex@brspark.com	AUTH	\N	\N	2026-03-25 20:41:42.452
cmn6j3ke3000220a7br5vyx8p	\N	\N	cmn3xhvkq0000dajk4h6w2ytx	INTEGRATION_ADD	Cloudflare R2	ADMIN	\N	\N	2026-03-25 21:01:19.996
cmn6j3u4o000520a7lts1dyo2	\N	\N	cmn3xhvkq0000dajk4h6w2ytx	INTEGRATION_ADD	Cloudflare R2	ADMIN	\N	\N	2026-03-25 21:01:32.616
cmn6j4nho000820a7wwn3nsvg	\N	\N	cmn3xhvkq0000dajk4h6w2ytx	INTEGRATION_ADD	Cloudflare R2	ADMIN	\N	\N	2026-03-25 21:02:10.668
cmn6j8oeo0001dritx06508up	\N	\N	cmn3xhvkq0000dajk4h6w2ytx	LOGIN	Admin Console	AUTH	\N	\N	2026-03-25 21:05:18.477
cmn6j958r0003drit0khx6b64	\N	\N	cmn3xhvkq0000dajk4h6w2ytx	LOGIN	Admin Console	AUTH	\N	\N	2026-03-25 21:05:40.299
cmn6jbafu0005dritwyzmnclp	cmn6hij2x0001j5dqofhbi9sd	cmn6hij3j0003j5dqqixl4ge1	\N	USER_LOGIN	alex@brspark.com	AUTH	\N	\N	2026-03-25 21:07:20.346
cmn6mfztg0007drit1d5bbmnk	cmn6hij2x0001j5dqofhbi9sd	cmn6hij3j0003j5dqqixl4ge1	\N	SYNC_PUSH	4 itens	DATA	{"total": 4, "processed": 4}	\N	2026-03-25 22:34:58.676
cmn6qhwgh00165epyndkumap9	\N	\N	cmn3xhvkq0000dajk4h6w2ytx	INTEGRATION_ADD	OpenAI	ADMIN	\N	\N	2026-03-26 00:28:26.129
cmn6sf2x1004k5epytmul3w9e	cmn6sf2we004g5epyw7uxjo73	cmn6sf2wq004i5epyd58t8qn2	\N	USER_REGISTER	luigi@lansolver.com	AUTH	\N	\N	2026-03-26 01:22:13.765
cmn6ugho2001re0hk47znqukb	cmn6sf2we004g5epyw7uxjo73	cmn6sf2wq004i5epyd58t8qn2	\N	USER_LOGIN	luigi@lansolver.com	AUTH	\N	\N	2026-03-26 02:19:18.77
cmn6um2kz0029e0hkup8lbp22	cmn6sf2we004g5epyw7uxjo73	cmn6sf2wq004i5epyd58t8qn2	\N	USER_LOGIN	luigi@lansolver.com	AUTH	\N	\N	2026-03-26 02:23:39.154
cmn6uoskv002ze0hkc9qcuay3	cmn6hij2x0001j5dqofhbi9sd	cmn6hij3j0003j5dqqixl4ge1	\N	USER_LOGIN	alex@brspark.com	AUTH	\N	\N	2026-03-26 02:25:46.16
cmn6uznso000hv9smbc51ru0z	cmn6sf2we004g5epyw7uxjo73	cmn6sf2wq004i5epyd58t8qn2	\N	USER_LOGIN	luigi@lansolver.com	AUTH	\N	\N	2026-03-26 02:34:13.176
cmn6uzxjx0017v9smfigy8flw	cmn6hij2x0001j5dqofhbi9sd	cmn6hij3j0003j5dqqixl4ge1	\N	USER_LOGIN	alex@brspark.com	AUTH	\N	\N	2026-03-26 02:34:25.821
cmn6vpljz002gv9smjw8mw2h5	cmn6sf2we004g5epyw7uxjo73	cmn6sf2wq004i5epyd58t8qn2	\N	USER_LOGIN	luigi@lansolver.com	AUTH	\N	\N	2026-03-26 02:54:23.327
cmn6vqa7k0036v9smxm04o49b	cmn6hij2x0001j5dqofhbi9sd	cmn6hij3j0003j5dqqixl4ge1	\N	SYNC_PUSH	1 itens	DATA	{"total": 1, "processed": 1}	\N	2026-03-26 02:54:55.28
cmn6vw5cv0044v9smlbwsg3tv	cmn6hij2x0001j5dqofhbi9sd	cmn6hij3j0003j5dqqixl4ge1	\N	USER_LOGIN	alex@brspark.com	AUTH	\N	\N	2026-03-26 02:59:28.927
cmn7e0jrk004mv9smi1kalf72	cmn6hij2x0001j5dqofhbi9sd	cmn6hij3j0003j5dqqixl4ge1	\N	USER_LOGIN	alex@brspark.com	AUTH	\N	\N	2026-03-26 11:26:47.312
cmn7ga5cc005ov9sm972tmvmr	cmn6hij2x0001j5dqofhbi9sd	cmn6hij3j0003j5dqqixl4ge1	\N	SYNC_PUSH	1 itens	DATA	{"total": 1, "processed": 1}	\N	2026-03-26 12:30:14.412
cmn7gai6e005uv9sms34hpew6	cmn6hij2x0001j5dqofhbi9sd	cmn6hij3j0003j5dqqixl4ge1	\N	USER_LOGIN	alex@brspark.com	AUTH	\N	\N	2026-03-26 12:30:31.046
cmn7gcg3o006av9sm9vusp0dg	cmn6hij2x0001j5dqofhbi9sd	cmn6hij3j0003j5dqqixl4ge1	\N	SYNC_PUSH	1 itens	DATA	{"total": 1, "processed": 1}	\N	2026-03-26 12:32:01.585
cmn7gcg3i0068v9smazmr9xg2	cmn6hij2x0001j5dqofhbi9sd	cmn6hij3j0003j5dqqixl4ge1	\N	SYNC_PUSH	1 itens	DATA	{"total": 1, "processed": 1}	\N	2026-03-26 12:32:01.581
cmn7geab3006pv9smz3dnom3d	cmn6sf2we004g5epyw7uxjo73	cmn6sf2wq004i5epyd58t8qn2	\N	USER_LOGIN	luigi@lansolver.com	AUTH	\N	\N	2026-03-26 12:33:27.471
cmn7ggb5o008bv9smtdl5b3ld	cmn6hij2x0001j5dqofhbi9sd	cmn6hij3j0003j5dqqixl4ge1	\N	USER_LOGIN	alex@brspark.com	AUTH	\N	\N	2026-03-26 12:35:01.884
cmn7gimju008pv9sm5xmm8dkl	cmn6hij2x0001j5dqofhbi9sd	cmn6hij3j0003j5dqqixl4ge1	\N	USER_LOGIN	alex@brspark.com	AUTH	\N	\N	2026-03-26 12:36:49.962
cmn7gky710093v9smhuo90klg	cmn6sf2we004g5epyw7uxjo73	cmn6sf2wq004i5epyd58t8qn2	\N	USER_LOGIN	luigi@lansolver.com	AUTH	\N	\N	2026-03-26 12:38:38.366
cmn7gna3400a1v9sm6x2umfi9	cmn6hij2x0001j5dqofhbi9sd	cmn6hij3j0003j5dqqixl4ge1	\N	USER_LOGIN	alex@brspark.com	AUTH	\N	\N	2026-03-26 12:40:27.089
cmn7gp6uh00afv9smdd2dilzs	cmn6sf2we004g5epyw7uxjo73	cmn6sf2wq004i5epyd58t8qn2	\N	USER_LOGIN	luigi@lansolver.com	AUTH	\N	\N	2026-03-26 12:41:56.201
cmn7gxr0800btv9smt7v5402o	cmn6sf2we004g5epyw7uxjo73	cmn6sf2wq004i5epyd58t8qn2	\N	USER_LOGIN	luigi@lansolver.com	AUTH	\N	\N	2026-03-26 12:48:35.576
cmn7h820v00dfv9sm6eja59ia	\N	\N	cmn3xhvkq0000dajk4h6w2ytx	LOGIN	Admin Console	AUTH	\N	\N	2026-03-26 12:56:36.415
cmn7h8tr200dhv9sm5i9ny2tc	\N	\N	cmn3xhvkq0000dajk4h6w2ytx	LOGIN	Admin Console	AUTH	\N	\N	2026-03-26 12:57:12.35
cmn7h9jnp00djv9sm938241s8	\N	\N	cmn3xhvkq0000dajk4h6w2ytx	LOGIN	Admin Console	AUTH	\N	\N	2026-03-26 12:57:45.925
cmn7hjryi00e9v9smq7sa7inn	cmn6sf2we004g5epyw7uxjo73	cmn6sf2wq004i5epyd58t8qn2	\N	USER_LOGIN	luigi@lansolver.com	AUTH	\N	\N	2026-03-26 13:05:43.243
cmn7hkfjb00f7v9smfi9lildp	cmn6sf2we004g5epyw7uxjo73	cmn6sf2wq004i5epyd58t8qn2	\N	USER_LOGIN	luigi@lansolver.com	AUTH	\N	\N	2026-03-26 13:06:13.8
cmn7hlry600fyv9smbyscq2ew	\N	\N	cmn3xhvkq0000dajk4h6w2ytx	INTEGRATION_ADD	Dropbox	ADMIN	\N	\N	2026-03-26 13:07:16.543
cmn7hmg5t00g1v9smc27cqafu	\N	\N	cmn3xhvkq0000dajk4h6w2ytx	INTEGRATION_ADD	Dropbox	ADMIN	\N	\N	2026-03-26 13:07:47.922
cmn7hmouv00g4v9smuv2jb2t3	\N	\N	cmn3xhvkq0000dajk4h6w2ytx	INTEGRATION_ADD	Dropbox	ADMIN	\N	\N	2026-03-26 13:07:59.192
cmn7hu7150002yy95096za470	\N	\N	cmn3xhvkq0000dajk4h6w2ytx	INTEGRATION_ADD	Dropbox	ADMIN	\N	\N	2026-03-26 13:13:49.338
cmn7iftf40010yy9537c1adet	cmn6sf2we004g5epyw7uxjo73	cmn6sf2wq004i5epyd58t8qn2	\N	USER_LOGIN	luigi@lansolver.com	AUTH	\N	\N	2026-03-26 13:30:38.128
cmn7izbo1002myy95b9ljodhp	cmn6sf2we004g5epyw7uxjo73	cmn6sf2wq004i5epyd58t8qn2	\N	USER_LOGIN	luigi@lansolver.com	AUTH	\N	\N	2026-03-26 13:45:48.241
cmn7j0s4t0048yy9586lbl331	cmn6sf2we004g5epyw7uxjo73	cmn6sf2wq004i5epyd58t8qn2	\N	USER_LOGIN	luigi@lansolver.com	AUTH	\N	\N	2026-03-26 13:46:56.237
cmn7j7aci005myy95ivokbdkw	cmn6sf2we004g5epyw7uxjo73	cmn6sf2wq004i5epyd58t8qn2	\N	USER_LOGIN	luigi@lansolver.com	AUTH	\N	\N	2026-03-26 13:51:59.779
cmn7jb3ao007gyy95g04fpy01	cmn6sf2we004g5epyw7uxjo73	cmn6sf2wq004i5epyd58t8qn2	\N	USER_LOGIN	luigi@lansolver.com	AUTH	\N	\N	2026-03-26 13:54:57.265
cmn7jc9jc008myy9542y4w5lt	cmn6sf2we004g5epyw7uxjo73	cmn6sf2wq004i5epyd58t8qn2	\N	USER_LOGIN	luigi@lansolver.com	AUTH	\N	\N	2026-03-26 13:55:52.008
cmn7jiyin00awyy95h4e5o1dy	cmn6sf2we004g5epyw7uxjo73	cmn6sf2wq004i5epyd58t8qn2	\N	SYNC_PUSH	ASSET	DATA	{"message": "Sincronizados 1 itens da fila offline."}	\N	2026-03-26 14:01:04.319
cmn7jk69s00b6yy95q80dzlia	cmn6sf2we004g5epyw7uxjo73	cmn6sf2wq004i5epyd58t8qn2	\N	SYNC_PUSH	ASSET	DATA	{"message": "Sincronizados 1 itens da fila offline."}	\N	2026-03-26 14:02:01.025
cmn7jk6cr00b8yy95cgg2rnzq	cmn6sf2we004g5epyw7uxjo73	cmn6sf2wq004i5epyd58t8qn2	\N	SYNC_PUSH	ASSET	DATA	{"message": "Sincronizados 1 itens da fila offline."}	\N	2026-03-26 14:02:01.131
cmn7jkh4900biyy95u227v6xl	cmn6sf2we004g5epyw7uxjo73	cmn6sf2wq004i5epyd58t8qn2	\N	SYNC_PUSH	ASSET	DATA	{"message": "Sincronizados 1 itens da fila offline."}	\N	2026-03-26 14:02:15.082
cmn7jop1q00015d5oi6eja91h	cmn6sf2we004g5epyw7uxjo73	cmn6sf2wq004i5epyd58t8qn2	\N	SYNC_PUSH	ASSET	DATA	{"message": "Sincronizados 1 itens da fila offline."}	\N	2026-03-26 14:05:31.982
cmn7jop2z00035d5ob1byyk8t	cmn6sf2we004g5epyw7uxjo73	cmn6sf2wq004i5epyd58t8qn2	\N	SYNC_PUSH	ASSET	DATA	{"message": "Sincronizados 1 itens da fila offline."}	\N	2026-03-26 14:05:32.028
cmn7jp5bo000t5d5oydqbfa2z	cmn6sf2we004g5epyw7uxjo73	cmn6sf2wq004i5epyd58t8qn2	\N	USER_LOGIN	luigi@lansolver.com	AUTH	\N	\N	2026-03-26 14:05:53.077
cmn7rptj2000h4ozlhir3sqbv	cmn6sf2we004g5epyw7uxjo73	cmn6sf2wq004i5epyd58t8qn2	\N	SYNC_PUSH	ASSET	DATA	{"message": "Sincronizados 1 itens da fila offline."}	\N	2026-03-26 17:50:21.374
cmn7rqen4000r4ozlw5erwdd5	cmn6sf2we004g5epyw7uxjo73	cmn6sf2wq004i5epyd58t8qn2	\N	USER_LOGIN	luigi@lansolver.com	AUTH	\N	\N	2026-03-26 17:50:48.737
cmn7ru7bm0001x0k1cf5386es	cmn6sf2we004g5epyw7uxjo73	cmn6sf2wq004i5epyd58t8qn2	\N	SYNC_PUSH	ASSET	DATA	{"message": "Sincronizados 1 itens da fila offline."}	\N	2026-03-26 17:53:45.874
cmn7rv0th000jx0k1hkgr4jq3	cmn6hij2x0001j5dqofhbi9sd	cmn6hij3j0003j5dqqixl4ge1	\N	USER_LOGIN	alex@brspark.com	AUTH	\N	\N	2026-03-26 17:54:24.101
cmn7t9pzn00014bmm3kz64e2t	cmn6hij2x0001j5dqofhbi9sd	cmn6hij3j0003j5dqqixl4ge1	\N	SYNC_PUSH	ASSET	DATA	{"message": "Sincronizados 1 itens da fila offline."}	\N	2026-03-26 18:33:49.523
cmn7y50fm002mhxk5i0y3oaul	cmn6sf2we004g5epyw7uxjo73	cmn6sf2wq004i5epyd58t8qn2	\N	USER_LOGIN	luigi@lansolver.com	AUTH	\N	\N	2026-03-26 20:50:07.858
cmn839wgw003lhq7b8thw4h40	cmn6hij2x0001j5dqofhbi9sd	cmn6hij3j0003j5dqqixl4ge1	\N	SYNC_PUSH	ASSET	DATA	{"message": "Sincronizados 1 itens da fila offline."}	\N	2026-03-26 23:13:54.077
cmn8a5f29000p7hesieuka4sg	cmn6hij2x0001j5dqofhbi9sd	cmn6hij3j0003j5dqqixl4ge1	\N	USER_LOGIN	alex@brspark.com	AUTH	\N	\N	2026-03-27 02:26:22.208
cmn8a94pm001b7heslyo1qce2	cmn6hij2x0001j5dqofhbi9sd	cmn6hij3j0003j5dqqixl4ge1	\N	SYNC_PUSH	ASSET	DATA	{"message": "Sincronizados 1 itens da fila offline."}	\N	2026-03-27 02:29:15.419
cmn8adcin00257hes0ew4hmjz	cmn6hij2x0001j5dqofhbi9sd	cmn6hij3j0003j5dqqixl4ge1	\N	USER_LOGIN	alex@brspark.com	AUTH	\N	\N	2026-03-27 02:32:32.159
cmn8wce4u003v7hes08sxb3m3	cmn6hij2x0001j5dqofhbi9sd	cmn6hij3j0003j5dqqixl4ge1	\N	USER_LOGIN	alex@brspark.com	AUTH	\N	\N	2026-03-27 12:47:39.149
cmn8witsc004d7hesjbvi52ac	cmn6hij2x0001j5dqofhbi9sd	cmn6hij3j0003j5dqqixl4ge1	\N	SYNC_PUSH	ASSET	DATA	{"message": "Sincronizados 3 itens da fila offline."}	\N	2026-03-27 12:52:39.371
cmn8wp9a9004j7hestd2ky7v8	cmn6hij2x0001j5dqofhbi9sd	cmn6hij3j0003j5dqqixl4ge1	\N	SYNC_PUSH	ASSET	DATA	{"message": "Sincronizados 9 itens da fila offline."}	\N	2026-03-27 12:57:39.393
cmn8wvors004p7hes3155vulz	cmn6hij2x0001j5dqofhbi9sd	cmn6hij3j0003j5dqqixl4ge1	\N	SYNC_PUSH	ASSET	DATA	{"message": "Sincronizados 1 itens da fila offline."}	\N	2026-03-27 13:02:39.399
cmn8xobix004v7hesjrlklsqc	\N	\N	cmn3xhvkq0000dajk4h6w2ytx	LOGIN	Admin Console	AUTH	\N	\N	2026-03-27 13:24:55.256
cmn8xpvst000213y40izrdrzd	\N	\N	cmn3xhvkq0000dajk4h6w2ytx	INTEGRATION_ADD	Bluesoft Cosmos	ADMIN	\N	\N	2026-03-27 13:26:08.189
cmn8xs2aa000413y4bw9l54qr	cmn6hij2x0001j5dqofhbi9sd	cmn6hij3j0003j5dqqixl4ge1	\N	SYNC_PUSH	ASSET	DATA	{"message": "Sincronizados 1 itens da fila offline."}	\N	2026-03-27 13:27:49.807
cmn8z4mwn0001w2fvqnmcc94s	\N	\N	cmn3xhvkq0000dajk4h6w2ytx	LOGIN	Admin Console	AUTH	\N	\N	2026-03-27 14:05:36.118
cmn99axhj0001lhmbbofnfjo4	cmn6hij2x0001j5dqofhbi9sd	cmn6hij3j0003j5dqqixl4ge1	\N	USER_LOGIN	alex@brspark.com	AUTH	\N	\N	2026-03-27 18:50:25.927
cmn9h32iw000zlhmbs49ebb23	cmn6hij2x0001j5dqofhbi9sd	cmn6hij3j0003j5dqqixl4ge1	\N	SYNC_PUSH	ASSET	DATA	{"message": "Sincronizados 18 itens da fila offline."}	\N	2026-03-27 22:28:16.084
\.


--
-- Data for Name: ChatContact; Type: TABLE DATA; Schema: public; Owner: alex
--

COPY public."ChatContact" (id, "requesterId", "addresseeId", status, "createdAt", "updatedAt") FROM stdin;
cmn7uspoz0010hxk5ret2qn3w	alex@brspark.com	luigi@lansolver.com	ACCEPTED	2026-03-26 19:16:35.219	2026-03-26 21:21:12.793
cmn7yir8l000k7d10ydexqhjp	luigi@lansolver.com	alex@brspark.com	ACCEPTED	2026-03-26 21:00:49.125	2026-03-26 21:21:12.806
\.


--
-- Data for Name: ChatMessage; Type: TABLE DATA; Schema: public; Owner: alex
--

COPY public."ChatMessage" (id, "roomId", "senderId", "senderName", type, content, "mediaUrl", "createdAt") FROM stdin;
cmn7z380c0008v0jj7l83mq6b	cmn7z31xm0004v0jjgs3ohtfa	alex@brspark.com	Usuário	text	Oi	\N	2026-03-26 21:16:43.98
cmn7z545e0009yc9q1e1ihlsr	cmn7z31xm0004v0jjgs3ohtfa	luigi@lansolver.com	Usuário	text	Belwza	\N	2026-03-26 21:18:12.29
cmn7z7rmy0001jwqb94zj6qi6	cmn7z31xm0004v0jjgs3ohtfa	alex@brspark.com	Usuário	text	Oi	\N	2026-03-26 21:20:16.042
cmn7za5mb0005146ysk7v57a8	cmn7z31xm0004v0jjgs3ohtfa	alex@brspark.com	Usuário	text	Oi	\N	2026-03-26 21:22:07.475
cmn7za8pd0007146ygr7w30up	cmn7z31xm0004v0jjgs3ohtfa	alex@brspark.com	Usuário	text	Tedte	\N	2026-03-26 21:22:11.474
cmn7zflpj000hacyvlvapu2h2	cmn7z31xm0004v0jjgs3ohtfa	alex@brspark.com	Usuário	text	Oi	\N	2026-03-26 21:26:21.607
cmn7zxau1000110hdw0joxm32	cmn7z31xm0004v0jjgs3ohtfa	luigi@lansolver.com	Usuário	audio	\N	file:///data/user/0/host.exp.exponent/cache/Audio/recording-51172591-836e-4192-813e-6464b54ec863.m4a	2026-03-26 21:40:07.32
cmn80ydmz000plh9d9zkyvzfh	cmn7z31xm0004v0jjgs3ohtfa	alex@brspark.com	Usuário	text	Oi	\N	2026-03-26 22:08:57.227
cmn80yk6v000rlh9d6li5uxuz	cmn7z31xm0004v0jjgs3ohtfa	alex@brspark.com	Usuário	text	Teste	\N	2026-03-26 22:09:05.72
cmn80ylni000tlh9dmrpqe5b1	cmn7z31xm0004v0jjgs3ohtfa	alex@brspark.com	Usuário	text	Teste	\N	2026-03-26 22:09:07.614
cmn81tcv80009hq7bnfdeg0e3	cmn7z31xm0004v0jjgs3ohtfa	alex@brspark.com	Usuário	text	Oi	\N	2026-03-26 22:33:02.563
cmn81term000bhq7bacwl1i55	cmn7z31xm0004v0jjgs3ohtfa	alex@brspark.com	Usuário	text	Teste	\N	2026-03-26 22:33:05.027
cmn81tfiy000dhq7bvi9npwnf	cmn7z31xm0004v0jjgs3ohtfa	alex@brspark.com	Usuário	text	Oi	\N	2026-03-26 22:33:06.011
cmn81tgzc000fhq7blkcnjd8d	cmn7z31xm0004v0jjgs3ohtfa	alex@brspark.com	Usuário	text	Oi	\N	2026-03-26 22:33:07.896
cmn81tifz000hhq7bw9mukg4y	cmn7z31xm0004v0jjgs3ohtfa	alex@brspark.com	Usuário	text	Oi	\N	2026-03-26 22:33:09.791
cmn81tj9k000jhq7bxo6x3cpe	cmn7z31xm0004v0jjgs3ohtfa	alex@brspark.com	Usuário	text	Oi	\N	2026-03-26 22:33:10.856
cmn81w9kz000thq7bvrxkfwtj	cmn7z31xm0004v0jjgs3ohtfa	alex@brspark.com	Usuário	text	Oi	\N	2026-03-26 22:35:18.276
cmn81wb9e000vhq7brq0mrjij	cmn7z31xm0004v0jjgs3ohtfa	alex@brspark.com	Usuário	text	Alou	\N	2026-03-26 22:35:20.45
cmn81wdai000xhq7bjq99mypc	cmn7z31xm0004v0jjgs3ohtfa	alex@brspark.com	Usuário	text	Ei	\N	2026-03-26 22:35:23.082
cmn82ulmb002jhq7bsfxr3c6r	cmn7z31xm0004v0jjgs3ohtfa	alex@brspark.com	Usuário	text	Oi	\N	2026-03-26 23:02:00.179
cmn86j0km0057hq7bs0ps09qc	cmn7z31xm0004v0jjgs3ohtfa	alex@brspark.com	Usuário	text	Oi	\N	2026-03-27 00:44:58.15
cmn86j27r0059hq7blqzluf7y	cmn7z31xm0004v0jjgs3ohtfa	alex@brspark.com	Usuário	text	Oi	\N	2026-03-27 00:45:00.279
cmn86j37b005bhq7b4q0k01z1	cmn7z31xm0004v0jjgs3ohtfa	alex@brspark.com	Usuário	text	Oi	\N	2026-03-27 00:45:01.559
cmn86j46n005dhq7be564ywif	cmn7z31xm0004v0jjgs3ohtfa	alex@brspark.com	Usuário	text	Oi	\N	2026-03-27 00:45:02.832
cmn86j5aw005fhq7b4q2t7cp6	cmn7z31xm0004v0jjgs3ohtfa	alex@brspark.com	Usuário	text	Oi	\N	2026-03-27 00:45:04.28
cmn86j6f5005hhq7bps3eod8t	cmn7z31xm0004v0jjgs3ohtfa	alex@brspark.com	Usuário	text	Oi	\N	2026-03-27 00:45:05.73
cmn86j7j5005jhq7bvc57n8ex	cmn7z31xm0004v0jjgs3ohtfa	alex@brspark.com	Usuário	text	Oi	\N	2026-03-27 00:45:07.168
cmn86j952005lhq7byj4o37sd	cmn7z31xm0004v0jjgs3ohtfa	alex@brspark.com	Usuário	text	Hughg	\N	2026-03-27 00:45:09.254
cmn86jvyu005vhq7bogp4lmf5	cmn7z31xm0004v0jjgs3ohtfa	alex@brspark.com	Usuário	text	Teste	\N	2026-03-27 00:45:38.838
cmn86jxjp005xhq7bmh54fen0	cmn7z31xm0004v0jjgs3ohtfa	alex@brspark.com	Usuário	text	Teste	\N	2026-03-27 00:45:40.886
cmn86jynz005zhq7bddohofyn	cmn7z31xm0004v0jjgs3ohtfa	alex@brspark.com	Usuário	text	1	\N	2026-03-27 00:45:42.335
cmn86jzm90061hq7bdas9mcpb	cmn7z31xm0004v0jjgs3ohtfa	alex@brspark.com	Usuário	text	2	\N	2026-03-27 00:45:43.569
cmn86k0nl0063hq7bnzdowl2d	cmn7z31xm0004v0jjgs3ohtfa	alex@brspark.com	Usuário	text	3	\N	2026-03-27 00:45:44.913
cmn86k1j50065hq7b5gagjf14	cmn7z31xm0004v0jjgs3ohtfa	alex@brspark.com	Usuário	text	4	\N	2026-03-27 00:45:46.049
cmn86k2cv0067hq7b0vx941m7	cmn7z31xm0004v0jjgs3ohtfa	alex@brspark.com	Usuário	text	5	\N	2026-03-27 00:45:47.119
cmn86l65q006phq7bo211w33m	cmn7z31xm0004v0jjgs3ohtfa	alex@brspark.com	Usuário	text	988	\N	2026-03-27 00:46:38.702
cmn86lhwy006rhq7beoj1wdo2	cmn7z31xm0004v0jjgs3ohtfa	luigi@lansolver.com	Usuário	text	Oiii	\N	2026-03-27 00:46:53.938
cmn86lnh7006thq7bvxazoq10	cmn7z31xm0004v0jjgs3ohtfa	alex@brspark.com	Usuário	text	Legal	\N	2026-03-27 00:47:01.148
cmn86lsbs006vhq7btgb69q5m	cmn7z31xm0004v0jjgs3ohtfa	luigi@lansolver.com	Usuário	text	Ai sim	\N	2026-03-27 00:47:07.432
cmn87hq500005lp8bqa912r1i	cmn7z31xm0004v0jjgs3ohtfa	alex@brspark.com	Usuário	text	Teste	\N	2026-03-27 01:11:57.589
\.


--
-- Data for Name: ChatRoom; Type: TABLE DATA; Schema: public; Owner: alex
--

COPY public."ChatRoom" (id, name, description, "avatarColor", "isGroup", "creatorId", "createdAt", "updatedAt") FROM stdin;
cmn7z31xm0004v0jjgs3ohtfa	\N	\N	#2563EB	f	\N	2026-03-26 21:16:36.106	2026-03-27 01:11:57.745
\.


--
-- Data for Name: ChatRoomMember; Type: TABLE DATA; Schema: public; Owner: alex
--

COPY public."ChatRoomMember" (id, "roomId", "userId", role, "joinedAt", "lastReadAt") FROM stdin;
cmn7z31xm0005v0jju6o3czeq	cmn7z31xm0004v0jjgs3ohtfa	luigi@lansolver.com	ADMIN	2026-03-26 21:16:36.106	2026-03-27 00:47:48.138
cmn7z31xm0006v0jjsb7uokdo	cmn7z31xm0004v0jjgs3ohtfa	alex@brspark.com	ADMIN	2026-03-26 21:16:36.106	2026-03-27 18:50:52.622
\.


--
-- Data for Name: ComplianceAcceptance; Type: TABLE DATA; Schema: public; Owner: alex
--

COPY public."ComplianceAcceptance" (id, "docId", "userId", "tenantId", "ipAddress", "acceptedAt") FROM stdin;
\.


--
-- Data for Name: ComplianceDoc; Type: TABLE DATA; Schema: public; Owner: alex
--

COPY public."ComplianceDoc" (id, type, version, title, content, "isActive", "publishedAt", "createdBy", "createdAt", "updatedAt") FROM stdin;
terms-v1	TERMS_OF_USE	1.0	Termos de Uso — Plataforma BrSpark	# Termos de Uso da Plataforma BrSpark\n\n**Versão 1.0 — Vigência a partir de 23 de março de 2025**\n\nBem-vindo à BrSpark. Ao criar uma conta e utilizar nossos serviços, você concorda com estes Termos de Uso.\n\n---\n\n## 1. Aceitação dos Termos\n\nO acesso e uso da plataforma BrSpark estão condicionados à aceitação e ao cumprimento destes termos.\n\n## 2. Descrição do Serviço\n\nA BrSpark é uma plataforma SaaS para gestão de patrimônio pessoal e empresarial, incluindo:\n\n- **Cadastro e rastreamento de bens**: imóveis, veículos, equipamentos e outros ativos;\n- **Gestão de estoque**: controle de entradas, saídas e inventário;\n- **Vault de documentos**: armazenamento seguro de arquivos e credenciais;\n- **Gestão de seguros**: controle de apólices e coberturas;\n- **Consultor AI**: assistente inteligente integrado à conta do usuário.\n\n## 3. Cadastro e Conta\n\n3.1. Para utilizar a plataforma, você deve criar uma conta com informações verdadeiras e atualizadas.\n\n3.2. Você é responsável pela confidencialidade de sua senha e por todas as atividades realizadas em sua conta.\n\n3.3. Notifique-nos imediatamente em caso de uso não autorizado: **suporte@brspark.com**.\n\n## 4. Uso Aceitável\n\nAo utilizar a plataforma, você concorda em **não**:\n\n- Cadastrar informações falsas ou fraudulentas;\n- Tentar acessar dados de outros usuários;\n- Realizar engenharia reversa ou extrair o código-fonte;\n- Utilizar a plataforma para fins ilegais;\n- Transmitir vírus ou código malicioso.\n\n## 5. Planos e Pagamentos\n\n5.1. A plataforma oferece planos pagos (Basic, Pro, Enterprise) e um período de avaliação gratuita.\n\n5.2. Os valores podem ser alterados mediante aviso prévio de 30 dias.\n\n5.3. Não há reembolso por períodos parciais utilizados, salvo exigido por lei.\n\n## 6. Dados e Privacidade\n\nO tratamento dos seus dados pessoais é regido pela nossa **Política de Privacidade**, em conformidade com a LGPD (Lei nº 13.709/2018) e o GDPR (EU 2016/679).\n\n## 7. Propriedade Intelectual\n\nTodo o conteúdo da plataforma BrSpark é de propriedade exclusiva da BrSpark Tecnologia Ltda. Os dados que você cadastra continuam sendo de sua propriedade.\n\n## 8. Limitação de Responsabilidade\n\nA responsabilidade total da BrSpark, em qualquer hipótese, é limitada ao valor pago nos últimos 3 meses de assinatura.\n\n## 9. Rescisão\n\n9.1. Você pode encerrar sua conta a qualquer momento nas configurações do aplicativo.\n\n9.2. Após o encerramento, seus dados são retidos por 90 dias e depois excluídos definitivamente.\n\n## 10. Legislação Aplicável\n\nEstes Termos são regidos pelas leis do Brasil. Foro: Comarca de São Paulo/SP.\n\n---\n\n📧 **Contato**: suporte@brspark.com | 🌐 https://www.brspark.com	t	2026-03-24 01:21:03.861	admin@brspark.com	2026-03-24 01:21:03.862	2026-03-24 01:21:03.862
privacy-v1	PRIVACY_POLICY	1.0	Política de Privacidade — BrSpark	# Política de Privacidade da BrSpark\n\n**Versão 1.0 — Vigência a partir de 23 de março de 2025**\n\nA BrSpark Tecnologia Ltda. tem o compromisso de proteger sua privacidade. Esta Política descreve como coletamos, usamos e protegemos seus dados pessoais, em conformidade com a **LGPD (Lei 13.709/2018)** e o **GDPR (EU 2016/679)**.\n\n## 1. Controlador dos Dados\n\n**BrSpark Tecnologia Ltda.**\nEndereço: São Paulo, SP — Brasil\nEncarregado de Dados (DPO): dpo@brspark.com\n\n## 2. Dados que Coletamos\n\n### 2.1 Dados fornecidos por você:\n- **Dados de cadastro**: nome completo, e-mail, senha (armazenada com hash bcrypt);\n- **Dados de bens**: informações sobre seus ativos cadastrados;\n- **Documentos**: arquivos armazenados no Vault.\n\n### 2.2 Dados coletados automaticamente:\n- Endereço IP e localização aproximada;\n- Tipo de dispositivo e versão do app;\n- Logs de acesso para segurança.\n\n## 3. Finalidades do Tratamento\n\n| Finalidade | Base Legal (LGPD) |\n|---|---|\n| Criação e gerenciamento de conta | Execução de contrato |\n| Prestação dos serviços | Execução de contrato |\n| Segurança e prevenção a fraudes | Interesse legítimo |\n| Conformidade LGPD/GDPR | Obrigação legal |\n| Notificações push | Consentimento |\n\n## 4. Compartilhamento de Dados\n\n**Não vendemos seus dados.** Compartilhamos apenas com provedores de infraestrutura (ex: AWS) e quando exigido por lei.\n\n## 5. Armazenamento e Segurança\n\n- Criptografia em trânsito (TLS 1.3) e em repouso (AES-256);\n- Senhas armazenadas exclusivamente sob hash bcrypt;\n- Incidentes notificados em até **72 horas** conforme exigido por lei.\n\n## 6. Retenção de Dados\n\n| Tipo | Prazo |\n|---|---|\n| Conta ativa | Enquanto durar a conta |\n| Conta encerrada | 90 dias após encerramento |\n| Logs de acesso | 12 meses |\n| Dados fiscais | 5 anos (obrigação legal) |\n\n## 7. Seus Direitos (LGPD/GDPR)\n\nVocê tem direito a: **acesso, correção, exclusão ("direito ao esquecimento"), portabilidade, oposição e revogação de consentimento**.\n\nPara exercer esses direitos: **dpo@brspark.com** ou Conta → Privacidade → Gerenciar Meus Dados.\n\n## 8. Cookies e Armazenamento Local\n\nO app móvel usa AsyncStorage (no próprio dispositivo) apenas para manter sua sessão. Não utilizamos cookies de rastreamento.\n\n## 9. Alterações\n\nNotificaremos sobre mudanças materiais com pelo menos 30 dias de antecedência.\n\n---\n\n📧 **DPO**: dpo@brspark.com | 🌐 https://www.brspark.com/privacidade	t	2026-03-24 01:21:03.864	admin@brspark.com	2026-03-24 01:21:03.865	2026-03-24 01:21:03.865
lgpd-v1	LGPD_DPA	1.0	DPA — Acordo de Processamento de Dados (LGPD)	# Acordo de Processamento de Dados (DPA)\n\n**Conforme a Lei 13.709/2018 — LGPD**\n\n## 1. Partes\n- **Controlador**: O usuário que contrata os serviços da BrSpark.\n- **Operador**: BrSpark Tecnologia Ltda.\n\n## 2. Obrigações do Operador\n- Tratar dados apenas conforme instruções documentadas;\n- Garantir confidencialidade;\n- Notificar incidentes em até 72 horas;\n- Excluir dados ao término do contrato.\n\n## 3. Vigência\nEste DPA vigora enquanto durar a relação contratual.	t	2026-03-24 01:21:03.865	admin@brspark.com	2026-03-24 01:21:03.865	2026-03-24 01:21:03.865
\.


--
-- Data for Name: FeatureFlag; Type: TABLE DATA; Schema: public; Owner: alex
--

COPY public."FeatureFlag" (id, key, label, description, icon, enabled, "tenantId", "updatedAt") FROM stdin;
cmn3xhvmh0005dajk600ltvea	stock	Módulo de Estoque	Gestão de almoxarifado e movimentações	cube-outline	t	\N	2026-03-24 01:21:03.834
cmn3xhvmk0007dajk0qsxwjtv	insurance	Módulo de Seguros	Apólices e cobertura de bens	shield-checkmark-outline	t	\N	2026-03-24 01:21:03.837
cmn3xhvml0009dajkzqaq313a	vault	Cofre (Vault)	Armazenamento de credenciais seguras	lock-closed-outline	t	\N	2026-03-24 01:21:03.837
cmn3xhvml000bdajkdo8bc9sl	ai	Consultor AI	Assistente inteligente por bem	sparkles-outline	t	\N	2026-03-24 01:21:03.838
cmn3xhvmm000ddajke75afqbk	documents	Módulo de Documentos	Upload e gestão de arquivos por bem	document-text-outline	t	\N	2026-03-24 01:21:03.839
cmn3xhvmn000fdajkayzr6bzp	reports	Relatórios Avançados	Exportação CSV e análise de custos	stats-chart-outline	f	\N	2026-03-24 01:21:03.84
cmn3xhvmo000jdajk7nhhzzdx	i18n	Multi-idioma	Suporte a EN, ES e PT-BR	globe-outline	t	\N	2026-03-24 01:21:03.841
cmn3xhvmo000hdajkdn4fpdew	realtime	Sync em Tempo Real	Sincronização cloud em tempo real	sync-outline	t	\N	2026-03-24 13:25:14.836
\.


--
-- Data for Name: Integration; Type: TABLE DATA; Schema: public; Owner: alex
--

COPY public."Integration" (id, name, type, icon, "apiKey", "baseUrl", "webhookUrl", "lastTestedAt", metadata, "createdAt", "updatedAt", description, status) FROM stdin;
cmn6gys74005pcta0yp594h7d	Office 365	EMAIL	\N	\N	\N	\N	\N	\N	2026-03-25 20:01:37.6	2026-03-25 20:01:37.6	\N	ACTIVE
cmn6qhwg000145epynb1opcoe	OpenAI	AI_LLM	\N	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	\N	\N	2026-03-26 00:28:28.361	\N	2026-03-26 00:28:26.111	2026-03-26 00:28:28.366	\N	ACTIVE
cmn7hu70u0000yy95q18ih5i6	Dropbox	STORAGE	\N	ne4t0os2lmrrlz3:ii6n3pcm3b0qux5	/BrSpark	\N	2026-03-26 13:24:24.865	\N	2026-03-26 13:13:49.326	2026-03-26 13:24:24.867	refresh_token:kSUlB_aJkzYAAAAAAAAAAQTwmnAGpNOxFElbLCav3Dvficl1vY6Vd6bXWxMu4KhU	ACTIVE
cmn8xpvrv000013y47mgdv874	Bluesoft Cosmos	ERP	\N	BO4PybchezDaegmlUyLXUA	https://api.cosmos.bluesoft.com.br	\N	2026-03-27 13:26:09.845	\N	2026-03-27 13:26:08.155	2026-03-27 13:26:09.846	\N	ACTIVE
\.


--
-- Data for Name: Invoice; Type: TABLE DATA; Schema: public; Owner: alex
--

COPY public."Invoice" (id, "subscriptionId", amount, status, "dueDate", "paidAt", "externalId", "createdAt") FROM stdin;
\.


--
-- Data for Name: LocaleProfile; Type: TABLE DATA; Schema: public; Owner: alex
--

COPY public."LocaleProfile" (id, "countryCode", name, language, currency, "currencySymbol", "dateFormat", "numberFormat", timezone, "taxIdLabel", "postalCodeLabel", "measureSystem", "isActive", "createdAt", "updatedAt") FROM stdin;
cmn3vyg7a0000124fc64ebh01	BR	Brasil	pt-BR	BRL	R$	DD/MM/YYYY	PT_STYLE	America/Sao_Paulo	CPF/CNPJ	CEP	METRIC	t	2026-03-24 00:37:57.766	2026-03-24 02:01:45.523
cmn3vyg8e0001124fmm7itdof	US	United States	en-US	USD	$	MM/DD/YYYY	US_STYLE	America/New_York	SSN/EIN	ZIP Code	IMPERIAL	t	2026-03-24 00:37:57.806	2026-03-24 02:01:45.533
cmn3vyg8g0002124f5eqzqfhe	ES	España	es-ES	EUR	€	DD/MM/YYYY	PT_STYLE	Europe/Madrid	NIF/NIE	Código Postal	METRIC	t	2026-03-24 00:37:57.808	2026-03-24 02:01:45.535
cmn3yy7nk0000pwwgzjok9ovu	AR	Argentina	es-AR	ARS	$	DD/MM/YYYY	PT_STYLE	America/Argentina/Buenos_Aires	Tax ID	Postal Code	METRIC	t	2026-03-24 02:01:45.537	2026-03-24 02:07:31.534
\.


--
-- Data for Name: Location; Type: TABLE DATA; Schema: public; Owner: alex
--

COPY public."Location" (id, "tenantId", name, type, address, floor, room, icon, latitude, longitude, "parentId", "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: Metatag; Type: TABLE DATA; Schema: public; Owner: alex
--

COPY public."Metatag" (id, type, key, "ptBr", "enUs", "esEs", icon, color, "isActive", "sortOrder", "createdAt", "updatedAt") FROM stdin;
cmn3xhvmp000kdajktso0x1w7	ASSET_TYPE	real_estate	Imóvel	Real Estate	Inmueble	home-outline	#3B82F6	t	0	2026-03-24 01:21:03.841	2026-03-24 01:21:03.841
cmn3xhvn2000ldajk1zm1snuz	ASSET_TYPE	terrestrial	Veículo	Vehicle	Vehículo	car-outline	#F97316	t	1	2026-03-24 01:21:03.855	2026-03-24 01:21:03.855
cmn3xhvn3000mdajkk5h5cyiz	ASSET_TYPE	aquatic	Embarcação	Vessel	Embarcación	boat-outline	#06B6D4	t	2	2026-03-24 01:21:03.855	2026-03-24 01:21:03.855
cmn3xhvn4000ndajkh6f6bym3	ASSET_TYPE	special	Equipamento	Equipment	Equipamiento	construct-outline	#8B5CF6	t	3	2026-03-24 01:21:03.856	2026-03-24 01:21:03.856
cmn3xhvn4000odajkphelcitk	ASSET_STATUS	operational	Operacional	Operational	Operacional	ellipse-outline	#10B981	t	4	2026-03-24 01:21:03.857	2026-03-24 01:21:03.857
cmn3xhvn5000pdajknaf0fesi	ASSET_STATUS	maintenance	Em Manutenção	In Maintenance	En Mantenimiento	ellipse-outline	#F59E0B	t	5	2026-03-24 01:21:03.857	2026-03-24 01:21:03.857
cmn3xhvn5000qdajkxxjkntaa	ASSET_STATUS	inactive	Inativo	Inactive	Inactivo	ellipse-outline	#EF4444	t	6	2026-03-24 01:21:03.858	2026-03-24 01:21:03.858
cmn3xhvn6000rdajkhr96du6q	SERVICE_CATEGORY	eletrica	Elétrica	Electrical	Eléctrica	flash-outline	#F59E0B	t	7	2026-03-24 01:21:03.858	2026-03-24 01:21:03.858
cmn3xhvn6000sdajkqnucvvgy	SERVICE_CATEGORY	hidraulica	Hidráulica	Hydraulic	Hidráulica	water-outline	#3B82F6	t	8	2026-03-24 01:21:03.858	2026-03-24 01:21:03.858
cmn3xhvn6000tdajk5s3glzz2	SERVICE_CATEGORY	limpeza	Limpeza	Cleaning	Limpieza	sparkles-outline	#10B981	t	9	2026-03-24 01:21:03.859	2026-03-24 01:21:03.859
cmn3xhvn7000udajkt2nv0i0t	SERVICE_CATEGORY	reformas	Reformas	Renovation	Reformas	hammer-outline	#8B5CF6	t	10	2026-03-24 01:21:03.859	2026-03-24 01:21:03.859
cmn3xhvn7000vdajkxwenf0em	SERVICE_CATEGORY	jardinagem	Jardinagem	Gardening	Jardinería	leaf-outline	#22C55E	t	11	2026-03-24 01:21:03.86	2026-03-24 01:21:03.86
cmn3xhvn7000wdajkmop7jlfy	SERVICE_CATEGORY	seguranca	Segurança	Security	Seguridad	shield-checkmark-outline	#EF4444	t	12	2026-03-24 01:21:03.86	2026-03-24 01:21:03.86
cmn3xhvn8000xdajk9hbr40ki	SERVICE_CATEGORY	tecnologia	Tecnologia	Technology	Tecnología	laptop-outline	#6366F1	t	13	2026-03-24 01:21:03.86	2026-03-24 01:21:03.86
cmn3xhvn8000ydajkg02kmobm	SERVICE_CATEGORY	mudanca	Mudança	Moving	Mudanza	cube-outline	#EC4899	t	14	2026-03-24 01:21:03.861	2026-03-24 01:21:03.861
cmn4wbq6u0000wmuzn5m7rsda	STOCK_CATEGORY	pecas_reposicao	Peças de Reposição	Spare Parts	Repuestos	build-outline	#F97316	t	1	2026-03-24 17:36:03.414	2026-03-24 17:36:03.414
cmn4wbq6u0001wmuzgxzpslan	STOCK_CATEGORY	consumiveis	Consumíveis	Consumables	Consumibles	flash-outline	#EAB308	t	2	2026-03-24 17:36:03.414	2026-03-24 17:36:03.414
cmn4wbq6u0002wmuz3g4tzy6n	STOCK_CATEGORY	epi	EPIs	PPE	EPP	shield-outline	#10B981	t	3	2026-03-24 17:36:03.414	2026-03-24 17:36:03.414
cmn4wbq6u0003wmuz3tkylhaa	STOCK_CATEGORY	ferramentas	Ferramentas	Tools	Herramientas	hammer-outline	#6366F1	t	4	2026-03-24 17:36:03.414	2026-03-24 17:36:03.414
cmn4wbq6u0004wmuzf6yuwir3	STOCK_CATEGORY	materiais_limpeza	Mat. de Limpeza	Cleaning Supplies	Mat. de Limpieza	water-outline	#3B82F6	t	5	2026-03-24 17:36:03.414	2026-03-24 17:36:03.414
cmn4wbq6u0005wmuzkr6g2l1l	STOCK_CATEGORY	escritorio	Material de Escritório	Office Supplies	Mat. de Oficina	document-outline	#8B5CF6	t	6	2026-03-24 17:36:03.414	2026-03-24 17:36:03.414
cmn4wbq6u0006wmuzpq4jfbrp	STOCK_CATEGORY	combustivel	Combustível	Fuel	Combustible	flame-outline	#EF4444	t	7	2026-03-24 17:36:03.414	2026-03-24 17:36:03.414
cmn4wbq6u0007wmuz63apzd1s	STOCK_CATEGORY	outros_estoque	Outros	Other	Otros	cube-outline	#64748B	t	99	2026-03-24 17:36:03.414	2026-03-24 17:36:03.414
cmn4wbq6u0008wmuzldu9zn55	EXPENSE_CATEGORY	manutencao	Manutenção	Maintenance	Mantenimiento	construct-outline	#F97316	t	1	2026-03-24 17:36:03.414	2026-03-24 17:36:03.414
cmn4wbq6u0009wmuz0rgnfkhh	EXPENSE_CATEGORY	seguro	Seguro	Insurance	Seguro	shield-checkmark-outline	#10B981	t	2	2026-03-24 17:36:03.414	2026-03-24 17:36:03.414
cmn4wbq6u000awmuz4a08mde0	EXPENSE_CATEGORY	iptu	IPTU / Impostos	Property Tax	Impuesto Predial	receipt-outline	#EF4444	t	3	2026-03-24 17:36:03.414	2026-03-24 17:36:03.414
cmn4wbq6u000bwmuzx3sre93f	EXPENSE_CATEGORY	condominio	Condomínio	Condo Fee	Condominio	business-outline	#3B82F6	t	4	2026-03-24 17:36:03.414	2026-03-24 17:36:03.414
cmn4wbq6u000cwmuze3lzqs8d	EXPENSE_CATEGORY	combustivel_exp	Combustível	Fuel	Combustible	flame-outline	#EAB308	t	5	2026-03-24 17:36:03.414	2026-03-24 17:36:03.414
cmn4wbq6u000dwmuzqbkbk6d0	EXPENSE_CATEGORY	reforma	Reforma / Obra	Renovation	Renovación	hammer-outline	#8B5CF6	t	6	2026-03-24 17:36:03.414	2026-03-24 17:36:03.414
cmn4wbq6u000ewmuz08sy3s5s	EXPENSE_CATEGORY	conta_agua	Água / Luz / Gás	Utilities	Servicios	water-outline	#06B6D4	t	7	2026-03-24 17:36:03.414	2026-03-24 17:36:03.414
cmn4wbq6v000fwmuzlgas7obj	EXPENSE_CATEGORY	outros_exp	Outros	Other	Otros	ellipsis-horizontal-outline	#64748B	t	99	2026-03-24 17:36:03.414	2026-03-24 17:36:03.414
cmn4wbq6v000gwmuzlbsahiki	REVENUE_CATEGORY	aluguel	Aluguel	Rent	Alquiler	home-outline	#10B981	t	1	2026-03-24 17:36:03.414	2026-03-24 17:36:03.414
cmn4wbq6v000hwmuze3crnkeq	REVENUE_CATEGORY	venda	Venda	Sale	Venta	cash-outline	#3B82F6	t	2	2026-03-24 17:36:03.414	2026-03-24 17:36:03.414
cmn4wbq6v000iwmuz0tc6wke3	REVENUE_CATEGORY	dividendos	Dividendos	Dividends	Dividendos	trending-up-outline	#6366F1	t	3	2026-03-24 17:36:03.414	2026-03-24 17:36:03.414
cmn4wbq6v000jwmuzmpq3nypm	REVENUE_CATEGORY	servico_prestado	Serviço Prestado	Service Revenue	Ingreso de Servicio	briefcase-outline	#F97316	t	4	2026-03-24 17:36:03.414	2026-03-24 17:36:03.414
cmn4wbq6v000kwmuz3rwo9bf6	REVENUE_CATEGORY	outros_rev	Outros	Other	Otros	ellipsis-horizontal-outline	#64748B	t	99	2026-03-24 17:36:03.414	2026-03-24 17:36:03.414
cmn6nq8bb0000sn7dxgvqfa65	MEDIA_CATEGORY	foto	Foto	Foto	Foto	camera-outline	#3B82F6	t	0	2026-03-25 23:10:55.895	2026-03-25 23:10:55.895
cmn6nq8ht0001sn7drkm65utm	MEDIA_CATEGORY	video	Vídeo	Vídeo	Vídeo	videocam-outline	#8B5CF6	t	1	2026-03-25 23:10:56.13	2026-03-25 23:10:56.13
cmn6nq8hw0002sn7d7xljotci	MEDIA_CATEGORY	documento	Documento	Documento	Documento	document-text-outline	#F59E0B	t	2	2026-03-25 23:10:56.132	2026-03-25 23:10:56.132
cmn6nq8i10003sn7dd7nsscxc	MEDIA_CATEGORY	planta_baixa	Planta Baixa	Planta Baixa	Planta Baixa	map-outline	#10B981	t	3	2026-03-25 23:10:56.137	2026-03-25 23:10:56.137
cmn6nq8i40004sn7dg6i5sf16	MEDIA_CATEGORY	nota_fiscal	Nota Fiscal	Nota Fiscal	Nota Fiscal	receipt-outline	#EF4444	t	4	2026-03-25 23:10:56.14	2026-03-25 23:10:56.14
cmn6nq8i60005sn7d3nl9yked	MEDIA_CATEGORY	contrato	Contrato	Contrato	Contrato	reader-outline	#6366F1	t	5	2026-03-25 23:10:56.142	2026-03-25 23:10:56.142
cmn6nq8i80006sn7dhgnkg73m	MEDIA_CATEGORY	laudo	Laudo / Relatório	Laudo / Relatório	Laudo / Relatório	clipboard-outline	#F97316	t	6	2026-03-25 23:10:56.144	2026-03-25 23:10:56.144
cmn6nq8lb0009sn7dwx3ruevw	MEDIA_CATEGORY	outro	Outro	Outro	Outro	ellipsis-horizontal-outline	#9CA3AF	t	9	2026-03-25 23:10:56.256	2026-03-25 23:10:56.256
\.


--
-- Data for Name: NotificationLog; Type: TABLE DATA; Schema: public; Owner: alex
--

COPY public."NotificationLog" (id, "templateId", recipient, channel, status, "sentAt", metadata) FROM stdin;
\.


--
-- Data for Name: NotificationTemplate; Type: TABLE DATA; Schema: public; Owner: alex
--

COPY public."NotificationTemplate" (id, key, label, channel, subject, body, variables, "isActive", "createdAt", "updatedAt") FROM stdin;
cmn3xhvne000zdajkrzl6l62p	welcome	Boas-vindas	EMAIL	Bem-vindo à BrSpark, {{name}}!	Olá {{name}},\n\nSeu acesso foi criado com sucesso.\n\nE-mail: {{email}}\nSenha temporária: {{password}}\n\nAcesse: {{loginUrl}}	{"name": "string", "email": "string", "loginUrl": "string", "password": "string"}	t	2026-03-24 01:21:03.867	2026-03-24 01:21:03.867
cmn3xhvni0010dajkkui4tyhq	stock_low	Estoque Crítico	PUSH	\N	⚠️ {{itemName}} atingiu nível crítico no {{assetName}} ({{currentStock}} {{unit}} restantes)	{"unit": "string", "itemName": "string", "assetName": "string", "currentStock": "string"}	t	2026-03-24 01:21:03.87	2026-03-24 01:21:03.87
cmn3xhvni0011dajkttz8ouzl	policy_expiring	Apólice Vencendo	EMAIL	Apólice vencendo em {{days}} dias	Sua apólice {{policyName}} vence em {{dueDate}}.	{"dueDate": "string", "policyName": "string"}	t	2026-03-24 01:21:03.871	2026-03-24 01:21:03.871
cmn3xhvnj0012dajkxchvr72i	trial_ending	Trial Encerrando	EMAIL	Seu período trial encerra em {{days}} dias	Olá {{tenantName}},\n\nSeu trial encerra em {{days}} dias. Escolha um plano para continuar usando.	{"days": "string", "tenantName": "string"}	t	2026-03-24 01:21:03.872	2026-03-24 01:21:03.872
\.


--
-- Data for Name: Plan; Type: TABLE DATA; Schema: public; Owner: alex
--

COPY public."Plan" (id, name, "priceMonthly", "priceYearly", "maxAssets", "maxUsers", "storageGb", features, "isActive", "createdAt", "updatedAt") FROM stdin;
cmn3xhvm00001dajksgpasg5e	Pro	399.00	3990.00	500	20	50	{"ai": true, "stock": true, "vault": true, "documents": true, "insurance": true}	t	2026-03-24 01:21:03.817	2026-03-24 01:21:03.817
cmn3xhvmb0003dajk7rnd1j9t	Enterprise	2400.00	24000.00	-1	-1	500	{"ai": true, "stock": true, "vault": true, "reports": true, "realtime": true, "documents": true, "insurance": true}	t	2026-03-24 01:21:03.817	2026-03-24 01:21:03.817
cmn3xhvma0002dajkn01kcgec	Basic	99.00	990.00	50	5	5	{"ai": false, "stock": true, "vault": false, "documents": true, "insurance": false}	t	2026-03-24 01:21:03.817	2026-03-24 01:21:03.817
\.


--
-- Data for Name: PushToken; Type: TABLE DATA; Schema: public; Owner: alex
--

COPY public."PushToken" (id, "userId", token, device, "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: ServiceProvider; Type: TABLE DATA; Schema: public; Owner: alex
--

COPY public."ServiceProvider" (id, name, category, rating, reviews, photo, tags, keywords, phone, email, city, state, verified, "isActive", "createdAt", "updatedAt") FROM stdin;
cmn3y6wju0000kqjya2y617lh	Carlos Andrade	Elétrica	4.4	278	https://randomuser.me/api/portraits/men/1.jpg	"[\\"Industrial\\",\\"Residencial\\",\\"Urgência\\"]"	eletrica instalacao quadro tomada luz iluminacao spda gerador urgencia emergencia	(11) 98847-6576	\N	Bauru	SP	t	t	2026-03-24 01:40:31.434	2026-03-24 01:40:31.434
cmn3y6wkf0001kqjyy8hz5u5d	Roberto Ferreira	Elétrica	3.9	251	https://randomuser.me/api/portraits/men/2.jpg	"[\\"Instalação\\",\\"Quadro\\",\\"SPDA\\"]"	eletrica instalacao quadro tomada luz iluminacao spda gerador urgencia emergencia	(11) 95831-1173	\N	Jundiaí	SP	t	t	2026-03-24 01:40:31.455	2026-03-24 01:40:31.455
cmn3y6wki0002kqjym95hnn9j	José Oliveira	Elétrica	4.7	43	https://randomuser.me/api/portraits/men/3.jpg	"[\\"Gerador\\",\\"Painel\\",\\"Certificado\\"]"	eletrica instalacao quadro tomada luz iluminacao spda gerador urgencia emergencia	(15) 91026-9317	\N	Jundiaí	SP	t	t	2026-03-24 01:40:31.459	2026-03-24 01:40:31.459
cmn3y6wl00003kqjyy1tfuac2	Marcos Santos	Elétrica	4.8	216	https://randomuser.me/api/portraits/men/4.jpg	"[\\"Instalação\\",\\"Quadro\\",\\"SPDA\\"]"	eletrica instalacao quadro tomada luz iluminacao spda gerador urgencia emergencia	(11) 95583-7535	\N	Bauru	SP	f	t	2026-03-24 01:40:31.476	2026-03-24 01:40:31.476
cmn3y6wl40004kqjyok7521r5	Paulo Rodrigues	Elétrica	4.6	15	https://randomuser.me/api/portraits/men/5.jpg	"[\\"Gerador\\",\\"Painel\\",\\"Certificado\\"]"	eletrica instalacao quadro tomada luz iluminacao spda gerador urgencia emergencia	(11) 97018-1468	\N	São Paulo	SP	f	t	2026-03-24 01:40:31.481	2026-03-24 01:40:31.481
cmn3y6wl50005kqjy31cars6f	Fernando Lima	Hidráulica	4	38	https://randomuser.me/api/portraits/men/6.jpg	"[\\"Fossa\\",\\"Desentupimento\\",\\"Bomba\\"]"	hidraulica encanamento cano vazamento desentupimento fossa bomba agua aquecedor	(11) 99153-9938	\N	Osasco	SP	t	t	2026-03-24 01:40:31.482	2026-03-24 01:40:31.482
cmn3y6wl60006kqjyxvfsyxfi	Antônio Araújo	Hidráulica	4.4	23	https://randomuser.me/api/portraits/men/7.jpg	"[\\"Caixa d'Água\\",\\"Encanamento\\",\\"Rápido\\"]"	hidraulica encanamento cano vazamento desentupimento fossa bomba agua aquecedor	(13) 93074-6879	\N	Santo André	SP	t	t	2026-03-24 01:40:31.483	2026-03-24 01:40:31.483
cmn3y6wl80007kqjymkparapr	Ricardo Alves	Hidráulica	4.1	130	https://randomuser.me/api/portraits/men/8.jpg	"[\\"Fossa\\",\\"Desentupimento\\",\\"Bomba\\"]"	hidraulica encanamento cano vazamento desentupimento fossa bomba agua aquecedor	(11) 91570-2463	\N	Sorocaba	SP	t	t	2026-03-24 01:40:31.484	2026-03-24 01:40:31.484
cmn3y6wl80008kqjy2ursw6zh	Eduardo Costa	Hidráulica	4.9	199	https://randomuser.me/api/portraits/men/9.jpg	"[\\"Aquecimento\\",\\"Chuveiro\\",\\"Infiltração\\"]"	hidraulica encanamento cano vazamento desentupimento fossa bomba agua aquecedor	(11) 99162-1619	\N	Osasco	SP	f	t	2026-03-24 01:40:31.485	2026-03-24 01:40:31.485
cmn3y6wlc0009kqjyspwywcdn	Renato Barbosa	Hidráulica	4.4	199	https://randomuser.me/api/portraits/men/10.jpg	"[\\"Vazamento\\",\\"Registro\\",\\"Urgência\\"]"	hidraulica encanamento cano vazamento desentupimento fossa bomba agua aquecedor	(13) 96039-8361	\N	Santo André	SP	t	t	2026-03-24 01:40:31.488	2026-03-24 01:40:31.488
cmn3y6wlc000akqjyky4d1q0k	Gustavo Carvalho	Limpeza	4.4	146	https://randomuser.me/api/portraits/men/11.jpg	"[\\"Pós Obra\\",\\"Profissional\\",\\"Rápido\\"]"	limpeza faxina residencial comercial predial condominio pos obra vidros fachada	(11) 96976-1218	\N	São Bernardo do Campo	SP	f	t	2026-03-24 01:40:31.489	2026-03-24 01:40:31.489
cmn3y6wld000bkqjyj64hut60	Leonardo Sousa	Limpeza	4.5	16	https://randomuser.me/api/portraits/men/12.jpg	"[\\"Fim de Obra\\",\\"Vidros\\",\\"Fachada\\"]"	limpeza faxina residencial comercial predial condominio pos obra vidros fachada	(11) 92432-3100	\N	Mogi das Cruzes	SP	t	t	2026-03-24 01:40:31.489	2026-03-24 01:40:31.489
cmn3y6wld000ckqjyl67fjewz	Alexandre Martins	Limpeza	4.3	306	https://randomuser.me/api/portraits/men/13.jpg	"[\\"Residencial\\",\\"Periódica\\",\\"Confiável\\"]"	limpeza faxina residencial comercial predial condominio pos obra vidros fachada	(11) 97385-1952	\N	São Paulo	SP	t	t	2026-03-24 01:40:31.49	2026-03-24 01:40:31.49
cmn3y6wle000dkqjyh4rhhx47	Bruno Pereira	Limpeza	3.9	89	https://randomuser.me/api/portraits/men/14.jpg	"[\\"Fim de Obra\\",\\"Vidros\\",\\"Fachada\\"]"	limpeza faxina residencial comercial predial condominio pos obra vidros fachada	(19) 92177-3800	\N	São Paulo	SP	t	t	2026-03-24 01:40:31.49	2026-03-24 01:40:31.49
cmn3y6wmb000ekqjy6i5qxbfm	Daniel Ribeiro	Limpeza	4.2	39	https://randomuser.me/api/portraits/men/15.jpg	"[\\"Residencial\\",\\"Periódica\\",\\"Confiável\\"]"	limpeza faxina residencial comercial predial condominio pos obra vidros fachada	(11) 96888-7675	\N	Bauru	SP	t	t	2026-03-24 01:40:31.523	2026-03-24 01:40:31.523
cmn3y6wms000fkqjyp0wrojqq	Lucas Azevedo	Reformas	4.3	272	https://randomuser.me/api/portraits/men/16.jpg	"[\\"Banheiro\\",\\"Cozinha\\",\\"Design\\"]"	reforma alvenaria construcao acabamento banheiro cozinha azulejo porcelanato gesseiro	(11) 98962-5755	\N	São Bernardo do Campo	SP	t	t	2026-03-24 01:40:31.54	2026-03-24 01:40:31.54
cmn3y6wnf000gkqjyr0yh93ur	Rodrigo Monteiro	Reformas	4.2	53	https://randomuser.me/api/portraits/men/17.jpg	"[\\"Banheiro\\",\\"Cozinha\\",\\"Design\\"]"	reforma alvenaria construcao acabamento banheiro cozinha azulejo porcelanato gesseiro	(11) 99888-3309	\N	Guarulhos	SP	t	t	2026-03-24 01:40:31.563	2026-03-24 01:40:31.563
cmn3y6wnn000hkqjyq8o6hmxn	Felipe Correia	Reformas	4.2	129	https://randomuser.me/api/portraits/men/18.jpg	"[\\"Banheiro\\",\\"Cozinha\\",\\"Design\\"]"	reforma alvenaria construcao acabamento banheiro cozinha azulejo porcelanato gesseiro	(11) 95948-5591	\N	Piracicaba	SP	t	t	2026-03-24 01:40:31.572	2026-03-24 01:40:31.572
cmn3y6wnp000ikqjyvmemyx1m	Thiago Nascimento	Reformas	4.1	237	https://randomuser.me/api/portraits/men/19.jpg	"[\\"Gesseiro\\",\\"Forro de Gesso\\",\\"Acabamento\\"]"	reforma alvenaria construcao acabamento banheiro cozinha azulejo porcelanato gesseiro	(13) 98449-4313	\N	São Paulo	SP	t	t	2026-03-24 01:40:31.574	2026-03-24 01:40:31.574
cmn3y6wnq000jkqjy6zuzqpd4	Mateus Medeiros	Reformas	4.8	62	https://randomuser.me/api/portraits/men/20.jpg	"[\\"Banheiro\\",\\"Cozinha\\",\\"Design\\"]"	reforma alvenaria construcao acabamento banheiro cozinha azulejo porcelanato gesseiro	(11) 99864-9959	\N	São Paulo	SP	f	t	2026-03-24 01:40:31.574	2026-03-24 01:40:31.574
cmn3y6wnr000kkqjynzfj93p2	Aline Silveira	Jardinagem	4.5	188	https://randomuser.me/api/portraits/men/21.jpg	"[\\"Jardim\\",\\"Horta\\",\\"Orgânico\\"]"	jardinagem poda paisagismo jardim grama adubacao irrigacao arvore horta organico	(11) 96078-7267	\N	São Bernardo do Campo	SP	t	t	2026-03-24 01:40:31.575	2026-03-24 01:40:31.575
cmn3y6wnr000lkqjym5y6pm84	Fernanda Gomes	Jardinagem	4.6	9	https://randomuser.me/api/portraits/men/22.jpg	"[\\"Grama\\",\\"Adubação\\",\\"Irrigação\\"]"	jardinagem poda paisagismo jardim grama adubacao irrigacao arvore horta organico	(13) 95999-9525	\N	Santo André	SP	t	t	2026-03-24 01:40:31.576	2026-03-24 01:40:31.576
cmn3y6wns000mkqjyk7mqdn6i	Juliana Castro	Jardinagem	4.8	94	https://randomuser.me/api/portraits/men/23.jpg	"[\\"Árvores\\",\\"Poda\\",\\"Certificado\\"]"	jardinagem poda paisagismo jardim grama adubacao irrigacao arvore horta organico	(15) 96044-7193	\N	Sorocaba	SP	f	t	2026-03-24 01:40:31.576	2026-03-24 01:40:31.576
cmn3y6wns000nkqjynenjul19	Camila Moreira	Jardinagem	4	315	https://randomuser.me/api/portraits/men/24.jpg	"[\\"Árvores\\",\\"Poda\\",\\"Certificado\\"]"	jardinagem poda paisagismo jardim grama adubacao irrigacao arvore horta organico	(19) 92625-9977	\N	Ribeirão Preto	SP	f	t	2026-03-24 01:40:31.577	2026-03-24 01:40:31.577
cmn3y6wnt000okqjystc22dm5	Patricia Nunes	Jardinagem	4.8	18	https://randomuser.me/api/portraits/men/25.jpg	"[\\"Vasos\\",\\"Decoração\\",\\"Projeto\\"]"	jardinagem poda paisagismo jardim grama adubacao irrigacao arvore horta organico	(11) 93565-8088	\N	São Paulo	SP	t	t	2026-03-24 01:40:31.577	2026-03-24 01:40:31.577
cmn3y6wnt000pkqjyl80prkm7	Sandra Rocha	Segurança	4.7	268	https://randomuser.me/api/portraits/men/26.jpg	"[\\"Câmeras\\",\\"CFTV\\",\\"24h\\"]"	seguranca cameras alarme monitoramento cftv cerca eletrica portao residencial	(11) 98240-9940	\N	Jundiaí	SP	t	t	2026-03-24 01:40:31.578	2026-03-24 01:40:31.578
cmn3y6wnu000qkqjyzqbu9rdp	Luciana Pinto	Segurança	4.5	281	https://randomuser.me/api/portraits/men/27.jpg	"[\\"Alarme\\",\\"Monitoramento\\",\\"Residencial\\"]"	seguranca cameras alarme monitoramento cftv cerca eletrica portao residencial	(13) 95735-7329	\N	Santo André	SP	t	t	2026-03-24 01:40:31.578	2026-03-24 01:40:31.578
cmn3y6wnu000rkqjyeitzv73r	Claudia Mendes	Segurança	5	107	https://randomuser.me/api/portraits/men/28.jpg	"[\\"Câmeras\\",\\"CFTV\\",\\"24h\\"]"	seguranca cameras alarme monitoramento cftv cerca eletrica portao residencial	(11) 99719-6235	\N	São Bernardo do Campo	SP	t	t	2026-03-24 01:40:31.579	2026-03-24 01:40:31.579
cmn3y6wnv000skqjy22fn14bf	Beatriz Ramos	Climatização	5	98	https://randomuser.me/api/portraits/men/29.jpg	"[\\"Ar Condicionado\\",\\"Instalação\\",\\"Manutenção\\"]"	ar condicionado split inverter climatizacao limpeza instalacao manutencao central	(11) 96229-3435	\N	Jundiaí	SP	t	t	2026-03-24 01:40:31.579	2026-03-24 01:40:31.579
cmn3y6wnv000tkqjym9up3eow	Gabriela Cardoso	Climatização	4	199	https://randomuser.me/api/portraits/men/30.jpg	"[\\"Central\\",\\"Comercial\\",\\"Certificado\\"]"	ar condicionado split inverter climatizacao limpeza instalacao manutencao central	(11) 96236-4258	\N	São Paulo	SP	t	t	2026-03-24 01:40:31.579	2026-03-24 01:40:31.579
cmn3y6wnv000ukqjy4lb4boky	Eletro Rápido SP	Climatização	4.9	305	https://randomuser.me/api/portraits/men/31.jpg	"[\\"Central\\",\\"Comercial\\",\\"Certificado\\"]"	ar condicionado split inverter climatizacao limpeza instalacao manutencao central	(11) 94048-9163	\N	São Bernardo do Campo	SP	t	t	2026-03-24 01:40:31.58	2026-03-24 01:40:31.58
cmn3y6wnw000vkqjywzotpa8a	Hidro Fix Encanamentos	Tecnologia	4.5	276	https://randomuser.me/api/portraits/men/32.jpg	"[\\"Redes\\",\\"Wi-Fi\\",\\"Cabeamento\\"]"	tecnologia rede wifi cabeamento computador notebook formatacao servidor cftv backup	(11) 94048-3176	\N	São Bernardo do Campo	SP	t	t	2026-03-24 01:40:31.58	2026-03-24 01:40:31.58
cmn3y6wnx000wkqjylr58raxg	Spick & Span Limpeza	Tecnologia	4.1	148	https://randomuser.me/api/portraits/men/33.jpg	"[\\"Computadores\\",\\"Formatação\\",\\"Suporte\\"]"	tecnologia rede wifi cabeamento computador notebook formatacao servidor cftv backup	(15) 95883-8077	\N	Jundiaí	SP	t	t	2026-03-24 01:40:31.581	2026-03-24 01:40:31.581
cmn3y6wnx000xkqjyzoa4jou5	ReformaMax SP	Tecnologia	4.7	177	https://randomuser.me/api/portraits/men/34.jpg	"[\\"CFTV\\",\\"Servidor\\",\\"Backup\\"]"	tecnologia rede wifi cabeamento computador notebook formatacao servidor cftv backup	(11) 97227-1046	\N	Santos	SP	t	t	2026-03-24 01:40:31.582	2026-03-24 01:40:31.582
cmn3y6wny000ykqjya510sact	Verde Jardins	Dedetização	4.4	257	https://randomuser.me/api/portraits/men/35.jpg	"[\\"Formigas\\",\\"Mosquitos\\",\\"Certificado\\"]"	dedetizacao cupim rato barata formiga mosquito certificado controle pragas	(19) 98943-6406	\N	Campinas	SP	f	t	2026-03-24 01:40:31.582	2026-03-24 01:40:31.582
cmn3y6wny000zkqjy0dodh9si	SecureHome SP	Dedetização	4.6	298	https://randomuser.me/api/portraits/men/36.jpg	"[\\"Cupim\\",\\"Baratas\\",\\"Ratos\\"]"	dedetizacao cupim rato barata formiga mosquito certificado controle pragas	(11) 91500-4874	\N	Mogi das Cruzes	SP	t	t	2026-03-24 01:40:31.583	2026-03-24 01:40:31.583
cmn3y6wnz0010kqjymaielmkm	ClimaTech SP	Mudança	4	144	https://randomuser.me/api/portraits/men/37.jpg	"[\\"Guarda Móveis\\",\\"Seguro\\",\\"Rápido\\"]"	mudanca transporte caminhao embalar desmontar guarda moveis comercial residencial	(11) 97275-6584	\N	Ribeirão Preto	SP	t	t	2026-03-24 01:40:31.583	2026-03-24 01:40:31.583
cmn3y6wo00011kqjy05arqocg	TechSupport Brasil	Mudança	4.7	220	https://randomuser.me/api/portraits/men/38.jpg	"[\\"Comercial\\",\\"Piano\\",\\"Desmontagem\\"]"	mudanca transporte caminhao embalar desmontar guarda moveis comercial residencial	(11) 93718-5028	\N	Mogi das Cruzes	SP	t	t	2026-03-24 01:40:31.585	2026-03-24 01:40:31.585
cmn3y6wo10012kqjy3j4mtjn8	Dedetizadora Alpha SP	Mudança	4.1	240	https://randomuser.me/api/portraits/men/39.jpg	"[\\"Residencial\\",\\"Caminhão\\",\\"Embalagem\\"]"	mudanca transporte caminhao embalar desmontar guarda moveis comercial residencial	(15) 97451-1527	\N	Bauru	SP	t	t	2026-03-24 01:40:31.586	2026-03-24 01:40:31.586
cmn3y6wo10013kqjy7lfy85co	Mudança Fácil SP	Gás	4.5	225	https://randomuser.me/api/portraits/men/40.jpg	"[\\"Botijão\\",\\"Encanamento\\",\\"Urgência\\"]"	gas gasoducto instalacao vazamento botijao encanamento regulagem urgencia	(11) 97775-3652	\N	São Bernardo do Campo	SP	t	t	2026-03-24 01:40:31.586	2026-03-24 01:40:31.586
cmn3y6wo20014kqjyyu14e6gz	Gastech Instalações	Gás	4	275	https://randomuser.me/api/portraits/men/41.jpg	"[\\"Instalação\\",\\"Vazamento\\",\\"Regulagem\\"]"	gas gasoducto instalacao vazamento botijao encanamento regulagem urgencia	(11) 97048-6670	\N	Santos	SP	t	t	2026-03-24 01:40:31.587	2026-03-24 01:40:31.587
cmn3y6wo30015kqjyuf0l83qi	Pintor Pro SP	Pintura	4.7	143	https://randomuser.me/api/portraits/men/42.jpg	"[\\"Fachada\\",\\"Predial\\",\\"CertificadoMaestria\\"]"	pintura tinta parede textura interna externa fachada predial epóxi piso	(15) 96683-9420	\N	Campinas	SP	t	t	2026-03-24 01:40:31.588	2026-03-24 01:40:31.588
cmn3y6wo30016kqjy3pkiketm	Elétrica 24h Santos	Pintura	3.8	260	https://randomuser.me/api/portraits/men/43.jpg	"[\\"Epóxi\\",\\"Piso\\",\\"Especializado\\"]"	pintura tinta parede textura interna externa fachada predial epóxi piso	(13) 96407-4145	\N	Piracicaba	SP	t	t	2026-03-24 01:40:31.588	2026-03-24 01:40:31.588
cmn3y6wo40017kqjy34yrrpdz	AquaPro Hidráulica	Pintura	4.1	138	https://randomuser.me/api/portraits/men/44.jpg	"[\\"Epóxi\\",\\"Piso\\",\\"Especializado\\"]"	pintura tinta parede textura interna externa fachada predial epóxi piso	(11) 98014-9411	\N	São Paulo	SP	t	t	2026-03-24 01:40:31.588	2026-03-24 01:40:31.588
cmn3y6wo40018kqjy1i245p9o	CleanSpace SP	Elétrica	4.1	154	https://randomuser.me/api/portraits/men/45.jpg	"[\\"Gerador\\",\\"Painel\\",\\"Certificado\\"]"	eletrica instalacao quadro tomada luz iluminacao spda gerador urgencia emergencia	(11) 96591-4748	\N	Santo André	SP	f	t	2026-03-24 01:40:31.589	2026-03-24 01:40:31.589
cmn3y6wo60019kqjy2m5ewfh6	Miguel Torres	Elétrica	4.2	20	https://randomuser.me/api/portraits/men/46.jpg	"[\\"Tomadas\\",\\"Iluminação\\",\\"Rápido\\"]"	eletrica instalacao quadro tomada luz iluminacao spda gerador urgencia emergencia	(11) 91704-6613	\N	Ribeirão Preto	SP	f	t	2026-03-24 01:40:31.591	2026-03-24 01:40:31.591
cmn3y6wo9001akqjya9f8y2c4	Henrique Campos	Elétrica	4.3	81	https://randomuser.me/api/portraits/men/47.jpg	"[\\"Tomadas\\",\\"Iluminação\\",\\"Rápido\\"]"	eletrica instalacao quadro tomada luz iluminacao spda gerador urgencia emergencia	(13) 99790-9130	\N	São Paulo	SP	t	t	2026-03-24 01:40:31.593	2026-03-24 01:40:31.593
cmn3y6won001bkqjyri19e4xu	Gabriel Vieira	Elétrica	4.4	48	https://randomuser.me/api/portraits/men/48.jpg	"[\\"Instalação\\",\\"Quadro\\",\\"SPDA\\"]"	eletrica instalacao quadro tomada luz iluminacao spda gerador urgencia emergencia	(15) 98439-9230	\N	Mogi das Cruzes	SP	t	t	2026-03-24 01:40:31.607	2026-03-24 01:40:31.607
cmn3y6wpm001ckqjyjdx3j2uk	Vinicius Santana	Elétrica	3.8	36	https://randomuser.me/api/portraits/men/49.jpg	"[\\"24h\\",\\"Emergência\\",\\"Confiável\\"]"	eletrica instalacao quadro tomada luz iluminacao spda gerador urgencia emergencia	(13) 96688-2620	\N	Sorocaba	SP	f	t	2026-03-24 01:40:31.643	2026-03-24 01:40:31.643
cmn3y6wpz001dkqjy7j6jx65n	Diego Teixeira	Hidráulica	4	72	https://randomuser.me/api/portraits/men/50.jpg	"[\\"Fossa\\",\\"Desentupimento\\",\\"Bomba\\"]"	hidraulica encanamento cano vazamento desentupimento fossa bomba agua aquecedor	(11) 97300-5574	\N	São Paulo	SP	t	t	2026-03-24 01:40:31.655	2026-03-24 01:40:31.655
cmn3y6wpz001ekqjy5mvms1lx	Andréia Lopes	Hidráulica	3.9	236	https://randomuser.me/api/portraits/women/1.jpg	"[\\"Aquecimento\\",\\"Chuveiro\\",\\"Infiltração\\"]"	hidraulica encanamento cano vazamento desentupimento fossa bomba agua aquecedor	(15) 99168-2887	\N	Osasco	SP	f	t	2026-03-24 01:40:31.656	2026-03-24 01:40:31.656
cmn3y6wq0001fkqjyp1budjnv	Mariana Freitas	Hidráulica	4.5	284	https://randomuser.me/api/portraits/women/2.jpg	"[\\"Fossa\\",\\"Desentupimento\\",\\"Bomba\\"]"	hidraulica encanamento cano vazamento desentupimento fossa bomba agua aquecedor	(11) 98570-8732	\N	Mogi das Cruzes	SP	t	t	2026-03-24 01:40:31.657	2026-03-24 01:40:31.657
cmn3y6wq1001gkqjyhqswtn58	Rafaela Macedo	Hidráulica	4.9	317	https://randomuser.me/api/portraits/women/3.jpg	"[\\"Fossa\\",\\"Desentupimento\\",\\"Bomba\\"]"	hidraulica encanamento cano vazamento desentupimento fossa bomba agua aquecedor	(11) 94586-3949	\N	Guarulhos	SP	t	t	2026-03-24 01:40:31.657	2026-03-24 01:40:31.657
cmn3y6wq1001hkqjybvg2unzj	Tatiane Borges	Hidráulica	4.9	67	https://randomuser.me/api/portraits/women/4.jpg	"[\\"Caixa d'Água\\",\\"Encanamento\\",\\"Rápido\\"]"	hidraulica encanamento cano vazamento desentupimento fossa bomba agua aquecedor	(13) 92687-3949	\N	Ribeirão Preto	SP	t	t	2026-03-24 01:40:31.658	2026-03-24 01:40:31.658
cmn3y6wq2001ikqjyc3jhofdo	Priscila Cunha	Limpeza	4.3	277	https://randomuser.me/api/portraits/women/5.jpg	"[\\"Condomínio\\",\\"Predial\\",\\"Empresa\\"]"	limpeza faxina residencial comercial predial condominio pos obra vidros fachada	(13) 94117-9011	\N	Piracicaba	SP	t	t	2026-03-24 01:40:31.659	2026-03-24 01:40:31.659
cmn3y6wq2001jkqjyhps44e07	MultiServ Elétrica	Limpeza	3.9	171	https://randomuser.me/api/portraits/women/6.jpg	"[\\"Pós Obra\\",\\"Profissional\\",\\"Rápido\\"]"	limpeza faxina residencial comercial predial condominio pos obra vidros fachada	(13) 98047-7129	\N	Campinas	SP	t	t	2026-03-24 01:40:31.659	2026-03-24 01:40:31.659
cmn3y6wq3001kkqjyu1sv49bc	HidroMestre	Limpeza	3.9	274	https://randomuser.me/api/portraits/women/7.jpg	"[\\"Residencial\\",\\"Periódica\\",\\"Confiável\\"]"	limpeza faxina residencial comercial predial condominio pos obra vidros fachada	(11) 93811-9490	\N	São Paulo	SP	t	t	2026-03-24 01:40:31.659	2026-03-24 01:40:31.659
cmn3y6wq3001lkqjya4khd2cm	LimpaMax	Limpeza	4.7	33	https://randomuser.me/api/portraits/women/8.jpg	"[\\"Residencial\\",\\"Periódica\\",\\"Confiável\\"]"	limpeza faxina residencial comercial predial condominio pos obra vidros fachada	(13) 93178-4921	\N	São Paulo	SP	t	t	2026-03-24 01:40:31.66	2026-03-24 01:40:31.66
cmn3y6wq4001mkqjy0b0qdbke	ConstruFácil	Limpeza	4.5	120	https://randomuser.me/api/portraits/women/9.jpg	"[\\"Fim de Obra\\",\\"Vidros\\",\\"Fachada\\"]"	limpeza faxina residencial comercial predial condominio pos obra vidros fachada	(11) 93251-8733	\N	Bauru	SP	f	t	2026-03-24 01:40:31.66	2026-03-24 01:40:31.66
cmn3y6wq4001nkqjyoa8u6pwp	JardimVerde	Reformas	4.5	94	https://randomuser.me/api/portraits/women/10.jpg	"[\\"Banheiro\\",\\"Cozinha\\",\\"Design\\"]"	reforma alvenaria construcao acabamento banheiro cozinha azulejo porcelanato gesseiro	(15) 97867-3427	\N	Osasco	SP	t	t	2026-03-24 01:40:31.661	2026-03-24 01:40:31.661
cmn3y6wq5001okqjy274aam32	GuardaSeuLar	Reformas	4.8	54	https://randomuser.me/api/portraits/women/11.jpg	"[\\"Banheiro\\",\\"Cozinha\\",\\"Design\\"]"	reforma alvenaria construcao acabamento banheiro cozinha azulejo porcelanato gesseiro	(11) 91275-2479	\N	Piracicaba	SP	t	t	2026-03-24 01:40:31.661	2026-03-24 01:40:31.661
cmn3y6wq5001pkqjylyb4rjn1	FrioCerto	Reformas	4.2	203	https://randomuser.me/api/portraits/women/12.jpg	"[\\"Gesseiro\\",\\"Forro de Gesso\\",\\"Acabamento\\"]"	reforma alvenaria construcao acabamento banheiro cozinha azulejo porcelanato gesseiro	(11) 93196-2850	\N	Osasco	SP	t	t	2026-03-24 01:40:31.662	2026-03-24 01:40:31.662
cmn3y6wq6001qkqjy7p9pu3oi	NetFix TI	Reformas	4.3	97	https://randomuser.me/api/portraits/women/13.jpg	"[\\"Banheiro\\",\\"Cozinha\\",\\"Design\\"]"	reforma alvenaria construcao acabamento banheiro cozinha azulejo porcelanato gesseiro	(11) 96327-4757	\N	Santos	SP	f	t	2026-03-24 01:40:31.662	2026-03-24 01:40:31.662
cmn3y6wq6001rkqjy2rdtiw6z	PragaZero	Reformas	4.6	55	https://randomuser.me/api/portraits/women/14.jpg	"[\\"Azulejo\\",\\"Porcelanato\\",\\"Assentamento\\"]"	reforma alvenaria construcao acabamento banheiro cozinha azulejo porcelanato gesseiro	(19) 92167-4103	\N	São Paulo	SP	t	t	2026-03-24 01:40:31.663	2026-03-24 01:40:31.663
cmn3y6wq7001skqjytxqy0vby	CarregaFácil	Jardinagem	4	141	https://randomuser.me/api/portraits/women/15.jpg	"[\\"Grama\\",\\"Adubação\\",\\"Irrigação\\"]"	jardinagem poda paisagismo jardim grama adubacao irrigacao arvore horta organico	(11) 96800-3156	\N	Piracicaba	SP	t	t	2026-03-24 01:40:31.663	2026-03-24 01:40:31.663
cmn3y6wq7001tkqjyfuci03d4	Anderson Melo	Jardinagem	4.3	253	https://randomuser.me/api/portraits/women/16.jpg	"[\\"Grama\\",\\"Adubação\\",\\"Irrigação\\"]"	jardinagem poda paisagismo jardim grama adubacao irrigacao arvore horta organico	(19) 91017-7839	\N	São Paulo	SP	t	t	2026-03-24 01:40:31.663	2026-03-24 01:40:31.663
cmn3y6wq7001ukqjy015uey2d	Peterson Cruz	Jardinagem	4.4	208	https://randomuser.me/api/portraits/women/17.jpg	"[\\"Vasos\\",\\"Decoração\\",\\"Projeto\\"]"	jardinagem poda paisagismo jardim grama adubacao irrigacao arvore horta organico	(11) 97039-7780	\N	Campinas	SP	t	t	2026-03-24 01:40:31.664	2026-03-24 01:40:31.664
cmn3y6wq8001vkqjy1ww4o6jj	Júnior Pacheco	Jardinagem	4.9	25	https://randomuser.me/api/portraits/women/18.jpg	"[\\"Vasos\\",\\"Decoração\\",\\"Projeto\\"]"	jardinagem poda paisagismo jardim grama adubacao irrigacao arvore horta organico	(13) 95283-7954	\N	Osasco	SP	f	t	2026-03-24 01:40:31.664	2026-03-24 01:40:31.664
cmn3y6wq8001wkqjyzsk2c7o4	Sandro Nogueira	Jardinagem	5	56	https://randomuser.me/api/portraits/women/19.jpg	"[\\"Grama\\",\\"Adubação\\",\\"Irrigação\\"]"	jardinagem poda paisagismo jardim grama adubacao irrigacao arvore horta organico	(15) 92049-7917	\N	Sorocaba	SP	t	t	2026-03-24 01:40:31.665	2026-03-24 01:40:31.665
cmn3y6wq8001xkqjyx8hy6gdr	Gilson Farias	Segurança	4.7	269	https://randomuser.me/api/portraits/women/20.jpg	"[\\"Câmeras\\",\\"CFTV\\",\\"24h\\"]"	seguranca cameras alarme monitoramento cftv cerca eletrica portao residencial	(15) 98646-9913	\N	Jundiaí	SP	t	t	2026-03-24 01:40:31.665	2026-03-24 01:40:31.665
cmn3y6wq9001ykqjy0tgdgjqv	Vera Paixão	Segurança	3.8	144	https://randomuser.me/api/portraits/women/21.jpg	"[\\"Alarme\\",\\"Monitoramento\\",\\"Residencial\\"]"	seguranca cameras alarme monitoramento cftv cerca eletrica portao residencial	(11) 94295-7210	\N	Ribeirão Preto	SP	t	t	2026-03-24 01:40:31.665	2026-03-24 01:40:31.665
cmn3y6wq9001zkqjywxgepvbb	Sônia Moura	Segurança	5	182	https://randomuser.me/api/portraits/women/22.jpg	"[\\"Portão\\",\\"Cerca Elétrica\\",\\"Instalação\\"]"	seguranca cameras alarme monitoramento cftv cerca eletrica portao residencial	(11) 92318-8879	\N	Osasco	SP	t	t	2026-03-24 01:40:31.666	2026-03-24 01:40:31.666
cmn3y6wq90020kqjy66itd7zh	Cilene Barros	Climatização	4.9	59	https://randomuser.me/api/portraits/women/23.jpg	"[\\"Split\\",\\"Inverter\\",\\"Limpeza\\"]"	ar condicionado split inverter climatizacao limpeza instalacao manutencao central	(15) 95944-1468	\N	Campinas	SP	t	t	2026-03-24 01:40:31.666	2026-03-24 01:40:31.666
cmn3y6wqa0021kqjyum2zb5hx	Denise Cavalcanti	Climatização	4.4	219	https://randomuser.me/api/portraits/women/24.jpg	"[\\"Ar Condicionado\\",\\"Instalação\\",\\"Manutenção\\"]"	ar condicionado split inverter climatizacao limpeza instalacao manutencao central	(13) 93498-9294	\N	Osasco	SP	t	t	2026-03-24 01:40:31.666	2026-03-24 01:40:31.666
cmn3y6wqa0022kqjyjrt98t0s	Elaine Brito	Climatização	4.6	123	https://randomuser.me/api/portraits/women/25.jpg	"[\\"Central\\",\\"Comercial\\",\\"Certificado\\"]"	ar condicionado split inverter climatizacao limpeza instalacao manutencao central	(19) 99600-9941	\N	São Paulo	SP	t	t	2026-03-24 01:40:31.667	2026-03-24 01:40:31.667
cmn3y6wqa0023kqjybo09waxl	Eletro Norte SP	Tecnologia	4.7	123	https://randomuser.me/api/portraits/women/26.jpg	"[\\"Redes\\",\\"Wi-Fi\\",\\"Cabeamento\\"]"	tecnologia rede wifi cabeamento computador notebook formatacao servidor cftv backup	(15) 98811-3229	\N	Piracicaba	SP	t	t	2026-03-24 01:40:31.667	2026-03-24 01:40:31.667
cmn3y6wqb0024kqjy48qywahp	CanoMestre	Tecnologia	4.6	165	https://randomuser.me/api/portraits/women/27.jpg	"[\\"Computadores\\",\\"Formatação\\",\\"Suporte\\"]"	tecnologia rede wifi cabeamento computador notebook formatacao servidor cftv backup	(11) 92372-4878	\N	São Paulo	SP	f	t	2026-03-24 01:40:31.667	2026-03-24 01:40:31.667
cmn3y6wqb0025kqjy0j6t4k47	BrilhoTotal	Tecnologia	4.3	96	https://randomuser.me/api/portraits/women/28.jpg	"[\\"CFTV\\",\\"Servidor\\",\\"Backup\\"]"	tecnologia rede wifi cabeamento computador notebook formatacao servidor cftv backup	(11) 94206-4262	\N	Osasco	SP	f	t	2026-03-24 01:40:31.667	2026-03-24 01:40:31.667
cmn3y6wqc0026kqjycxpp9nt9	AlvenariaMax	Dedetização	4.4	107	https://randomuser.me/api/portraits/women/29.jpg	"[\\"Cupim\\",\\"Baratas\\",\\"Ratos\\"]"	dedetizacao cupim rato barata formiga mosquito certificado controle pragas	(11) 95399-7991	\N	Sorocaba	SP	t	t	2026-03-24 01:40:31.668	2026-03-24 01:40:31.668
cmn3y6wqc0027kqjykqf4quai	EcoJardim	Dedetização	4.6	83	https://randomuser.me/api/portraits/women/30.jpg	"[\\"Formigas\\",\\"Mosquitos\\",\\"Certificado\\"]"	dedetizacao cupim rato barata formiga mosquito certificado controle pragas	(19) 97832-4865	\N	Ribeirão Preto	SP	t	t	2026-03-24 01:40:31.669	2026-03-24 01:40:31.669
cmn3y6wqd0028kqjyc2z4sbv1	VisionSeg	Mudança	4.5	105	https://randomuser.me/api/portraits/women/31.jpg	"[\\"Comercial\\",\\"Piano\\",\\"Desmontagem\\"]"	mudanca transporte caminhao embalar desmontar guarda moveis comercial residencial	(11) 91232-4722	\N	Osasco	SP	t	t	2026-03-24 01:40:31.669	2026-03-24 01:40:31.669
cmn3y6wqd0029kqjy21zi18qz	ClimateMax	Mudança	4.8	124	https://randomuser.me/api/portraits/women/32.jpg	"[\\"Guarda Móveis\\",\\"Seguro\\",\\"Rápido\\"]"	mudanca transporte caminhao embalar desmontar guarda moveis comercial residencial	(11) 93002-3993	\N	Sorocaba	SP	t	t	2026-03-24 01:40:31.67	2026-03-24 01:40:31.67
cmn3y6wqe002akqjypbtsdpi8	DataFix	Mudança	4	100	https://randomuser.me/api/portraits/women/33.jpg	"[\\"Guarda Móveis\\",\\"Seguro\\",\\"Rápido\\"]"	mudanca transporte caminhao embalar desmontar guarda moveis comercial residencial	(15) 93738-1563	\N	São Bernardo do Campo	SP	t	t	2026-03-24 01:40:31.67	2026-03-24 01:40:31.67
cmn3y6wqe002bkqjyuqcvbsis	BioControl	Gás	4.1	161	https://randomuser.me/api/portraits/women/34.jpg	"[\\"Instalação\\",\\"Vazamento\\",\\"Regulagem\\"]"	gas gasoducto instalacao vazamento botijao encanamento regulagem urgencia	(11) 98526-2289	\N	São Bernardo do Campo	SP	t	t	2026-03-24 01:40:31.67	2026-03-24 01:40:31.67
cmn3y6wqe002ckqjyvp5w3dd0	MudaFácil	Gás	4.3	21	https://randomuser.me/api/portraits/women/35.jpg	"[\\"Botijão\\",\\"Encanamento\\",\\"Urgência\\"]"	gas gasoducto instalacao vazamento botijao encanamento regulagem urgencia	(13) 98251-8433	\N	Santo André	SP	t	t	2026-03-24 01:40:31.671	2026-03-24 01:40:31.671
cmn3y6wqf002dkqjylsqkaeh2	GasSeguro	Pintura	5	53	https://randomuser.me/api/portraits/women/36.jpg	"[\\"Fachada\\",\\"Predial\\",\\"CertificadoMaestria\\"]"	pintura tinta parede textura interna externa fachada predial epóxi piso	(11) 99949-6389	\N	Guarulhos	SP	f	t	2026-03-24 01:40:31.671	2026-03-24 01:40:31.671
cmn3y6wqf002ekqjyz2eh4732	ColorMax Pinturas	Pintura	4.1	256	https://randomuser.me/api/portraits/women/37.jpg	"[\\"Interna\\",\\"Externa\\",\\"Textura\\"]"	pintura tinta parede textura interna externa fachada predial epóxi piso	(13) 91972-9763	\N	Mogi das Cruzes	SP	t	t	2026-03-24 01:40:31.672	2026-03-24 01:40:31.672
cmn3y6wqg002fkqjyy33tg6bj	Amper Elétrica	Pintura	4.4	68	https://randomuser.me/api/portraits/women/38.jpg	"[\\"Epóxi\\",\\"Piso\\",\\"Especializado\\"]"	pintura tinta parede textura interna externa fachada predial epóxi piso	(11) 95315-9468	\N	São Paulo	SP	t	t	2026-03-24 01:40:31.672	2026-03-24 01:40:31.672
cmn3y6wqg002gkqjyridhkfg3	FluxoHidro	Elétrica	4.1	22	https://randomuser.me/api/portraits/women/39.jpg	"[\\"Industrial\\",\\"Residencial\\",\\"Urgência\\"]"	eletrica instalacao quadro tomada luz iluminacao spda gerador urgencia emergencia	(13) 92862-4328	\N	Santo André	SP	t	t	2026-03-24 01:40:31.672	2026-03-24 01:40:31.672
cmn3y6wqg002hkqjy27hquf8h	WhiteClean	Elétrica	3.8	23	https://randomuser.me/api/portraits/women/40.jpg	"[\\"Gerador\\",\\"Painel\\",\\"Certificado\\"]"	eletrica instalacao quadro tomada luz iluminacao spda gerador urgencia emergencia	(19) 93615-7433	\N	São Paulo	SP	t	t	2026-03-24 01:40:31.673	2026-03-24 01:40:31.673
cmn3y6wqh002ikqjyiksf4csg	StructMax Reformas	Elétrica	4.8	41	https://randomuser.me/api/portraits/women/41.jpg	"[\\"24h\\",\\"Emergência\\",\\"Confiável\\"]"	eletrica instalacao quadro tomada luz iluminacao spda gerador urgencia emergencia	(15) 98223-5269	\N	Santos	SP	t	t	2026-03-24 01:40:31.673	2026-03-24 01:40:31.673
cmn3y6wqh002jkqjygyv5hdte	GreenLand Jardins	Elétrica	4.6	187	https://randomuser.me/api/portraits/women/42.jpg	"[\\"24h\\",\\"Emergência\\",\\"Confiável\\"]"	eletrica instalacao quadro tomada luz iluminacao spda gerador urgencia emergencia	(13) 99690-6191	\N	São Paulo	SP	f	t	2026-03-24 01:40:31.674	2026-03-24 01:40:31.674
cmn3y6wqi002kkqjylw3ceoxk	SafeGroup	Elétrica	4.9	283	https://randomuser.me/api/portraits/women/43.jpg	"[\\"24h\\",\\"Emergência\\",\\"Confiável\\"]"	eletrica instalacao quadro tomada luz iluminacao spda gerador urgencia emergencia	(19) 93641-3327	\N	Santo André	SP	t	t	2026-03-24 01:40:31.674	2026-03-24 01:40:31.674
cmn3y6wqi002lkqjym8863b2d	ArcticAir	Hidráulica	4.4	124	https://randomuser.me/api/portraits/women/44.jpg	"[\\"Caixa d'Água\\",\\"Encanamento\\",\\"Rápido\\"]"	hidraulica encanamento cano vazamento desentupimento fossa bomba agua aquecedor	(15) 99507-7103	\N	São Paulo	SP	t	t	2026-03-24 01:40:31.675	2026-03-24 01:40:31.675
cmn3y6wqj002mkqjydswjdd9v	SpeedTech	Hidráulica	4	148	https://randomuser.me/api/portraits/women/45.jpg	"[\\"Aquecimento\\",\\"Chuveiro\\",\\"Infiltração\\"]"	hidraulica encanamento cano vazamento desentupimento fossa bomba agua aquecedor	(11) 96269-3590	\N	Osasco	SP	t	t	2026-03-24 01:40:31.675	2026-03-24 01:40:31.675
cmn3y6wqj002nkqjy002c74ug	NoPragas	Hidráulica	5	284	https://randomuser.me/api/portraits/women/46.jpg	"[\\"Vazamento\\",\\"Registro\\",\\"Urgência\\"]"	hidraulica encanamento cano vazamento desentupimento fossa bomba agua aquecedor	(13) 99221-3300	\N	Bauru	SP	t	t	2026-03-24 01:40:31.676	2026-03-24 01:40:31.676
cmn3y6wqj002okqjy2wx2ux40	TransporteMax	Hidráulica	4.3	187	https://randomuser.me/api/portraits/women/47.jpg	"[\\"Caixa d'Água\\",\\"Encanamento\\",\\"Rápido\\"]"	hidraulica encanamento cano vazamento desentupimento fossa bomba agua aquecedor	(15) 98564-4094	\N	Santos	SP	t	t	2026-03-24 01:40:31.676	2026-03-24 01:40:31.676
cmn3y6wqk002pkqjyizk074x2	GásMais	Hidráulica	4	289	https://randomuser.me/api/portraits/women/48.jpg	"[\\"Esgoto\\",\\"Residencial\\",\\"Vistoria\\"]"	hidraulica encanamento cano vazamento desentupimento fossa bomba agua aquecedor	(15) 93713-8183	\N	Santo André	SP	t	t	2026-03-24 01:40:31.676	2026-03-24 01:40:31.676
cmn3y6wqk002qkqjyptp3i08t	PincelMestre	Limpeza	4.4	158	https://randomuser.me/api/portraits/women/49.jpg	"[\\"Condomínio\\",\\"Predial\\",\\"Empresa\\"]"	limpeza faxina residencial comercial predial condominio pos obra vidros fachada	(11) 92725-7808	\N	São Paulo	SP	t	t	2026-03-24 01:40:31.677	2026-03-24 01:40:31.677
cmn3y6wqk002rkqjy8mxij6wb	ElétricaVIP	Limpeza	5	102	https://randomuser.me/api/portraits/women/50.jpg	"[\\"Residencial\\",\\"Periódica\\",\\"Confiável\\"]"	limpeza faxina residencial comercial predial condominio pos obra vidros fachada	(11) 99909-3890	\N	Piracicaba	SP	t	t	2026-03-24 01:40:31.677	2026-03-24 01:40:31.677
\.


--
-- Data for Name: StockItem; Type: TABLE DATA; Schema: public; Owner: alex
--

COPY public."StockItem" (id, "assetId", name, sku, "currentStock", "minStock", unit, "subLocation", "unitPrice", "createdAt", "updatedAt") FROM stdin;
cmn3xwgtm00098gtlegbjwzp0	cmn3xwgtj00078gtly9ejtlxj	Item A	SKU-brspark-br-cmn3xwgtj00078gtly9ejtlxj-A	10	5	un	\N	\N	2026-03-24 01:32:24.49	2026-03-24 01:32:24.49
cmn3xwgtt000b8gtld22q0udc	cmn3xwgtj00078gtly9ejtlxj	Item Crítico	SKU-brspark-br-cmn3xwgtj00078gtly9ejtlxj-B	2	5	un	\N	\N	2026-03-24 01:32:24.498	2026-03-24 01:32:24.498
cmn3xwgtw000f8gtlfb5981rd	cmn3xwgtv000d8gtlsiwqien4	Item A	SKU-brspark-br-cmn3xwgtv000d8gtlsiwqien4-A	10	5	un	\N	\N	2026-03-24 01:32:24.5	2026-03-24 01:32:24.5
cmn3xwgtx000h8gtlv8z824rc	cmn3xwgtv000d8gtlsiwqien4	Item Crítico	SKU-brspark-br-cmn3xwgtv000d8gtlsiwqien4-B	2	5	un	\N	\N	2026-03-24 01:32:24.501	2026-03-24 01:32:24.501
cmn3xwgty000l8gtl416plf7z	cmn3xwgtx000j8gtlf0vw1qok	Item A	SKU-brspark-br-cmn3xwgtx000j8gtlf0vw1qok-A	10	5	un	\N	\N	2026-03-24 01:32:24.502	2026-03-24 01:32:24.502
cmn3xwgtz000n8gtlowqnxx3x	cmn3xwgtx000j8gtlf0vw1qok	Item Crítico	SKU-brspark-br-cmn3xwgtx000j8gtlf0vw1qok-B	2	5	un	\N	\N	2026-03-24 01:32:24.503	2026-03-24 01:32:24.503
cmn3xwgu9000z8gtlz7oshky7	cmn3xwgu8000x8gtlixouh8pm	Item A	SKU-solaris-us-cmn3xwgu8000x8gtlixouh8pm-A	10	5	un	\N	\N	2026-03-24 01:32:24.513	2026-03-24 01:32:24.513
cmn3xwgu900118gtl49y9gjj3	cmn3xwgu8000x8gtlixouh8pm	Item Crítico	SKU-solaris-us-cmn3xwgu8000x8gtlixouh8pm-B	2	5	un	\N	\N	2026-03-24 01:32:24.514	2026-03-24 01:32:24.514
cmn3xwgua00158gtl1a8hwys9	cmn3xwgua00138gtlgxlzuqfm	Item A	SKU-solaris-us-cmn3xwgua00138gtlgxlzuqfm-A	10	5	un	\N	\N	2026-03-24 01:32:24.515	2026-03-24 01:32:24.515
cmn3xwgub00178gtlgvn5zymz	cmn3xwgua00138gtlgxlzuqfm	Item Crítico	SKU-solaris-us-cmn3xwgua00138gtlgxlzuqfm-B	2	5	un	\N	\N	2026-03-24 01:32:24.515	2026-03-24 01:32:24.515
cmn3xwguc001b8gtld8rr55bp	cmn3xwgub00198gtlm6juwtim	Item A	SKU-solaris-us-cmn3xwgub00198gtlm6juwtim-A	10	5	un	\N	\N	2026-03-24 01:32:24.516	2026-03-24 01:32:24.516
cmn3xwguc001d8gtlcdrziopy	cmn3xwgub00198gtlm6juwtim	Item Crítico	SKU-solaris-us-cmn3xwgub00198gtlm6juwtim-B	2	5	un	\N	\N	2026-03-24 01:32:24.517	2026-03-24 01:32:24.517
cmn3xwguk001p8gtlh57eem05	cmn3xwguj001n8gtlutpesgpc	Item A	SKU-iberia-es-cmn3xwguj001n8gtlutpesgpc-A	10	5	un	\N	\N	2026-03-24 01:32:24.524	2026-03-24 01:32:24.524
cmn3xwguk001r8gtln60aal8g	cmn3xwguj001n8gtlutpesgpc	Item Crítico	SKU-iberia-es-cmn3xwguj001n8gtlutpesgpc-B	2	5	un	\N	\N	2026-03-24 01:32:24.524	2026-03-24 01:32:24.524
cmn3xwgul001v8gtlhwja740x	cmn3xwguk001t8gtluwfugchd	Item A	SKU-iberia-es-cmn3xwguk001t8gtluwfugchd-A	10	5	un	\N	\N	2026-03-24 01:32:24.525	2026-03-24 01:32:24.525
cmn3xwgum001x8gtl5j4xqj05	cmn3xwguk001t8gtluwfugchd	Item Crítico	SKU-iberia-es-cmn3xwguk001t8gtluwfugchd-B	2	5	un	\N	\N	2026-03-24 01:32:24.527	2026-03-24 01:32:24.527
cmn3xwguo00218gtlo05vs3rc	cmn3xwgun001z8gtlncywzd8z	Item A	SKU-iberia-es-cmn3xwgun001z8gtlncywzd8z-A	10	5	un	\N	\N	2026-03-24 01:32:24.528	2026-03-24 01:32:24.528
cmn3xwgup00238gtlma4f4l45	cmn3xwgun001z8gtlncywzd8z	Item Crítico	SKU-iberia-es-cmn3xwgun001z8gtlncywzd8z-B	2	5	un	\N	\N	2026-03-24 01:32:24.529	2026-03-24 01:32:24.529
\.


--
-- Data for Name: StockMovement; Type: TABLE DATA; Schema: public; Owner: alex
--

COPY public."StockMovement" (id, "itemId", type, quantity, reason, "fromAssetId", "toAssetId", "createdAt") FROM stdin;
\.


--
-- Data for Name: Subscription; Type: TABLE DATA; Schema: public; Owner: alex
--

COPY public."Subscription" (id, "tenantId", "planId", "billingCycle", status, "currentStart", "currentEnd", "cancelledAt", "trialEndsAt", "externalId", "createdAt", "updatedAt") FROM stdin;
cmn3xv66a0005a0ses6mrkhfp	cmn3xud9y0001kldgdiksukq5	cmn3xhvm00001dajksgpasg5e	MONTHLY	ACTIVE	2026-03-24 01:31:24.034	2026-04-23 01:31:24.034	\N	\N	\N	2026-03-24 01:31:24.035	2026-03-24 01:31:24.035
cmn3xwgu6000v8gtlzcupv5nf	cmn3xwgu1000r8gtl768s8zcj	cmn3xhvmb0003dajk7rnd1j9t	MONTHLY	ACTIVE	2026-03-24 01:32:24.51	2026-04-23 01:32:24.51	\N	\N	\N	2026-03-24 01:32:24.51	2026-03-24 01:32:24.51
cmn3xwgug001l8gtly6fzxjix	cmn3xwgue001h8gtlfcskpc0d	cmn3xhvma0002dajkn01kcgec	MONTHLY	ACTIVE	2026-03-24 01:32:24.52	2026-04-23 01:32:24.52	\N	\N	\N	2026-03-24 01:32:24.52	2026-03-24 01:32:24.52
cmn3y22oa0004ez5ccxkx7bnj	cmn3y22nk0000ez5ct3cd9uja	cmn3xhvm00001dajksgpasg5e	MONTHLY	ACTIVE	2026-03-24 01:36:46.086	2027-03-24 01:36:46.086	\N	\N	\N	2026-03-24 01:36:46.091	2026-03-24 01:36:46.091
\.


--
-- Data for Name: Tenant; Type: TABLE DATA; Schema: public; Owner: alex
--

COPY public."Tenant" (id, name, slug, email, phone, "taxId", "defaultLang", status, "createdAt", "updatedAt", "avatarUrl", "localeId", "ownerName") FROM stdin;
cmn3xud9y0001kldgdiksukq5	Brspark Global Brazil	brspark-br	contato@brspark.br	\N	\N	pt-BR	ACTIVE	2026-03-24 01:30:46.582	2026-03-24 01:30:46.582	\N	cmn3vyg7a0000124fc64ebh01	Brspark
cmn3xwgu1000r8gtl768s8zcj	Solaris Energy US	solaris-us	operations@solaris.us	\N	\N	pt-BR	ACTIVE	2026-03-24 01:32:24.506	2026-03-24 01:32:24.506	\N	cmn3vyg8e0001124fmm7itdof	Solaris
cmn3xwgue001h8gtlfcskpc0d	Iberia Logistics	iberia-es	info@iberia.es	\N	\N	pt-BR	ACTIVE	2026-03-24 01:32:24.518	2026-03-24 01:32:24.518	\N	cmn3vyg8g0002124f5eqzqfhe	Iberia
cmn3y22nk0000ez5ct3cd9uja	João Silva	joao-silva	joao.silva@brspark.com	(11) 99999-1234	\N	pt-BR	ACTIVE	2026-03-24 01:36:46.065	2026-03-24 01:36:46.065	\N	\N	João
cmn3y2uck0000sfjubh0n7z5o	João Teste	joao-teste	joao@teste.com	\N	\N	pt-BR	ACTIVE	2026-03-24 01:37:21.957	2026-03-24 01:38:37.735	\N	\N	João
cmn6hij2x0001j5dqofhbi9sd	Alex	alex	alex@brspark.com	\N	\N	pt-BR	TRIAL	2026-03-25 20:16:58.905	2026-03-25 20:16:58.905	\N	\N	Alex
cmn6sf2we004g5epyw7uxjo73	Luigi Marchetti	luigi	luigi@lansolver.com	\N	\N	pt-BR	TRIAL	2026-03-26 01:22:13.741	2026-03-26 01:22:13.741	\N	\N	Luigi Marchetti
\.


--
-- Data for Name: TranslationOverride; Type: TABLE DATA; Schema: public; Owner: alex
--

COPY public."TranslationOverride" (id, "tenantId", key, language, value, "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: User; Type: TABLE DATA; Schema: public; Owner: alex
--

COPY public."User" (id, "tenantId", email, name, password, role, "isActive", "lastLogin", "createdAt", "updatedAt", "avatarUrl") FROM stdin;
cmn6sf2wq004i5epyd58t8qn2	cmn6sf2we004g5epyw7uxjo73	luigi@lansolver.com	Luigi Marchetti	$2a$10$0oLzyiB0Z74/AxFJ7Lxny.p6fgG3kXUbjTHU7qVo5CpdP/9yLovf6	ADMIN	t	2026-03-26 20:50:07.75	2026-03-26 01:22:13.753	2026-03-26 22:11:48.779	http://192.168.15.73:3001/uploads/storage/avatars/cmn6sf2wq004i5epyd58t8qn2_1774563105054.jpeg
cmn6hij3j0003j5dqqixl4ge1	cmn6hij2x0001j5dqofhbi9sd	alex@brspark.com	Alex	$2a$10$LYCgB7c2fXOd22UjngG/ZO4yhfDVGSLbYBYSOYPkkzYxo6oFclgVO	ADMIN	t	2026-03-27 18:50:25.914	2026-03-25 20:16:58.927	2026-03-27 18:50:25.916	http://192.168.15.73:3001/uploads/storage/avatars/cmn6hij3j0003j5dqqixl4ge1_1774563015508.jpg
cmn3xwgu3000t8gtlvhuyyizu	cmn3xwgu1000r8gtl768s8zcj	operations@solaris.us	Solaris Energy US Admin	$2a$10$MY.3mTkx6.rc9xTDwrJ90OygdfQ5FUF8UTPIgP1TjhAQjFyVVyxwO	ADMIN	t	\N	2026-03-24 01:32:24.507	2026-03-26 21:51:12.903	https://randomuser.me/api/portraits/men/4.jpg
cmn3xwguf001j8gtlbxs9yzx9	cmn3xwgue001h8gtlfcskpc0d	info@iberia.es	Iberia Logistics Admin	$2a$10$MY.3mTkx6.rc9xTDwrJ90OygdfQ5FUF8UTPIgP1TjhAQjFyVVyxwO	ADMIN	t	\N	2026-03-24 01:32:24.519	2026-03-26 21:51:12.903	https://randomuser.me/api/portraits/men/4.jpg
cmn3y22nz0002ez5c1hzi6chf	cmn3y22nk0000ez5ct3cd9uja	joao.silva@brspark.com	João Silva	$2a$10$iNyp0KtfS4tN5C6ShHb2W.XTfTngHsrIoSgwoUadURrUmmUQ2b9j2	ADMIN	t	\N	2026-03-24 01:36:46.08	2026-03-26 21:51:12.903	https://randomuser.me/api/portraits/men/4.jpg
cmn3y2ucr0002sfju83h732a4	cmn3y2uck0000sfjubh0n7z5o	joao@teste.com	João Teste	$2a$10$4nhrqJ2uw8qX3Sf1OFl9M.GgSIFTFkU3PLEtkG8npP7CQuIssF3fO	ADMIN	t	2026-03-25 19:43:56.542	2026-03-24 01:37:21.963	2026-03-26 21:51:12.903	https://randomuser.me/api/portraits/men/4.jpg
cmn3xuq0c0003aufuay5elb67	cmn3xud9y0001kldgdiksukq5	contato@brspark.br	Brspark Global Brazil Admin	$2a$10$MDkv.akxEovWisetwTn1ie.RcE/YLAUdb0FEH5vgfcUj1nhwvKczC	ADMIN	t	\N	2026-03-24 01:31:03.085	2026-03-26 21:52:09.712	SUCCESS
\.


--
-- Data for Name: UserModuleData; Type: TABLE DATA; Schema: public; Owner: alex
--

COPY public."UserModuleData" (id, "ownerEmail", module, data, "updatedAt", "createdAt") FROM stdin;
cmn6u4n3i0005e0hkjsplnzl4	luigi@lansolver.com	costs_expenses	[]	2026-03-27 00:46:27.507	2026-03-26 02:10:05.935
cmn6u4n3x0007e0hknad8z47c	luigi@lansolver.com	insurance_policies	[]	2026-03-27 00:46:27.606	2026-03-26 02:10:05.949
cmn6u4n3z0009e0hkhxc1lj0k	luigi@lansolver.com	asset_docs	[{"id": "jrsu5w", "uri": "file:///var/mobile/Containers/Data/Application/B49F90C2-F617-4081-910B-D71CE9F435F3/Library/Caches/ExponentExperienceData/@anonymous/BrsparkMobile-be63636c-8058-4d28-bef6-7ebf19f8191b/DocumentPicker/5F6E3240-CAC6-4BC7-9A6C-16396ABD4B28.pdf", "type": "pdf", "title": "NF-e - Nota Fiscal Eletrônica de Serviços - São Paulo.pdf", "assetId": "brsp-314572", "version": 1, "category": "general", "createdAt": "2026-03-26T13:28:02.961Z", "description": ""}]	2026-03-27 00:46:27.648	2026-03-26 02:10:05.952
cmn6u4n3x0008e0hkq2f8eeac	luigi@lansolver.com	costs_recurring	[]	2026-03-27 00:46:27.51	2026-03-26 02:10:05.95
cmn6numgb000asn7d7mmll21z	alex@brspark.com	costs_recurring	[{"id": "rec-mn69xf9l-h54zj", "type": "REVENUE", "amount": 2500, "status": "ACTIVE", "assetId": "brsp-215880", "frequency": "MONTHLY", "ownerEmail": "alex@brspark.com", "description": "Tedte", "nextDueDate": "2026-03-25", "alertDaysBefore": 1, "totalInstallments": 2, "remainingInstallments": 2}, {"id": "ins_cost_ins_1774477825766_cwk5h", "type": "EXPENSE", "amount": 0, "status": "ACTIVE", "assetId": "brsp-190135", "category": "SEGURO", "frequency": "YEARLY", "ownerEmail": "alex@brspark.com", "description": "Seguro Residencial — Teste", "nextDueDate": "209383", "alertDaysBefore": 10}, {"id": "ins_cost_ins_1774477826163_pyzx0", "type": "EXPENSE", "amount": 0, "status": "ACTIVE", "assetId": "brsp-190135", "category": "SEGURO", "frequency": "YEARLY", "ownerEmail": "alex@brspark.com", "description": "Seguro Residencial — Teste", "nextDueDate": "209383", "alertDaysBefore": 10}, {"id": "rec-mn8wim0o-uh9wo", "type": "REVENUE", "amount": 1000, "status": "ACTIVE", "assetId": "brsp-756993", "frequency": "MONTHLY", "ownerEmail": "alex@brspark.com", "description": "Aluguel", "nextDueDate": "2026-03-28", "alertDaysBefore": 1, "totalInstallments": 12, "remainingInstallments": 12}, {"id": "rec-mn8wlgmp-owx71", "type": "REVENUE", "amount": 300, "status": "ACTIVE", "assetId": "brsp-134786", "frequency": "MONTHLY", "ownerEmail": "alex@brspark.com", "description": "Aluguel", "nextDueDate": "2026-03-27", "alertDaysBefore": 1, "totalInstallments": 12, "remainingInstallments": 12}, {"id": "rec-mn8wma7d-j64lj", "type": "REVENUE", "amount": 50, "status": "ACTIVE", "assetId": "brsp-756993", "frequency": "MONTHLY", "ownerEmail": "alex@brspark.com", "description": "Teste", "nextDueDate": "2026-03-27", "alertDaysBefore": 1, "totalInstallments": 12, "remainingInstallments": 12}, {"id": "rec-mn8wmvf1-vx666", "type": "EXPENSE", "amount": 300, "status": "ACTIVE", "assetId": "brsp-756993", "frequency": "MONTHLY", "ownerEmail": "alex@brspark.com", "description": "Teste rec", "nextDueDate": "2026-03-27", "alertDaysBefore": 1, "totalInstallments": 12, "remainingInstallments": 12}, {"id": "rec-mn8wn9yc-roy0r", "type": "EXPENSE", "amount": 50, "status": "ACTIVE", "assetId": "brsp-756993", "frequency": "MONTHLY", "ownerEmail": "alex@brspark.com", "description": "2", "nextDueDate": "2026-03-27", "alertDaysBefore": 1, "totalInstallments": 12, "remainingInstallments": 12}, {"id": "rec-mn8wnmsw-3nbph", "type": "REVENUE", "amount": 100, "status": "ACTIVE", "assetId": "brsp-756993", "frequency": "MONTHLY", "ownerEmail": "alex@brspark.com", "description": "3", "nextDueDate": "2026-03-27", "alertDaysBefore": 1, "totalInstallments": 12, "remainingInstallments": 12}, {"id": "rec-mn8wo9xg-olj46", "type": "REVENUE", "amount": 100, "status": "ACTIVE", "assetId": "brsp-134786", "frequency": "MONTHLY", "ownerEmail": "alex@brspark.com", "description": "1", "nextDueDate": "2026-03-27", "alertDaysBefore": 1, "totalInstallments": 12, "remainingInstallments": 12}, {"id": "rec-mn8wolzq-k0t6i", "type": "EXPENSE", "amount": 200, "status": "ACTIVE", "assetId": "brsp-134786", "frequency": "MONTHLY", "ownerEmail": "alex@brspark.com", "description": "2", "nextDueDate": "2026-03-27", "alertDaysBefore": 1, "totalInstallments": 12, "remainingInstallments": 12}, {"id": "rec-mn8wwasg-y98d3", "type": "EXPENSE", "amount": 50, "status": "ACTIVE", "assetId": "brsp-134786", "frequency": "MONTHLY", "ownerEmail": "alex@brspark.com", "description": "Netflix", "nextDueDate": "2026-03-27", "alertDaysBefore": 1}, {"id": "ins_cost_ins_1774648334205_drxzi", "type": "EXPENSE", "amount": 0, "status": "ACTIVE", "assetId": "brsp-134786", "category": "SEGURO", "frequency": "YEARLY", "ownerEmail": "alex@brspark.com", "description": "Seguro Residencial — Teste", "nextDueDate": "2026-04-27", "alertDaysBefore": 1}, {"id": "ins_cost_ins_1774648335970_y32ey", "type": "EXPENSE", "amount": 0, "status": "ACTIVE", "assetId": "brsp-134786", "category": "SEGURO", "frequency": "YEARLY", "ownerEmail": "alex@brspark.com", "description": "Seguro Residencial — Teste", "nextDueDate": "2026-04-27", "alertDaysBefore": 1}, {"id": "ins_cost_ins_1774648337353_bjq8z", "type": "EXPENSE", "amount": 0, "status": "ACTIVE", "assetId": "brsp-134786", "category": "SEGURO", "frequency": "YEARLY", "ownerEmail": "alex@brspark.com", "description": "Seguro Residencial — Teste", "nextDueDate": "2026-04-27", "alertDaysBefore": 1}, {"id": "ins_cost_ins_1774648337620_kuvjy", "type": "EXPENSE", "amount": 0, "status": "ACTIVE", "assetId": "brsp-134786", "category": "SEGURO", "frequency": "YEARLY", "ownerEmail": "alex@brspark.com", "description": "Seguro Residencial — Teste", "nextDueDate": "2026-04-27", "alertDaysBefore": 1}, {"id": "ins_cost_ins_1774648337870_l14de", "type": "EXPENSE", "amount": 0, "status": "ACTIVE", "assetId": "brsp-134786", "category": "SEGURO", "frequency": "YEARLY", "ownerEmail": "alex@brspark.com", "description": "Seguro Residencial — Teste", "nextDueDate": "2026-04-27", "alertDaysBefore": 1}, {"id": "ins_cost_ins_1774648441070_05axk", "type": "EXPENSE", "amount": 0, "status": "ACTIVE", "assetId": "brsp-134786", "category": "SEGURO", "frequency": "YEARLY", "ownerEmail": "alex@brspark.com", "description": "Seguro Residencial — Teste", "nextDueDate": "2026-04-27", "alertDaysBefore": 1}]	2026-03-27 23:56:09.269	2026-03-25 23:14:20.765
cmn6numhy000dsn7dd1oeoyke	alex@brspark.com	asset_docs	[{"id": "qdce4o", "uri": "https://pub-5fc6db4a467f3070a46bf138e5b79edb.r2.dev/docs/alex_brspark_com/qdce4o.pdf", "type": "pdf", "title": "NF-e - Nota Fiscal Eletrônica de Serviços - São Paulo.pdf", "assetId": "brsp-190135", "version": 1, "category": "general", "createdAt": "2026-03-25T23:39:27.408Z", "description": ""}, {"id": "5b8tw4", "uri": "https://pub-5fc6db4a467f3070a46bf138e5b79edb.r2.dev/docs/alex_brspark_com/5b8tw4.pdf", "type": "pdf", "title": "Currículo Thais 2025.pdf", "assetId": "brsp-190135", "version": 1, "category": "general", "createdAt": "2026-03-25T23:39:33.198Z", "description": ""}, {"id": "nmft9b", "uri": "", "type": "folder", "title": "Teste", "assetId": "brsp-756993", "version": 1, "category": "general", "createdAt": "2026-03-26T18:13:09.048Z"}, {"id": "4oc4kl", "uri": "/BrSpark/docs/alex_brspark_com/4oc4kl.pdf", "type": "pdf", "title": "NF-e - Nota Fiscal Eletrônica de Serviços - São Paulo.pdf", "assetId": "brsp-756993", "version": 1, "category": "general", "parentId": "nmft9b", "createdAt": "2026-03-26T18:13:15.140Z", "description": ""}, {"id": "wf9ejb", "uri": "", "type": "folder", "title": "123", "assetId": "brsp-756993", "version": 1, "category": "general", "createdAt": "2026-03-26T18:16:09.617Z"}, {"id": "krsucl", "uri": "", "type": "folder", "title": "1", "assetId": "brsp-756993", "version": 1, "category": "general", "parentId": "nmft9b", "createdAt": "2026-03-26T18:20:06.259Z"}]	2026-03-27 23:56:09.383	2026-03-25 23:14:20.902
cmn6numhk000csn7daaw45e16	alex@brspark.com	insurance_policies	[{"id": "ins_1774477825766_cwk5h", "type": "RESIDENTIAL", "status": "ACTIVE", "assetId": "brsp-190135", "endDate": "209383", "insurer": "Teste", "createdAt": "2026-03-25T22:30:25.766Z", "startDate": "2026-03-25", "brokerName": "", "deductible": 0, "ownerEmail": "alex@brspark.com", "brokerPhone": "", "documentUri": "file:///var/mobile/Containers/Data/Application/B49F90C2-F617-4081-910B-D71CE9F435F3/Library/Caches/ExponentExperienceData/@anonymous/BrsparkMobile-be63636c-8058-4d28-bef6-7ebf19f8191b/DocumentPicker/F0257E79-A544-48D8-AEC0-14D3CE2AB092.pages", "policyNumber": "123", "premiumValue": 0, "coverageAmount": 0, "alertDaysBefore": 10, "coverageDetails": ""}, {"id": "ins_1774477826163_pyzx0", "type": "RESIDENTIAL", "status": "ACTIVE", "assetId": "brsp-190135", "endDate": "209383", "insurer": "Teste", "createdAt": "2026-03-25T22:30:26.163Z", "startDate": "2026-03-25", "brokerName": "", "deductible": 0, "ownerEmail": "alex@brspark.com", "brokerPhone": "", "documentUri": "file:///var/mobile/Containers/Data/Application/B49F90C2-F617-4081-910B-D71CE9F435F3/Library/Caches/ExponentExperienceData/@anonymous/BrsparkMobile-be63636c-8058-4d28-bef6-7ebf19f8191b/DocumentPicker/F0257E79-A544-48D8-AEC0-14D3CE2AB092.pages", "policyNumber": "123", "premiumValue": 0, "coverageAmount": 0, "alertDaysBefore": 10, "coverageDetails": ""}, {"id": "ins_1774648334205_drxzi", "type": "RESIDENTIAL", "status": "ACTIVE", "assetId": "brsp-134786", "endDate": "2026-04-27", "insurer": "Teste", "createdAt": "2026-03-27T21:52:14.205Z", "startDate": "2026-03-27", "brokerName": "", "deductible": 0, "ownerEmail": "alex@brspark.com", "brokerPhone": "", "documentUri": "http://192.168.15.73:3001/uploads/storage/docs/alex_brspark_com/ins_1774648334205_drxzi.insurance_355", "policyNumber": "355", "premiumValue": 0, "coverageAmount": 0, "alertDaysBefore": 1, "coverageDetails": ""}, {"id": "ins_1774648335970_y32ey", "type": "RESIDENTIAL", "status": "ACTIVE", "assetId": "brsp-134786", "endDate": "2026-04-27", "insurer": "Teste", "createdAt": "2026-03-27T21:52:15.970Z", "startDate": "2026-03-27", "brokerName": "", "deductible": 0, "ownerEmail": "alex@brspark.com", "brokerPhone": "", "documentUri": "http://192.168.15.73:3001/uploads/storage/docs/alex_brspark_com/ins_1774648335970_y32ey.insurance_355", "policyNumber": "355", "premiumValue": 0, "coverageAmount": 0, "alertDaysBefore": 1, "coverageDetails": ""}, {"id": "ins_1774648337353_bjq8z", "type": "RESIDENTIAL", "status": "ACTIVE", "assetId": "brsp-134786", "endDate": "2026-04-27", "insurer": "Teste", "createdAt": "2026-03-27T21:52:17.353Z", "startDate": "2026-03-27", "brokerName": "", "deductible": 0, "ownerEmail": "alex@brspark.com", "brokerPhone": "", "documentUri": "http://192.168.15.73:3001/uploads/storage/docs/alex_brspark_com/ins_1774648337353_bjq8z.insurance_355", "policyNumber": "355", "premiumValue": 0, "coverageAmount": 0, "alertDaysBefore": 1, "coverageDetails": ""}, {"id": "ins_1774648337620_kuvjy", "type": "RESIDENTIAL", "status": "ACTIVE", "assetId": "brsp-134786", "endDate": "2026-04-27", "insurer": "Teste", "createdAt": "2026-03-27T21:52:17.620Z", "startDate": "2026-03-27", "brokerName": "", "deductible": 0, "ownerEmail": "alex@brspark.com", "brokerPhone": "", "documentUri": "http://192.168.15.73:3001/uploads/storage/docs/alex_brspark_com/ins_1774648337620_kuvjy.insurance_355", "policyNumber": "355", "premiumValue": 0, "coverageAmount": 0, "alertDaysBefore": 1, "coverageDetails": ""}, {"id": "ins_1774648337870_l14de", "type": "RESIDENTIAL", "status": "ACTIVE", "assetId": "brsp-134786", "endDate": "2026-04-27", "insurer": "Teste", "createdAt": "2026-03-27T21:52:17.870Z", "startDate": "2026-03-27", "brokerName": "", "deductible": 0, "ownerEmail": "alex@brspark.com", "brokerPhone": "", "documentUri": "http://192.168.15.73:3001/uploads/storage/docs/alex_brspark_com/ins_1774648337870_l14de.insurance_355", "policyNumber": "355", "premiumValue": 0, "coverageAmount": 0, "alertDaysBefore": 1, "coverageDetails": ""}, {"id": "ins_1774648441070_05axk", "type": "RESIDENTIAL", "status": "ACTIVE", "assetId": "brsp-134786", "endDate": "2026-04-27", "insurer": "Teste", "createdAt": "2026-03-27T21:54:01.070Z", "startDate": "2026-03-27", "brokerName": "", "deductible": 0, "ownerEmail": "alex@brspark.com", "brokerPhone": "", "documentUri": "http://192.168.15.73:3001/uploads/storage/docs/alex_brspark_com/ins_1774648441070_05axk.insurance_355", "policyNumber": "355", "premiumValue": 0, "coverageAmount": 0, "alertDaysBefore": 1, "coverageDetails": ""}]	2026-03-27 23:56:09.269	2026-03-25 23:14:20.765
cmn6numgk000bsn7dio7u4kgb	alex@brspark.com	costs_expenses	[{"id": "exp-mn67vmfh-dy607", "date": "2026-03-25", "type": "EXPENSE", "amount": 532, "status": "PENDING", "assetId": "brsp-215880", "category": "OUTROS", "ownerEmail": "alex@brspark.com", "description": "Pneu"}, {"id": "exp-mn67xbkl-2bu76", "date": "2026-03-25", "type": "EXPENSE", "amount": 523.87, "status": "PENDING", "assetId": "brsp-585500", "category": "OUTROS", "ownerEmail": "alex@brspark.com", "description": "Pneu"}, {"id": "exp-mn68cwe3-e1zb0", "date": "2026-03-25", "type": "EXPENSE", "amount": 235, "status": "PENDING", "assetId": "brsp-215880", "category": "OUTROS", "ownerEmail": "alex@brspark.com", "description": "Pneu"}, {"id": "exp-mn6hn1bs-ka6kt", "date": "2026-03-25", "type": "EXPENSE", "amount": 152, "status": "PENDING", "assetId": "brsp-190135", "category": "OUTROS", "ownerEmail": "alex@brspark.com", "description": "Luz"}, {"id": "exp-mn6hp6c6-u9q2w", "date": "2026-03-25", "type": "EXPENSE", "amount": 500, "status": "PENDING", "assetId": "brsp-628386", "category": "OUTROS", "ownerEmail": "alex@brspark.com", "description": "Pmeu"}, {"id": "exp-mn7gcdd2-74nic", "date": "2026-03-26", "type": "REVENUE", "amount": 100, "status": "PENDING", "assetId": "brsp-756993", "category": "OUTROS", "ownerEmail": "alex@brspark.com", "description": "Testw"}, {"id": "exp-mn8wkyku-t309v", "date": "2026-03-27", "type": "REVENUE", "amount": 100, "status": "PENDING", "assetId": "brsp-134786", "category": "OUTROS", "ownerEmail": "alex@brspark.com", "description": "Teste"}, {"id": "exp-mn8wuoci-3bvk6", "date": "2026-03-27", "type": "EXPENSE", "amount": 25, "status": "PENDING", "assetId": "brsp-134786", "category": "OUTROS", "ownerEmail": "alex@brspark.com", "description": "Teste22"}]	2026-03-27 23:56:09.269	2026-03-25 23:14:20.765
\.


--
-- Data for Name: _prisma_migrations; Type: TABLE DATA; Schema: public; Owner: alex
--

COPY public._prisma_migrations (id, checksum, finished_at, migration_name, logs, rolled_back_at, started_at, applied_steps_count) FROM stdin;
88e7ba54-b943-4298-b4a2-ea8b736a2125	73224fe465c7de5be1d4f58cef71fe703fb824623c5ac8e5cb2f2f6321e13618	2026-03-23 21:13:49.442506-03	20260323143455_init	\N	\N	2026-03-23 21:13:49.40633-03	1
327e5d1e-7f12-4b6c-9086-c7ea2cdae478	b00868e21b0ca2a3323cd88c3837296362a8462505fcd8fd176873fdd031d0e0	2026-03-23 21:14:07.840326-03	20260324001407_add_locale_profiles	\N	\N	2026-03-23 21:14:07.701459-03	1
c5d144ad-13c5-42f5-b9d0-828474b0ded4	4aee8126753b087ae1d49fcb712baf2e1c6e24482a4c62352b79d536d572e4fe	2026-03-23 21:55:28.879335-03	20260324005528_add_translation_overrides	\N	\N	2026-03-23 21:55:28.871565-03	1
971d38b9-d917-4ca4-8fc8-9cd12cafcf46	9d60239b46e3f387ba472534b063e7b1ec3b3261abed0fc6518319807e150d9f	2026-03-24 14:35:11.484744-03	20260324173511_add_expense_revenue_metatag_types	\N	\N	2026-03-24 14:35:11.455941-03	1
0547e099-2b1f-4aaf-9f64-ce245c08121b	589531bd1df68a2b7555da033cb015bbcbd21f47a34108adc3062f3239503fdd	2026-03-25 19:50:08.669677-03	20260325225008_add_user_module_data	\N	\N	2026-03-25 19:50:08.659308-03	1
d8b0d2ea-4184-464b-9423-9900865a2bea	69261f245187956b568acf26c08edaaa8f37d68a4f7837d767ad498780c8045e	2026-03-25 20:03:53.367647-03	20260325230353_add_media_category	\N	\N	2026-03-25 20:03:53.305337-03	1
ee0003b9-d3d3-4fec-a918-8e6e5e3e04f2	78071a54b17cd3c1f7831a52989a8e4b26c043c6761ea11357637c77c6134b4e	2026-03-25 21:53:47.510058-03	20260326005347_init_asset_shares	\N	\N	2026-03-25 21:53:47.487591-03	1
\.


--
-- Name: Admin Admin_pkey; Type: CONSTRAINT; Schema: public; Owner: alex
--

ALTER TABLE ONLY public."Admin"
    ADD CONSTRAINT "Admin_pkey" PRIMARY KEY (id);


--
-- Name: AssetShare AssetShare_pkey; Type: CONSTRAINT; Schema: public; Owner: alex
--

ALTER TABLE ONLY public."AssetShare"
    ADD CONSTRAINT "AssetShare_pkey" PRIMARY KEY (id);


--
-- Name: Asset Asset_pkey; Type: CONSTRAINT; Schema: public; Owner: alex
--

ALTER TABLE ONLY public."Asset"
    ADD CONSTRAINT "Asset_pkey" PRIMARY KEY (id);


--
-- Name: AuditLog AuditLog_pkey; Type: CONSTRAINT; Schema: public; Owner: alex
--

ALTER TABLE ONLY public."AuditLog"
    ADD CONSTRAINT "AuditLog_pkey" PRIMARY KEY (id);


--
-- Name: ChatContact ChatContact_pkey; Type: CONSTRAINT; Schema: public; Owner: alex
--

ALTER TABLE ONLY public."ChatContact"
    ADD CONSTRAINT "ChatContact_pkey" PRIMARY KEY (id);


--
-- Name: ChatMessage ChatMessage_pkey; Type: CONSTRAINT; Schema: public; Owner: alex
--

ALTER TABLE ONLY public."ChatMessage"
    ADD CONSTRAINT "ChatMessage_pkey" PRIMARY KEY (id);


--
-- Name: ChatRoomMember ChatRoomMember_pkey; Type: CONSTRAINT; Schema: public; Owner: alex
--

ALTER TABLE ONLY public."ChatRoomMember"
    ADD CONSTRAINT "ChatRoomMember_pkey" PRIMARY KEY (id);


--
-- Name: ChatRoom ChatRoom_pkey; Type: CONSTRAINT; Schema: public; Owner: alex
--

ALTER TABLE ONLY public."ChatRoom"
    ADD CONSTRAINT "ChatRoom_pkey" PRIMARY KEY (id);


--
-- Name: ComplianceAcceptance ComplianceAcceptance_pkey; Type: CONSTRAINT; Schema: public; Owner: alex
--

ALTER TABLE ONLY public."ComplianceAcceptance"
    ADD CONSTRAINT "ComplianceAcceptance_pkey" PRIMARY KEY (id);


--
-- Name: ComplianceDoc ComplianceDoc_pkey; Type: CONSTRAINT; Schema: public; Owner: alex
--

ALTER TABLE ONLY public."ComplianceDoc"
    ADD CONSTRAINT "ComplianceDoc_pkey" PRIMARY KEY (id);


--
-- Name: FeatureFlag FeatureFlag_pkey; Type: CONSTRAINT; Schema: public; Owner: alex
--

ALTER TABLE ONLY public."FeatureFlag"
    ADD CONSTRAINT "FeatureFlag_pkey" PRIMARY KEY (id);


--
-- Name: Integration Integration_pkey; Type: CONSTRAINT; Schema: public; Owner: alex
--

ALTER TABLE ONLY public."Integration"
    ADD CONSTRAINT "Integration_pkey" PRIMARY KEY (id);


--
-- Name: Invoice Invoice_pkey; Type: CONSTRAINT; Schema: public; Owner: alex
--

ALTER TABLE ONLY public."Invoice"
    ADD CONSTRAINT "Invoice_pkey" PRIMARY KEY (id);


--
-- Name: LocaleProfile LocaleProfile_pkey; Type: CONSTRAINT; Schema: public; Owner: alex
--

ALTER TABLE ONLY public."LocaleProfile"
    ADD CONSTRAINT "LocaleProfile_pkey" PRIMARY KEY (id);


--
-- Name: Location Location_pkey; Type: CONSTRAINT; Schema: public; Owner: alex
--

ALTER TABLE ONLY public."Location"
    ADD CONSTRAINT "Location_pkey" PRIMARY KEY (id);


--
-- Name: Metatag Metatag_pkey; Type: CONSTRAINT; Schema: public; Owner: alex
--

ALTER TABLE ONLY public."Metatag"
    ADD CONSTRAINT "Metatag_pkey" PRIMARY KEY (id);


--
-- Name: NotificationLog NotificationLog_pkey; Type: CONSTRAINT; Schema: public; Owner: alex
--

ALTER TABLE ONLY public."NotificationLog"
    ADD CONSTRAINT "NotificationLog_pkey" PRIMARY KEY (id);


--
-- Name: NotificationTemplate NotificationTemplate_pkey; Type: CONSTRAINT; Schema: public; Owner: alex
--

ALTER TABLE ONLY public."NotificationTemplate"
    ADD CONSTRAINT "NotificationTemplate_pkey" PRIMARY KEY (id);


--
-- Name: Plan Plan_pkey; Type: CONSTRAINT; Schema: public; Owner: alex
--

ALTER TABLE ONLY public."Plan"
    ADD CONSTRAINT "Plan_pkey" PRIMARY KEY (id);


--
-- Name: PushToken PushToken_pkey; Type: CONSTRAINT; Schema: public; Owner: alex
--

ALTER TABLE ONLY public."PushToken"
    ADD CONSTRAINT "PushToken_pkey" PRIMARY KEY (id);


--
-- Name: ServiceProvider ServiceProvider_pkey; Type: CONSTRAINT; Schema: public; Owner: alex
--

ALTER TABLE ONLY public."ServiceProvider"
    ADD CONSTRAINT "ServiceProvider_pkey" PRIMARY KEY (id);


--
-- Name: StockItem StockItem_pkey; Type: CONSTRAINT; Schema: public; Owner: alex
--

ALTER TABLE ONLY public."StockItem"
    ADD CONSTRAINT "StockItem_pkey" PRIMARY KEY (id);


--
-- Name: StockMovement StockMovement_pkey; Type: CONSTRAINT; Schema: public; Owner: alex
--

ALTER TABLE ONLY public."StockMovement"
    ADD CONSTRAINT "StockMovement_pkey" PRIMARY KEY (id);


--
-- Name: Subscription Subscription_pkey; Type: CONSTRAINT; Schema: public; Owner: alex
--

ALTER TABLE ONLY public."Subscription"
    ADD CONSTRAINT "Subscription_pkey" PRIMARY KEY (id);


--
-- Name: Tenant Tenant_pkey; Type: CONSTRAINT; Schema: public; Owner: alex
--

ALTER TABLE ONLY public."Tenant"
    ADD CONSTRAINT "Tenant_pkey" PRIMARY KEY (id);


--
-- Name: TranslationOverride TranslationOverride_pkey; Type: CONSTRAINT; Schema: public; Owner: alex
--

ALTER TABLE ONLY public."TranslationOverride"
    ADD CONSTRAINT "TranslationOverride_pkey" PRIMARY KEY (id);


--
-- Name: UserModuleData UserModuleData_pkey; Type: CONSTRAINT; Schema: public; Owner: alex
--

ALTER TABLE ONLY public."UserModuleData"
    ADD CONSTRAINT "UserModuleData_pkey" PRIMARY KEY (id);


--
-- Name: User User_pkey; Type: CONSTRAINT; Schema: public; Owner: alex
--

ALTER TABLE ONLY public."User"
    ADD CONSTRAINT "User_pkey" PRIMARY KEY (id);


--
-- Name: _prisma_migrations _prisma_migrations_pkey; Type: CONSTRAINT; Schema: public; Owner: alex
--

ALTER TABLE ONLY public._prisma_migrations
    ADD CONSTRAINT _prisma_migrations_pkey PRIMARY KEY (id);


--
-- Name: Admin_email_key; Type: INDEX; Schema: public; Owner: alex
--

CREATE UNIQUE INDEX "Admin_email_key" ON public."Admin" USING btree (email);


--
-- Name: AssetShare_assetId_sharedWithEmail_key; Type: INDEX; Schema: public; Owner: alex
--

CREATE UNIQUE INDEX "AssetShare_assetId_sharedWithEmail_key" ON public."AssetShare" USING btree ("assetId", "sharedWithEmail");


--
-- Name: ChatContact_requesterId_addresseeId_key; Type: INDEX; Schema: public; Owner: alex
--

CREATE UNIQUE INDEX "ChatContact_requesterId_addresseeId_key" ON public."ChatContact" USING btree ("requesterId", "addresseeId");


--
-- Name: ChatRoomMember_roomId_userId_key; Type: INDEX; Schema: public; Owner: alex
--

CREATE UNIQUE INDEX "ChatRoomMember_roomId_userId_key" ON public."ChatRoomMember" USING btree ("roomId", "userId");


--
-- Name: FeatureFlag_key_tenantId_key; Type: INDEX; Schema: public; Owner: alex
--

CREATE UNIQUE INDEX "FeatureFlag_key_tenantId_key" ON public."FeatureFlag" USING btree (key, "tenantId");


--
-- Name: LocaleProfile_countryCode_key; Type: INDEX; Schema: public; Owner: alex
--

CREATE UNIQUE INDEX "LocaleProfile_countryCode_key" ON public."LocaleProfile" USING btree ("countryCode");


--
-- Name: Metatag_key_key; Type: INDEX; Schema: public; Owner: alex
--

CREATE UNIQUE INDEX "Metatag_key_key" ON public."Metatag" USING btree (key);


--
-- Name: NotificationTemplate_key_key; Type: INDEX; Schema: public; Owner: alex
--

CREATE UNIQUE INDEX "NotificationTemplate_key_key" ON public."NotificationTemplate" USING btree (key);


--
-- Name: Plan_name_key; Type: INDEX; Schema: public; Owner: alex
--

CREATE UNIQUE INDEX "Plan_name_key" ON public."Plan" USING btree (name);


--
-- Name: PushToken_token_key; Type: INDEX; Schema: public; Owner: alex
--

CREATE UNIQUE INDEX "PushToken_token_key" ON public."PushToken" USING btree (token);


--
-- Name: StockItem_assetId_sku_key; Type: INDEX; Schema: public; Owner: alex
--

CREATE UNIQUE INDEX "StockItem_assetId_sku_key" ON public."StockItem" USING btree ("assetId", sku);


--
-- Name: Subscription_tenantId_key; Type: INDEX; Schema: public; Owner: alex
--

CREATE UNIQUE INDEX "Subscription_tenantId_key" ON public."Subscription" USING btree ("tenantId");


--
-- Name: Tenant_email_key; Type: INDEX; Schema: public; Owner: alex
--

CREATE UNIQUE INDEX "Tenant_email_key" ON public."Tenant" USING btree (email);


--
-- Name: Tenant_slug_key; Type: INDEX; Schema: public; Owner: alex
--

CREATE UNIQUE INDEX "Tenant_slug_key" ON public."Tenant" USING btree (slug);


--
-- Name: TranslationOverride_tenantId_key_language_key; Type: INDEX; Schema: public; Owner: alex
--

CREATE UNIQUE INDEX "TranslationOverride_tenantId_key_language_key" ON public."TranslationOverride" USING btree ("tenantId", key, language);


--
-- Name: UserModuleData_ownerEmail_idx; Type: INDEX; Schema: public; Owner: alex
--

CREATE INDEX "UserModuleData_ownerEmail_idx" ON public."UserModuleData" USING btree ("ownerEmail");


--
-- Name: UserModuleData_ownerEmail_module_key; Type: INDEX; Schema: public; Owner: alex
--

CREATE UNIQUE INDEX "UserModuleData_ownerEmail_module_key" ON public."UserModuleData" USING btree ("ownerEmail", module);


--
-- Name: User_email_tenantId_key; Type: INDEX; Schema: public; Owner: alex
--

CREATE UNIQUE INDEX "User_email_tenantId_key" ON public."User" USING btree (email, "tenantId");


--
-- Name: Asset Asset_locationId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: alex
--

ALTER TABLE ONLY public."Asset"
    ADD CONSTRAINT "Asset_locationId_fkey" FOREIGN KEY ("locationId") REFERENCES public."Location"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: Asset Asset_parentId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: alex
--

ALTER TABLE ONLY public."Asset"
    ADD CONSTRAINT "Asset_parentId_fkey" FOREIGN KEY ("parentId") REFERENCES public."Asset"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: Asset Asset_tenantId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: alex
--

ALTER TABLE ONLY public."Asset"
    ADD CONSTRAINT "Asset_tenantId_fkey" FOREIGN KEY ("tenantId") REFERENCES public."Tenant"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: AuditLog AuditLog_adminId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: alex
--

ALTER TABLE ONLY public."AuditLog"
    ADD CONSTRAINT "AuditLog_adminId_fkey" FOREIGN KEY ("adminId") REFERENCES public."Admin"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: AuditLog AuditLog_tenantId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: alex
--

ALTER TABLE ONLY public."AuditLog"
    ADD CONSTRAINT "AuditLog_tenantId_fkey" FOREIGN KEY ("tenantId") REFERENCES public."Tenant"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: AuditLog AuditLog_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: alex
--

ALTER TABLE ONLY public."AuditLog"
    ADD CONSTRAINT "AuditLog_userId_fkey" FOREIGN KEY ("userId") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: ChatMessage ChatMessage_roomId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: alex
--

ALTER TABLE ONLY public."ChatMessage"
    ADD CONSTRAINT "ChatMessage_roomId_fkey" FOREIGN KEY ("roomId") REFERENCES public."ChatRoom"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: ChatRoomMember ChatRoomMember_roomId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: alex
--

ALTER TABLE ONLY public."ChatRoomMember"
    ADD CONSTRAINT "ChatRoomMember_roomId_fkey" FOREIGN KEY ("roomId") REFERENCES public."ChatRoom"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: ComplianceAcceptance ComplianceAcceptance_docId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: alex
--

ALTER TABLE ONLY public."ComplianceAcceptance"
    ADD CONSTRAINT "ComplianceAcceptance_docId_fkey" FOREIGN KEY ("docId") REFERENCES public."ComplianceDoc"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: FeatureFlag FeatureFlag_tenantId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: alex
--

ALTER TABLE ONLY public."FeatureFlag"
    ADD CONSTRAINT "FeatureFlag_tenantId_fkey" FOREIGN KEY ("tenantId") REFERENCES public."Tenant"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: Invoice Invoice_subscriptionId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: alex
--

ALTER TABLE ONLY public."Invoice"
    ADD CONSTRAINT "Invoice_subscriptionId_fkey" FOREIGN KEY ("subscriptionId") REFERENCES public."Subscription"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: Location Location_parentId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: alex
--

ALTER TABLE ONLY public."Location"
    ADD CONSTRAINT "Location_parentId_fkey" FOREIGN KEY ("parentId") REFERENCES public."Location"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: Location Location_tenantId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: alex
--

ALTER TABLE ONLY public."Location"
    ADD CONSTRAINT "Location_tenantId_fkey" FOREIGN KEY ("tenantId") REFERENCES public."Tenant"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: NotificationLog NotificationLog_templateId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: alex
--

ALTER TABLE ONLY public."NotificationLog"
    ADD CONSTRAINT "NotificationLog_templateId_fkey" FOREIGN KEY ("templateId") REFERENCES public."NotificationTemplate"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: PushToken PushToken_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: alex
--

ALTER TABLE ONLY public."PushToken"
    ADD CONSTRAINT "PushToken_userId_fkey" FOREIGN KEY ("userId") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: StockItem StockItem_assetId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: alex
--

ALTER TABLE ONLY public."StockItem"
    ADD CONSTRAINT "StockItem_assetId_fkey" FOREIGN KEY ("assetId") REFERENCES public."Asset"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: StockMovement StockMovement_itemId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: alex
--

ALTER TABLE ONLY public."StockMovement"
    ADD CONSTRAINT "StockMovement_itemId_fkey" FOREIGN KEY ("itemId") REFERENCES public."StockItem"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: Subscription Subscription_planId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: alex
--

ALTER TABLE ONLY public."Subscription"
    ADD CONSTRAINT "Subscription_planId_fkey" FOREIGN KEY ("planId") REFERENCES public."Plan"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: Subscription Subscription_tenantId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: alex
--

ALTER TABLE ONLY public."Subscription"
    ADD CONSTRAINT "Subscription_tenantId_fkey" FOREIGN KEY ("tenantId") REFERENCES public."Tenant"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: Tenant Tenant_localeId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: alex
--

ALTER TABLE ONLY public."Tenant"
    ADD CONSTRAINT "Tenant_localeId_fkey" FOREIGN KEY ("localeId") REFERENCES public."LocaleProfile"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: TranslationOverride TranslationOverride_tenantId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: alex
--

ALTER TABLE ONLY public."TranslationOverride"
    ADD CONSTRAINT "TranslationOverride_tenantId_fkey" FOREIGN KEY ("tenantId") REFERENCES public."Tenant"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: User User_tenantId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: alex
--

ALTER TABLE ONLY public."User"
    ADD CONSTRAINT "User_tenantId_fkey" FOREIGN KEY ("tenantId") REFERENCES public."Tenant"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- PostgreSQL database dump complete
--

\unrestrict uviTvDjTCrJDfV4MBzM51iv8NIyhE2abBfHMNsyCalIdkAz6dZeyfsAx1duPum2

