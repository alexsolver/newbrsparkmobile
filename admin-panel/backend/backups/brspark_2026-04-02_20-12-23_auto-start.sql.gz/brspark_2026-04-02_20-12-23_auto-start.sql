--
-- PostgreSQL database dump
--

\restrict 2xt2YKOt8SNvgKsWdighBeBqcthyuESGpcMOKKfshXegsXwNRmFwzBAD1M4Tagd

-- Dumped from database version 14.20 (Homebrew)
-- Dumped by pg_dump version 14.20 (Homebrew)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: AssetType; Type: TYPE; Schema: public; Owner: alex
--

CREATE TYPE public."AssetType" AS ENUM (
    'REAL_ESTATE',
    'TERRESTRIAL',
    'AQUATIC',
    'SPECIAL',
    'OTHER'
);


ALTER TYPE public."AssetType" OWNER TO alex;

--
-- Name: AuditCategory; Type: TYPE; Schema: public; Owner: alex
--

CREATE TYPE public."AuditCategory" AS ENUM (
    'AUTH',
    'DATA',
    'ADMIN',
    'SYSTEM'
);


ALTER TYPE public."AuditCategory" OWNER TO alex;

--
-- Name: BillingCycle; Type: TYPE; Schema: public; Owner: alex
--

CREATE TYPE public."BillingCycle" AS ENUM (
    'MONTHLY',
    'YEARLY'
);


ALTER TYPE public."BillingCycle" OWNER TO alex;

--
-- Name: Channel; Type: TYPE; Schema: public; Owner: alex
--

CREATE TYPE public."Channel" AS ENUM (
    'EMAIL',
    'PUSH',
    'WHATSAPP',
    'SMS'
);


ALTER TYPE public."Channel" OWNER TO alex;

--
-- Name: DocType; Type: TYPE; Schema: public; Owner: alex
--

CREATE TYPE public."DocType" AS ENUM (
    'TERMS_OF_USE',
    'PRIVACY_POLICY',
    'LGPD_DPA',
    'COOKIE_POLICY'
);


ALTER TYPE public."DocType" OWNER TO alex;

--
-- Name: IntType; Type: TYPE; Schema: public; Owner: alex
--

CREATE TYPE public."IntType" AS ENUM (
    'AI_LLM',
    'EMAIL',
    'PUSH',
    'STORAGE',
    'WEBHOOK',
    'ERP',
    'PAYMENT',
    'MAPS'
);


ALTER TYPE public."IntType" OWNER TO alex;

--
-- Name: InvoiceStatus; Type: TYPE; Schema: public; Owner: alex
--

CREATE TYPE public."InvoiceStatus" AS ENUM (
    'PENDING',
    'PAID',
    'OVERDUE',
    'VOID'
);


ALTER TYPE public."InvoiceStatus" OWNER TO alex;

--
-- Name: LocationType; Type: TYPE; Schema: public; Owner: alex
--

CREATE TYPE public."LocationType" AS ENUM (
    'BUILDING',
    'FLOOR',
    'ROOM',
    'AREA',
    'WAREHOUSE',
    'OTHER'
);


ALTER TYPE public."LocationType" OWNER TO alex;

--
-- Name: MetatagType; Type: TYPE; Schema: public; Owner: alex
--

CREATE TYPE public."MetatagType" AS ENUM (
    'ASSET_TYPE',
    'STOCK_CATEGORY',
    'SERVICE_CATEGORY',
    'ASSET_STATUS',
    'GLOBAL_TAG',
    'EXPENSE_CATEGORY',
    'REVENUE_CATEGORY',
    'MEDIA_CATEGORY'
);


ALTER TYPE public."MetatagType" OWNER TO alex;

--
-- Name: MovementType; Type: TYPE; Schema: public; Owner: alex
--

CREATE TYPE public."MovementType" AS ENUM (
    'IN',
    'OUT',
    'TRANSFER'
);


ALTER TYPE public."MovementType" OWNER TO alex;

--
-- Name: NotifStatus; Type: TYPE; Schema: public; Owner: alex
--

CREATE TYPE public."NotifStatus" AS ENUM (
    'SENT',
    'DELIVERED',
    'FAILED',
    'BOUNCED'
);


ALTER TYPE public."NotifStatus" OWNER TO alex;

--
-- Name: SubStatus; Type: TYPE; Schema: public; Owner: alex
--

CREATE TYPE public."SubStatus" AS ENUM (
    'ACTIVE',
    'PAST_DUE',
    'CANCELLED',
    'TRIALING'
);


ALTER TYPE public."SubStatus" OWNER TO alex;

--
-- Name: TelemetryEventType; Type: TYPE; Schema: public; Owner: alex
--

CREATE TYPE public."TelemetryEventType" AS ENUM (
    'SESSION_OPEN',
    'SESSION_CLOSE',
    'OS_ACCEPT',
    'OS_START',
    'CHECKIN',
    'CHECKOUT',
    'TRANSIT_START',
    'TRANSIT_END',
    'HEARTBEAT',
    'GEOFENCE_ENTER',
    'GEOFENCE_EXIT',
    'PAUSE',
    'RESUME',
    'FRAUD_FLAG',
    'INTEGRITY_CHECK',
    'POLICY_VIOLATION'
);


ALTER TYPE public."TelemetryEventType" OWNER TO alex;

--
-- Name: TenantStatus; Type: TYPE; Schema: public; Owner: alex
--

CREATE TYPE public."TenantStatus" AS ENUM (
    'TRIAL',
    'ACTIVE',
    'SUSPENDED',
    'CANCELLED'
);


ALTER TYPE public."TenantStatus" OWNER TO alex;

--
-- Name: UserRole; Type: TYPE; Schema: public; Owner: alex
--

CREATE TYPE public."UserRole" AS ENUM (
    'ADMIN',
    'MANAGER',
    'USER'
);


ALTER TYPE public."UserRole" OWNER TO alex;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: Admin; Type: TABLE; Schema: public; Owner: alex
--

CREATE TABLE public."Admin" (
    id text NOT NULL,
    email text NOT NULL,
    name text NOT NULL,
    password text NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public."Admin" OWNER TO alex;

--
-- Name: Asset; Type: TABLE; Schema: public; Owner: alex
--

CREATE TABLE public."Asset" (
    id text NOT NULL,
    "tenantId" text NOT NULL,
    "parentId" text,
    title text NOT NULL,
    type public."AssetType" NOT NULL,
    status text DEFAULT 'Operacional'::text NOT NULL,
    description text,
    "imageUrl" text,
    "locationId" text,
    metadata jsonb,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL,
    "deletedAt" timestamp(3) without time zone
);


ALTER TABLE public."Asset" OWNER TO alex;

--
-- Name: AssetShare; Type: TABLE; Schema: public; Owner: alex
--

CREATE TABLE public."AssetShare" (
    id text NOT NULL,
    "assetId" text NOT NULL,
    "ownerEmail" text NOT NULL,
    "sharedWithEmail" text NOT NULL,
    permission text NOT NULL,
    modules jsonb NOT NULL,
    status text DEFAULT 'PENDING'::text NOT NULL,
    "invitedAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "expiresAt" timestamp(3) without time zone
);


ALTER TABLE public."AssetShare" OWNER TO alex;

--
-- Name: AuditLog; Type: TABLE; Schema: public; Owner: alex
--

CREATE TABLE public."AuditLog" (
    id text NOT NULL,
    "tenantId" text,
    "userId" text,
    "adminId" text,
    action text NOT NULL,
    resource text NOT NULL,
    category public."AuditCategory" NOT NULL,
    metadata jsonb,
    "ipAddress" text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public."AuditLog" OWNER TO alex;

--
-- Name: ChatContact; Type: TABLE; Schema: public; Owner: alex
--

CREATE TABLE public."ChatContact" (
    id text NOT NULL,
    "requesterId" text NOT NULL,
    "addresseeId" text NOT NULL,
    status text DEFAULT 'PENDING'::text NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public."ChatContact" OWNER TO alex;

--
-- Name: ChatMessage; Type: TABLE; Schema: public; Owner: alex
--

CREATE TABLE public."ChatMessage" (
    id text NOT NULL,
    "roomId" text NOT NULL,
    "senderId" text NOT NULL,
    "senderName" text NOT NULL,
    type text DEFAULT 'text'::text NOT NULL,
    content text,
    "mediaUrl" text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public."ChatMessage" OWNER TO alex;

--
-- Name: ChatRoom; Type: TABLE; Schema: public; Owner: alex
--

CREATE TABLE public."ChatRoom" (
    id text NOT NULL,
    name text,
    description text,
    "avatarColor" text DEFAULT '#2563EB'::text,
    "isGroup" boolean DEFAULT false NOT NULL,
    "creatorId" text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public."ChatRoom" OWNER TO alex;

--
-- Name: ChatRoomMember; Type: TABLE; Schema: public; Owner: alex
--

CREATE TABLE public."ChatRoomMember" (
    id text NOT NULL,
    "roomId" text NOT NULL,
    "userId" text NOT NULL,
    role text DEFAULT 'MEMBER'::text NOT NULL,
    "joinedAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "lastReadAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public."ChatRoomMember" OWNER TO alex;

--
-- Name: ChecklistExecution; Type: TABLE; Schema: public; Owner: alex
--

CREATE TABLE public."ChecklistExecution" (
    id text NOT NULL,
    "templateId" text,
    "ownerEmail" text NOT NULL,
    "assetId" text,
    status text DEFAULT 'PENDING'::text NOT NULL,
    responses jsonb,
    metadata jsonb,
    "locationAddress" text,
    "locationLat" double precision,
    "locationLng" double precision,
    "locationRadius" integer,
    "locationZoneType" text,
    "locationPolygon" jsonb,
    "gpsLocation" jsonb,
    "startedAt" timestamp(3) without time zone,
    "completedAt" timestamp(3) without time zone,
    "syncedAt" timestamp(3) without time zone,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public."ChecklistExecution" OWNER TO alex;

--
-- Name: ChecklistTemplate; Type: TABLE; Schema: public; Owner: alex
--

CREATE TABLE public."ChecklistTemplate" (
    id text NOT NULL,
    "tenantId" text,
    title text NOT NULL,
    description text,
    settings jsonb NOT NULL,
    "schemaData" jsonb NOT NULL,
    metadata jsonb,
    version integer DEFAULT 1 NOT NULL,
    "isActive" boolean DEFAULT true NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public."ChecklistTemplate" OWNER TO alex;

--
-- Name: CollectionPolicy; Type: TABLE; Schema: public; Owner: alex
--

CREATE TABLE public."CollectionPolicy" (
    id text NOT NULL,
    "tenantId" text,
    "sectorCode" text,
    label text DEFAULT 'Padrão'::text NOT NULL,
    "locationEnabled" boolean DEFAULT true NOT NULL,
    "locationBackgroundEnabled" boolean DEFAULT true NOT NULL,
    "locationIntervalIdleMin" integer DEFAULT 30 NOT NULL,
    "locationIntervalTransitMin" integer DEFAULT 2 NOT NULL,
    "locationIntervalOnSiteMin" integer DEFAULT 5 NOT NULL,
    "locationDistanceFilterMeters" integer DEFAULT 200 NOT NULL,
    "retentionGpsRawDays" integer DEFAULT 15 NOT NULL,
    "retentionEventsYears" integer DEFAULT 5 NOT NULL,
    "retentionAuditDays" integer DEFAULT 180 NOT NULL,
    "retentionMetricsDays" integer DEFAULT 730 NOT NULL,
    "mockGpsAction" text DEFAULT 'WARN'::text NOT NULL,
    "rootJailbreakAction" text DEFAULT 'WARN'::text NOT NULL,
    "clockDriftMaxSeconds" integer DEFAULT 300 NOT NULL,
    "requireExplicitConsent" boolean DEFAULT true NOT NULL,
    "consentGranular" boolean DEFAULT true NOT NULL,
    "legalBasis" text DEFAULT 'LGPD'::text NOT NULL,
    "requireCheckinPhoto" boolean DEFAULT false NOT NULL,
    "allowOfflineCheckin" boolean DEFAULT true NOT NULL,
    "minOnSiteMinutes" integer DEFAULT 0 NOT NULL,
    "outOfPolicyAction" text DEFAULT 'PROCEED_FLAG'::text NOT NULL,
    "isActive" boolean DEFAULT true NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public."CollectionPolicy" OWNER TO alex;

--
-- Name: ComplianceAcceptance; Type: TABLE; Schema: public; Owner: alex
--

CREATE TABLE public."ComplianceAcceptance" (
    id text NOT NULL,
    "docId" text NOT NULL,
    "userId" text,
    "tenantId" text,
    "ipAddress" text,
    "acceptedAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public."ComplianceAcceptance" OWNER TO alex;

--
-- Name: ComplianceDoc; Type: TABLE; Schema: public; Owner: alex
--

CREATE TABLE public."ComplianceDoc" (
    id text NOT NULL,
    type public."DocType" NOT NULL,
    version text NOT NULL,
    title text NOT NULL,
    content text NOT NULL,
    "isActive" boolean DEFAULT false NOT NULL,
    "publishedAt" timestamp(3) without time zone,
    "createdBy" text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL,
    "sectorCode" text,
    "tenantId" text
);


ALTER TABLE public."ComplianceDoc" OWNER TO alex;

--
-- Name: ConsentRecord; Type: TABLE; Schema: public; Owner: alex
--

CREATE TABLE public."ConsentRecord" (
    id text NOT NULL,
    "tenantId" text,
    "ownerEmail" text NOT NULL,
    "policyId" text,
    "docId" text,
    "consentType" text NOT NULL,
    accepted boolean NOT NULL,
    "ipAddress" text,
    "deviceId" text,
    "appVersion" text,
    "acceptedAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "revokedAt" timestamp(3) without time zone
);


ALTER TABLE public."ConsentRecord" OWNER TO alex;

--
-- Name: ExecutionMetric; Type: TABLE; Schema: public; Owner: alex
--

CREATE TABLE public."ExecutionMetric" (
    id text NOT NULL,
    "tenantId" text,
    "executionId" text NOT NULL,
    "ownerEmail" text NOT NULL,
    "transitDurationMin" integer,
    "siteArrivalDelayMin" integer,
    "onSiteDurationMin" integer,
    "idleTimeMin" integer,
    "distanceKm" double precision,
    "geofenceBreaches" integer DEFAULT 0 NOT NULL,
    "routeDeviationMaxMeters" integer,
    "scoreExecution" integer,
    "scoreReliability" integer,
    "scoreRisk" integer,
    "fraudFlags" jsonb,
    "calculatedAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    source text DEFAULT 'BATCH'::text NOT NULL,
    "etaMinutes" integer
);


ALTER TABLE public."ExecutionMetric" OWNER TO alex;

--
-- Name: FeatureFlag; Type: TABLE; Schema: public; Owner: alex
--

CREATE TABLE public."FeatureFlag" (
    id text NOT NULL,
    key text NOT NULL,
    label text NOT NULL,
    description text NOT NULL,
    icon text,
    enabled boolean DEFAULT true NOT NULL,
    "tenantId" text,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public."FeatureFlag" OWNER TO alex;

--
-- Name: Integration; Type: TABLE; Schema: public; Owner: alex
--

CREATE TABLE public."Integration" (
    id text NOT NULL,
    name text NOT NULL,
    type public."IntType" NOT NULL,
    icon text,
    "apiKey" text,
    "baseUrl" text,
    "webhookUrl" text,
    "lastTestedAt" timestamp(3) without time zone,
    metadata jsonb,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL,
    description text,
    status text DEFAULT 'ACTIVE'::text NOT NULL
);


ALTER TABLE public."Integration" OWNER TO alex;

--
-- Name: Invoice; Type: TABLE; Schema: public; Owner: alex
--

CREATE TABLE public."Invoice" (
    id text NOT NULL,
    "subscriptionId" text NOT NULL,
    amount numeric(10,2) NOT NULL,
    status public."InvoiceStatus" DEFAULT 'PENDING'::public."InvoiceStatus" NOT NULL,
    "dueDate" timestamp(3) without time zone NOT NULL,
    "paidAt" timestamp(3) without time zone,
    "externalId" text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public."Invoice" OWNER TO alex;

--
-- Name: LocaleProfile; Type: TABLE; Schema: public; Owner: alex
--

CREATE TABLE public."LocaleProfile" (
    id text NOT NULL,
    "countryCode" text NOT NULL,
    name text NOT NULL,
    language text DEFAULT 'pt-BR'::text NOT NULL,
    currency text DEFAULT 'BRL'::text NOT NULL,
    "currencySymbol" text DEFAULT 'R$'::text NOT NULL,
    "dateFormat" text DEFAULT 'DD/MM/YYYY'::text NOT NULL,
    "numberFormat" text DEFAULT 'PT_STYLE'::text NOT NULL,
    timezone text DEFAULT 'UTC'::text NOT NULL,
    "taxIdLabel" text DEFAULT 'Tax ID'::text NOT NULL,
    "postalCodeLabel" text DEFAULT 'Postal Code'::text NOT NULL,
    "measureSystem" text DEFAULT 'METRIC'::text NOT NULL,
    "isActive" boolean DEFAULT true NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public."LocaleProfile" OWNER TO alex;

--
-- Name: Location; Type: TABLE; Schema: public; Owner: alex
--

CREATE TABLE public."Location" (
    id text NOT NULL,
    "tenantId" text NOT NULL,
    name text NOT NULL,
    type public."LocationType" DEFAULT 'BUILDING'::public."LocationType" NOT NULL,
    address text,
    floor text,
    room text,
    icon text,
    latitude double precision,
    longitude double precision,
    "parentId" text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public."Location" OWNER TO alex;

--
-- Name: Metatag; Type: TABLE; Schema: public; Owner: alex
--

CREATE TABLE public."Metatag" (
    id text NOT NULL,
    type public."MetatagType" NOT NULL,
    key text NOT NULL,
    "ptBr" text NOT NULL,
    "enUs" text NOT NULL,
    "esEs" text NOT NULL,
    icon text,
    color text,
    "isActive" boolean DEFAULT true NOT NULL,
    "sortOrder" integer DEFAULT 0 NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public."Metatag" OWNER TO alex;

--
-- Name: NotificationLog; Type: TABLE; Schema: public; Owner: alex
--

CREATE TABLE public."NotificationLog" (
    id text NOT NULL,
    "templateId" text NOT NULL,
    recipient text NOT NULL,
    channel public."Channel" NOT NULL,
    status public."NotifStatus" DEFAULT 'SENT'::public."NotifStatus" NOT NULL,
    "sentAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    metadata jsonb
);


ALTER TABLE public."NotificationLog" OWNER TO alex;

--
-- Name: NotificationTemplate; Type: TABLE; Schema: public; Owner: alex
--

CREATE TABLE public."NotificationTemplate" (
    id text NOT NULL,
    key text NOT NULL,
    label text NOT NULL,
    channel public."Channel" NOT NULL,
    subject text,
    body text NOT NULL,
    variables jsonb,
    "isActive" boolean DEFAULT true NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public."NotificationTemplate" OWNER TO alex;

--
-- Name: Plan; Type: TABLE; Schema: public; Owner: alex
--

CREATE TABLE public."Plan" (
    id text NOT NULL,
    name text NOT NULL,
    "priceMonthly" numeric(10,2) NOT NULL,
    "priceYearly" numeric(10,2) NOT NULL,
    "maxAssets" integer NOT NULL,
    "maxUsers" integer NOT NULL,
    "storageGb" integer NOT NULL,
    features jsonb NOT NULL,
    "isActive" boolean DEFAULT true NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public."Plan" OWNER TO alex;

--
-- Name: PushToken; Type: TABLE; Schema: public; Owner: alex
--

CREATE TABLE public."PushToken" (
    id text NOT NULL,
    "userId" text NOT NULL,
    token text NOT NULL,
    device text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public."PushToken" OWNER TO alex;

--
-- Name: ServiceProvider; Type: TABLE; Schema: public; Owner: alex
--

CREATE TABLE public."ServiceProvider" (
    id text NOT NULL,
    name text NOT NULL,
    category text NOT NULL,
    rating double precision DEFAULT 0 NOT NULL,
    reviews integer DEFAULT 0 NOT NULL,
    photo text,
    tags jsonb,
    keywords text,
    phone text,
    email text,
    city text,
    state text DEFAULT 'SP'::text NOT NULL,
    verified boolean DEFAULT false NOT NULL,
    "isActive" boolean DEFAULT true NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public."ServiceProvider" OWNER TO alex;

--
-- Name: StockItem; Type: TABLE; Schema: public; Owner: alex
--

CREATE TABLE public."StockItem" (
    id text NOT NULL,
    "assetId" text NOT NULL,
    name text NOT NULL,
    sku text NOT NULL,
    "currentStock" integer DEFAULT 0 NOT NULL,
    "minStock" integer DEFAULT 1 NOT NULL,
    unit text DEFAULT 'un'::text NOT NULL,
    "subLocation" text,
    "unitPrice" numeric(10,2),
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public."StockItem" OWNER TO alex;

--
-- Name: StockMovement; Type: TABLE; Schema: public; Owner: alex
--

CREATE TABLE public."StockMovement" (
    id text NOT NULL,
    "itemId" text NOT NULL,
    type public."MovementType" NOT NULL,
    quantity integer NOT NULL,
    reason text,
    "fromAssetId" text,
    "toAssetId" text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public."StockMovement" OWNER TO alex;

--
-- Name: Subscription; Type: TABLE; Schema: public; Owner: alex
--

CREATE TABLE public."Subscription" (
    id text NOT NULL,
    "tenantId" text NOT NULL,
    "planId" text NOT NULL,
    "billingCycle" public."BillingCycle" DEFAULT 'MONTHLY'::public."BillingCycle" NOT NULL,
    status public."SubStatus" DEFAULT 'ACTIVE'::public."SubStatus" NOT NULL,
    "currentStart" timestamp(3) without time zone NOT NULL,
    "currentEnd" timestamp(3) without time zone NOT NULL,
    "cancelledAt" timestamp(3) without time zone,
    "trialEndsAt" timestamp(3) without time zone,
    "externalId" text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public."Subscription" OWNER TO alex;

--
-- Name: TechnicianProfile; Type: TABLE; Schema: public; Owner: alex
--

CREATE TABLE public."TechnicianProfile" (
    id text NOT NULL,
    "userId" text NOT NULL,
    status text DEFAULT 'PENDING'::text NOT NULL,
    score double precision DEFAULT 5.0 NOT NULL,
    cft text,
    specialty text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public."TechnicianProfile" OWNER TO alex;

--
-- Name: TelemetryEvent; Type: TABLE; Schema: public; Owner: alex
--

CREATE TABLE public."TelemetryEvent" (
    id text NOT NULL,
    "tenantId" text,
    "ownerEmail" text NOT NULL,
    "deviceId" text,
    "executionId" text,
    "eventType" public."TelemetryEventType" NOT NULL,
    lat double precision,
    lng double precision,
    accuracy double precision,
    altitude double precision,
    speed double precision,
    heading double precision,
    "locationSource" text,
    "batteryLevel" double precision,
    "batteryCharging" boolean,
    "networkType" text,
    "appVersion" text,
    "osVersion" text,
    "deviceModel" text,
    "isMockLocation" boolean DEFAULT false NOT NULL,
    "isRooted" boolean DEFAULT false NOT NULL,
    "clockDriftMs" integer,
    "serverTimestamp" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "deviceTimestamp" timestamp(3) without time zone,
    payload jsonb,
    "retentionTier" text DEFAULT 'OPERATIONAL'::text NOT NULL,
    "expiresAt" timestamp(3) without time zone
);


ALTER TABLE public."TelemetryEvent" OWNER TO alex;

--
-- Name: Tenant; Type: TABLE; Schema: public; Owner: alex
--

CREATE TABLE public."Tenant" (
    id text NOT NULL,
    name text NOT NULL,
    slug text NOT NULL,
    email text NOT NULL,
    phone text,
    "taxId" text,
    "defaultLang" text DEFAULT 'pt-BR'::text NOT NULL,
    status public."TenantStatus" DEFAULT 'TRIAL'::public."TenantStatus" NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL,
    "avatarUrl" text,
    "localeId" text,
    "ownerName" text NOT NULL,
    "sectorCode" text
);


ALTER TABLE public."Tenant" OWNER TO alex;

--
-- Name: TranslationOverride; Type: TABLE; Schema: public; Owner: alex
--

CREATE TABLE public."TranslationOverride" (
    id text NOT NULL,
    "tenantId" text NOT NULL,
    key text NOT NULL,
    language text NOT NULL,
    value text NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public."TranslationOverride" OWNER TO alex;

--
-- Name: User; Type: TABLE; Schema: public; Owner: alex
--

CREATE TABLE public."User" (
    id text NOT NULL,
    "tenantId" text NOT NULL,
    email text NOT NULL,
    name text NOT NULL,
    password text NOT NULL,
    role public."UserRole" DEFAULT 'USER'::public."UserRole" NOT NULL,
    "isActive" boolean DEFAULT true NOT NULL,
    "lastLogin" timestamp(3) without time zone,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL,
    "avatarUrl" text
);


ALTER TABLE public."User" OWNER TO alex;

--
-- Name: UserModuleData; Type: TABLE; Schema: public; Owner: alex
--

CREATE TABLE public."UserModuleData" (
    id text NOT NULL,
    "ownerEmail" text NOT NULL,
    module text NOT NULL,
    data jsonb NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public."UserModuleData" OWNER TO alex;

--
-- Name: _prisma_migrations; Type: TABLE; Schema: public; Owner: alex
--

CREATE TABLE public._prisma_migrations (
    id character varying(36) NOT NULL,
    checksum character varying(64) NOT NULL,
    finished_at timestamp with time zone,
    migration_name character varying(255) NOT NULL,
    logs text,
    rolled_back_at timestamp with time zone,
    started_at timestamp with time zone DEFAULT now() NOT NULL,
    applied_steps_count integer DEFAULT 0 NOT NULL
);


ALTER TABLE public._prisma_migrations OWNER TO alex;

--
-- Data for Name: Admin; Type: TABLE DATA; Schema: public; Owner: alex
--

COPY public."Admin" (id, email, name, password, "createdAt", "updatedAt") FROM stdin;
cmnhrwhb50000l828dmz8w1u0	admin@brspark.com	Administrador Demo	$2a$10$K5Gw6YEgD8dKkFReUMkvrOWrSyDk3gQVybAA8bCTSAGk5r0SGkesW	2026-04-02 17:53:13.87	2026-04-02 17:53:24.554
\.


--
-- Data for Name: Asset; Type: TABLE DATA; Schema: public; Owner: alex
--

COPY public."Asset" (id, "tenantId", "parentId", title, type, status, description, "imageUrl", "locationId", metadata, "createdAt", "updatedAt", "deletedAt") FROM stdin;
\.


--
-- Data for Name: AssetShare; Type: TABLE DATA; Schema: public; Owner: alex
--

COPY public."AssetShare" (id, "assetId", "ownerEmail", "sharedWithEmail", permission, modules, status, "invitedAt", "expiresAt") FROM stdin;
\.


--
-- Data for Name: AuditLog; Type: TABLE DATA; Schema: public; Owner: alex
--

COPY public."AuditLog" (id, "tenantId", "userId", "adminId", action, resource, category, metadata, "ipAddress", "createdAt") FROM stdin;
cmnhhqj64000i3yrjoyd41ka7	cmnhhqj5c000e3yrjmvwv50er	cmnhhqj5w000g3yrj2m7fnu6n	\N	USER_REGISTER	alex@brspark.com	AUTH	\N	\N	2026-04-02 13:08:40.204
cmnhhqp3i000k3yrj3ksacor8	cmnhhqj5c000e3yrjmvwv50er	cmnhhqj5w000g3yrj2m7fnu6n	\N	USER_LOGIN	alex@brspark.com	AUTH	\N	\N	2026-04-02 13:08:47.887
cmnhhrrqf000m3yrj8k5f9izk	cmnhhqj5c000e3yrjmvwv50er	cmnhhqj5w000g3yrj2m7fnu6n	\N	USER_LOGIN	alex@brspark.com	AUTH	\N	\N	2026-04-02 13:09:37.959
cmnhhz6p8007i3yrjuoi7xhv8	cmnhhqj5c000e3yrjmvwv50er	cmnhhqj5w000g3yrj2m7fnu6n	\N	USER_LOGIN	alex@brspark.com	AUTH	\N	\N	2026-04-02 13:15:23.949
cmnhr9dmh0a309g8mueiw933b	cmnhhqj5c000e3yrjmvwv50er	cmnhhqj5w000g3yrj2m7fnu6n	\N	USER_LOGIN	alex@brspark.com	AUTH	\N	\N	2026-04-02 17:35:16.025
cmnhrxx3p003nl0zim1gwwksj	\N	\N	\N	SYNC_OS_COMPLETED	ChecklistExecution	DATA	{"hasGps": false, "ownerEmail": "alex@brspark.com", "templateId": "chk_mnhro4is", "executionId": "cmnhrqhbi0b9j9g8mtnd7ocdb"}	\N	2026-04-02 17:54:21.012
cmnhrxx4k003ol0zioziegn64	\N	\N	\N	SYNC_OS_COMPLETED	ChecklistExecution	DATA	{"hasGps": false, "ownerEmail": "alex@brspark.com", "templateId": "chk_mnhro4is", "executionId": "cmnhrqhbi0b9j9g8mtnd7ocdb"}	\N	2026-04-02 17:54:21.045
cmnhrxx5a003pl0zi4pm4gmjp	\N	\N	\N	SYNC_OS_COMPLETED	ChecklistExecution	DATA	{"hasGps": false, "ownerEmail": "alex@brspark.com", "templateId": "chk_mnhro4is", "executionId": "cmnhrqhbi0b9j9g8mtnd7ocdb"}	\N	2026-04-02 17:54:21.071
cmnhrxx8a003ql0zitnj8vstt	\N	\N	\N	SYNC_OS_COMPLETED	ChecklistExecution	DATA	{"hasGps": false, "ownerEmail": "alex@brspark.com", "templateId": "chk_mnhro4is", "executionId": "cmnhrqhbi0b9j9g8mtnd7ocdb"}	\N	2026-04-02 17:54:21.178
cmnhry81x0052l0zieauhrl16	\N	\N	cmnhrwhb50000l828dmz8w1u0	LOGIN	Admin Console	AUTH	\N	\N	2026-04-02 17:54:35.204
cmnht03e800k2quvgtwftftfm	\N	\N	cmnhrwhb50000l828dmz8w1u0	LOGIN	Admin Console	AUTH	\N	\N	2026-04-02 18:24:02.096
cmnht46ox00pjquvgqqijwp9b	\N	\N	cmnhrwhb50000l828dmz8w1u0	LOGIN	Admin Console	AUTH	\N	\N	2026-04-02 18:27:12.993
cmnhtb56h00z2quvgaotk0p0n	\N	\N	\N	SYNC_OS_COMPLETED	ChecklistExecution	DATA	{"hasGps": false, "ownerEmail": "alex@brspark.com", "templateId": "chk_mnhro4is", "executionId": "cmnht8qog00vkquvgverzll77"}	\N	2026-04-02 18:32:37.625
cmnhtb56l00z3quvgehlfcmk0	\N	\N	\N	SYNC_OS_COMPLETED	ChecklistExecution	DATA	{"hasGps": false, "ownerEmail": "alex@brspark.com", "templateId": "chk_mnhro4is", "executionId": "cmnht8qog00vkquvgverzll77"}	\N	2026-04-02 18:32:37.629
cmnhtrfo7006sf5jr99vysotq	\N	\N	\N	SYNC_OS_COMPLETED	ChecklistExecution	DATA	{"hasGps": false, "ownerEmail": "alex@brspark.com", "templateId": "chk_mnhro4is", "executionId": "cmnhtnyp4001zf5jrvv0r23qa"}	\N	2026-04-02 18:45:17.72
cmnhtrfob006tf5jraizt9s64	\N	\N	\N	SYNC_OS_COMPLETED	ChecklistExecution	DATA	{"hasGps": false, "ownerEmail": "alex@brspark.com", "templateId": "chk_mnhro4is", "executionId": "cmnhtnyp4001zf5jrvv0r23qa"}	\N	2026-04-02 18:45:17.724
cmnhv5qhn0215f5jrmh1cr3px	\N	\N	cmnhrwhb50000l828dmz8w1u0	LOGIN	Admin Console	AUTH	\N	\N	2026-04-02 19:24:24.539
cmnhv9qg9026hf5jr9oty8kbv	\N	\N	cmnhrwhb50000l828dmz8w1u0	LOGIN	Admin Console	AUTH	\N	\N	2026-04-02 19:27:31.113
cmnhwj49a0001k84ws2tksgg4	\N	\N	cmnhrwhb50000l828dmz8w1u0	LOGIN	Admin Console	AUTH	\N	\N	2026-04-02 20:02:48.526
cmnhyj5fh0003k84we7wyje15	\N	\N	cmnhrwhb50000l828dmz8w1u0	LOGIN	Admin Console	AUTH	\N	\N	2026-04-02 20:58:49.277
cmnhz0llw00gck84wcp6w8aj9	\N	\N	\N	SYNC_OS_COMPLETED	ChecklistExecution	DATA	{"hasGps": false, "ownerEmail": "alex@brspark.com", "templateId": "chk_mnhro4is", "executionId": "cmnhykdhy0005k84w6xci9f1x"}	\N	2026-04-02 21:12:23.396
cmnhz0lmr00gdk84wyxyvcjpz	\N	\N	\N	SYNC_OS_COMPLETED	ChecklistExecution	DATA	{"hasGps": false, "ownerEmail": "alex@brspark.com", "templateId": "chk_mnhro4is", "executionId": "cmnhykdhy0005k84w6xci9f1x"}	\N	2026-04-02 21:12:23.427
cmni0w9bb0314k84we0fsy9v7	\N	\N	\N	SYNC_OS_COMPLETED	ChecklistExecution	DATA	{"hasGps": false, "ownerEmail": "alex@brspark.com", "templateId": "chk_mnhro4is", "executionId": "cmni0qayq02sqk84wy5bpuvea"}	\N	2026-04-02 22:05:00.071
cmni0w9be0315k84w7bw6y5pw	\N	\N	\N	SYNC_OS_COMPLETED	ChecklistExecution	DATA	{"hasGps": false, "ownerEmail": "alex@brspark.com", "templateId": "chk_mnhro4is", "executionId": "cmni0qayq02sqk84wy5bpuvea"}	\N	2026-04-02 22:05:00.074
cmni14irv03e9k84w5os3u3lt	\N	\N	\N	SYNC_OS_COMPLETED	ChecklistExecution	DATA	{"hasGps": false, "ownerEmail": "alex@brspark.com", "templateId": "chk_mnhro4is", "executionId": "cmni0zakf035wk84wuzy84yix"}	\N	2026-04-02 22:11:25.579
cmni14irw03eak84wdcjrv2a9	\N	\N	\N	SYNC_OS_COMPLETED	ChecklistExecution	DATA	{"hasGps": false, "ownerEmail": "alex@brspark.com", "templateId": "chk_mnhro4is", "executionId": "cmni0zakf035wk84wuzy84yix"}	\N	2026-04-02 22:11:25.58
\.


--
-- Data for Name: ChatContact; Type: TABLE DATA; Schema: public; Owner: alex
--

COPY public."ChatContact" (id, "requesterId", "addresseeId", status, "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: ChatMessage; Type: TABLE DATA; Schema: public; Owner: alex
--

COPY public."ChatMessage" (id, "roomId", "senderId", "senderName", type, content, "mediaUrl", "createdAt") FROM stdin;
\.


--
-- Data for Name: ChatRoom; Type: TABLE DATA; Schema: public; Owner: alex
--

COPY public."ChatRoom" (id, name, description, "avatarColor", "isGroup", "creatorId", "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: ChatRoomMember; Type: TABLE DATA; Schema: public; Owner: alex
--

COPY public."ChatRoomMember" (id, "roomId", "userId", role, "joinedAt", "lastReadAt") FROM stdin;
\.


--
-- Data for Name: ChecklistExecution; Type: TABLE DATA; Schema: public; Owner: alex
--

COPY public."ChecklistExecution" (id, "templateId", "ownerEmail", "assetId", status, responses, metadata, "locationAddress", "locationLat", "locationLng", "locationRadius", "locationZoneType", "locationPolygon", "gpsLocation", "startedAt", "completedAt", "syncedAt", "createdAt") FROM stdin;
cmnhrqhbi0b9j9g8mtnd7ocdb	chk_mnhro4is	alex@brspark.com	\N	COMPLETED	{"field_4248": "{\\"action\\":\\"CHEGADA\\",\\"timestamp\\":\\"2026-04-02T17:52:04.330Z\\",\\"coordinates\\":{\\"lat\\":-23.569983,\\"lng\\":-46.7851655},\\"address\\":\\"Parque Chico Mendes,  - Jd Bussocaba City, Osasco - SP\\",\\"traversedPath\\":[[-23.569983,-46.7851655]]}", "field_21036": "file:///Users/alex/Library/Developer/CoreSimulator/Devices/99E0B8BD-911F-42C8-A707-E7AA58227EEE/data/Containers/Data/Application/63BD2007-9626-4C9B-920B-136B093842C7/Library/Caches/ImagePicker/A7F606A3-78BC-4282-B393-F5A8E2158EE6.heic", "field_66812": "Sim", "field_75000": "SIG_V1|meta:{\\"lat\\":-23.569983,\\"lng\\":-46.7851655,\\"address\\":\\",  - Osasco, SP\\",\\"ip\\":\\"2804:7f0:9383:8b58:b9fe:d321:ec05:865c\\"}|M60.33333333333333,179.00000127156574 L61,179.00000127156574 L92,169.66666793823242 L166,140.33333460489905 L187.66666666666666,119.66666793823242 L191,102.33333460489905 L191.66666666666666,100.66666793823242 L191.66666666666666,100.33333460489905 L191.66666666666666,99.66666793823242 L191.66666666666666,99.33333460489905 L191.66666666666666,99.66666793823242|M191.66666666666666,101.00000127156574 L191.66666666666666,100.66666793823242 L103.33333333333333,73.33333460489905 L77,78.66666793823242 L58.66666666666666,100.00000127156574 L58,104.66666793823242|M59.66666666666666,99.66666793823242 L128,218.00000127156568 L133.66666666666666,222.66666793823242 L172.33333333333331,183.00000127156568 L173,173.66666793823242 L181,192.00000127156568 L213.33333333333331,199.66666793823242 L248.33333333333331,178.66666793823242 L249,178.33333460489905 L249.33333333333331,178.66666793823242 L253.66666666666663,184.33333460489905 L260.66666666666663,201.66666793823242 L262.3333333333333,207.33333460489905 L257.3333333333333,222.66666793823242 L252,228.33333460489905 L240.66666666666663,230.33333460489905 L229,230.33333460489905 L203.66666666666666,225.00000127156568 L186,218.33333460489905 L164.33333333333331,201.66666793823242 L161,188.33333460489905 L171,179.33333460489905 L174.66666666666666,177.33333460489905 L203.66666666666666,172.66666793823242 L233,169.66666793823242 L240.66666666666663,169.66666793823242 L247.66666666666663,167.00000127156574 L249.33333333333331,165.66666793823242 L256.66666666666663,157.33333460489905 L258,156.00000127156574 L282.66666666666663,150.66666793823242 L317.66666666666663,140.66666793823242 L319,140.33333460489905 L319.3333333333333,140.00000127156574 L328.66666666666663,120.66666793823242 L330.66666666666663,109.66666793823242 L330.66666666666663,108.33333460489905 L330.66666666666663,109.33333460489905 L336.3333333333333,139.33333460489905 L336.66666666666663,139.33333460489905 L336.66666666666663,138.66666793823242", "field_75975": "{\\"action\\":\\"SAIDA\\",\\"timestamp\\":\\"2026-04-02T17:51:36.803Z\\",\\"coordinates\\":{\\"lat\\":-23.569983,\\"lng\\":-46.7851655},\\"address\\":\\"Parque Chico Mendes,  - Jd Bussocaba City, Osasco - SP\\"}", "__time_field_4248": "2026-04-02T17:52:04.330Z", "__time_field_21036": "2026-04-02T17:54:01.637Z", "__time_field_66812": "2026-04-02T17:52:10.089Z", "__time_field_75000": "2026-04-02T17:54:17.283Z", "__time_field_75975": "2026-04-02T17:51:36.804Z", "__section_end_page_1": "2026-04-02T17:54:19.304Z", "__section_start_page_1": "2026-04-02T17:51:37.044Z"}	{"icon": "build-outline", "refId": "chk_mnhro4is", "title": "Rota", "acceptedAt": "2026-04-02T17:50:40.054Z", "appVersion": "1.0", "receivedAt": "2026-04-02T17:48:35.018Z", "description": "Tarefa de rotina despachada.", "devicePlatform": "AppMovel", "durationSeconds": 214}	\N	44.8492	7.343651	150	segment	[[44.849368, 7.343243], [44.849033, 7.34406]]	null	2026-04-02 17:50:44.616	2026-04-02 17:54:19.305	2026-04-02 17:54:21.044	2026-04-02 17:48:33.965
cmnht8qog00vkquvgverzll77	chk_mnhro4is	alex@brspark.com	\N	COMPLETED	{"field_4248": "{\\"action\\":\\"CHEGADA\\",\\"timestamp\\":\\"2026-04-02T18:31:40.775Z\\",\\"coordinates\\":{\\"lat\\":-23.569983,\\"lng\\":-46.7851655},\\"address\\":\\"Parque Chico Mendes,  - Jd Bussocaba City, Osasco - SP\\",\\"traversedPath\\":[[-23.569983,-46.7851655],[-23.569983,-46.7851655]]}", "field_21036": "file:///Users/alex/Library/Developer/CoreSimulator/Devices/99E0B8BD-911F-42C8-A707-E7AA58227EEE/data/Containers/Data/Application/63BD2007-9626-4C9B-920B-136B093842C7/Library/Caches/ImagePicker/01481CF1-D738-41CB-8EB6-EC38B439637C.jpg", "field_66812": "Sim", "field_75000": "SIG_V1|meta:{\\"lat\\":-23.569983,\\"lng\\":-46.7851655,\\"address\\":\\",  - Osasco, SP\\",\\"ip\\":\\"2804:7f0:9383:8b58:b9fe:d321:ec05:865c\\"}|M144,217.66666793823242 L186.6666666666667,196.66666793823242 L233.00000000000003,174.66666793823242 L335.6666666666667,120.33333460489908 L366.00000000000006,101.33333460489908 L366.6666666666667,100.33333460489908 L365.6666666666667,101.00000127156574 L343.6666666666667,126.66666793823242 L335.33333333333337,133.66666793823242 L306.6666666666667,152.66666793823242 L266.33333333333337,172.66666793823242 L232.33333333333337,187.33333460489905 L207.00000000000003,192.00000127156574 L195.33333333333337,193.33333460489905 L185.6666666666667,190.00000127156574 L174.00000000000003,185.33333460489905 L168.6666666666667,176.33333460489908 L159.6666666666667,145.00000127156574 L158.33333333333337,133.33333460489908 L159.00000000000006,131.66666793823242 L165.33333333333337,131.33333460489908 L177.00000000000003,135.33333460489908 L192.33333333333337,148.00000127156574 L218.00000000000003,172.00000127156574 L238.33333333333337,197.33333460489905 L249.66666666666669,210.00000127156574 L278.6666666666667,238.00000127156574 L335.6666666666667,235.00000127156574 L392.00000000000006,205.00000127156574 L392.33333333333337,204.66666793823242 L392.33333333333337,205.33333460489905 L393.6666666666667,206.66666793823242 L393.6666666666667,207.00000127156574 L394.33333333333337,207.00000127156574 L398.00000000000006,204.66666793823242 L411.00000000000006,194.33333460489905 L423.00000000000006,180.66666793823242 L426.6666666666667,171.00000127156574 L426.6666666666667,170.00000127156574 L423.00000000000006,168.66666793823242 L409.33333333333337,168.66666793823242 L401.6666666666667,173.33333460489908 L400.6666666666667,175.66666793823242 L400.6666666666667,176.00000127156574 L402.6666666666667,176.33333460489908 L421.6666666666667,166.66666793823242 L436.6666666666667,156.00000127156574 L448.33333333333337,150.00000127156574 L449,150.66666793823242 L450.6666666666667,161.00000127156574 L447.6666666666667,168.66666793823242 L426.33333333333337,186.66666793823242 L410.6666666666667,190.66666793823242 L403.6666666666667,189.66666793823242 L402.00000000000006,182.00000127156574 L402.00000000000006,172.66666793823242 L409.00000000000006,162.00000127156574 L418.33333333333337,159.00000127156574 L434,163.33333460489908 L444.33333333333337,169.00000127156574 L461.6666666666667,183.66666793823242 L469,190.00000127156574 L478.6666666666667,193.00000127156574 L486.33333333333337,193.00000127156574 L495.66666666666674,186.00000127156574 L501,174.66666793823242 L502.33333333333337,170.33333460489908 L502.66666666666674,170.33333460489908 L504,171.00000127156574 L507.66666666666674,174.66666793823242 L515.3333333333334,178.66666793823242 L526.6666666666667,179.66666793823242 L532.3333333333334,178.00000127156574 L542,173.66666793823242 L563,165.00000127156574 L564.3333333333334,165.00000127156574 L564.3333333333334,165.33333460489908 L565.3333333333334,165.33333460489908 L570.6666666666667,164.66666793823242 L576.3333333333334,164.00000127156574 L586,164.00000127156574 L588.6666666666667,164.00000127156574 L590.6666666666667,164.00000127156574 L595,164.00000127156574 L604.6666666666666,163.33333460489908 L616,162.33333460489908 L617.6666666666666,163.66666793823242 L618.6666666666666,165.00000127156574 L620.3333333333334,166.00000127156574 L634.3333333333334,158.33333460489908 L643,152.00000127156574 L653.3333333333334,146.00000127156574 L656.6666666666666,145.66666793823242 L658,147.33333460489908 L661.6666666666666,152.00000127156574 L664,151.33333460489908 L671.3333333333334,138.00000127156574 L675,126.33333460489908 L678.6666666666666,112.66666793823242 L682.6666666666666,95.00000127156574 L686,85.33333460489908 L686.6666666666666,84.33333460489908 L687.3333333333334,84.33333460489908 L687.6666666666666,84.66666793823242 L694,94.00000127156574 L700.6666666666666,109.33333460489908 L705.3333333333334,199.00000127156574 L686.6666666666666,222.00000127156574 L652.6666666666666,236.33333460489905 L613,239.66666793823242 L569.3333333333334,229.66666793823242 L529.3333333333334,213.00000127156574 L495,193.33333460489905 L472,179.33333460489908 L472.6666666666667,175.00000127156574 L474.6666666666667,169.66666793823242 L480,161.00000127156574 L489.6666666666667,156.00000127156574 L501,154.00000127156574 L526.6666666666667,152.66666793823242 L612,168.00000127156574 L645.6666666666666,177.66666793823242 L665.3333333333334,186.00000127156574 L668,187.33333460489905 L672,192.00000127156574 L687.6666666666666,205.33333460489905 L693.3333333333334,206.66666793823242 L709,208.00000127156574 L730.3333333333334,202.33333460489905 L742.6666666666666,194.66666793823242 L759.3333333333334,173.66666793823242 L763.6666666666666,148.00000127156574 L765,130.33333460489908 L762.6666666666666,126.66666793823242 L761,125.00000127156574 L756.3333333333334,123.33333460489908 L745,123.33333460489908 L737.3333333333334,128.00000127156574 L722,144.33333460489908 L720.3333333333334,148.33333460489908 L719.6666666666666,146.33333460489908 L718.6666666666666,136.66666793823242 L718.6666666666666,127.00000127156574 L724.6666666666666,113.33333460489908 L741,105.33333460489908 L764.6666666666666,103.66666793823242 L796,113.66666793823242 L801.3333333333334,116.66666793823242 L807,119.00000127156574 L817.3333333333334,117.66666793823242 L818,115.00000127156574 L817,110.00000127156574 L816.3333333333334,109.00000127156574 L816,109.00000127156574", "field_75975": "{\\"action\\":\\"SAIDA\\",\\"timestamp\\":\\"2026-04-02T18:31:01.016Z\\",\\"coordinates\\":{\\"lat\\":-23.569983,\\"lng\\":-46.7851655},\\"address\\":\\"Parque Chico Mendes,  - Jd Bussocaba City, Osasco - SP\\"}", "__time_field_4248": "2026-04-02T18:31:40.775Z", "__time_field_21036": "2026-04-02T18:32:08.565Z", "__time_field_66812": "2026-04-02T18:31:53.660Z", "__time_field_75000": "2026-04-02T18:32:31.588Z", "__time_field_75975": "2026-04-02T18:31:01.016Z", "__section_end_page_1": "2026-04-02T18:32:37.205Z", "__section_start_page_1": "2026-04-02T18:31:01.039Z"}	{"icon": "build-outline", "refId": "chk_mnhro4is", "title": "Rota", "acceptedAt": "2026-04-02T18:30:53.912Z", "appVersion": "1.0", "receivedAt": "2026-04-02T18:30:48.175Z", "description": "Tarefa de rotina despachada.", "devicePlatform": "AppMovel", "durationSeconds": 103}	\N	-17.20713	-49.918002	150	segment	[[-17.205391, -49.946573], [-17.208869, -49.889431]]	null	2026-04-02 18:30:53.941	2026-04-02 18:32:37.205	2026-04-02 18:32:37.615	2026-04-02 18:30:45.52
cmnhtnyp4001zf5jrvv0r23qa	chk_mnhro4is	alex@brspark.com	\N	COMPLETED	{"field_4248": "{\\"action\\":\\"CHEGADA\\",\\"timestamp\\":\\"2026-04-02T18:44:07.697Z\\",\\"coordinates\\":{\\"lat\\":-23.569983,\\"lng\\":-46.7851655},\\"address\\":\\"Parque Chico Mendes,  - Jd Bussocaba City, Osasco - SP\\",\\"traversedPath\\":[[-23.569983,-46.7851655],[-23.569983,-46.7851655],[37.33240731,-122.03046898],[37.33240731,-122.03046898],[37.33233141,-122.0312186],[37.33233141,-122.0312186],[37.33233141,-122.0312186],[37.33233141,-122.0312186],[37.33233141,-122.0312186],[37.33233141,-122.0312186]]}", "field_21036": "http://localhost:3001/uploads/storage/checklists/unknown_empresa_com/cmnhtnyp4001zf5jrvv0r23qa_field_21036_1775155517486.jpg", "field_75000": "SIG_V1|meta:{\\"lat\\":-23.569983,\\"lng\\":-46.7851655,\\"address\\":\\",  - Osasco, SP\\",\\"ip\\":\\"2804:7f0:9383:8b58:b9fe:d321:ec05:865c\\"}|M57.66666666666674,189.66666793823242 L230.00000000000003,106.33333460489908 L266.00000000000006,92.00000127156574 L320.00000000000006,69.00000127156574 L352.00000000000006,56.33333460489908 L346.00000000000006,60.000001271565736 L331.00000000000006,72.33333460489908 L316.6666666666667,82.66666793823242 L282.33333333333337,102.33333460489908 L206.00000000000003,135.33333460489908 L154.33333333333337,154.33333460489908 L116.66666666666671,169.00000127156574 L99.00000000000004,177.33333460489908 L99.00000000000004,177.66666793823242 L99.66666666666671,177.33333460489908 L125.33333333333337,169.66666793823242 L193.00000000000003,152.00000127156574 L262.6666666666667,137.66666793823242 L332.33333333333337,125.00000127156574 L372.00000000000006,120.33333460489908 L372.33333333333337,120.33333460489908 L365.00000000000006,125.00000127156574 L339.33333333333337,135.66666793823242 L325.6666666666667,141.66666793823242 L298.00000000000006,151.00000127156574 L268.33333333333337,160.33333460489908 L256.6666666666667,164.66666793823242 L238.66666666666669,170.00000127156574 L239.33333333333337,170.00000127156574 L244.66666666666669,170.66666793823242 L247.33333333333337,170.66666793823242 L247.66666666666669,170.66666793823242 L248.00000000000006,171.00000127156574 L248.66666666666669,171.00000127156574 L254.00000000000006,169.00000127156574 L284.00000000000006,155.00000127156574 L306.33333333333337,144.66666793823242 L372.33333333333337,114.33333460489908 L448.33333333333337,87.00000127156574 L514,73.00000127156574 L545.6666666666667,74.00000127156574 L552.6666666666667,84.33333460489908 L554,104.00000127156574 L534,142.00000127156574 L525,153.33333460489908 L517.3333333333334,157.33333460489908 L509.66666666666674,159.66666793823242 L506.33333333333337,160.00000127156574 L498.66666666666674,161.00000127156574 L489,164.00000127156574 L486.33333333333337,165.66666793823242 L485,166.66666793823242 L485,167.00000127156574 L484.6666666666667,167.00000127156574 L470.33333333333337,168.33333460489908 L462.6666666666667,168.33333460489908 L449,168.33333460489908 L433.6666666666667,168.33333460489908 L416.00000000000006,165.66666793823242 L413.33333333333337,165.00000127156574 L413.00000000000006,164.66666793823242 L412.33333333333337,163.33333460489908|M455.33333333333337,132.33333460489908 L459.6666666666667,133.33333460489908 L471,134.66666793823242 L490.6666666666667,137.00000127156574 L506,138.33333460489908 L514.3333333333334,138.33333460489908|M407.66666666666674,96.00000127156574 L483,82.33333460489908 L556.6666666666667,73.33333460489908 L688,66.33333460489908 L708.3333333333334,68.33333460489908 L675.3333333333334,91.33333460489908 L619.6666666666666,105.33333460489908 L558,114.33333460489908 L532.3333333333334,117.66666793823242 L531.6666666666667,118.00000127156574 L545.3333333333334,118.00000127156574 L601,112.66666793823242 L668.6666666666666,111.00000127156574 L734.3333333333334,111.00000127156574 L782.3333333333334,126.33333460489908 L723.6666666666666,189.00000127156574 L658,208.66666793823242 L578.3333333333334,216.00000127156574 L494.66666666666674,216.00000127156574 L409.00000000000006,206.66666793823242 L341.33333333333337,194.33333460489905 L293.6666666666667,182.33333460489908 L276.00000000000006,178.66666793823242 L276.33333333333337,178.66666793823242 L288.00000000000006,178.66666793823242|M503.33333333333337,172.66666793823242 L504.33333333333337,172.66666793823242 L505.66666666666674,172.66666793823242 L515.3333333333334,171.33333460489908 L551,170.00000127156574 L610.6666666666666,164.66666793823242 L734,148.66666793823242 L773.6666666666666,142.00000127156574 L807,139.00000127156574 L810.3333333333334,138.33333460489908 L811.3333333333334,138.33333460489908 L811.6666666666666,139.00000127156574 L813.6666666666666,140.00000127156574 L823.6666666666666,147.33333460489908 L827.3333333333334,151.00000127156574 L829,152.66666793823242 L831.3333333333334,156.33333460489908 L833.6666666666666,160.00000127156574 L834,160.66666793823242 L834,160.33333460489908 L836.3333333333334,148.66666793823242 L837.6666666666666,137.00000127156574 L839.6666666666666,126.66666793823242 L840,126.66666793823242 L840.3333333333334,128.00000127156574 L847.3333333333334,138.33333460489908 L850.3333333333334,144.00000127156574 L853.6666666666666,147.66666793823242 L855,148.66666793823242 L853.6666666666666,140.33333460489908 L853.6666666666666,135.00000127156574 L854.3333333333334,135.33333460489908 L855.3333333333334,136.66666793823242 L855.6666666666666,137.33333460489908 L856.3333333333334,138.33333460489908|M40.33333333333337,239.66666793823242 L41.00000000000005,239.00000127156574 L53.00000000000004,225.00000127156574 L58.666666666666714,222.00000127156574 L66.33333333333339,219.00000127156574 L69.66666666666671,219.00000127156574 L73.33333333333339,220.66666793823242 L88.66666666666671,233.33333460489905 L101.66666666666671,242.33333460489905 L109.33333333333337,247.00000127156574 L131.6666666666667,257.33333460489905 L147.33333333333337,261.33333460489905 L176.33333333333337,255.33333460489905 L188.00000000000003,243.66666793823242 L194.00000000000003,232.00000127156574 L196.33333333333337,220.33333460489905 L196.6666666666667,218.00000127156574 L197.33333333333337,218.00000127156574 L198.00000000000003,218.00000127156574 L258.6666666666667,243.33333460489905 L321.6666666666667,256.00000127156574 L341.33333333333337,256.00000127156574 L343.6666666666667,256.00000127156574 L343.6666666666667,255.33333460489905 L347.6666666666667,250.33333460489905 L361.6666666666667,241.33333460489905 L375.33333333333337,234.00000127156574 L397.33333333333337,222.00000127156574 L423.00000000000006,213.00000127156574 L464.33333333333337,207.00000127156574 L486,207.00000127156574 L505.66666666666674,211.33333460489905 L527,219.66666793823242 L530.3333333333334,220.33333460489905 L536,219.66666793823242 L541.6666666666667,218.33333460489905 L551.3333333333334,216.00000127156574 L558.6666666666667,213.33333460489905 L570.3333333333334,210.66666793823242 L575,209.66666793823242 L590.3333333333334,210.66666793823242 L598,212.66666793823242 L607.6666666666666,214.66666793823242 L617,214.66666793823242 L624.6666666666666,214.66666793823242 L640.3333333333334,212.33333460489905 L664,207.66666793823242 L685.6666666666666,205.00000127156574 L697,203.33333460489905 L707.3333333333334,205.33333460489905 L720.6666666666666,209.66666793823242 L724.3333333333334,210.33333460489905 L728,209.66666793823242 L729.6666666666666,209.00000127156574 L732,208.33333460489905 L735.6666666666666,208.33333460489905 L736.6666666666666,208.33333460489905 L738.6666666666666,210.00000127156574 L748.3333333333334,214.33333460489905 L758,219.33333460489905 L769.6666666666666,223.00000127156574 L779,223.33333460489905 L790.3333333333334,222.33333460489905 L796,220.00000127156574 L800.6666666666666,217.66666793823242 L801.3333333333334,217.33333460489905 L803,218.00000127156574 L811.6666666666666,223.33333460489905 L825.6666666666666,231.33333460489905 L833.3333333333334,234.33333460489905 L838,234.33333460489905 L843,234.00000127156574 L845.3333333333334,233.33333460489905 L847.6666666666666,233.33333460489905 L853.3333333333334,235.33333460489905 L861,238.33333460489905 L865.6666666666666,238.66666793823242 L867.6666666666666,238.66666793823242 L867.6666666666666,238.33333460489905 L876.3333333333334,233.66666793823242 L887.6666666666666,231.66666793823242 L889.6666666666666,231.00000127156574 L890,231.00000127156574", "field_75975": "{\\"action\\":\\"SAIDA\\",\\"timestamp\\":\\"2026-04-02T18:43:34.763Z\\",\\"coordinates\\":{\\"lat\\":-23.569983,\\"lng\\":-46.7851655},\\"address\\":\\"Parque Chico Mendes,  - Jd Bussocaba City, Osasco - SP\\"}", "__time_field_4248": "2026-04-02T18:44:07.697Z", "__time_field_21036": "2026-04-02T18:44:18.060Z", "__time_field_75000": "2026-04-02T18:44:32.150Z", "__time_field_75975": "2026-04-02T18:43:34.763Z", "__section_end_page_1": "2026-04-02T18:45:17.414Z", "__section_start_page_1": "2026-04-02T18:43:34.808Z"}	{"icon": "build-outline", "refId": "chk_mnhro4is", "title": "Rota", "acceptedAt": "2026-04-02T18:42:53.337Z", "appVersion": "1.0", "receivedAt": "2026-04-02T18:42:40.125Z", "description": "Tarefa de rotina despachada.", "devicePlatform": "AppMovel", "durationSeconds": 144}	\N	-16.174903	-51.91452	150	segment	[[-16.153347, -51.70166], [-16.19646, -52.12738]]	null	2026-04-02 18:42:53.356	2026-04-02 18:45:17.414	2026-04-02 18:45:17.714	2026-04-02 18:42:35.752
cmnhykdhy0005k84w6xci9f1x	chk_mnhro4is	alex@brspark.com	\N	COMPLETED	{"field_4248": "{\\"action\\":\\"CHEGADA\\",\\"timestamp\\":\\"2026-04-02T21:12:10.632Z\\",\\"coordinates\\":{\\"lat\\":37.34154237,\\"lng\\":-122.09108423},\\"address\\":\\"I-280,  - The Highlands, Los Altos - CA\\",\\"traversedPath\\":[[37.33485843,-122.03334424],[37.33485843,-122.03334424],[37.33485843,-122.03334424],[37.33485843,-122.03334424],[37.33482105,-122.03350886],[37.33482105,-122.03350886],[37.33477977,-122.03369603],[37.33477977,-122.03369603],[37.33474691,-122.03389325],[37.33474691,-122.03389325],[37.33470894,-122.03411085],[37.33470894,-122.03411085],[37.33467638,-122.03432425],[37.33467638,-122.03432425],[37.33464561,-122.03455442],[37.33464561,-122.03455442],[37.33461946,-122.03478727],[37.33461946,-122.03478727],[37.33460316,-122.0350347],[37.33460316,-122.0350347],[37.33458564,-122.03529395],[37.33458564,-122.03529395],[37.3345628,-122.03556217],[37.3345628,-122.03556217],[37.3345597,-122.03583308],[37.3345597,-122.03583308],[37.33454847,-122.03611286],[37.33454847,-122.03611286],[37.33454218,-122.03638578],[37.33454218,-122.03638578],[37.33454235,-122.03666775],[37.33454235,-122.03666775],[37.33453849,-122.03695223],[37.33453849,-122.03695223],[37.33453874,-122.03724626],[37.33453874,-122.03724626],[37.33453652,-122.03753997],[37.33453652,-122.03753997],[37.33452613,-122.03783266],[37.33452613,-122.03783266],[37.33451917,-122.03813827],[37.33451917,-122.03813827],[37.33451284,-122.03845141],[37.33451284,-122.03845141],[37.33450379,-122.03875937],[37.33450379,-122.03875937],[37.33449629,-122.03908048],[37.33449629,-122.03908048],[37.33448791,-122.03941089],[37.33448791,-122.03941089],[37.33447622,-122.0397398],[37.33447622,-122.0397398],[37.33447068,-122.04007348],[37.33447068,-122.04007348],[37.33446519,-122.04041597],[37.33446519,-122.04041597],[37.3344584,-122.04077831],[37.3344584,-122.04077831],[37.33445283,-122.04113765],[37.33445283,-122.04113765],[37.3344499,-122.04149924],[37.3344499,-122.04149924],[37.33444604,-122.04187567],[37.33444604,-122.04187567],[37.33444843,-122.04226334],[37.33444843,-122.04226334],[37.33444952,-122.04265083],[37.33444952,-122.04265083],[37.33445363,-122.04302852],[37.33445363,-122.04302852],[37.33445945,-122.04342255],[37.33445945,-122.04342255],[37.33446146,-122.04380955],[37.33446146,-122.04380955],[37.33445832,-122.04420408],[37.33445832,-122.04420408],[37.33445442,-122.04458579],[37.33445442,-122.04458579],[37.33444763,-122.04496063],[37.33444763,-122.04496063],[37.33444244,-122.045341],[37.33444244,-122.045341],[37.33443657,-122.04571727],[37.33443657,-122.04571727],[37.33441708,-122.04607568],[37.33441708,-122.04607568],[37.3343947,-122.04644121],[37.3343947,-122.04644121],[37.33436235,-122.04681002],[37.33436235,-122.04681002],[37.33431797,-122.04716524],[37.33431797,-122.04716524],[37.33426985,-122.04751058],[37.33426985,-122.04751058],[37.33420971,-122.04784191],[37.33420971,-122.04784191],[37.33414287,-122.04818683],[37.33414287,-122.04818683],[37.33406324,-122.04853007],[37.33406324,-122.04853007],[37.33398776,-122.04886543],[37.33398776,-122.04886543],[37.33390604,-122.04921638],[37.33390604,-122.04921638],[37.3338288,-122.04956959],[37.3338288,-122.04956959],[37.33375445,-122.04992666],[37.33375445,-122.04992666],[37.33367998,-122.05028306],[37.33367998,-122.05028306],[37.33360693,-122.05063996],[37.33360693,-122.05063996],[37.33352458,-122.05100549],[37.33352458,-122.05100549],[37.33344889,-122.05137547],[37.33344889,-122.05137547],[37.33336511,-122.05174034],[37.33336511,-122.05174034],[37.33328787,-122.05209673],[37.33328787,-122.05209673],[37.33321101,-122.05246948],[37.33321101,-122.05246948],[37.33313411,-122.05283635],[37.33313411,-122.05283635],[37.33305632,-122.05318781],[37.33305632,-122.05318781],[37.33298105,-122.0535463],[37.33298105,-122.0535463],[37.33290406,-122.05391527],[37.33290406,-122.05391527],[37.33282486,-122.05427997],[37.33282486,-122.05427997],[37.33275353,-122.05462472],[37.33275353,-122.05462472],[37.33268517,-122.05498531],[37.33268517,-122.05498531],[37.33260475,-122.05535361],[37.33260475,-122.05535361],[37.33252881,-122.05571688],[37.33252881,-122.05571688],[37.33245639,-122.05608208],[37.33245639,-122.05608208],[37.33238246,-122.05644652],[37.33238246,-122.05644652],[37.33236209,-122.05682698],[37.33236209,-122.05682698],[37.33232211,-122.05719234],[37.33232211,-122.05719234],[37.33229772,-122.05757204],[37.33229772,-122.05757204],[37.332289,-122.05795133],[37.332289,-122.05795133],[37.33228724,-122.05833354],[37.33228724,-122.05833354],[37.33230505,-122.05871525],[37.33230505,-122.05871525],[37.33233606,-122.05909629],[37.33233606,-122.05909629],[37.33238246,-122.0594718],[37.33238246,-122.0594718],[37.33244004,-122.05984991],[37.33244004,-122.05984991],[37.33251376,-122.06021989],[37.33251376,-122.06021989],[37.33260198,-122.06059221],[37.33260198,-122.06059221],[37.33270432,-122.06095339],[37.33270432,-122.06095339],[37.33282574,-122.06131389],[37.33282574,-122.06131389],[37.3329513,-122.06167465],[37.3329513,-122.06167465],[37.33307736,-122.06203541],[37.33307736,-122.06203541],[37.33320782,-122.06239181],[37.33320782,-122.06239181],[37.33333498,-122.06274686],[37.33333498,-122.06274686],[37.33346293,-122.06310662],[37.33346293,-122.06310662],[37.33358639,-122.06346075],[37.33358639,-122.06346075],[37.33370957,-122.06381723],[37.33370957,-122.06381723],[37.33383844,-122.06417204],[37.33383844,-122.06417204],[37.33395407,-122.06452986],[37.33395407,-122.06452986],[37.33405917,-122.06489607],[37.33405917,-122.06489607],[37.33414928,-122.06526437],[37.33414928,-122.06526437],[37.33422447,-122.06562781],[37.33422447,-122.06562781],[37.33429383,-122.06600055],[37.33429383,-122.06600055],[37.33435409,-122.06636961],[37.33435409,-122.06636961],[37.33440019,-122.06674461],[37.33440019,-122.06674461],[37.33442928,-122.06711736],[37.33442928,-122.06711736],[37.3344465,-122.06749672],[37.3344465,-122.06749672],[37.3344543,-122.06787986],[37.3344543,-122.06787986],[37.33444654,-122.06826065],[37.33444654,-122.06826065],[37.33442613,-122.06864035],[37.33442613,-122.06864035],[37.33439537,-122.06901468],[37.33439537,-122.06901468],[37.33435661,-122.06939204],[37.33435661,-122.06939204],[37.33430397,-122.06976336],[37.33430397,-122.06976336],[37.33424182,-122.07013275],[37.33424182,-122.07013275],[37.33417438,-122.07050306],[37.33417438,-122.07050306],[37.33410968,-122.07087404],[37.33410968,-122.07087404],[37.33403923,-122.07123245],[37.33403923,-122.07123245],[37.33396475,-122.07160897],[37.33396475,-122.07160897],[37.33389384,-122.07197743],[37.33389384,-122.07197743],[37.33382775,-122.07235512],[37.33382775,-122.07235512],[37.33375801,-122.07272963],[37.33375801,-122.07272963],[37.33369775,-122.07309474],[37.33369775,-122.07309474],[37.33363907,-122.07346522],[37.33363907,-122.07346522],[37.33359159,-122.07381886],[37.33359159,-122.07381886],[37.33355651,-122.07417592],[37.33355651,-122.07417592],[37.33353728,-122.07453283],[37.33353728,-122.07453283],[37.33353065,-122.07488445],[37.33353065,-122.07488445],[37.33353363,-122.07523112],[37.33353363,-122.07523112],[37.33355228,-122.07558936],[37.33355228,-122.07558936],[37.33358308,-122.07595104],[37.33358308,-122.07595104],[37.33362663,-122.0763056],[37.33362663,-122.0763056],[37.33368006,-122.07665613],[37.33368006,-122.07665613],[37.33374934,-122.07700482],[37.33374934,-122.07700482],[37.33382825,-122.07735141],[37.33382825,-122.07735141],[37.33392322,-122.07769942],[37.33392322,-122.07769942],[37.33402871,-122.07804543],[37.33402871,-122.07804543],[37.33415037,-122.07838406],[37.33415037,-122.07838406],[37.3342805,-122.07872034],[37.3342805,-122.07872034],[37.33442102,-122.07904631],[37.33442102,-122.07904631],[37.33457244,-122.0793639],[37.33457244,-122.0793639],[37.33473735,-122.0796747],[37.33473735,-122.0796747],[37.33492184,-122.07997503],[37.33492184,-122.07997503],[37.33511119,-122.08026077],[37.33511119,-122.08026077],[37.33531428,-122.08054952],[37.33531428,-122.08054952],[37.33552177,-122.08082252],[37.33552177,-122.08082252],[37.33573891,-122.08110667],[37.33573891,-122.08110667],[37.33595575,-122.08138403],[37.33595575,-122.08138403],[37.33617167,-122.08165962],[37.33617167,-122.08165962],[37.33638536,-122.08193111],[37.33638536,-122.08193111],[37.33659906,-122.08220411],[37.33659906,-122.08220411],[37.33680278,-122.08247812],[37.33680278,-122.08247812],[37.3370055,-122.0827595],[37.3370055,-122.0827595],[37.33720302,-122.08304213],[37.33720302,-122.08304213],[37.3373963,-122.08332863],[37.3373963,-122.08332863],[37.33758129,-122.08362627],[37.33758129,-122.08362627],[37.33775509,-122.08392617],[37.33775509,-122.08392617],[37.33793145,-122.0842275],[37.33793145,-122.0842275],[37.33810893,-122.08454124],[37.33810893,-122.08454124],[37.3382842,-122.08484542],[37.3382842,-122.08484542],[37.3384549,-122.08515152],[37.3384549,-122.08515152],[37.33862249,-122.08545696],[37.33862249,-122.08545696],[37.33879885,-122.08577472],[37.33879885,-122.08577472],[37.3389669,-122.08608946],[37.3389669,-122.08608946],[37.33913576,-122.08640269],[37.33913576,-122.08640269],[37.33930008,-122.08670293],[37.33930008,-122.08670293],[37.33947623,-122.08701088],[37.33947623,-122.08701088],[37.3396502,-122.08732093],[37.3396502,-122.08732093],[37.33981846,-122.08762326],[37.33981846,-122.08762326],[37.33998434,-122.08792937],[37.33998434,-122.08792937],[37.3401493,-122.08824042],[37.3401493,-122.08824042],[37.34031484,-122.08856086],[37.34031484,-122.08856086],[37.34046597,-122.08886286],[37.34046597,-122.08886286],[37.34061718,-122.08917878],[37.34061718,-122.08917878],[37.34077165,-122.08949679],[37.34077165,-122.08949679],[37.34092739,-122.08983097],[37.34092739,-122.08983097],[37.34107194,-122.09015057],[37.34107194,-122.09015057],[37.34121879,-122.09045668],[37.34121879,-122.09045668],[37.34137909,-122.09077234],[37.34137909,-122.09077234],[37.34154237,-122.09108423],[37.34154237,-122.09108423]]}", "field_66812": "Não", "field_75000": "SIG_V1|meta:{\\"lat\\":37.34394974,\\"lng\\":-122.09415478,\\"address\\":\\"I-280,  - Los Altos, CA\\",\\"ip\\":\\"2804:7f0:9383:8b58:2cf9:997d:bbdb:7ecb\\"}|M154,194.66666793823242 L152,211.00000127156568 L131,209.00000127156568 L118,198.33333460489905 L99.66666666666666,179.00000127156574 L83.66666666666666,146.33333460489905 L77,108.66666793823242 L80,81.33333460489905 L93,64.00000127156574 L115.33333333333331,55.33333460489905 L163,68.00000127156574 L191,94.00000127156574 L211.66666666666666,121.33333460489905 L233.33333333333331,143.33333460489905 L247.66666666666663,152.33333460489905 L261.3333333333333,152.00000127156574 L281.3333333333333,140.66666793823242 L301.3333333333333,120.66666793823242 L316.66666666666663,96.00000127156574 L325.66666666666663,70.66666793823242 L328.66666666666663,51.000001271565736 L328.66666666666663,50.66666793823242 L326.3333333333333,56.66666793823242 L325,78.00000127156574 L325,109.66666793823242 L323.3333333333333,143.33333460489905 L322,167.00000127156574 L313.66666666666663,183.33333460489905 L306.3333333333333,185.00000127156568 L282.66666666666663,185.00000127156568 L241,181.66666793823242 L205.33333333333331,175.00000127156574 L171.66666666666666,168.66666793823242 L142,164.00000127156574 L108.66666666666666,154.00000127156574 L102.33333333333333,149.66666793823242 L103.33333333333333,150.33333460489905 L119.66666666666666,159.33333460489905 L143.33333333333331,165.33333460489905 L181,170.00000127156574 L244.33333333333331,173.33333460489905 L278,175.00000127156574 L305.66666666666663,176.66666793823242 L307.66666666666663,176.66666793823242 L307.3333333333333,176.66666793823242 L307,176.66666793823242", "field_75975": "{\\"action\\":\\"SAIDA\\",\\"timestamp\\":\\"2026-04-02T21:09:19.276Z\\",\\"coordinates\\":{\\"lat\\":37.33485843,\\"lng\\":-122.03334424},\\"address\\":\\"N De Anza Blvd, 10889 - Santa Clara, Cupertino - CA\\"}", "__time_field_4248": "2026-04-02T21:12:10.633Z", "__time_field_66812": "2026-04-02T21:12:16.012Z", "__time_field_75000": "2026-04-02T21:12:22.238Z", "__time_field_75975": "2026-04-02T21:09:19.276Z", "__section_end_page_1": "2026-04-02T21:12:23.147Z", "__section_start_page_1": "2026-04-02T21:09:19.301Z"}	{"icon": "build-outline", "refId": "chk_mnhro4is", "title": "Rota", "acceptedAt": "2026-04-02T21:08:34.389Z", "appVersion": "1.0", "receivedAt": "2026-04-02T21:03:42.530Z", "description": "Tarefa de rotina despachada.", "devicePlatform": "AppMovel", "durationSeconds": 228}	\N	-15.388346	-49.145966	150	segment	[[-15.380536, -49.21875], [-15.396156, -49.073181]]	null	2026-04-02 21:08:34.48	2026-04-02 21:12:23.147	2026-04-02 21:12:23.244	2026-04-02 20:59:46.389
cmni0qayq02sqk84wy5bpuvea	chk_mnhro4is	alex@brspark.com	\N	COMPLETED	{"field_4248": "{\\"action\\":\\"CHEGADA\\",\\"timestamp\\":\\"2026-04-02T22:04:50.463Z\\",\\"coordinates\\":{\\"lat\\":37.33500926,\\"lng\\":-122.03272188},\\"address\\":\\"N De Anza Blvd, 10889 - Santa Clara, Cupertino - CA\\",\\"traversedPath\\":[[37.33021988,-122.02396374],[37.33021988,-122.02396374],[37.33021988,-122.02396374],[37.33021988,-122.02396374],[37.33021717,-122.02382845],[37.33021717,-122.02382845],[37.33021864,-122.02370753],[37.33021864,-122.02370753],[37.33022668,-122.02358845],[37.33022668,-122.02358845],[37.33022057,-122.023459],[37.33022057,-122.023459],[37.33020882,-122.0233343],[37.33020882,-122.0233343],[37.33019792,-122.02320222],[37.33019792,-122.02320222],[37.33019502,-122.02306835],[37.33019502,-122.02306835],[37.33019527,-122.02294631],[37.33019527,-122.02294631],[37.33019055,-122.02282064],[37.33019055,-122.02282064],[37.3301749,-122.02269435],[37.3301749,-122.02269435],[37.33015856,-122.02257019],[37.33015856,-122.02257019],[37.33013541,-122.02244406],[37.33013541,-122.02244406],[37.3301169,-122.02230795],[37.3301169,-122.02230795],[37.33010689,-122.02216391],[37.33010689,-122.02216391],[37.33010478,-122.02202626],[37.33010478,-122.02202626],[37.33010093,-122.02188644],[37.33010093,-122.02188644],[37.33009437,-122.02175602],[37.33009437,-122.02175602],[37.33008848,-122.02162795],[37.33008848,-122.02162795],[37.33008277,-122.02149879],[37.33008277,-122.02149879],[37.33008066,-122.02136042],[37.33008066,-122.02136042],[37.33007095,-122.02122343],[37.33007095,-122.02122343],[37.33006472,-122.02108977],[37.33006472,-122.02108977]]}", "field_75000": "SIG_V1|meta:{\\"lat\\":37.33470894,\\"lng\\":-122.03411085,\\"address\\":\\"I-280,  - Cupertino, CA\\",\\"ip\\":\\"2804:7f0:9383:8b58:2cf9:997d:bbdb:7ecb\\"}|M100,187.00000127156568 L98.66666666666666,158.00000127156574 L108,112.33333460489905 L115.66666666666666,110.00000127156574 L127,111.00000127156574 L133,114.33333460489905 L140.33333333333331,122.00000127156574 L186,191.66666793823242 L202,220.00000127156568 L208.33333333333331,228.33333460489905 L212,230.66666793823242 L218.33333333333331,230.66666793823242 L225,225.00000127156568 L241.66666666666663,202.00000127156568 L256,172.00000127156574 L265.3333333333333,142.33333460489905 L269.3333333333333,124.00000127156574 L269.3333333333333,124.66666793823242 L274.3333333333333,133.33333460489905 L282.3333333333333,142.66666793823242 L296.66666666666663,161.33333460489905 L300.3333333333333,165.00000127156574 L300.66666666666663,165.00000127156574 L300.3333333333333,164.33333460489905", "field_75975": "{\\"action\\":\\"SAIDA\\",\\"timestamp\\":\\"2026-04-02T22:00:41.378Z\\",\\"coordinates\\":{\\"lat\\":37.33021988,\\"lng\\":-122.02396374},\\"address\\":\\"Merritt Dr, 20046 - Santa Clara, Cupertino - CA\\"}", "__time_field_4248": "2026-04-02T22:04:50.463Z", "__time_field_75000": "2026-04-02T22:04:59.124Z", "__time_field_75975": "2026-04-02T22:00:41.378Z", "__section_end_page_1": "2026-04-02T22:04:59.870Z", "__section_start_page_1": "2026-04-02T22:00:41.412Z"}	{"icon": "build-outline", "refId": "chk_mnhro4is", "title": "Rota", "acceptedAt": "2026-04-02T22:00:29.125Z", "appVersion": "1.0", "receivedAt": "2026-04-02T22:00:25.014Z", "description": "Tarefa de rotina despachada.", "devicePlatform": "AppMovel", "durationSeconds": 270}	\N	-15.68897	-51.010208	150	segment	[[-15.688493, -51.020508], [-15.689447, -50.999908]]	null	2026-04-02 22:00:29.202	2026-04-02 22:04:59.87	2026-04-02 22:04:59.945	2026-04-02 22:00:22.274
cmni0yc0l034gk84wpt1ucqfp	chk_mnhro4is	alex@brspark.com	\N	RECEIVED	null	{"icon": "build-outline", "refId": "chk_mnhro4is", "title": "Rota", "receivedAt": "2026-04-02T22:06:41.098Z", "description": "alex@brspark.com"}	\N	-14.840603	-51.328125	200	radius	null	\N	\N	\N	\N	2026-04-02 22:06:36.885
cmni0ykni034tk84w4shu4k67	chk_mnhro4is	alex@brspark.com	\N	RECEIVED	null	{"icon": "build-outline", "refId": "chk_mnhro4is", "title": "Rota", "receivedAt": "2026-04-02T22:06:51.150Z", "description": "Tarefa de rotina despachada."}	\N	-14.841123	-51.31804	200	radius	null	\N	\N	\N	\N	2026-04-02 22:06:48.079
cmni0zakf035wk84wuzy84yix	chk_mnhro4is	alex@brspark.com	\N	COMPLETED	{"field_4248": "{\\"action\\":\\"CHEGADA\\",\\"timestamp\\":\\"2026-04-02T22:11:11.258Z\\",\\"coordinates\\":{\\"lat\\":37.37709618,\\"lng\\":-122.14869624},\\"address\\":\\"I-280,  - Santa Clara, Los Altos Hills - CA\\",\\"traversedPath\\":[[37.34415677,-122.09439031],[37.34415677,-122.09439031],[37.34415677,-122.09439031],[37.34415677,-122.09439031],[37.34434595,-122.09463741],[37.34434595,-122.09463741],[37.34453978,-122.09489641],[37.34453978,-122.09489641],[37.34472464,-122.09516438],[37.34472464,-122.09516438],[37.3448932,-122.0954383],[37.3448932,-122.0954383],[37.34505141,-122.09572596],[37.34505141,-122.09572596],[37.34520782,-122.0960117],[37.34520782,-122.0960117],[37.34534964,-122.09631924],[37.34534964,-122.09631924],[37.34548953,-122.096638],[37.34548953,-122.096638],[37.34562364,-122.09695274],[37.34562364,-122.09695274],[37.34576798,-122.09727888],[37.34576798,-122.09727888],[37.34590884,-122.09760787],[37.34590884,-122.09760787],[37.34604924,-122.0979434],[37.34604924,-122.0979434],[37.34619047,-122.09828781],[37.34619047,-122.09828781],[37.34633112,-122.09862728],[37.34633112,-122.09862728],[37.3464786,-122.09896549],[37.3464786,-122.09896549],[37.3466164,-122.09929791],[37.3466164,-122.09929791],[37.34676434,-122.09963352],[37.34676434,-122.09963352],[37.34690805,-122.09997509],[37.34690805,-122.09997509],[37.34705171,-122.10032243],[37.34705171,-122.10032243],[37.34719244,-122.1006624],[37.34719244,-122.1006624],[37.34733473,-122.10099349],[37.34733473,-122.10099349],[37.34747663,-122.10131879],[37.34747663,-122.10131879],[37.34762491,-122.1016513],[37.34762491,-122.1016513],[37.34777737,-122.10196336],[37.34777737,-122.10196336],[37.34794036,-122.10227399],[37.34794036,-122.10227399],[37.34812405,-122.10257499],[37.34812405,-122.10257499],[37.34831482,-122.10286198],[37.34831482,-122.10286198],[37.34851318,-122.10314001],[37.34851318,-122.10314001],[37.34872189,-122.10340186],[37.34872189,-122.10340186],[37.34894824,-122.1036539],[37.34894824,-122.1036539],[37.34918436,-122.10389589],[37.34918436,-122.10389589],[37.34941931,-122.10411164],[37.34941931,-122.10411164],[37.34966435,-122.10431859],[37.34966435,-122.10431859],[37.34991623,-122.10451573],[37.34991623,-122.10451573],[37.35016915,-122.1047086],[37.35016915,-122.1047086],[37.35042203,-122.10490214],[37.35042203,-122.10490214],[37.3506804,-122.10509685],[37.3506804,-122.10509685],[37.3509353,-122.10529449],[37.3509353,-122.10529449],[37.35119518,-122.1054944],[37.35119518,-122.1054944],[37.35145376,-122.10569934],[37.35145376,-122.10569934],[37.35170078,-122.10589849],[37.35170078,-122.10589849],[37.35194528,-122.10610938],[37.35194528,-122.10610938],[37.35218349,-122.10633762],[37.35218349,-122.10633762],[37.35240938,-122.10656821],[37.35240938,-122.10656821],[37.35262907,-122.10682025],[37.35262907,-122.10682025],[37.35283833,-122.10707414],[37.35283833,-122.10707414],[37.35304318,-122.1073468],[37.35304318,-122.1073468],[37.35322775,-122.10761167],[37.35322775,-122.10761167],[37.35340125,-122.10789012],[37.35340125,-122.10789012],[37.35357644,-122.10818206],[37.35357644,-122.10818206],[37.35373217,-122.10847987],[37.35373217,-122.10847987],[37.35388229,-122.10878137],[37.35388229,-122.10878137],[37.35402763,-122.10909116],[37.35402763,-122.10909116],[37.35416275,-122.10941512],[37.35416275,-122.10941512],[37.354285,-122.10973833],[37.354285,-122.10973833],[37.35439853,-122.1100721],[37.35439853,-122.1100721],[37.35450989,-122.11040469],[37.35450989,-122.11040469],[37.35460422,-122.11074625],[37.35460422,-122.11074625],[37.35470108,-122.11109678],[37.35470108,-122.11109678],[37.35478615,-122.11144128],[37.35478615,-122.11144128],[37.35486926,-122.11178469],[37.35486926,-122.11178469],[37.3549592,-122.11213723],[37.3549592,-122.11213723],[37.35504792,-122.11248818],[37.35504792,-122.11248818],[37.35513836,-122.11282957],[37.35513836,-122.11282957],[37.35522226,-122.11317885],[37.35522226,-122.11317885],[37.35532071,-122.11352779],[37.35532071,-122.11352779],[37.35543424,-122.11386968],[37.35543424,-122.11386968],[37.35555758,-122.11420421],[37.35555758,-122.11420421],[37.35568444,-122.11452423],[37.35568444,-122.11452423],[37.35583234,-122.11484701],[37.35583234,-122.11484701],[37.35598347,-122.11516142],[37.35598347,-122.11516142],[37.35614335,-122.11546778],[37.35614335,-122.11546778],[37.35630592,-122.11577145],[37.35630592,-122.11577145],[37.35647419,-122.11607907],[37.35647419,-122.11607907],[37.35667204,-122.11636489],[37.35667204,-122.11636489],[37.35687073,-122.11663286],[37.35687073,-122.11663286],[37.35707534,-122.11689874],[37.35707534,-122.11689874],[37.35728082,-122.11715581],[37.35728082,-122.11715581],[37.3575003,-122.11741087],[37.3575003,-122.11741087],[37.35772158,-122.11764607],[37.35772158,-122.11764607],[37.35796495,-122.11787221],[37.35796495,-122.11787221],[37.35821377,-122.11808519],[37.35821377,-122.11808519],[37.35846644,-122.11829223],[37.35846644,-122.11829223],[37.35872263,-122.11848501],[37.35872263,-122.11848501],[37.3589945,-122.11866179],[37.3589945,-122.11866179],[37.35928216,-122.11883998],[37.35928216,-122.11883998],[37.35955814,-122.11901575],[37.35955814,-122.11901575],[37.35983897,-122.11918616],[37.35983897,-122.11918616],[37.36011952,-122.1193553],[37.36011952,-122.1193553],[37.36040727,-122.11952001],[37.36040727,-122.11952001],[37.36069305,-122.11969553],[37.36069305,-122.11969553],[37.3609743,-122.11986677],[37.3609743,-122.11986677],[37.36126096,-122.12003751],[37.36126096,-122.12003751],[37.36154377,-122.1202173],[37.36154377,-122.1202173],[37.36181958,-122.1204183],[37.36181958,-122.1204183],[37.36207862,-122.12062282],[37.36207862,-122.12062282],[37.36233305,-122.12084385],[37.36233305,-122.12084385],[37.36258266,-122.12108055],[37.36258266,-122.12108055],[37.36281941,-122.12133444],[37.36281941,-122.12133444],[37.36303768,-122.12160442],[37.36303768,-122.12160442],[37.36324345,-122.12188572],[37.36324345,-122.12188572],[37.36344328,-122.12218294],[37.36344328,-122.12218294],[37.36362588,-122.12248745],[37.36362588,-122.12248745],[37.36380169,-122.12279364],[37.36380169,-122.12279364],[37.36396061,-122.12310285],[37.36396061,-122.12310285],[37.36410876,-122.12341793],[37.36410876,-122.12341793],[37.36424153,-122.12374717],[37.36424153,-122.12374717],[37.36436332,-122.12407817],[37.36436332,-122.12407817],[37.36447237,-122.12441747],[37.36447237,-122.12441747],[37.36457081,-122.12476867],[37.36457081,-122.12476867],[37.36465673,-122.12512859],[37.36465673,-122.12512859],[37.36472923,-122.12549681],[37.36472923,-122.12549681],[37.3647884,-122.12586327],[37.3647884,-122.12586327],[37.36483488,-122.12623861],[37.36483488,-122.12623861],[37.36486694,-122.12661646],[37.36486694,-122.12661646],[37.36488463,-122.12699926],[37.36488463,-122.12699926],[37.36489573,-122.12737863],[37.36489573,-122.12737863],[37.36489494,-122.12775531],[37.36489494,-122.12775531],[37.36489561,-122.12814457],[37.36489561,-122.12814457],[37.36489536,-122.12851823],[37.36489536,-122.12851823],[37.36490102,-122.12889651],[37.36490102,-122.12889651],[37.364913,-122.12927755],[37.364913,-122.12927755],[37.36492641,-122.12966111],[37.36492641,-122.12966111],[37.36495642,-122.13002966],[37.36495642,-122.13002966],[37.36500231,-122.13039762],[37.36500231,-122.13039762],[37.36505801,-122.13076299],[37.36505801,-122.13076299],[37.36513495,-122.13112023],[37.36513495,-122.13112023],[37.36522619,-122.13147671],[37.36522619,-122.13147671],[37.36533088,-122.13182204],[37.36533088,-122.13182204],[37.36543834,-122.13217241],[37.36543834,-122.13217241],[37.36554852,-122.13253006],[37.36554852,-122.13253006],[37.36565505,-122.13287858],[37.36565505,-122.13287858],[37.36576171,-122.13322476],[37.36576171,-122.13322476],[37.3658664,-122.13358057],[37.3658664,-122.13358057],[37.36597474,-122.1339342],[37.36597474,-122.1339342],[37.36607239,-122.13427694],[37.36607239,-122.13427694],[37.36617599,-122.13462026],[37.36617599,-122.13462026],[37.36627984,-122.13496408],[37.36627984,-122.13496408],[37.36637342,-122.13530514],[37.36637342,-122.13530514],[37.3664761,-122.13564763],[37.3664761,-122.13564763],[37.36657341,-122.13598643],[37.36657341,-122.13598643],[37.36667454,-122.13633075],[37.36667454,-122.13633075],[37.3667825,-122.13667173],[37.3667825,-122.13667173],[37.3668918,-122.13700784],[37.3668918,-122.13700784],[37.36700588,-122.13734664],[37.36700588,-122.13734664],[37.36714083,-122.13768569],[37.36714083,-122.13768569],[37.36728357,-122.13801602],[37.36728357,-122.13801602],[37.36743034,-122.13834434],[37.36743034,-122.13834434],[37.36759001,-122.13866201],[37.36759001,-122.13866201],[37.36776176,-122.13898061],[37.36776176,-122.13898061],[37.36794754,-122.13929619],[37.36794754,-122.13929619],[37.36813371,-122.13959391],[37.36813371,-122.13959391],[37.36833646,-122.13988803],[37.36833646,-122.13988803],[37.36854278,-122.1401674],[37.36854278,-122.1401674],[37.36876231,-122.14043713],[37.36876231,-122.14043713],[37.36898397,-122.14069152],[37.36898397,-122.14069152],[37.36921459,-122.14094005],[37.36921459,-122.14094005],[37.36945654,-122.1411796],[37.36945654,-122.1411796],[37.3697059,-122.14141823],[37.3697059,-122.14141823],[37.36994839,-122.1416339],[37.36994839,-122.1416339],[37.37019243,-122.14186189],[37.37019243,-122.14186189],[37.37043777,-122.14209172],[37.37043777,-122.14209172],[37.37068524,-122.14231367],[37.37068524,-122.14231367],[37.37092857,-122.14253931],[37.37092857,-122.14253931],[37.37117332,-122.14276269],[37.37117332,-122.14276269],[37.37142067,-122.14297886],[37.37142067,-122.14297886],[37.37167049,-122.14320232],[37.37167049,-122.14320232],[37.37190954,-122.14341883],[37.37190954,-122.14341883],[37.37215601,-122.14364204],[37.37215601,-122.14364204],[37.37240005,-122.14386038],[37.37240005,-122.14386038],[37.37263743,-122.14409064],[37.37263743,-122.14409064],[37.37287229,-122.14430781],[37.37287229,-122.14430781],[37.37311268,-122.14451887],[37.37311268,-122.14451887],[37.37336271,-122.14472699],[37.37336271,-122.14472699],[37.37361371,-122.14495984],[37.37361371,-122.14495984],[37.37385134,-122.14517802],[37.37385134,-122.14517802],[37.37409077,-122.14540877],[37.37409077,-122.14540877],[37.37433481,-122.14563986],[37.37433481,-122.14563986],[37.37457281,-122.14588663],[37.37457281,-122.14588663],[37.37481249,-122.14611939],[37.37481249,-122.14611939],[37.37503792,-122.14636347],[37.37503792,-122.14636347],[37.37527039,-122.14662055],[37.37527039,-122.14662055],[37.37550207,-122.14687494],[37.37550207,-122.14687494],[37.37572427,-122.14713511],[37.37572427,-122.14713511],[37.37595557,-122.14739872],[37.37595557,-122.14739872],[37.37618545,-122.14766024],[37.37618545,-122.14766024],[37.37641444,-122.14792309],[37.37641444,-122.14792309],[37.37664016,-122.14817958],[37.37664016,-122.14817958],[37.37686895,-122.14843858],[37.37686895,-122.14843858],[37.37709618,-122.14869624],[37.37709618,-122.14869624]]}", "field_66812": "Sim", "field_75000": "SIG_V1|meta:{\\"lat\\":37.38078049,\\"lng\\":-122.15133956,\\"address\\":\\"I-280,  - Los Altos Hills, CA\\",\\"ip\\":\\"2804:7f0:9383:8b58:2cf9:997d:bbdb:7ecb\\"}|M209.66666666666666,150.33333460489905 L201,169.66666793823242 L191.33333333333331,172.66666793823242 L181.66666666666666,172.66666793823242 L172,171.00000127156574 L152,160.66666793823242 L129.33333333333331,145.66666793823242 L106,125.33333460489905 L87.66666666666666,102.33333460489905 L81,87.00000127156574 L79.66666666666666,69.33333460489905 L91,50.33333460489905 L105,42.33333460489905 L126.66666666666666,38.33333460489905 L144.33333333333331,38.33333460489905 L160,39.33333460489905 L178,49.33333460489905 L191,59.66666793823242 L201.33333333333331,74.00000127156574 L207.66666666666666,87.66666793823242 L208.66666666666666,99.00000127156574 L206.33333333333331,110.66666793823242 L198.33333333333331,119.00000127156574 L177,129.00000127156574 L165.33333333333331,131.00000127156574 L157.66666666666666,131.00000127156574 L155,131.00000127156574 L154.66666666666666,130.66666793823242 L154.33333333333331,130.66666793823242", "field_75975": "{\\"action\\":\\"SAIDA\\",\\"timestamp\\":\\"2026-04-02T22:08:00.448Z\\",\\"coordinates\\":{\\"lat\\":37.34415677,\\"lng\\":-122.09439031},\\"address\\":\\"I-280,  - West Loyola, Los Altos - CA\\"}", "__time_field_4248": "2026-04-02T22:11:11.258Z", "__time_field_66812": "2026-04-02T22:11:13.663Z", "__time_field_75000": "2026-04-02T22:11:24.775Z", "__time_field_75975": "2026-04-02T22:08:00.449Z", "__section_end_page_1": "2026-04-02T22:11:25.377Z", "__section_start_page_1": "2026-04-02T22:08:00.476Z"}	{"icon": "build-outline", "refId": "chk_mnhro4is", "title": "Rota", "acceptedAt": "2026-04-02T22:07:37.343Z", "appVersion": "1.0", "receivedAt": "2026-04-02T22:07:24.081Z", "description": "Tarefa de rotina despachada.", "devicePlatform": "AppMovel", "durationSeconds": 227}	\N	-15.646864	-54.615226	150	segment	[[-15.64618, -54.624023], [-15.647548, -54.606428]]	null	2026-04-02 22:07:37.379	2026-04-02 22:11:25.377	2026-04-02 22:11:25.567	2026-04-02 22:07:21.663
cmni1npwo045ck84w2mp3uaqv	chk_mnhro4is	alex@brspark.com	\N	IN_PROGRESS	null	{"icon": "build-outline", "refId": "chk_mnhro4is", "title": "Rota", "acceptedAt": "2026-04-02T22:27:45.283Z", "receivedAt": "2026-04-02T22:26:22.530Z", "description": "Tarefa de rotina despachada."}	apple	42.764352	-84.514731	200	radius	null	\N	2026-04-02 22:27:58.34	\N	\N	2026-04-02 22:26:21.288
\.


--
-- Data for Name: ChecklistTemplate; Type: TABLE DATA; Schema: public; Owner: alex
--

COPY public."ChecklistTemplate" (id, "tenantId", title, description, settings, "schemaData", metadata, version, "isActive", "createdAt", "updatedAt") FROM stdin;
chk_mnhro4is	\N	Rota		{"rules": [], "globalGeofenceRadius": 200, "requireGlobalGeofence": false}	[{"id": "field_75975", "icon": "arrow-up", "type": "transit_start", "label": "Iniciar Deslocamento", "options": null, "required": false, "textMask": null, "iconColor": "#0F172A", "calcFormula": null, "dependsOnId": "", "description": "", "iconLibrary": "FontAwesome", "defaultValue": "", "dependsOnValue": "", "geofenceRadius": null, "dependsOnOperator": "=="}, {"id": "field_4248", "icon": "arrows-alt", "type": "transit_end", "label": "Finalizar Deslocamento", "options": null, "required": false, "textMask": null, "iconColor": "#0F172A", "calcFormula": null, "dependsOnId": "", "description": "", "iconLibrary": "FontAwesome", "defaultValue": "", "dependsOnValue": "", "geofenceRadius": null, "dependsOnOperator": "=="}, {"id": "field_66812", "icon": "aliwangwang", "type": "yes_no", "label": "Sim / Não (Toggle)", "options": null, "required": false, "textMask": null, "iconColor": "#1c50ca", "calcFormula": null, "dependsOnId": "", "description": "", "iconLibrary": "AntDesign", "defaultValue": "", "dependsOnValue": "", "geofenceRadius": null, "dependsOnOperator": "=="}, {"id": "field_57585", "icon": "", "type": "file_upload", "label": "Enviar PDF/Doc", "options": null, "required": false, "textMask": null, "calcFormula": null, "dependsOnId": "", "description": "", "defaultValue": "", "dependsOnValue": "", "geofenceRadius": null, "dependsOnOperator": "=="}, {"id": "field_40882", "icon": "", "type": "photo_stamped", "label": "Foto Carimbada (Ao Vivo)", "options": null, "required": false, "textMask": null, "calcFormula": null, "dependsOnId": "", "description": "", "defaultValue": "", "dependsOnValue": "", "geofenceRadius": null, "dependsOnOperator": "=="}, {"id": "field_21036", "icon": "", "type": "photo", "label": "Foto (Galeria Livre)", "options": null, "required": false, "textMask": null, "calcFormula": null, "dependsOnId": "", "description": "", "defaultValue": "", "dependsOnValue": "", "geofenceRadius": null, "dependsOnOperator": "=="}, {"id": "field_75000", "icon": "", "type": "signature", "label": "Assinatura", "options": null, "required": false, "textMask": null, "calcFormula": null, "dependsOnId": "", "description": "", "defaultValue": "", "dependsOnValue": "", "geofenceRadius": null, "dependsOnOperator": "=="}, {"id": "field_82052", "icon": "", "type": "hidden", "label": "Campo Oculto", "options": null, "required": false, "textMask": null, "calcFormula": null, "dependsOnId": "", "description": "", "defaultValue": "", "dependsOnValue": "", "geofenceRadius": null, "dependsOnOperator": "=="}]	{"icon": ""}	1	t	2026-04-02 17:46:44.14	2026-04-02 17:46:44.14
chk_mni0xdfi	\N	NOVO CHECKLIST		{"rules": [], "globalGeofenceRadius": 200, "requireGlobalGeofence": false}	[]	{"icon": ""}	1	t	2026-04-02 22:05:52.08	2026-04-02 22:05:56.458
\.


--
-- Data for Name: CollectionPolicy; Type: TABLE DATA; Schema: public; Owner: alex
--

COPY public."CollectionPolicy" (id, "tenantId", "sectorCode", label, "locationEnabled", "locationBackgroundEnabled", "locationIntervalIdleMin", "locationIntervalTransitMin", "locationIntervalOnSiteMin", "locationDistanceFilterMeters", "retentionGpsRawDays", "retentionEventsYears", "retentionAuditDays", "retentionMetricsDays", "mockGpsAction", "rootJailbreakAction", "clockDriftMaxSeconds", "requireExplicitConsent", "consentGranular", "legalBasis", "requireCheckinPhoto", "allowOfflineCheckin", "minOnSiteMinutes", "outOfPolicyAction", "isActive", "createdAt", "updatedAt") FROM stdin;
cmnhgi1rs000cedboz4pbavp7	\N	\N	Padrão Global	t	t	30	2	5	200	15	5	180	730	WARN	WARN	300	t	t	LGPD	f	t	0	PROCEED_FLAG	t	2026-04-02 12:34:04.793	2026-04-02 12:34:04.793
cmnhgi1rs000aedbo1qs68ys2	\N	\N	Padrão Global	t	t	30	2	5	200	15	5	180	730	WARN	WARN	300	t	t	LGPD	f	t	0	PROCEED_FLAG	t	2026-04-02 12:34:04.792	2026-04-02 12:34:04.792
cmnhgi1u2000ledbo2e4s9nne	\N	\N	Padrão Global	t	t	30	2	5	200	15	5	180	730	WARN	WARN	300	t	t	LGPD	f	t	0	PROCEED_FLAG	t	2026-04-02 12:34:04.874	2026-04-02 12:34:04.874
\.


--
-- Data for Name: ComplianceAcceptance; Type: TABLE DATA; Schema: public; Owner: alex
--

COPY public."ComplianceAcceptance" (id, "docId", "userId", "tenantId", "ipAddress", "acceptedAt") FROM stdin;
\.


--
-- Data for Name: ComplianceDoc; Type: TABLE DATA; Schema: public; Owner: alex
--

COPY public."ComplianceDoc" (id, type, version, title, content, "isActive", "publishedAt", "createdBy", "createdAt", "updatedAt", "sectorCode", "tenantId") FROM stdin;
\.


--
-- Data for Name: ConsentRecord; Type: TABLE DATA; Schema: public; Owner: alex
--

COPY public."ConsentRecord" (id, "tenantId", "ownerEmail", "policyId", "docId", "consentType", accepted, "ipAddress", "deviceId", "appVersion", "acceptedAt", "revokedAt") FROM stdin;
cmnhguuaz00023yrjny5gnwh2	\N	tech@brspark.com	\N	\N	LOCATION_BACKGROUND	t	::1	\N	1.0	2026-04-02 12:44:01.643	\N
\.


--
-- Data for Name: ExecutionMetric; Type: TABLE DATA; Schema: public; Owner: alex
--

COPY public."ExecutionMetric" (id, "tenantId", "executionId", "ownerEmail", "transitDurationMin", "siteArrivalDelayMin", "onSiteDurationMin", "idleTimeMin", "distanceKm", "geofenceBreaches", "routeDeviationMaxMeters", "scoreExecution", "scoreReliability", "scoreRisk", "fraudFlags", "calculatedAt", source, "etaMinutes") FROM stdin;
cmnhrxwy5003ml0zixdixrenr	\N	cmnhrqhbi0b9j9g8mtnd7ocdb	alex@brspark.com	\N	\N	\N	\N	0	0	\N	40	100	0	null	2026-04-02 17:54:20.812	REALTIME	\N
cmnhtb51a00z1quvgbhcgbaa0	\N	cmnht8qog00vkquvgverzll77	alex@brspark.com	\N	\N	\N	\N	0	0	\N	40	100	0	null	2026-04-02 18:32:37.439	REALTIME	\N
cmnhtrflg006rf5jrs5550t0z	\N	cmnhtnyp4001zf5jrvv0r23qa	alex@brspark.com	\N	\N	\N	\N	0	0	\N	40	50	45	[{"lat": 37.33240731, "lng": -122.03046898, "reason": "MOCK_LOCATION", "severity": "HIGH"}]	2026-04-02 18:45:17.621	REALTIME	\N
cmnhz0liz00gbk84wsvfj6p2v	\N	cmnhykdhy0005k84w6xci9f1x	alex@brspark.com	\N	\N	\N	\N	0	0	\N	40	100	0	null	2026-04-02 21:12:23.291	REALTIME	\N
cmni0w9850313k84wfi6itx34	\N	cmni0qayq02sqk84wy5bpuvea	alex@brspark.com	\N	\N	\N	\N	0	0	\N	40	100	0	null	2026-04-02 22:04:59.958	REALTIME	\N
cmni14ips03e6k84wqt4znm2o	\N	cmni0zakf035wk84wuzy84yix	alex@brspark.com	\N	\N	\N	\N	0	0	\N	40	100	0	null	2026-04-02 22:11:25.504	REALTIME	\N
\.


--
-- Data for Name: FeatureFlag; Type: TABLE DATA; Schema: public; Owner: alex
--

COPY public."FeatureFlag" (id, key, label, description, icon, enabled, "tenantId", "updatedAt") FROM stdin;
\.


--
-- Data for Name: Integration; Type: TABLE DATA; Schema: public; Owner: alex
--

COPY public."Integration" (id, name, type, icon, "apiKey", "baseUrl", "webhookUrl", "lastTestedAt", metadata, "createdAt", "updatedAt", description, status) FROM stdin;
\.


--
-- Data for Name: Invoice; Type: TABLE DATA; Schema: public; Owner: alex
--

COPY public."Invoice" (id, "subscriptionId", amount, status, "dueDate", "paidAt", "externalId", "createdAt") FROM stdin;
\.


--
-- Data for Name: LocaleProfile; Type: TABLE DATA; Schema: public; Owner: alex
--

COPY public."LocaleProfile" (id, "countryCode", name, language, currency, "currencySymbol", "dateFormat", "numberFormat", timezone, "taxIdLabel", "postalCodeLabel", "measureSystem", "isActive", "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: Location; Type: TABLE DATA; Schema: public; Owner: alex
--

COPY public."Location" (id, "tenantId", name, type, address, floor, room, icon, latitude, longitude, "parentId", "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: Metatag; Type: TABLE DATA; Schema: public; Owner: alex
--

COPY public."Metatag" (id, type, key, "ptBr", "enUs", "esEs", icon, color, "isActive", "sortOrder", "createdAt", "updatedAt") FROM stdin;
cmnhgwp9000033yrjo4bw7jf1	MEDIA_CATEGORY	foto	Foto	Foto	Foto	camera-outline	#3B82F6	t	0	2026-04-02 12:45:28.404	2026-04-02 12:45:28.404
cmnhgwpa900043yrjwalyd0mk	MEDIA_CATEGORY	video	Vídeo	Vídeo	Vídeo	videocam-outline	#8B5CF6	t	1	2026-04-02 12:45:28.449	2026-04-02 12:45:28.449
cmnhgwpab00053yrjqpxn2ki9	MEDIA_CATEGORY	documento	Documento	Documento	Documento	document-text-outline	#F59E0B	t	2	2026-04-02 12:45:28.452	2026-04-02 12:45:28.452
cmnhgwpae00063yrj5odh568a	MEDIA_CATEGORY	planta_baixa	Planta Baixa	Planta Baixa	Planta Baixa	map-outline	#10B981	t	3	2026-04-02 12:45:28.454	2026-04-02 12:45:28.454
cmnhgwpah00073yrjczi6purf	MEDIA_CATEGORY	nota_fiscal	Nota Fiscal	Nota Fiscal	Nota Fiscal	receipt-outline	#EF4444	t	4	2026-04-02 12:45:28.457	2026-04-02 12:45:28.457
cmnhgwpak00083yrjoflalzze	MEDIA_CATEGORY	contrato	Contrato	Contrato	Contrato	reader-outline	#6366F1	t	5	2026-04-02 12:45:28.46	2026-04-02 12:45:28.46
cmnhgwpal00093yrjy14vtvom	MEDIA_CATEGORY	laudo	Laudo / Relatório	Laudo / Relatório	Laudo / Relatório	clipboard-outline	#F97316	t	6	2026-04-02 12:45:28.462	2026-04-02 12:45:28.462
cmnhgwpao000a3yrj1q154hb1	MEDIA_CATEGORY	manutencao	Manutenção	Manutenção	Manutenção	construct-outline	#64748B	t	7	2026-04-02 12:45:28.464	2026-04-02 12:45:28.464
cmnhgwpaq000b3yrj03ikvtl4	MEDIA_CATEGORY	seguro	Seguro	Seguro	Seguro	shield-outline	#0EA5E9	t	8	2026-04-02 12:45:28.467	2026-04-02 12:45:28.467
cmnhgwpas000c3yrjwh11nnlq	MEDIA_CATEGORY	outro	Outro	Outro	Outro	ellipsis-horizontal-outline	#9CA3AF	t	9	2026-04-02 12:45:28.468	2026-04-02 12:45:28.468
\.


--
-- Data for Name: NotificationLog; Type: TABLE DATA; Schema: public; Owner: alex
--

COPY public."NotificationLog" (id, "templateId", recipient, channel, status, "sentAt", metadata) FROM stdin;
\.


--
-- Data for Name: NotificationTemplate; Type: TABLE DATA; Schema: public; Owner: alex
--

COPY public."NotificationTemplate" (id, key, label, channel, subject, body, variables, "isActive", "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: Plan; Type: TABLE DATA; Schema: public; Owner: alex
--

COPY public."Plan" (id, name, "priceMonthly", "priceYearly", "maxAssets", "maxUsers", "storageGb", features, "isActive", "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: PushToken; Type: TABLE DATA; Schema: public; Owner: alex
--

COPY public."PushToken" (id, "userId", token, device, "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: ServiceProvider; Type: TABLE DATA; Schema: public; Owner: alex
--

COPY public."ServiceProvider" (id, name, category, rating, reviews, photo, tags, keywords, phone, email, city, state, verified, "isActive", "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: StockItem; Type: TABLE DATA; Schema: public; Owner: alex
--

COPY public."StockItem" (id, "assetId", name, sku, "currentStock", "minStock", unit, "subLocation", "unitPrice", "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: StockMovement; Type: TABLE DATA; Schema: public; Owner: alex
--

COPY public."StockMovement" (id, "itemId", type, quantity, reason, "fromAssetId", "toAssetId", "createdAt") FROM stdin;
\.


--
-- Data for Name: Subscription; Type: TABLE DATA; Schema: public; Owner: alex
--

COPY public."Subscription" (id, "tenantId", "planId", "billingCycle", status, "currentStart", "currentEnd", "cancelledAt", "trialEndsAt", "externalId", "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: TechnicianProfile; Type: TABLE DATA; Schema: public; Owner: alex
--

COPY public."TechnicianProfile" (id, "userId", status, score, cft, specialty, "createdAt", "updatedAt") FROM stdin;
cmnhr8sw90a2j9g8m4sk391vj	cmnhhqj5w000g3yrj2m7fnu6n	ACTIVE	5	\N	\N	2026-04-02 17:34:49.161	2026-04-02 17:34:49.161
\.


--
-- Data for Name: TelemetryEvent; Type: TABLE DATA; Schema: public; Owner: alex
--

COPY public."TelemetryEvent" (id, "tenantId", "ownerEmail", "deviceId", "executionId", "eventType", lat, lng, accuracy, altitude, speed, heading, "locationSource", "batteryLevel", "batteryCharging", "networkType", "appVersion", "osVersion", "deviceModel", "isMockLocation", "isRooted", "clockDriftMs", "serverTimestamp", "deviceTimestamp", payload, "retentionTier", "expiresAt") FROM stdin;
cmnhgupgc00003yrj16djy6ut	\N	test@brspark.com	\N	\N	SESSION_OPEN	-23.5505	-46.6333	15	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 12:43:55.356	\N	null	OPERATIONAL	2026-09-29 12:43:55.354
cmnhid0hx00rz3yrjx67fssf3	\N	unknown	dev_szkcjr	cmngw885r005p7y155oxu7qiw	OS_ACCEPT	\N	\N	\N	\N	\N	\N	GPS	\N	\N	UNKNOWN	1.0.0	26.3.1	Simulator iOS	f	f	4	2026-04-02 13:26:09.093	2026-04-02 13:26:08.883	{"previousState": "IDLE"}	LEGAL	2031-04-02 13:26:09.092
cmnhidbh600sf3yrjfgzwv9iz	\N	unknown	\N	\N	HEARTBEAT	-23.569983	-46.7851655	5	0	-1	-1	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 13:26:23.323	2026-04-02 13:26:17.669	null	RAW_SHORT	2026-04-17 13:26:23.322
cmnhidmvs00sv3yrjqupyu2vh	\N	unknown	dev_szkcjr	cmngw885r005p7y155oxu7qiw	OS_ACCEPT	\N	\N	\N	\N	\N	\N	GPS	\N	\N	UNKNOWN	1.0.0	26.3.1	Simulator iOS	f	f	-1	2026-04-02 13:26:38.105	2026-04-02 13:26:37.933	{"previousState": "DISPATCHED"}	LEGAL	2031-04-02 13:26:38.102
cmnhidmvs00sw3yrj435sc22k	\N	unknown	\N	\N	HEARTBEAT	-23.569983	-46.7851655	5	0	-1	-1	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 13:26:38.105	2026-04-02 13:26:37.749	null	RAW_SHORT	2026-04-17 13:26:38.102
cmnhif5be00v53yrj9sahfgfl	\N	unknown	dev_szkcjr	cmngw885r005p7y155oxu7qiw	OS_ACCEPT	\N	\N	\N	\N	\N	\N	GPS	\N	\N	UNKNOWN	1.0.0	26.3.1	Simulator iOS	f	f	8	2026-04-02 13:27:48.65	2026-04-02 13:27:45.286	{"previousState": "IDLE"}	LEGAL	2031-04-02 13:27:48.649
cmnhif5be00v63yrjdg10zh7l	\N	unknown	\N	\N	HEARTBEAT	-23.569983	-46.7851655	5	0	-1	-1	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 13:27:48.65	2026-04-02 13:27:45.042	null	RAW_SHORT	2026-04-17 13:27:48.649
cmnhif96q00vh3yrjnhto9zam	\N	unknown	dev_szkcjr	cmngw885r005p7y155oxu7qiw	OS_ACCEPT	\N	\N	\N	\N	\N	\N	GPS	\N	\N	UNKNOWN	1.0.0	26.3.1	Simulator iOS	f	f	-2	2026-04-02 13:27:53.666	2026-04-02 13:27:49.304	{"previousState": "DISPATCHED"}	LEGAL	2031-04-02 13:27:53.665
cmnhif96q00vi3yrj9g46y0hj	\N	unknown	\N	\N	HEARTBEAT	-23.569983	-46.7851655	5	0	-1	-1	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 13:27:53.666	2026-04-02 13:27:49.051	null	RAW_SHORT	2026-04-17 13:27:53.665
cmnhigepx00x23yrjcc0g2duk	\N	unknown	dev_szkcjr	cmngw885r005p7y155oxu7qiw	OS_ACCEPT	\N	\N	\N	\N	\N	\N	GPS	\N	\N	UNKNOWN	1.0.0	26.3.1	Simulator iOS	f	f	9	2026-04-02 13:28:47.493	2026-04-02 13:28:47.366	{"previousState": "DISPATCHED"}	LEGAL	2031-04-02 13:28:47.492
cmnhigfr100x83yrjyr6gw7wk	\N	unknown	\N	\N	HEARTBEAT	-23.569983	-46.7851655	5	0	-1	-1	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 13:28:48.829	2026-04-02 13:28:47.339	null	RAW_SHORT	2026-04-17 13:28:48.828
cmnhivt0w01he3yrjibb378vq	\N	unknown	dev_szkcjr	cmngw885r005p7y155oxu7qiw	OS_ACCEPT	\N	\N	\N	\N	\N	\N	GPS	\N	\N	UNKNOWN	1.0.0	26.3.1	Simulator iOS	f	f	-116	2026-04-02 13:40:45.872	2026-04-02 13:40:41.567	{"previousState": "DISPATCHED"}	LEGAL	2031-04-02 13:40:45.87
cmnhivt0w01hf3yrjjm5hycq7	\N	unknown	\N	\N	HEARTBEAT	-23.569983	-46.7851655	5	0	-1	-1	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 13:40:45.872	2026-04-02 13:40:41.161	null	RAW_SHORT	2026-04-17 13:40:45.87
cmnhr9hmq0a3d9g8mkgcxvg3z	cmnhhqj5c000e3yrjmvwv50er	alex@brspark.com	dev_szkcjr	\N	SESSION_OPEN	\N	\N	\N	\N	\N	\N	GPS	\N	\N	UNKNOWN	1.0.0	26.3.1	Simulator iOS	f	f	-106	2026-04-02 17:35:21.218	2026-04-02 17:35:16.922	{}	OPERATIONAL	2026-09-29 17:35:21.216
cmnhrb85j0a5r9g8mckgo44l2	\N	unknown	dev_szkcjr	\N	SESSION_OPEN	\N	\N	\N	\N	\N	\N	GPS	\N	\N	UNKNOWN	1.0.0	26.3.1	Simulator iOS	f	f	6	2026-04-02 17:36:42.248	2026-04-02 17:36:42.087	{}	OPERATIONAL	2026-09-29 17:36:42.247
cmnhrtfrb0bh09g8m3rdlnrcp	\N	unknown	dev_szkcjr	cmnhrqhbi0b9j9g8mtnd7ocdb	OS_ACCEPT	\N	\N	\N	\N	\N	\N	GPS	\N	\N	UNKNOWN	1.0.0	26.3.1	Simulator iOS	f	f	-45	2026-04-02 17:50:51.911	2026-04-02 17:50:40.178	{"previousState": "IDLE"}	LEGAL	2031-04-02 17:50:51.884
cmnhrtfiz0bgw9g8meixc78k2	\N	unknown	dev_szkcjr	cmnhrqhbi0b9j9g8mtnd7ocdb	OS_ACCEPT	\N	\N	\N	\N	\N	\N	GPS	\N	\N	UNKNOWN	1.0.0	26.3.1	Simulator iOS	f	f	-45	2026-04-02 17:50:51.611	2026-04-02 17:50:40.178	{"previousState": "IDLE"}	LEGAL	2031-04-02 17:50:51.611
cmnhrtf8n0bgu9g8m5z2rf4f5	\N	unknown	dev_szkcjr	cmnhrqhbi0b9j9g8mtnd7ocdb	OS_ACCEPT	\N	\N	\N	\N	\N	\N	GPS	\N	\N	UNKNOWN	1.0.0	26.3.1	Simulator iOS	f	f	-45	2026-04-02 17:50:51.239	2026-04-02 17:50:40.178	{"previousState": "IDLE"}	LEGAL	2031-04-02 17:50:51.208
cmnhrtfkc0bgy9g8mr1drf0g1	\N	unknown	dev_szkcjr	cmnhrqhbi0b9j9g8mtnd7ocdb	OS_ACCEPT	\N	\N	\N	\N	\N	\N	GPS	\N	\N	UNKNOWN	1.0.0	26.3.1	Simulator iOS	f	f	-45	2026-04-02 17:50:51.66	2026-04-02 17:50:40.178	{"previousState": "IDLE"}	LEGAL	2031-04-02 17:50:51.659
cmnhrtf7b0bgs9g8mw1z5rekj	\N	unknown	dev_szkcjr	cmnhrqhbi0b9j9g8mtnd7ocdb	OS_ACCEPT	\N	\N	\N	\N	\N	\N	GPS	\N	\N	UNKNOWN	1.0.0	26.3.1	Simulator iOS	f	f	-45	2026-04-02 17:50:51.184	2026-04-02 17:50:40.178	{"previousState": "IDLE"}	LEGAL	2031-04-02 17:50:50.967
cmnhrtfkc0bgz9g8m4o9coxew	\N	unknown	\N	\N	HEARTBEAT	-23.569983	-46.7851655	5	0	-1	-1	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 17:50:51.66	2026-04-02 17:50:40.752	null	RAW_SHORT	2026-04-17 17:50:51.659
cmnhrtfiz0bgx9g8m9jf22zmm	\N	unknown	\N	\N	HEARTBEAT	-23.569983	-46.7851655	5	0	-1	-1	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 17:50:51.611	2026-04-02 17:50:40.752	null	RAW_SHORT	2026-04-17 17:50:51.611
cmnhrtf7j0bgt9g8mpc2clbzt	\N	unknown	\N	\N	HEARTBEAT	-23.569983	-46.7851655	5	0	-1	-1	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 17:50:51.184	2026-04-02 17:50:40.752	null	RAW_SHORT	2026-04-17 17:50:50.967
cmnhrtf8n0bgv9g8mdjkh25lo	\N	unknown	\N	\N	HEARTBEAT	-23.569983	-46.7851655	5	0	-1	-1	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 17:50:51.239	2026-04-02 17:50:40.752	null	RAW_SHORT	2026-04-17 17:50:51.208
cmnhrtfrb0bh19g8melp76gxq	\N	unknown	\N	\N	HEARTBEAT	-23.569983	-46.7851655	5	0	-1	-1	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 17:50:51.911	2026-04-02 17:50:40.752	null	RAW_SHORT	2026-04-17 17:50:51.884
cmnhrufd00bk49g8mkhakgz4u	\N	unknown	dev_szkcjr	cmnhrqhbi0b9j9g8mtnd7ocdb	TRANSIT_START	\N	\N	\N	\N	\N	\N	GPS	\N	\N	UNKNOWN	1.0.0	26.3.1	Simulator iOS	f	f	-4	2026-04-02 17:51:38.051	2026-04-02 17:51:36.074	{"previousState": "DISPATCHED"}	LEGAL	2031-04-02 17:51:38.048
cmnhrufd00bk59g8mumlxae5f	\N	unknown	\N	\N	HEARTBEAT	-23.569983	-46.7851655	5	0	-1	-1	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 17:51:38.051	2026-04-02 17:51:36.082	null	RAW_SHORT	2026-04-17 17:51:38.048
cmnhrxyhk003wl0zikj60jev4	\N	unknown@empresa.com	dev_szkcjr	cmnhrqhbi0b9j9g8mtnd7ocdb	SESSION_CLOSE	\N	\N	\N	\N	\N	\N	GPS	\N	\N	UNKNOWN	1.0.0	26.3.1	Simulator iOS	f	f	-35	2026-04-02 17:54:22.808	2026-04-02 17:54:20.099	{"previousState": "IN_TRANSIT"}	OPERATIONAL	2026-09-29 17:54:22.807
cmnhrxyhm003xl0zinfo86p1o	\N	unknown@empresa.com	dev_szkcjr	cmnhrqhbi0b9j9g8mtnd7ocdb	SESSION_CLOSE	\N	\N	\N	\N	\N	\N	GPS	\N	\N	UNKNOWN	1.0.0	26.3.1	Simulator iOS	f	f	-35	2026-04-02 17:54:22.811	2026-04-02 17:54:20.099	{"previousState": "IN_TRANSIT"}	OPERATIONAL	2026-09-29 17:54:22.81
cmnhslt190014quvgeygqf2z7	\N	unknown	dev_szkcjr	cmnhrqhbi0b9j9g8mtnd7ocdb	OS_ACCEPT	\N	\N	\N	\N	\N	\N	GPS	\N	\N	UNKNOWN	1.0.0	26.3.1	Simulator iOS	f	f	6	2026-04-02 18:12:55.485	2026-04-02 18:12:55.438	{"previousState": "IDLE"}	LEGAL	2031-04-02 18:12:55.484
cmnht90hm00w0quvgb26boerv	\N	unknown	dev_szkcjr	cmnht8qog00vkquvgverzll77	OS_ACCEPT	\N	\N	\N	\N	\N	\N	GPS	\N	\N	UNKNOWN	1.0.0	26.3.1	Simulator iOS	f	f	0	2026-04-02 18:30:58.234	2026-04-02 18:30:53.922	{"previousState": "DISPATCHED"}	LEGAL	2031-04-02 18:30:58.231
cmnht90hm00w1quvgvy7tuptg	\N	unknown	\N	\N	HEARTBEAT	-23.569983	-46.7851655	5	0	-1	-1	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 18:30:58.234	2026-04-02 18:30:53.973	null	RAW_SHORT	2026-04-17 18:30:58.231
cmnht94cs00w7quvgmalrzbb8	\N	unknown	dev_szkcjr	cmnht8qog00vkquvgverzll77	TRANSIT_START	\N	\N	\N	\N	\N	\N	GPS	\N	\N	UNKNOWN	1.0.0	26.3.1	Simulator iOS	f	f	19	2026-04-02 18:31:03.245	2026-04-02 18:31:00.835	{"previousState": "DISPATCHED"}	LEGAL	2031-04-02 18:31:03.242
cmnht94ct00w8quvg6uc7wrpm	\N	unknown	\N	\N	HEARTBEAT	-23.569983	-46.7851655	5	0	-1	-1	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 18:31:03.245	2026-04-02 18:31:00.799	null	RAW_SHORT	2026-04-17 18:31:03.242
cmnhtb5ur00z9quvgtcvokbkh	\N	unknown@empresa.com	dev_szkcjr	cmnht8qog00vkquvgverzll77	SESSION_CLOSE	\N	\N	\N	\N	\N	\N	GPS	\N	\N	UNKNOWN	1.0.0	26.3.1	Simulator iOS	f	f	-30	2026-04-02 18:32:38.5	2026-04-02 18:32:37.306	{"previousState": "IN_TRANSIT"}	OPERATIONAL	2026-09-29 18:32:38.499
cmnhtodp8002kf5jr53ojt1fj	\N	unknown	dev_szkcjr	cmnhtnyp4001zf5jrvv0r23qa	OS_ACCEPT	\N	\N	\N	\N	\N	\N	GPS	\N	\N	UNKNOWN	1.0.0	26.3.1	Simulator iOS	f	f	2	2026-04-02 18:42:55.196	2026-04-02 18:42:53.355	{"previousState": "IDLE"}	LEGAL	2031-04-02 18:42:55.195
cmnhtodp8002lf5jr6dfeu396	\N	unknown	\N	\N	HEARTBEAT	-23.569983	-46.7851655	5	0	-1	-1	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 18:42:55.196	2026-04-02 18:42:52.846	null	RAW_SHORT	2026-04-17 18:42:55.195
cmnhtp8or003qf5jrdo5o3nqh	\N	unknown	dev_szkcjr	cmnhtnyp4001zf5jrvv0r23qa	TRANSIT_START	\N	\N	\N	\N	\N	\N	GPS	\N	\N	UNKNOWN	1.0.0	26.3.1	Simulator iOS	f	f	22	2026-04-02 18:43:35.356	2026-04-02 18:43:34.526	{"previousState": "DISPATCHED"}	LEGAL	2031-04-02 18:43:35.355
cmnhtp8or003rf5jrvi6ttfuu	\N	unknown	\N	\N	HEARTBEAT	-23.569983	-46.7851655	5	0	-1	-1	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 18:43:35.356	2026-04-02 18:43:30.993	null	RAW_SHORT	2026-04-17 18:43:35.355
cmnhtp8or003sf5jrqh8mara0	\N	unknown	dev_szkcjr	cmnhtnyp4001zf5jrvv0r23qa	FRAUD_FLAG	37.33240731	-122.03046898	\N	\N	\N	\N	GPS	\N	\N	UNKNOWN	1.0.0	26.3.1	Simulator iOS	t	f	-8	2026-04-02 18:43:35.356	2026-04-02 18:43:34.872	{"lat": 37.33240731, "lng": -122.03046898, "reason": "MOCK_LOCATION", "severity": "HIGH"}	LEGAL	2031-04-02 18:43:35.355
cmnhtp8or003tf5jr84hv6jbp	\N	unknown	\N	\N	HEARTBEAT	37.33240731	-122.03046898	65	0	-1	-1	\N	\N	\N	\N	\N	\N	\N	t	f	\N	2026-04-02 18:43:35.356	2026-04-02 18:43:34.802	null	RAW_SHORT	2026-04-17 18:43:35.355
cmnhtrhzl006zf5jrb2167vkh	\N	unknown@empresa.com	dev_szkcjr	cmnhtnyp4001zf5jrvv0r23qa	SESSION_CLOSE	\N	\N	\N	\N	\N	\N	GPS	\N	\N	UNKNOWN	1.0.0	26.3.1	Simulator iOS	f	f	-44	2026-04-02 18:45:20.721	2026-04-02 18:45:17.527	{"previousState": "IN_TRANSIT"}	OPERATIONAL	2026-09-29 18:45:20.72
cmnhyvreh008xk84w92e0f1zw	\N	unknown	dev_szkcjr	cmnhykdhy0005k84w6xci9f1x	OS_ACCEPT	\N	\N	\N	\N	\N	\N	GPS	\N	\N	UNKNOWN	1.0.0	26.3.1	Simulator iOS	f	f	-3	2026-04-02 21:08:37.626	2026-04-02 21:08:34.411	{"previousState": "IDLE"}	LEGAL	2031-04-02 21:08:37.623
cmnhyvreh008yk84w9t6pjag6	\N	unknown	\N	\N	HEARTBEAT	-23.569983	-46.7851655	5	0	-1	-1	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 21:08:37.626	2026-04-02 21:08:34.008	null	RAW_SHORT	2026-04-17 21:08:37.623
cmnhywq4600adk84wknlp6ede	\N	unknown	dev_szkcjr	cmnhykdhy0005k84w6xci9f1x	TRANSIT_START	\N	\N	\N	\N	\N	\N	GPS	\N	\N	UNKNOWN	1.0.0	26.3.1	Simulator iOS	f	f	24	2026-04-02 21:09:22.615	2026-04-02 21:09:18.466	{"previousState": "DISPATCHED"}	LEGAL	2031-04-02 21:09:22.611
cmnhywq4600aek84w95laywt5	\N	unknown	\N	\N	HEARTBEAT	37.33485843	-122.03334424	5	0	14.82	254.88	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 21:09:22.615	2026-04-02 21:09:18.63	null	RAW_SHORT	2026-04-17 21:09:22.611
cmnhywxts00apk84w2c8qcus8	\N	unknown	\N	\N	HEARTBEAT	37.3345597	-122.03583308	5	0	24.28	267.19	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 21:09:32.609	2026-04-02 21:09:28.883	null	RAW_SHORT	2026-04-17 21:09:32.608
cmnhyx1oi00avk84wnems85du	\N	unknown	\N	\N	HEARTBEAT	37.33451917	-122.03813827	5	0	27.07	268.95	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 21:09:37.602	2026-04-02 21:09:36.883	null	RAW_SHORT	2026-04-17 21:09:37.601
cmnhyx9eh00b6k84wbnyc591j	\N	unknown	\N	\N	HEARTBEAT	37.33446519	-122.04041597	5	0	31.11	268.59	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 21:09:47.61	2026-04-02 21:09:43.892	null	RAW_SHORT	2026-04-17 21:09:47.609
cmnhyxd9w00bck84wh2rob6nk	\N	unknown	\N	\N	HEARTBEAT	37.33445363	-122.04302852	5	0	34.3	270	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 21:09:52.629	2026-04-02 21:09:50.892	null	RAW_SHORT	2026-04-17 21:09:52.628
cmnhyxh4q00bik84wz63sb06k	\N	unknown	\N	\N	HEARTBEAT	37.33444244	-122.045341	5	0	33.15	269.3	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 21:09:57.626	2026-04-02 21:09:56.88	null	RAW_SHORT	2026-04-17 21:09:57.625
cmnhyxout00btk84wtslp8wpk	\N	unknown	\N	\N	HEARTBEAT	37.33420971	-122.04784191	5	0	30.78	256.64	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 21:10:07.637	2026-04-02 21:10:03.881	null	RAW_SHORT	2026-04-17 21:10:07.636
cmnhyxsph00bzk84wfuxwn789	\N	unknown	\N	\N	HEARTBEAT	37.33367998	-122.05028306	5	0	32.98	255.59	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 21:10:12.629	2026-04-02 21:10:10.894	null	RAW_SHORT	2026-04-17 21:10:12.627
cmnhyxwkc00c5k84wfda5j6uc	\N	unknown	\N	\N	HEARTBEAT	37.33321101	-122.05246948	5	0	33.49	254.88	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 21:10:17.629	2026-04-02 21:10:16.886	null	RAW_SHORT	2026-04-17 21:10:17.628
cmnhyy4a300cgk84wamthky10	\N	unknown	\N	\N	HEARTBEAT	37.33268517	-122.05498531	5	0	33.08	254.88	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 21:10:27.627	2026-04-02 21:10:23.885	null	RAW_SHORT	2026-04-17 21:10:27.626
cmnhyy84z00cmk84w3k6qhux3	\N	unknown	\N	\N	HEARTBEAT	37.33229772	-122.05757204	5	0	33.77	266.48	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 21:10:32.627	2026-04-02 21:10:30.89	null	RAW_SHORT	2026-04-17 21:10:32.626
cmnhyybzw00csk84winayrmj1	\N	unknown	\N	\N	HEARTBEAT	37.33244004	-122.05984991	5	0	34	282.3	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 21:10:37.628	2026-04-02 21:10:36.886	null	RAW_SHORT	2026-04-17 21:10:37.627
cmnhyyjpm00d3k84wqg7ulg6w	\N	unknown	\N	\N	HEARTBEAT	37.33307736	-122.06203541	5	0	34.54	294.26	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 21:10:47.626	2026-04-02 21:10:42.892	null	RAW_SHORT	2026-04-17 21:10:47.625
cmnhyynkg00d9k84wp3hgpse8	\N	unknown	\N	\N	HEARTBEAT	37.33383844	-122.06417204	5	0	34.46	293.91	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 21:10:52.624	2026-04-02 21:10:48.883	null	RAW_SHORT	2026-04-17 21:10:52.623
cmnhyyrfh00dfk84w7nn4vnee	\N	unknown	\N	\N	HEARTBEAT	37.33435409	-122.06636961	5	0	33.82	279.84	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 21:10:57.629	2026-04-02 21:10:54.886	null	RAW_SHORT	2026-04-17 21:10:57.628
cmnhyyva900dlk84wl3y9s9cn	\N	unknown	\N	\N	HEARTBEAT	37.33442613	-122.06864035	5	0	33.67	266.13	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 21:11:02.625	2026-04-02 21:11:00.89	null	RAW_SHORT	2026-04-17 21:11:02.624
cmnhyyz4y00drk84w6milyv11	\N	unknown	\N	\N	HEARTBEAT	37.33410968	-122.07087404	5	0	33.62	256.99	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 21:11:07.618	2026-04-02 21:11:06.883	null	RAW_SHORT	2026-04-17 21:11:07.617
cmnhyz6uq00e2k84wr6s0bh6o	\N	unknown	\N	\N	HEARTBEAT	37.33369775	-122.07309474	5	0	33.08	258.05	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 21:11:17.619	2026-04-02 21:11:12.878	null	RAW_SHORT	2026-04-17 21:11:17.618
cmnhyzapt00e8k84wcen9iwui	\N	unknown	\N	\N	HEARTBEAT	37.33355228	-122.07558936	5	0	31.58	274.57	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 21:11:22.625	2026-04-02 21:11:19.888	null	RAW_SHORT	2026-04-17 21:11:22.624
cmnhyzekq00eek84w3iztijd4	\N	unknown	\N	\N	HEARTBEAT	37.33402871	-122.07804543	5	0	32.47	292.15	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 21:11:27.626	2026-04-02 21:11:26.893	null	RAW_SHORT	2026-04-17 21:11:27.625
cmnhyzmak00epk84wcqpy9h9y	\N	unknown	\N	\N	HEARTBEAT	37.33511119	-122.08026077	5	0	33.53	310.78	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 21:11:37.629	2026-04-02 21:11:33.884	null	RAW_SHORT	2026-04-17 21:11:37.627
cmnhyzq5g00evk84we3b0wiaq	\N	unknown	\N	\N	HEARTBEAT	37.33638536	-122.08193111	5	0	33.88	314.3	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 21:11:42.628	2026-04-02 21:11:39.882	null	RAW_SHORT	2026-04-17 21:11:42.627
cmnhyzu0p00f1k84weoqq0zmh	\N	unknown	\N	\N	HEARTBEAT	37.33758129	-122.08362627	5	0	33.46	307.27	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 21:11:47.642	2026-04-02 21:11:45.889	null	RAW_SHORT	2026-04-17 21:11:47.641
cmnhz01qk00fck84wmhkpld0i	\N	unknown	\N	\N	HEARTBEAT	37.33879885	-122.08577472	5	0	33.54	304.45	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 21:11:57.644	2026-04-02 21:11:52.879	null	RAW_SHORT	2026-04-17 21:11:57.643
cmnhz05m700fik84wstcioevu	\N	unknown	\N	\N	HEARTBEAT	37.33998434	-122.08792937	5	0	32.79	304.45	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 21:12:02.671	2026-04-02 21:11:59.895	null	RAW_SHORT	2026-04-17 21:12:02.67
cmnhz09h300fok84wvrdr8aeh	\N	unknown	\N	\N	HEARTBEAT	37.34107194	-122.09015057	5	0	33.16	299.88	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 21:12:07.671	2026-04-02 21:12:06.888	null	RAW_SHORT	2026-04-17 21:12:07.67
cmnhz0h6l00fzk84wpqa87c2i	\N	unknown	\N	\N	HEARTBEAT	37.34229154	-122.092223	5	0	32.66	314.3	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 21:12:17.662	2026-04-02 21:12:13.884	null	RAW_SHORT	2026-04-17 21:12:17.661
cmnhz0l1e00g5k84w0us6iclf	\N	unknown	\N	\N	HEARTBEAT	37.34374576	-122.09392	5	0	31.14	317.46	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 21:12:22.659	2026-04-02 21:12:20.878	null	RAW_SHORT	2026-04-17 21:12:22.658
cmnhz0ox100gjk84w044ojlxq	\N	unknown@empresa.com	dev_szkcjr	cmnhykdhy0005k84w6xci9f1x	SESSION_CLOSE	\N	\N	\N	\N	\N	\N	GPS	\N	\N	UNKNOWN	1.0.0	26.3.1	Simulator iOS	f	f	-30	2026-04-02 21:12:27.685	2026-04-02 21:12:23.227	{"previousState": "IN_TRANSIT"}	OPERATIONAL	2026-09-29 21:12:27.684
cmni0bjvo027wk84waxxdyg02	cmnhhqj5c000e3yrjmvwv50er	alex@brspark.com	dev_szkcjr	cmnhykdhy0005k84w6xci9f1x	SESSION_OPEN	\N	\N	\N	\N	\N	\N	GPS	\N	\N	UNKNOWN	1.0.0	26.3.1	Simulator iOS	f	f	1	2026-04-02 21:48:53.988	2026-04-02 21:48:51.464	{}	OPERATIONAL	2026-09-29 21:48:53.987
cmni0brlf028ck84wzdkcipvx	cmnhhqj5c000e3yrjmvwv50er	alex@brspark.com	dev_szkcjr	cmnhykdhy0005k84w6xci9f1x	SESSION_OPEN	\N	\N	\N	\N	\N	\N	GPS	\N	\N	UNKNOWN	1.0.0	26.3.1	Simulator iOS	f	f	6	2026-04-02 21:49:03.987	2026-04-02 21:49:01.195	{}	OPERATIONAL	2026-09-29 21:49:03.986
cmni0hjo402gkk84wujipynw1	cmnhhqj5c000e3yrjmvwv50er	alex@brspark.com	dev_szkcjr	\N	SESSION_OPEN	\N	\N	\N	\N	\N	\N	GPS	\N	\N	UNKNOWN	1.0.0	26.3.1	Simulator iOS	f	f	7	2026-04-02 21:53:33.653	2026-04-02 21:53:33.479	{}	OPERATIONAL	2026-09-29 21:53:33.652
cmni0hnjr02gqk84wnannaf3k	cmnhhqj5c000e3yrjmvwv50er	alex@brspark.com	dev_szkcjr	\N	SESSION_OPEN	\N	\N	\N	\N	\N	\N	GPS	\N	\N	UNKNOWN	1.0.0	26.3.1	Simulator iOS	f	f	6	2026-04-02 21:53:38.68	2026-04-02 21:53:34.129	{}	OPERATIONAL	2026-09-29 21:53:38.679
cmni0qgy302tbk84wmyzhct36	cmnhhqj5c000e3yrjmvwv50er	alex@brspark.com	dev_szkcjr	cmni0qayq02sqk84wy5bpuvea	OS_ACCEPT	\N	\N	\N	\N	\N	\N	GPS	\N	\N	UNKNOWN	1.0.0	26.3.1	Simulator iOS	f	f	-3	2026-04-02 22:00:30.028	2026-04-02 22:00:29.162	{"previousState": "IDLE"}	LEGAL	2031-04-02 22:00:30.027
cmni0qgy302tck84w2appofd9	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.33019806	-122.02462051	10	0	3.74	88.4	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 22:00:30.028	2026-04-02 22:00:29.134	null	RAW_SHORT	2026-04-17 22:00:30.027
cmni0qsir02txk84w6707ilke	cmnhhqj5c000e3yrjmvwv50er	alex@brspark.com	dev_szkcjr	cmni0qayq02sqk84wy5bpuvea	TRANSIT_START	\N	\N	\N	\N	\N	\N	GPS	\N	\N	UNKNOWN	1.0.0	26.3.1	Simulator iOS	f	f	21	2026-04-02 22:00:45.028	2026-04-02 22:00:40.17	{"previousState": "DISPATCHED"}	LEGAL	2031-04-02 22:00:45.027
cmni0qsir02tyk84wqp1r8juh	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.33020867	-122.024012	30	0	3.9	91.39	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 22:00:45.028	2026-04-02 22:00:40.13	null	RAW_SHORT	2026-04-17 22:00:45.027
cmni0rv8l02vdk84wzvej8crg	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.33009437	-122.02175602	5	0	3.68	97.01	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 22:01:35.205	2026-04-02 22:01:32.143	null	RAW_SHORT	2026-04-17 22:01:35.204
cmni0w9vs031bk84wyku8cpzu	cmnhhqj5c000e3yrjmvwv50er	alex@brspark.com	dev_szkcjr	cmni0qayq02sqk84wy5bpuvea	SESSION_CLOSE	\N	\N	\N	\N	\N	\N	GPS	\N	\N	UNKNOWN	1.0.0	26.3.1	Simulator iOS	f	f	-31	2026-04-02 22:05:00.808	2026-04-02 22:04:59.946	{"previousState": "IN_TRANSIT"}	OPERATIONAL	2026-09-29 22:05:00.807
cmni0w9vs031ck84w7u35bcb9	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.33467638	-122.03432425	5	0	20.07	259.45	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 22:05:00.808	2026-04-02 22:04:59.826	null	RAW_SHORT	2026-04-17 22:05:00.807
cmni0wpdf031xk84wzy8d1uqw	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.33447068	-122.04007348	5	0	30.45	267.89	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 22:05:20.884	2026-04-02 22:05:19.82	null	RAW_SHORT	2026-04-17 22:05:20.883
cmni0x0zr032ik84w10qf00yv	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.33443657	-122.04571727	5	0	33.01	267.54	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 22:05:35.943	2026-04-02 22:05:34.828	null	RAW_SHORT	2026-04-17 22:05:35.942
cmni0xcl0032yk84w48p8db73	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.33344889	-122.05137547	5	0	33.73	255.59	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 22:05:50.964	2026-04-02 22:05:50.817	null	RAW_SHORT	2026-04-17 22:05:50.963
cmni0xs1v033jk84w4ppjohru	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.33232211	-122.05719234	5	0	33.56	264.38	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 22:06:11.012	2026-04-02 22:06:06.82	null	RAW_SHORT	2026-04-17 22:06:11.011
cmni0y3nw033zk84wavq2joml	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.33333498	-122.06274686	5	0	34.33	294.61	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 22:06:26.061	2026-04-02 22:06:21.819	null	RAW_SHORT	2026-04-17 22:06:26.059
cmni0yfa8034hk84wdwfw532y	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.33444654	-122.06826065	5	0	33.67	268.24	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 22:06:41.121	2026-04-02 22:06:36.827	null	RAW_SHORT	2026-04-17 22:06:41.12
cmni0yqvz034zk84wp4qxddn6	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.33359159	-122.07381886	5	0	32.16	261.21	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 22:06:56.159	2026-04-02 22:06:51.832	null	RAW_SHORT	2026-04-17 22:06:56.158
cmni0z2ih035fk84wpv52f3vr	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.33457244	-122.0793639	5	0	33.02	301.99	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 22:07:11.225	2026-04-02 22:07:07.818	null	RAW_SHORT	2026-04-17 22:07:11.224
cmni0zce3035xk84wjjd2u0k8	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.33758129	-122.08362627	5	0	33.46	307.27	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 22:07:24.028	2026-04-02 22:07:22.824	null	RAW_SHORT	2026-04-17 22:07:24.027
cmni0zppi036sk84wyycp3ei1	cmnhhqj5c000e3yrjmvwv50er	alex@brspark.com	dev_szkcjr	cmni0zakf035wk84wuzy84yix	OS_ACCEPT	\N	\N	\N	\N	\N	\N	GPS	\N	\N	UNKNOWN	1.0.0	26.3.1	Simulator iOS	f	f	6	2026-04-02 22:07:41.287	2026-04-02 22:07:37.361	{"previousState": "IDLE"}	LEGAL	2031-04-02 22:07:41.286
cmni0zppj036tk84ws1c9y0tl	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.33998434	-122.08792937	5	0	32.79	304.45	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 22:07:41.287	2026-04-02 22:07:36.831	null	RAW_SHORT	2026-04-17 22:07:41.286
cmni0zxfx0374k84wwno6sqav	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.34154237	-122.09108423	5	0	32.97	304.1	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 22:07:51.31	2026-04-02 22:07:46.821	null	RAW_SHORT	2026-04-17 22:07:51.309
cmni1056j037fk84w04o2x6fd	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.34353735	-122.09368045	5	0	31.14	317.46	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 22:08:01.34	2026-04-02 22:07:56.827	null	RAW_SHORT	2026-04-17 22:08:01.339
cmni1056j037gk84wyscftrde	cmnhhqj5c000e3yrjmvwv50er	alex@brspark.com	dev_szkcjr	cmni0zakf035wk84wuzy84yix	TRANSIT_START	\N	\N	\N	\N	\N	\N	GPS	\N	\N	UNKNOWN	1.0.0	26.3.1	Simulator iOS	f	f	-9	2026-04-02 22:08:01.34	2026-04-02 22:08:00.228	{"previousState": "DISPATCHED"}	LEGAL	2031-04-02 22:08:01.339
cmni1056j037hk84wg6r2pzdm	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.34415677	-122.09439031	5	0	30.74	316.41	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 22:08:01.34	2026-04-02 22:07:59.816	null	RAW_SHORT	2026-04-17 22:08:01.339
cmni10cws037sk84wk0djaki8	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.34534964	-122.09631924	5	0	31.26	300.23	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 22:08:11.356	2026-04-02 22:08:06.821	null	RAW_SHORT	2026-04-17 22:08:11.355
cmni10gsq037yk84wtipz185i	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.34633112	-122.09862728	5	0	34.15	298.12	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 22:08:16.394	2026-04-02 22:08:13.846	null	RAW_SHORT	2026-04-17 22:08:16.393
cmni10ko20384k84wzthgwtqc	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.34719244	-122.1006624	5	0	33.72	297.77	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 22:08:21.41	2026-04-02 22:08:19.834	null	RAW_SHORT	2026-04-17 22:08:21.409
cmni10sn3038fk84wiyf9iwie	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.34831482	-122.10286198	5	0	33.08	310.78	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 22:08:31.743	2026-04-02 22:08:26.825	null	RAW_SHORT	2026-04-17 22:08:31.742
cmni10wag038lk84whmsyd1gx	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.34991623	-122.10451573	5	0	33.2	328.01	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 22:08:36.472	2026-04-02 22:08:33.828	null	RAW_SHORT	2026-04-17 22:08:36.471
cmni1105j038rk84waeyleizz	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.35145376	-122.10569934	5	0	33.23	327.66	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 22:08:41.48	2026-04-02 22:08:39.843	null	RAW_SHORT	2026-04-17 22:08:41.479
cmni117v80392k84wxxx062rt	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.35304318	-122.1073468	5	0	32.43	312.19	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 22:08:51.476	2026-04-02 22:08:46.829	null	RAW_SHORT	2026-04-17 22:08:51.475
cmni11bqo0398k84wbxl7p56j	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.35416275	-122.10941512	5	0	31.82	297.07	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 22:08:56.497	2026-04-02 22:08:53.83	null	RAW_SHORT	2026-04-17 22:08:56.496
cmni11fm1039ek84wu6cz5303	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.35486926	-122.11178469	5	0	32.5	287.58	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 22:09:01.513	2026-04-02 22:09:00.829	null	RAW_SHORT	2026-04-17 22:09:01.512
cmni11nbn039pk84wq65qgct9	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.35555758	-122.11420421	5	0	32.28	295.31	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 22:09:11.507	2026-04-02 22:09:07.828	null	RAW_SHORT	2026-04-17 22:09:11.507
cmni11r71039vk84w2kd307tw	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.35667204	-122.11636489	5	0	32.76	310.43	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 22:09:16.525	2026-04-02 22:09:14.829	null	RAW_SHORT	2026-04-17 22:09:16.524
cmni11yxb03a6k84wy17wzpnl	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.35821377	-122.11808519	5	0	33.51	325.9	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 22:09:26.543	2026-04-02 22:09:21.888	null	RAW_SHORT	2026-04-17 22:09:26.542
cmni122t803ack84w85714rj8	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.35983897	-122.11918616	5	0	34.77	333.98	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 22:09:31.58	2026-04-02 22:09:27.82	null	RAW_SHORT	2026-04-17 22:09:31.579
cmni126nh03aik84w9js3qco5	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.36154377	-122.1202173	5	0	34.65	332.23	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 22:09:36.558	2026-04-02 22:09:33.828	null	RAW_SHORT	2026-04-17 22:09:36.557
cmni12aif03aok84w45p3vbhg	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.36303768	-122.12160442	5	0	34.35	315.35	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 22:09:41.56	2026-04-02 22:09:39.82	null	RAW_SHORT	2026-04-17 22:09:41.559
cmni12i9503azk84wynhzhwrg	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.36424153	-122.12374717	5	0	32.83	296.72	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 22:09:51.593	2026-04-02 22:09:46.826	null	RAW_SHORT	2026-04-17 22:09:51.592
cmni12m4j03b5k84wkllg23x8	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.36483488	-122.12623861	5	0	33.57	278.09	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 22:09:56.611	2026-04-02 22:09:53.822	null	RAW_SHORT	2026-04-17 22:09:56.61
cmni12pzd03bbk84wjggdfe3g	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.36489536	-122.12851823	5	0	33.32	270.35	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 22:10:01.609	2026-04-02 22:09:59.826	null	RAW_SHORT	2026-04-17 22:10:01.608
cmni12xq303bmk84w96d7dqi6	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.36513495	-122.13112023	5	0	33.14	285.82	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 22:10:11.643	2026-04-02 22:10:06.821	null	RAW_SHORT	2026-04-17 22:10:11.642
cmni131mf03bsk84wuhxfs87f	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.3658664	-122.13358057	5	0	33.38	290.74	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 22:10:16.696	2026-04-02 22:10:13.826	null	RAW_SHORT	2026-04-17 22:10:16.695
cmni135gw03byk84wq90gg5hq	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.36657341	-122.13598643	5	0	32.22	290.39	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 22:10:21.681	2026-04-02 22:10:20.831	null	RAW_SHORT	2026-04-17 22:10:21.68
cmni13d7i03c9k84w2wmvsbm4	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.36743034	-122.13834434	5	0	33.46	300.59	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 22:10:31.711	2026-04-02 22:10:27.824	null	RAW_SHORT	2026-04-17 22:10:31.71
cmni1449f03djk84wb5kzi1c8	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.37595557	-122.14739872	5	0	34.41	317.81	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 22:11:06.771	2026-04-02 22:11:04.826	null	RAW_SHORT	2026-04-17 22:11:06.77
cmni14ipu03e8k84wdbedlax4	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.38048092	-122.15123277	5	0	34.49	342.42	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 22:11:25.506	2026-04-02 22:11:22.828	null	RAW_SHORT	2026-04-17 22:11:25.505
cmni16l9y03h8k84w9upi2htw	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.39602298	-122.17827723	5	0	33.26	322.03	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 22:13:02.135	2026-04-02 22:13:00.837	null	RAW_SHORT	2026-04-17 22:13:02.134
cmni178js03i4k84w176mnkcm	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.40336963	-122.1855891	5	0	34.12	321.33	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 22:13:32.296	2026-04-02 22:13:30.826	null	RAW_SHORT	2026-04-17 22:13:32.295
cmni187bp03jgk84wvbi9egkl	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.41082094	-122.19968311	5	0	34.81	291.8	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 22:14:17.365	2026-04-02 22:14:16.831	null	RAW_SHORT	2026-04-17 22:14:17.365
cmni13f5503cfk84wyxoxbwgt	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.36854278	-122.1401674	5	0	34.22	312.89	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 22:10:34.217	2026-04-02 22:10:33.827	null	RAW_SHORT	2026-04-17 22:10:34.217
cmni13kya03cqk84wzij3f4jj	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.36994839	-122.1416339	5	0	34.01	324.14	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 22:10:41.747	2026-04-02 22:10:39.827	null	RAW_SHORT	2026-04-17 22:10:41.746
cmni13osq03cwk84wvd7snzrz	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.37142067	-122.14297886	5	0	33.47	324.14	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 22:10:46.731	2026-04-02 22:10:45.826	null	RAW_SHORT	2026-04-17 22:10:46.73
cmni14vcx03evk84wav5n23hq	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.38560981	-122.15272559	5	0	33.44	335.74	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 22:11:41.89	2026-04-02 22:11:39.829	null	RAW_SHORT	2026-04-17 22:11:41.889
cmni156za03fbk84wuz1reza1	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.38852302	-122.15740629	5	0	32.12	283.36	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 22:11:56.95	2026-04-02 22:11:56.832	null	RAW_SHORT	2026-04-17 22:11:56.949
cmni15mgl03fwk84w1t8vf04z	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.38966543	-122.16308369	5	0	32.49	297.07	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 22:12:17.014	2026-04-02 22:12:12.834	null	RAW_SHORT	2026-04-17 22:12:17.013
cmni17vq203j0k84whgk4hiii	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.40913001	-122.19434853	5	0	33.41	291.8	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 22:14:02.33	2026-04-02 22:14:01.83	null	RAW_SHORT	2026-04-17 22:14:02.329
cmni19unc03ltk84wx5odysbu	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.42180622	-122.225047	5	0	34.15	310.78	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 22:15:34.248	2026-04-02 22:15:33.828	null	RAW_SHORT	2026-04-17 22:15:34.247
cmni13wjb03d7k84whihdrdup	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.37311268	-122.14451887	5	0	33.18	324.14	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 22:10:56.76	2026-04-02 22:10:52.828	null	RAW_SHORT	2026-04-17 22:10:56.759
cmni1485a03dpk84wnil70qyy	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.37732484	-122.14894979	5	0	33.48	317.81	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 22:11:11.806	2026-04-02 22:11:10.828	null	RAW_SHORT	2026-04-17 22:11:11.806
cmni14fwb03e0k84wqnqrxuyh	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.3787954	-122.15030297	5	0	33.74	329.41	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 22:11:21.852	2026-04-02 22:11:16.816	null	RAW_SHORT	2026-04-17 22:11:21.851
cmni15y2q03gck84w5rzavgrc	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.39203734	-122.16826622	5	0	33.12	284.41	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 22:12:32.066	2026-04-02 22:12:28.827	null	RAW_SHORT	2026-04-17 22:12:32.065
cmni140ed03ddk84w519w0fla	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.37457281	-122.14588663	5	0	33.98	321.33	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 22:11:01.765	2026-04-02 22:10:58.821	null	RAW_SHORT	2026-04-17 22:11:01.764
cmni14ips03e7k84wkb16l5b8	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.38048092	-122.15123277	5	0	34.49	342.42	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 22:11:25.504	2026-04-02 22:11:22.828	null	RAW_SHORT	2026-04-17 22:11:25.504
cmni169q403gsk84ww9uu4skq	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.39286883	-122.17400749	5	0	32.29	293.55	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 22:12:47.164	2026-04-02 22:12:44.827	null	RAW_SHORT	2026-04-17 22:12:47.163
cmni16wve03hok84wy2e2vwmk	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.39971672	-122.18192127	5	0	35.22	321.68	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 22:13:17.163	2026-04-02 22:13:15.824	null	RAW_SHORT	2026-04-17 22:13:17.162
cmni17k4c03ikk84woaj0o0y2	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.40684142	-122.18921084	5	0	32.72	314.65	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 22:13:47.293	2026-04-02 22:13:45.82	null	RAW_SHORT	2026-04-17 22:13:47.292
cmni18iy503jwk84wtljaqrw9	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.41256089	-122.20514618	5	0	34.47	291.45	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 22:14:32.43	2026-04-02 22:14:31.834	null	RAW_SHORT	2026-04-17 22:14:32.429
cmni18unm03kck84wrtoit688	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.41511369	-122.2099019	5	0	34.21	320.98	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 22:14:47.602	2026-04-02 22:14:46.846	null	RAW_SHORT	2026-04-17 22:14:47.601
cmni19a0k03kxk84wb94k2v8z	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.41821562	-122.21438304	5	0	32.7	293.55	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 22:15:07.508	2026-04-02 22:15:02.832	null	RAW_SHORT	2026-04-17 22:15:07.507
cmni19lnd03ldk84wec1rmvea	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.41926445	-122.22021307	5	0	34.26	283.01	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 22:15:22.585	2026-04-02 22:15:18.831	null	RAW_SHORT	2026-04-17 22:15:22.584
cmni1a8uy03mek84wrnqdz501	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.42488967	-122.22949008	5	0	35.8	311.84	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 22:15:52.667	2026-04-02 22:15:48.824	null	RAW_SHORT	2026-04-17 22:15:52.666
cmni1akgx03muk84w4rwdultf	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.4282366	-122.23374641	5	0	34.4	311.48	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 22:16:07.713	2026-04-02 22:16:03.831	null	RAW_SHORT	2026-04-17 22:16:07.713
cmni1aw2503nak84wqcz4t2eh	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.43117949	-122.23802512	5	0	33.51	312.89	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 22:16:22.733	2026-04-02 22:16:18.835	null	RAW_SHORT	2026-04-17 22:16:22.732
cmni1b7o303nqk84wmkln4vc8	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.43441436	-122.24197802	5	0	33.17	316.05	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 22:16:37.779	2026-04-02 22:16:33.823	null	RAW_SHORT	2026-04-17 22:16:37.779
cmni1bja203o6k84wak3x6mdu	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.4378918	-122.24613695	5	0	33.5	316.41	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 22:16:52.827	2026-04-02 22:16:49.825	null	RAW_SHORT	2026-04-17 22:16:52.826
cmni1buvm03omk84wvrh8kp8p	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.44124096	-122.25037308	5	0	32.82	313.95	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 22:17:07.858	2026-04-02 22:17:05.823	null	RAW_SHORT	2026-04-17 22:17:07.858
cmni1c6ht03p2k84w30xjqfwv	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.44384262	-122.25528153	5	0	32.69	288.63	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 22:17:22.913	2026-04-02 22:17:21.827	null	RAW_SHORT	2026-04-17 22:17:22.912
cmni1ci4a03pik84wke15cplr	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.44407878	-122.26109077	5	0	32.65	264.38	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 22:17:37.979	2026-04-02 22:17:37.833	null	RAW_SHORT	2026-04-17 22:17:37.978
cmni1cxlx03q3k84wmhllxw1f	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.44395875	-122.2668851	5	0	32.2	279.84	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 22:17:58.053	2026-04-02 22:17:53.824	null	RAW_SHORT	2026-04-17 22:17:58.052
cmni1d98003qjk84w9ma6g6uy	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.44598499	-122.27225807	5	0	34.36	309.73	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 22:18:13.104	2026-04-02 22:18:09.831	null	RAW_SHORT	2026-04-17 22:18:13.104
cmni1dkte03qzk84wh2g05dku	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.44910327	-122.27674381	5	0	35.36	310.78	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 22:18:28.13	2026-04-02 22:18:24.837	null	RAW_SHORT	2026-04-17 22:18:28.129
cmni1dwig03rfk84wgpig2cpm	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.45213903	-122.28131706	5	0	34.62	309.38	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 22:18:43.288	2026-04-02 22:18:39.824	null	RAW_SHORT	2026-04-17 22:18:43.287
cmni1e81603rvk84wstell9xl	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.45508011	-122.28577665	5	0	34.46	309.73	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 22:18:58.218	2026-04-02 22:18:54.831	null	RAW_SHORT	2026-04-17 22:18:58.217
cmni1ejmp03sbk84wats7cqwl	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.45855399	-122.28964389	5	0	34.6	333.28	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 22:19:13.25	2026-04-02 22:19:09.834	null	RAW_SHORT	2026-04-17 22:19:13.249
cmni1ev8403srk84wd6jb1cqv	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.46299866	-122.29070546	5	0	33.43	358.59	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 22:19:28.276	2026-04-02 22:19:24.828	null	RAW_SHORT	2026-04-17 22:19:28.276
cmni1f6uq03t7k84wdecbnnhv	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.46768876	-122.29178052	5	0	33.44	338.2	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 22:19:43.347	2026-04-02 22:19:40.832	null	RAW_SHORT	2026-04-17 22:19:43.346
cmni1fifv03tnk84wz7eviw8i	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.47146019	-122.2948939	5	0	33.57	321.68	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 22:19:58.363	2026-04-02 22:19:55.828	null	RAW_SHORT	2026-04-17 22:19:58.362
cmni1fu1v03u3k84w8ay0ekkw	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.47511504	-122.29823928	5	0	33.49	333.63	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 22:20:13.412	2026-04-02 22:20:10.833	null	RAW_SHORT	2026-04-17 22:20:13.411
cmni1g5nj03ujk84w369sxkkm	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.47959504	-122.29920555	5	0	34.03	5.62	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 22:20:28.448	2026-04-02 22:20:25.827	null	RAW_SHORT	2026-04-17 22:20:28.447
cmni1gh9703v4k84woiadl8rt	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.48415014	-122.29845126	5	0	33.01	7.73	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 22:20:43.483	2026-04-02 22:20:40.828	null	RAW_SHORT	2026-04-17 22:20:43.483
cmni1gsu803vkk84wnpckmuz2	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.48888495	-122.29847339	5	0	33.55	347.7	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 22:20:58.497	2026-04-02 22:20:56.828	null	RAW_SHORT	2026-04-17 22:20:58.496
cmni1h4fw03w0k84ws1m9ujcf	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.49291363	-122.30150194	5	0	32.67	313.95	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 22:21:13.532	2026-04-02 22:21:12.849	null	RAW_SHORT	2026-04-17 22:21:13.531
cmni1hj3o03wlk84w6frpb757	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.49508765	-122.30676787	5	0	32.87	286.88	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 22:21:32.532	2026-04-02 22:21:28.832	null	RAW_SHORT	2026-04-17 22:21:32.531
cmni1hunp03x1k84wgmxx05l6	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.49664228	-122.31227193	5	0	32.79	296.72	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 22:21:47.51	2026-04-02 22:21:44.848	null	RAW_SHORT	2026-04-17 22:21:47.509
cmni1i67j03xhk84wbdacp9z9	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.49913263	-122.31702405	5	0	33.81	303.75	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 22:22:02.48	2026-04-02 22:21:59.83	null	RAW_SHORT	2026-04-17 22:22:02.479
cmni1ihs503xxk84wb8t715sh	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.50075222	-122.32244974	5	0	31.21	277.38	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 22:22:17.478	2026-04-02 22:22:15.833	null	RAW_SHORT	2026-04-17 22:22:17.477
cmni1itcl03ydk84wa9jqnyyg	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.50133564	-122.32819947	5	0	32.41	287.58	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 22:22:32.469	2026-04-02 22:22:31.832	null	RAW_SHORT	2026-04-17 22:22:32.468
cmni1j8rw03yyk84w5qnw6xx9	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.5038171	-122.33321034	5	0	33.55	307.27	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 22:22:52.461	2026-04-02 22:22:47.832	null	RAW_SHORT	2026-04-17 22:22:52.46
cmni1jkd203zek84wkyz7c0oi	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.50664554	-122.33782793	5	0	34.93	307.62	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 22:23:07.479	2026-04-02 22:23:02.841	null	RAW_SHORT	2026-04-17 22:23:07.478
cmni1jvx303zuk84wyuy5uy8a	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.50948943	-122.34244552	5	0	33.34	309.73	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 22:23:22.456	2026-04-02 22:23:17.828	null	RAW_SHORT	2026-04-17 22:23:22.455
cmni1k7j2040ak84ws04xgxyx	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.51292513	-122.3466607	5	0	33.47	317.46	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 22:23:37.502	2026-04-02 22:23:33.835	null	RAW_SHORT	2026-04-17 22:23:37.501
cmni1kj38040qk84wk9856gcm	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.51644813	-122.35068376	5	0	32.69	318.16	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 22:23:52.485	2026-04-02 22:23:49.831	null	RAW_SHORT	2026-04-17 22:23:52.483
cmni1kuoe0416k84wkt2a5asz	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.5202453	-122.35426233	5	0	33.74	332.23	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 22:24:07.502	2026-04-02 22:24:05.834	null	RAW_SHORT	2026-04-17 22:24:07.501
cmni1l6ap041mk84w814kn131	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.52454815	-122.35693297	5	0	33.35	324.84	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 22:24:22.561	2026-04-02 22:24:21.831	null	RAW_SHORT	2026-04-17 22:24:22.559
cmni1lhts0422k84wlmf5q2ui	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.52859497	-122.35974351	5	0	34.72	341.37	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 22:24:37.504	2026-04-02 22:24:36.829	null	RAW_SHORT	2026-04-17 22:24:37.503
cmni1qfcs049nk84w672yt7qp	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.58502861	-122.40717301	5	0	34.12	316.41	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 22:28:27.58	2026-04-02 22:28:23.836	null	RAW_SHORT	2026-04-17 22:28:27.58
cmni1lteu042ik84wn1ei0zth	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.53305079	-122.36164578	5	0	34.53	341.02	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 22:24:52.518	2026-04-02 22:24:51.831	null	RAW_SHORT	2026-04-17 22:24:52.517
cmni1m4ys042yk84w6u98yybm	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.53727196	-122.36378208	5	0	33.19	333.98	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 22:25:07.493	2026-04-02 22:25:06.851	null	RAW_SHORT	2026-04-17 22:25:07.492
cmni1mkga043jk84wbvn9ppm2	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.54148915	-122.36637376	5	0	32.23	331.17	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 22:25:27.562	2026-04-02 22:25:22.829	null	RAW_SHORT	2026-04-17 22:25:27.561
cmni1mvzk0444k84wmttom2kv	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.54528133	-122.36988486	5	0	33.45	320.62	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 22:25:42.513	2026-04-02 22:25:38.836	null	RAW_SHORT	2026-04-17 22:25:42.512
cmni1n7kb044kk84wy49ma1oj	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.54895177	-122.37367935	5	0	32.54	319.57	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 22:25:57.515	2026-04-02 22:25:54.832	null	RAW_SHORT	2026-04-17 22:25:57.514
cmni1nj5e0450k84wrv1v3osl	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.55254949	-122.37717024	5	0	35.34	327.3	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 22:26:12.53	2026-04-02 22:26:09.832	null	RAW_SHORT	2026-04-17 22:26:12.529
cmni1nuqd045ik84wjgp6l1ab	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.55656673	-122.37994851	5	0	35.45	332.23	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 22:26:27.541	2026-04-02 22:26:23.832	null	RAW_SHORT	2026-04-17 22:26:27.54
cmni1o6bc045yk84wr2cwk4zj	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.56043141	-122.38316263	5	0	35.63	321.33	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 22:26:42.553	2026-04-02 22:26:38.835	null	RAW_SHORT	2026-04-17 22:26:42.552
cmni1ohvd046ek84wf8u6db9s	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.56410897	-122.3868381	5	0	33.66	321.33	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 22:26:57.529	2026-04-02 22:26:53.833	null	RAW_SHORT	2026-04-17 22:26:57.528
cmni1otfi046uk84w1nakv0jd	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.56674169	-122.39169239	5	0	33.49	294.61	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 22:27:12.511	2026-04-02 22:27:09.828	null	RAW_SHORT	2026-04-17 22:27:12.51
cmni1p51f047ak84w102keszp	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.56998858	-122.39608401	5	0	33.78	323.09	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 22:27:27.556	2026-04-02 22:27:25.833	null	RAW_SHORT	2026-04-17 22:27:27.555
cmni1pgbo0480k84wum03px03	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.57361598	-122.39950986	5	0	33.29	325.2	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 22:27:42.18	2026-04-02 22:27:40.838	null	RAW_SHORT	2026-04-17 22:27:42.18
cmni1pkh6048bk84w2zl1r6nu	cmnhhqj5c000e3yrjmvwv50er	alex@brspark.com	dev_szkcjr	cmni1npwo045ck84w2mp3uaqv	OS_ACCEPT	\N	\N	\N	\N	\N	\N	GPS	\N	\N	UNKNOWN	1.0.0	26.3.1	Simulator iOS	f	f	4	2026-04-02 22:27:47.562	2026-04-02 22:27:45.312	{"previousState": "IDLE"}	LEGAL	2031-04-02 22:27:47.561
cmni1pkh6048ck84w80oa5qfz	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.57495771	-122.40041879	5	0	34.34	337.85	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 22:27:47.562	2026-04-02 22:27:45.832	null	RAW_SHORT	2026-04-17 22:27:47.561
cmni1ps6v048nk84wnooakhqa	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.57760761	-122.40156585	5	0	34	341.37	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 22:27:57.56	2026-04-02 22:27:54.829	null	RAW_SHORT	2026-04-17 22:27:57.559
cmni1pw1z048tk84w9npq4ydi	cmnhhqj5c000e3yrjmvwv50er	alex@brspark.com	dev_szkcjr	cmni1npwo045ck84w2mp3uaqv	TRANSIT_START	\N	\N	\N	\N	\N	\N	GPS	\N	\N	UNKNOWN	1.0.0	26.3.1	Simulator iOS	f	f	-108	2026-04-02 22:28:02.567	2026-04-02 22:27:58.245	{"previousState": "DISPATCHED"}	LEGAL	2031-04-02 22:28:02.566
cmni1pw1z048uk84wh5q5cvg9	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.5784743	-122.40192879	5	0	34.14	341.37	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 22:28:02.567	2026-04-02 22:27:57.845	null	RAW_SHORT	2026-04-17 22:28:02.566
cmni1pzwn0490k84wnf4rshs2	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.58030013	-122.40309329	5	0	32.41	329.41	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 22:28:07.56	2026-04-02 22:28:04.83	null	RAW_SHORT	2026-04-17 22:28:07.559
cmni1q3rm0496k84wwljmyy65	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.58207437	-122.404453	5	0	33.47	328.71	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 22:28:12.562	2026-04-02 22:28:11.848	null	RAW_SHORT	2026-04-17 22:28:12.561
cmni1qbio049hk84wpgbqaged	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.58362519	-122.40571196	5	0	34.04	325.9	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 22:28:22.609	2026-04-02 22:28:17.83	null	RAW_SHORT	2026-04-17 22:28:22.608
cmni1qj70049tk84w9qbdhexy	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.58628103	-122.40888284	5	0	34.43	310.08	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 22:28:32.557	2026-04-02 22:28:29.83	null	RAW_SHORT	2026-04-17 22:28:32.556
cmni1qn2f049zk84w5fs7u5t7	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.58751653	-122.41061705	5	0	34.23	315.7	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 22:28:37.576	2026-04-02 22:28:35.836	null	RAW_SHORT	2026-04-17 22:28:37.575
cmni1qqwt04a5k84wz832zqml	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.58894149	-122.4121014	5	0	34.06	322.03	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 22:28:42.557	2026-04-02 22:28:41.837	null	RAW_SHORT	2026-04-17 22:28:42.556
cmni1qymp04agk84wc1ny12ln	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.59039961	-122.4135301	5	0	34.34	322.03	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 22:28:52.562	2026-04-02 22:28:47.835	null	RAW_SHORT	2026-04-17 22:28:52.561
cmni1r2hy04amk84wqkrlaxov	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.59186703	-122.41497883	5	0	34.34	321.68	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 22:28:57.575	2026-04-02 22:28:53.838	null	RAW_SHORT	2026-04-17 22:28:57.574
cmni1r6fy04ask84wexcbwzi0	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.5933155	-122.41641054	5	0	34.1	322.03	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 22:29:02.686	2026-04-02 22:28:59.843	null	RAW_SHORT	2026-04-17 22:29:02.682
cmni1ra7s04ayk84we8vok68e	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.59477194	-122.41782784	5	0	33.66	322.03	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 22:29:07.576	2026-04-02 22:29:05.845	null	RAW_SHORT	2026-04-17 22:29:07.575
cmni1re2n04b4k84wukizukwp	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.5961884	-122.41924144	5	0	33.2	320.98	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 22:29:12.576	2026-04-02 22:29:11.844	null	RAW_SHORT	2026-04-17 22:29:12.575
cmni1rls904bfk84w2poiimkq	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.59753085	-122.42080467	5	0	33.88	315.7	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 22:29:22.569	2026-04-02 22:29:17.825	null	RAW_SHORT	2026-04-17 22:29:22.568
cmni1rpnd04blk84w7a3bt9uy	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.59881294	-122.42240561	5	0	33.64	315.7	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 22:29:27.577	2026-04-02 22:29:23.832	null	RAW_SHORT	2026-04-17 22:29:27.576
cmni1rtj704brk84w26owi8ih	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.60011457	-122.42399767	5	0	33.7	316.05	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 22:29:32.611	2026-04-02 22:29:29.832	null	RAW_SHORT	2026-04-17 22:29:32.61
cmni1rxco04bxk84wz4rfcrhd	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.60144184	-122.42557665	5	0	33.85	317.11	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 22:29:37.56	2026-04-02 22:29:35.831	null	RAW_SHORT	2026-04-17 22:29:37.559
cmni1s17i04c3k84w6ist4u5d	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.60292963	-122.42692212	5	0	34.03	331.52	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 22:29:42.558	2026-04-02 22:29:41.834	null	RAW_SHORT	2026-04-17 22:29:42.557
cmni1s8xt04cek84w6m7y5a5j	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.60490126	-122.42782443	5	0	33.81	347.7	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 22:29:52.578	2026-04-02 22:29:48.846	null	RAW_SHORT	2026-04-17 22:29:52.577
cmni1scsn04ckk84wz7lhfy41	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.60697453	-122.42798519	5	0	32.63	2.81	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 22:29:57.575	2026-04-02 22:29:55.836	null	RAW_SHORT	2026-04-17 22:29:57.574
cmni1skjz04cvk84wta3pr1wu	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.60901452	-122.42752478	5	0	33.23	14.06	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 22:30:07.631	2026-04-02 22:30:02.85	null	RAW_SHORT	2026-04-17 22:30:07.629
cmni1sodd04d1k84wbndfmtme	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.61097345	-122.42659053	5	0	33.43	24.61	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 22:30:12.577	2026-04-02 22:30:09.851	null	RAW_SHORT	2026-04-17 22:30:12.576
cmni1ss8a04d7k84wy0nrhisk	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.61255499	-122.42549493	5	0	32.91	29.88	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 22:30:17.579	2026-04-02 22:30:15.848	null	RAW_SHORT	2026-04-17 22:30:17.578
cmni1szyh04dik84wt7o9debm	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.6144335	-122.42438064	5	0	33.19	18.63	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 22:30:27.593	2026-04-02 22:30:22.869	null	RAW_SHORT	2026-04-17 22:30:27.592
cmni1t3u804dok84w1g2x310k	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.61622802	-122.4240856	5	0	33.35	1.76	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 22:30:32.625	2026-04-02 22:30:28.839	null	RAW_SHORT	2026-04-17 22:30:32.623
cmni1t7np04dzk84wnoyxj8ww	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.61830682	-122.42451894	5	0	33.98	344.88	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 22:30:37.573	2026-04-02 22:30:35.845	null	RAW_SHORT	2026-04-17 22:30:37.573
cmni1tbj104e5k84wty7u7ls4	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.61997167	-122.42551723	5	0	34.89	332.58	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 22:30:42.589	2026-04-02 22:30:41.84	null	RAW_SHORT	2026-04-17 22:30:42.588
cmni1tj8y04egk84w228zxqzn	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.62166536	-122.42661417	5	0	35.4	332.93	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 22:30:52.595	2026-04-02 22:30:47.835	null	RAW_SHORT	2026-04-17 22:30:52.594
cmni1ultv04g3k84wsmc98el0	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.6349348	-122.43884269	5	0	34.88	339.61	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 22:31:42.595	2026-04-02 22:31:41.837	null	RAW_SHORT	2026-04-17 22:31:42.594
cmni1uxes04gkk84wd57q59kz	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.63827763	-122.44069124	5	0	33.2	327.66	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 22:31:57.604	2026-04-02 22:31:53.852	null	RAW_SHORT	2026-04-17 22:31:57.603
cmni1vog504hok84w0gz1qr1f	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.64568224	-122.44954965	5	0	32.82	324.14	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 22:32:32.646	2026-04-02 22:32:28.836	null	RAW_SHORT	2026-04-17 22:32:32.645
cmni1wfhb04isk84wicys337h	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.65414599	-122.45638216	5	0	32.19	314.65	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 22:33:07.679	2026-04-02 22:33:03.841	null	RAW_SHORT	2026-04-17 22:33:07.679
cmni1tn6704emk84wsvse7kg5	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.62334694	-122.42769149	5	0	34.53	332.93	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 22:30:57.68	2026-04-02 22:30:53.836	null	RAW_SHORT	2026-04-17 22:30:57.679
cmni1ue4704frk84wuxl0ciiv	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.63173002	-122.43652912	5	0	33.71	317.46	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 22:31:32.599	2026-04-02 22:31:29.837	null	RAW_SHORT	2026-04-17 22:31:32.599
cmni1utkh04gek84w3btpzg1z	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.63666256	-122.43965423	5	0	33.48	338.91	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 22:31:52.625	2026-04-02 22:31:47.846	null	RAW_SHORT	2026-04-17 22:31:52.625
cmni1tr0004esk84wwdvajw4j	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.62499411	-122.42876044	5	0	34.39	331.52	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 22:31:02.64	2026-04-02 22:30:59.836	null	RAW_SHORT	2026-04-17 22:31:02.639
cmni1tutq04eyk84wjfu7st5o	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.62659895	-122.43005762	5	0	36.58	325.9	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 22:31:07.598	2026-04-02 22:31:05.85	null	RAW_SHORT	2026-04-17 22:31:07.597
cmni1tyog04f4k84w6oghdt0p	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.62794567	-122.43159863	5	0	33.88	315	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 22:31:12.592	2026-04-02 22:31:11.834	null	RAW_SHORT	2026-04-17 22:31:12.591
cmni1u6eb04ffk84ww3wkuedc	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.62919127	-122.43325339	5	0	33.92	313.59	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 22:31:22.595	2026-04-02 22:31:17.858	null	RAW_SHORT	2026-04-17 22:31:22.594
cmni1ua9704flk84wkresb208	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.63043476	-122.43489758	5	0	33.42	313.95	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 22:31:27.595	2026-04-02 22:31:23.831	null	RAW_SHORT	2026-04-17 22:31:27.594
cmni1uhz304fxk84wz3g33upj	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.63323021	-122.4378776	5	0	34.35	329.41	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 22:31:37.599	2026-04-02 22:31:35.834	null	RAW_SHORT	2026-04-17 22:31:37.598
cmni1v91d04h1k84wt7a3qt4v	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.64164233	-122.44364393	5	0	32.33	322.73	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 22:32:12.674	2026-04-02 22:32:07.837	null	RAW_SHORT	2026-04-17 22:32:12.673
cmni1vgpv04hdk84w89xlpz3p	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.64425086	-122.44768593	5	0	33.27	303.05	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 22:32:22.627	2026-04-02 22:32:21.835	null	RAW_SHORT	2026-04-17 22:32:22.626
cmni1wjco04iyk84wxrcue4dy	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.655592	-122.45823598	5	0	33.05	314.65	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 22:33:12.696	2026-04-02 22:33:10.85	null	RAW_SHORT	2026-04-17 22:33:12.695
cmni1wn7204j4k84wzp0hpneo	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.65685674	-122.45985453	5	0	33.73	314.3	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 22:33:17.678	2026-04-02 22:33:16.847	null	RAW_SHORT	2026-04-17 22:33:17.677
cmni1v1ae04gqk84wlqi2bspb	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.63997584	-122.44214793	5	0	32.22	325.2	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 22:32:02.63	2026-04-02 22:32:00.837	null	RAW_SHORT	2026-04-17 22:32:02.629
cmni1vcus04h7k84w604gka37	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.64307505	-122.44550295	5	0	32.91	307.27	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 22:32:17.621	2026-04-02 22:32:14.937	null	RAW_SHORT	2026-04-17 22:32:17.62
cmni1vsb104huk84w27zxhsny	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.64750744	-122.45075656	5	0	32.66	334.34	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 22:32:37.645	2026-04-02 22:32:35.845	null	RAW_SHORT	2026-04-17 22:32:37.644
cmni1w01e04i5k84wp0i6iatk	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.64934857	-122.45186264	5	0	32.21	334.34	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 22:32:47.667	2026-04-02 22:32:42.836	null	RAW_SHORT	2026-04-17 22:32:47.666
cmni1w3w504ibk84w6co8wu87	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.65116761	-122.45299486	5	0	31.84	329.77	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 22:32:52.661	2026-04-02 22:32:49.835	null	RAW_SHORT	2026-04-17 22:32:52.66
cmni1w7ri04ihk84wqg18e233	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.65273415	-122.45456253	5	0	31.84	314.65	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 22:32:57.678	2026-04-02 22:32:56.836	null	RAW_SHORT	2026-04-17 22:32:57.677
cmni1wuwp04jfk84wmz69myh3	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.65831775	-122.46173392	5	0	33	313.95	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 22:33:27.673	2026-04-02 22:33:23.831	null	RAW_SHORT	2026-04-17 22:33:27.673
cmni1wyrq04jlk84w2f4xo99z	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.6595944	-122.46334517	5	0	33.46	314.65	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 22:33:32.678	2026-04-02 22:33:29.862	null	RAW_SHORT	2026-04-17 22:33:32.677
cmni1x2mm04jrk84w3qx9frkz	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.66129513	-122.46489055	5	0	33.28	333.28	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 22:33:37.678	2026-04-02 22:33:36.847	null	RAW_SHORT	2026-04-17 22:33:37.677
cmni1xacv04k2k84w768ltgew	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.66331739	-122.46552707	5	0	33.46	355.08	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 22:33:47.696	2026-04-02 22:33:43.863	null	RAW_SHORT	2026-04-17 22:33:47.695
cmni1xe7s04k8k84wug2tok1s	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.66513186	-122.46553863	5	0	33.59	360	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 22:33:52.696	2026-04-02 22:33:49.846	null	RAW_SHORT	2026-04-17 22:33:52.695
cmni1xi2q04kek84w540yl2nr	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.66695534	-122.46555179	5	0	33.64	359.65	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 22:33:57.698	2026-04-02 22:33:55.848	null	RAW_SHORT	2026-04-17 22:33:57.697
cmni1xlxg04kkk84wo8zr1831	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.66878205	-122.46570828	5	0	33.91	351.56	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 22:34:02.693	2026-04-02 22:34:01.844	null	RAW_SHORT	2026-04-17 22:34:02.692
cmni1xtoa04kvk84w5qu1pxqz	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.67058693	-122.46624196	5	0	34.11	343.12	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 22:34:12.73	2026-04-02 22:34:07.847	null	RAW_SHORT	2026-04-17 22:34:12.728
cmni1xxil04l1k84we8agdtxj	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.67225941	-122.46713488	5	0	33.45	332.93	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 22:34:17.71	2026-04-02 22:34:13.844	null	RAW_SHORT	2026-04-17 22:34:17.709
cmni1y1e004l7k84w93oxw0i1	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.67402812	-122.46851379	5	0	32.85	326.95	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 22:34:22.728	2026-04-02 22:34:20.835	null	RAW_SHORT	2026-04-17 22:34:22.727
cmni1y95b04lik84wdf922n0v	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.67577633	-122.46992933	5	0	32.26	327.3	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 22:34:32.783	2026-04-02 22:34:27.837	null	RAW_SHORT	2026-04-17 22:34:32.781
cmni1ycz404lok84w7n28bemq	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.67751495	-122.47117463	5	0	31.21	337.85	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 22:34:37.744	2026-04-02 22:34:34.85	null	RAW_SHORT	2026-04-17 22:34:37.743
cmni1ygu204luk84ws0h180dh	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.67947426	-122.47165114	5	0	32.72	358.59	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 22:34:42.746	2026-04-02 22:34:41.842	null	RAW_SHORT	2026-04-17 22:34:42.745
cmni1yoju04m5k84wuzz5gh20	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.68155054	-122.47154159	5	0	33.15	2.81	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 22:34:52.747	2026-04-02 22:34:48.851	null	RAW_SHORT	2026-04-17 22:34:52.746
cmni1ysf704mbk84wxja3fc4q	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.68362322	-122.47142784	5	0	32.51	3.16	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 22:34:57.763	2026-04-02 22:34:55.853	null	RAW_SHORT	2026-04-17 22:34:57.762
cmni1z05c04mmk84wgmai44wy	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.68566509	-122.47130429	5	0	32.81	1.76	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 22:35:07.777	2026-04-02 22:35:02.851	null	RAW_SHORT	2026-04-17 22:35:07.776
cmni1z3zs04msk84wmb49hoj1	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.6876731	-122.47090381	5	0	33	14.41	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 22:35:12.76	2026-04-02 22:35:09.849	null	RAW_SHORT	2026-04-17 22:35:12.76
cmni1z7up04myk84w3am9bq28	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.68971271	-122.47030274	5	0	33.13	10.9	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 22:35:17.761	2026-04-02 22:35:16.869	null	RAW_SHORT	2026-04-17 22:35:17.761
cmni1zfki04n9k84w8gq9f9u4	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.69179595	-122.47024616	5	0	32.06	359.3	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 22:35:27.763	2026-04-02 22:35:23.836	null	RAW_SHORT	2026-04-17 22:35:27.762
cmni1zjfc04nfk84wrad9defb	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.6937618	-122.47026427	5	0	30.32	359.65	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 22:35:32.76	2026-04-02 22:35:30.843	null	RAW_SHORT	2026-04-17 22:35:32.76
cmni1zr5k04nvk84w92ks8dtt	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.69577346	-122.47054154	5	0	32.28	347.7	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 22:35:42.776	2026-04-02 22:35:37.867	null	RAW_SHORT	2026-04-17 22:35:42.775
cmni1zv0h04o1k84wsbsjm4o1	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.69773847	-122.47121318	5	0	32.25	350.16	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 22:35:47.778	2026-04-02 22:35:44.847	null	RAW_SHORT	2026-04-17 22:35:47.777
cmni1zyve04o7k84wk3qp01m6	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.69970403	-122.47131284	5	0	30.73	358.24	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 22:35:52.778	2026-04-02 22:35:51.834	null	RAW_SHORT	2026-04-17 22:35:52.777
cmni206l304oik84wyjmmosjq	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.70172029	-122.47133397	5	0	32.93	0.35	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 22:36:02.775	2026-04-02 22:35:58.849	null	RAW_SHORT	2026-04-17 22:36:02.775
cmni20aku04ook84w85nh2bby	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.70374603	-122.47131519	5	0	31.51	0.7	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 22:36:07.951	2026-04-02 22:36:05.841	null	RAW_SHORT	2026-04-17 22:36:07.95
cmni20i6o04ozk84we9cb2je7	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.70569093	-122.47085796	5	0	32.33	16.88	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 22:36:17.808	2026-04-02 22:36:12.858	null	RAW_SHORT	2026-04-17 22:36:17.808
cmni20m1704p5k84wqm3o6gds	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.70741441	-122.4695213	5	0	32.68	37.97	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 22:36:22.795	2026-04-02 22:36:19.848	null	RAW_SHORT	2026-04-17 22:36:22.794
cmni20pxg04pbk84wyszr3knl	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.70903656	-122.46788255	5	0	33.51	38.32	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 22:36:27.844	2026-04-02 22:36:26.849	null	RAW_SHORT	2026-04-17 22:36:27.843
cmni20xmv04pmk84w0v0izkxl	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.71011779	-122.46571449	5	0	32.38	67.15	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 22:36:37.831	2026-04-02 22:36:33.838	null	RAW_SHORT	2026-04-17 22:36:37.83
cmni211hp04psk84wmzeo5qc0	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.71044166	-122.46319019	5	0	32.55	89.65	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 22:36:42.829	2026-04-02 22:36:40.837	null	RAW_SHORT	2026-04-17 22:36:42.828
cmni215dq04pyk84wn14pdpn1	cmnhhqj5c000e3yrjmvwv50er	alex@brspark.com	dev_szkcjr	cmni1npwo045ck84w2mp3uaqv	OS_ACCEPT	\N	\N	\N	\N	\N	\N	GPS	\N	\N	UNKNOWN	1.0.0	26.3.1	Simulator iOS	f	f	-2	2026-04-02 22:36:47.871	2026-04-02 22:36:47.345	{"previousState": "IN_TRANSIT"}	LEGAL	2031-04-02 22:36:47.87
cmni215dq04pzk84wclnas62x	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.71045038	-122.46097678	5	0	32.1	89.65	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 22:36:47.871	2026-04-02 22:36:46.856	null	RAW_SHORT	2026-04-17 22:36:47.87
cmni21d2u04qak84wnlqb5qms	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.71052364	-122.45740525	5	0	31.01	82.97	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 22:36:57.846	2026-04-02 22:36:56.838	null	RAW_SHORT	2026-04-17 22:36:57.846
cmni21kuf04qlk84w4xsobgje	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.71162795	-122.45419314	5	0	31.95	50.27	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 22:37:07.911	2026-04-02 22:37:06.841	null	RAW_SHORT	2026-04-17 22:37:07.911
cmni21sk304qwk84wj5q0t8pe	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.71380725	-122.45159173	5	0	34.36	42.89	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 22:37:17.907	2026-04-02 22:37:16.854	null	RAW_SHORT	2026-04-17 22:37:17.906
cmni220aq04r7k84wkksu91we	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.71585977	-122.44931077	5	0	32.96	37.62	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 22:37:27.937	2026-04-02 22:37:25.861	null	RAW_SHORT	2026-04-17 22:37:27.931
cmni227zi04rik84wuvh4yuxf	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.71869117	-122.44835883	5	0	33.04	5.62	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 22:37:37.903	2026-04-02 22:37:35.9	null	RAW_SHORT	2026-04-17 22:37:37.902
cmni22fo804rtk84w6sltdu6d	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.72141299	-122.44803948	5	0	34.01	5.27	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 22:37:47.865	2026-04-02 22:37:44.897	null	RAW_SHORT	2026-04-17 22:37:47.864
cmni241l804u4k84wpv3oop04	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.73150681	-122.42617839	5	0	34.34	99.49	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 22:39:02.924	2026-04-02 22:38:59.846	null	RAW_SHORT	2026-04-17 22:39:02.923
cmni276k004z7k84w56zquml9	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.75658588	-122.40323083	5	0	24.84	350.51	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 22:41:29.329	2026-04-02 22:41:24.849	null	RAW_SHORT	2026-04-17 22:41:29.328
cmni22nlu04s4k84wq5no5e5m	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.72410961	-122.44729576	5	0	34.32	19.34	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 22:37:58.145	2026-04-02 22:37:53.847	null	RAW_SHORT	2026-04-17 22:37:58.143
cmni22slr04sak84w0ojj5fsb	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.72651765	-122.44565416	5	0	33.82	34.45	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 22:38:04.623	2026-04-02 22:38:02.852	null	RAW_SHORT	2026-04-17 22:38:04.621
cmni24h0q04uqk84wg4yskuf6	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.73190474	-122.4188029	5	0	33.33	90.7	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 22:39:22.923	2026-04-02 22:39:19.843	null	RAW_SHORT	2026-04-17 22:39:22.922
cmni22zbg04slk84wb0cfstrq	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.72855831	-122.44296625	5	0	32.56	57.66	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 22:38:13.324	2026-04-02 22:38:12.865	null	RAW_SHORT	2026-04-17 22:38:13.322
cmni2546304vnk84wz8s8ztdq	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.7348374	-122.40873523	5	0	27.12	46.76	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 22:39:52.923	2026-04-02 22:39:50.849	null	RAW_SHORT	2026-04-17 22:39:52.922
cmni25bwg04vyk84w8pieymt8	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.73748596	-122.40752731	5	0	26.71	357.54	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 22:40:02.945	2026-04-02 22:40:02.835	null	RAW_SHORT	2026-04-17 22:40:02.944
cmni236pu04swk84wcdrcullj	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.72991563	-122.43968599	5	0	33.15	64.69	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 22:38:22.914	2026-04-02 22:38:22.85	null	RAW_SHORT	2026-04-17 22:38:22.913
cmni23eii04t7k84wu8al7icd	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.7309606	-122.43651914	5	0	33.93	69.96	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 22:38:33.018	2026-04-02 22:38:31.833	null	RAW_SHORT	2026-04-17 22:38:33.017
cmni23m5d04tik84w7lwnwryd	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.73184624	-122.43321198	5	0	33.48	71.72	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 22:38:42.913	2026-04-02 22:38:40.84	null	RAW_SHORT	2026-04-17 22:38:42.912
cmni23tvw04ttk84wjcogk489	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.73212414	-122.42955135	5	0	33.39	99.14	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 22:38:52.94	2026-04-02 22:38:50.843	null	RAW_SHORT	2026-04-17 22:38:52.939
cmni249ay04ufk84w8bbe9qge	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.73152823	-122.42250586	5	0	32.35	80.51	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 22:39:12.922	2026-04-02 22:39:09.844	null	RAW_SHORT	2026-04-17 22:39:12.921
cmni24oqn04v1k84w0w2gwh28	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.73208047	-122.4151556	5	0	31.8	74.88	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 22:39:32.927	2026-04-02 22:39:29.849	null	RAW_SHORT	2026-04-17 22:39:32.926
cmni24wgv04vck84wi44h5bwz	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.73335846	-122.41185347	5	0	32.12	61.52	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 22:39:42.943	2026-04-02 22:39:39.848	null	RAW_SHORT	2026-04-17 22:39:42.943
cmni25nh404wek84w7gcc5214	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.74031301	-122.40778103	5	0	24.04	7.03	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 22:40:17.945	2026-04-02 22:40:14.849	null	RAW_SHORT	2026-04-17 22:40:17.944
cmni25v6u04wpk84wy5uak9rw	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.74291726	-122.40638042	5	0	25.33	33.05	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 22:40:27.942	2026-04-02 22:40:27.848	null	RAW_SHORT	2026-04-17 22:40:27.941
cmni266rm04xak84w06qxxntl	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.7454038	-122.40480714	5	0	26.43	16.88	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 22:40:42.946	2026-04-02 22:40:39.848	null	RAW_SHORT	2026-04-17 22:40:42.945
cmni26n8204yfk84woblq1k8m	\N	alex@brspark.com	dev_szkcjr	cmni1npwo045ck84w2mp3uaqv	OS_ACCEPT	\N	\N	\N	\N	\N	\N	GPS	\N	\N	UNKNOWN	1.0.0	26.3.1	Simulator iOS	f	f	9	2026-04-02 22:41:04.274	2026-04-02 22:41:02.195	{"previousState": "IDLE"}	LEGAL	2031-04-02 22:41:04.273
cmni26n8204ygk84wlhcjmuf2	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.75088225	-122.40310192	5	0	29.3	12.3	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 22:41:04.274	2026-04-02 22:41:01.857	null	RAW_SHORT	2026-04-17 22:41:04.273
cmni26v0304yrk84werx7fun2	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.75380183	-122.40286605	5	0	28.81	355.78	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 22:41:14.355	2026-04-02 22:41:12.829	null	RAW_SHORT	2026-04-17 22:41:14.354
cmni27ea604zik84w2e8mycgy	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.75875152	-122.40553318	5	0	25.54	318.87	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 22:41:39.343	2026-04-02 22:41:37.845	null	RAW_SHORT	2026-04-17 22:41:39.342
cmni27pwv04zyk84w1lbjsfw8	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.76147723	-122.40613148	5	0	27.02	20.04	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 22:41:54.415	2026-04-02 22:41:49.844	null	RAW_SHORT	2026-04-17 22:41:54.414
cmni28u2l051sk84wi038v18o	\N	alex@brspark.com	dev_szkcjr	cmni1npwo045ck84w2mp3uaqv	OS_ACCEPT	\N	\N	\N	\N	\N	\N	GPS	\N	\N	UNKNOWN	1.0.0	26.3.1	Simulator iOS	f	f	6	2026-04-02 22:42:46.461	2026-04-02 22:42:42.543	{"previousState": "IDLE"}	LEGAL	2031-04-02 22:42:46.46
cmni28u2l051tk84w6m9rhfw1	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.3344584	-122.04077831	5	0	31.67	268.59	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 22:42:46.461	2026-04-02 22:42:42.126	null	RAW_SHORT	2026-04-17 22:42:46.46
cmni28u2l051uk84wwm17xlns	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.3344584	-122.04077831	5	0	31.67	268.59	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 22:42:46.461	2026-04-02 22:42:43.154	null	RAW_SHORT	2026-04-17 22:42:46.46
cmni28xxp0520k84wqcre85wj	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.33445832	-122.04420408	5	0	34.56	270.35	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 22:42:51.469	2026-04-02 22:42:51.124	null	RAW_SHORT	2026-04-17 22:42:51.469
cmni295o4052bk84w7vt5zxho	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.33420971	-122.04784191	5	0	30.78	256.64	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 22:43:01.493	2026-04-02 22:43:01.126	null	RAW_SHORT	2026-04-17 22:43:01.492
cmni29dem052mk84w6hc0tpfe	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.33344889	-122.05137547	5	0	33.73	255.59	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 22:43:11.519	2026-04-02 22:43:11.125	null	RAW_SHORT	2026-04-17 22:43:11.518
cmni29l59052xk84w47kue2zj	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.33268517	-122.05498531	5	0	33.08	254.88	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 22:43:21.549	2026-04-02 22:43:21.124	null	RAW_SHORT	2026-04-17 22:43:21.545
cmni29swm0538k84w8jhjz9kt	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.33230505	-122.05871525	5	0	33.93	274.22	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 22:43:31.606	2026-04-02 22:43:31.125	null	RAW_SHORT	2026-04-17 22:43:31.605
cmni2a0m8053jk84wt23z2lsm	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.33307736	-122.06203541	5	0	34.54	294.26	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 22:43:41.6	2026-04-02 22:43:40.136	null	RAW_SHORT	2026-04-17 22:43:41.599
cmni2a8br053uk84wdyhqveh3	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.33414928	-122.06526437	5	0	34.2	286.52	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 22:43:51.591	2026-04-02 22:43:49.135	null	RAW_SHORT	2026-04-17 22:43:51.591
cmni2ag200545k84w1yslceoe	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.33442613	-122.06864035	5	0	33.67	266.13	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 22:44:01.608	2026-04-02 22:43:58.133	null	RAW_SHORT	2026-04-17 22:44:01.608
cmni2ansv054gk84w188sdcky	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.33389384	-122.07197743	5	0	33.67	257.34	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 22:44:11.648	2026-04-02 22:44:07.144	null	RAW_SHORT	2026-04-17 22:44:11.647
cmni2aviu054rk84wd1oce5u5	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.33355228	-122.07558936	5	0	31.58	274.57	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 22:44:21.654	2026-04-02 22:44:17.138	null	RAW_SHORT	2026-04-17 22:44:21.654
cmni2b3970552k84wu6arbr1g	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.33442102	-122.07904631	5	0	32.75	299.18	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 22:44:31.676	2026-04-02 22:44:27.133	null	RAW_SHORT	2026-04-17 22:44:31.675
cmni2b7930558k84w8c5du1et	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.33617167	-122.08165962	5	0	33.81	314.3	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 22:44:36.855	2026-04-02 22:44:36.125	null	RAW_SHORT	2026-04-17 22:44:36.854
cmni2bev6055jk84wb2ayl3nt	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.33810893	-122.08454124	5	0	33.63	305.51	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 22:44:46.722	2026-04-02 22:44:46.138	null	RAW_SHORT	2026-04-17 22:44:46.722
cmni2bmkz055uk84wt217qkr1	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.33981846	-122.08762326	5	0	32.9	304.45	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 22:44:56.724	2026-04-02 22:44:56.133	null	RAW_SHORT	2026-04-17 22:44:56.723
cmni2buc80565k84wqcnbv2h3	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.34137909	-122.09077234	5	0	33.04	302.34	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 22:45:06.777	2026-04-02 22:45:06.125	null	RAW_SHORT	2026-04-17 22:45:06.776
cmni2c22f056gk84wx45fm51o	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.34332805	-122.09343444	5	0	31.35	317.11	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 22:45:16.791	2026-04-02 22:45:16.121	null	RAW_SHORT	2026-04-17 22:45:16.79
cmni2c9sm056rk84w1919l9zn	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.34520782	-122.0960117	5	0	31.12	302.7	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 22:45:26.806	2026-04-02 22:45:26.154	null	RAW_SHORT	2026-04-17 22:45:26.805
cmni2chnx0572k84wpa015754	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.3466164	-122.09929791	5	0	33.93	297.42	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 22:45:37.005	2026-04-02 22:45:36.127	null	RAW_SHORT	2026-04-17 22:45:37.004
cmni2cp9j057dk84wx4dhezfw	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.34794036	-122.10227399	5	0	33.1	304.8	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 22:45:46.855	2026-04-02 22:45:45.159	null	RAW_SHORT	2026-04-17 22:45:46.854
cmni2cx0l057ok84wep20g44a	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.35016915	-122.1047086	5	0	33.52	329.06	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 22:45:56.901	2026-04-02 22:45:55.137	null	RAW_SHORT	2026-04-17 22:45:56.901
cmni2d4qj057zk84wx3svxusq	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.35262907	-122.10682025	5	0	32.67	317.46	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 22:46:06.907	2026-04-02 22:46:05.136	null	RAW_SHORT	2026-04-17 22:46:06.906
cmni2dcho058ak84wlv1kz88x	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.354285	-122.10973833	5	0	31.86	295.31	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 22:46:16.956	2026-04-02 22:46:15.14	null	RAW_SHORT	2026-04-17 22:46:16.956
cmni2dk8e058lk84w2puaz2dl	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.35522226	-122.11317885	5	0	32.24	288.28	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 22:46:26.991	2026-04-02 22:46:25.136	null	RAW_SHORT	2026-04-17 22:46:26.99
cmni2dryf058wk84wr6exjhm9	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.35667204	-122.11636489	5	0	32.76	310.43	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 22:46:37	2026-04-02 22:46:35.135	null	RAW_SHORT	2026-04-17 22:46:36.999
cmni2dzow0597k84wjk2slzvq	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.3589945	-122.11866179	5	0	34.06	332.23	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 22:46:47.024	2026-04-02 22:46:45.131	null	RAW_SHORT	2026-04-17 22:46:47.024
cmni2emwr05a4k84wskhzqmxj	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.3647884	-122.12586327	5	0	33.5	280.55	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 22:47:17.116	2026-04-02 22:47:13.125	null	RAW_SHORT	2026-04-17 22:47:17.115
cmni2e7fn059ik84wa506s3hj	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.36154377	-122.1202173	5	0	34.65	332.23	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 22:46:57.059	2026-04-02 22:46:54.134	null	RAW_SHORT	2026-04-17 22:46:57.058
cmni2ef6s059tk84wv5kpn1kh	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.36362588	-122.12248745	5	0	33.39	306.56	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 22:47:07.108	2026-04-02 22:47:03.137	null	RAW_SHORT	2026-04-17 22:47:07.108
cmni2eu1y05afk84wnk598tvz	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.364913	-122.12927755	5	0	33.43	271.41	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 22:47:26.374	2026-04-02 22:47:22.132	null	RAW_SHORT	2026-04-17 22:47:26.373
cmni2eymu05aqk84wdpiyo546	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.36565505	-122.13287858	5	0	33.39	290.74	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 22:47:32.31	2026-04-02 22:47:32.132	null	RAW_SHORT	2026-04-17 22:47:32.309
cmni2f6ky05b1k84wzlqo6hbe	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.36667454	-122.13633075	5	0	32.17	290.39	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 22:47:42.61	2026-04-02 22:47:42.133	null	RAW_SHORT	2026-04-17 22:47:42.609
cmni2fe6805bck84w9hlsb2oy	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.36813371	-122.13959391	5	0	34.03	308.67	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 22:47:52.448	2026-04-02 22:47:52.129	null	RAW_SHORT	2026-04-17 22:47:52.446
cmni2hr2f05ezk84wml02us4s	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.39063719	-122.16493601	5	0	33.54	306.56	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 22:49:42.472	2026-04-02 22:49:39.133	null	RAW_SHORT	2026-04-17 22:49:42.471
cmni2ieae05fwk84wnqihyw0b	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.39327728	-122.17497485	5	0	32.3	301.99	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 22:50:12.566	2026-04-02 22:50:08.135	null	RAW_SHORT	2026-04-17 22:50:12.565
cmni2j5e805gzk84wjw9ca9i7	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.40193507	-122.18412948	5	0	34.75	320.98	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 22:50:47.697	2026-04-02 22:50:45.138	null	RAW_SHORT	2026-04-17 22:50:47.696
cmni2jsr005hwk84wshg66ww4	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.40807192	-122.19127153	5	0	32.36	300.23	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 22:51:17.964	2026-04-02 22:51:13.126	null	RAW_SHORT	2026-04-17 22:51:17.963
cmni2lmeq05kik84wm348b1cv	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.41919475	-122.21983287	5	0	34.26	283.01	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 22:52:43.059	2026-04-02 22:52:38.136	null	RAW_SHORT	2026-04-17 22:52:43.058
cmni2fxay05cck84wqpxfwy9y	\N	alex@brspark.com	dev_szkcjr	cmni1npwo045ck84w2mp3uaqv	OS_ACCEPT	\N	\N	\N	\N	\N	\N	GPS	\N	\N	UNKNOWN	1.0.0	26.3.1	Simulator iOS	f	f	1	2026-04-02 22:48:17.242	2026-04-02 22:48:14.208	{"previousState": "IDLE"}	LEGAL	2031-04-02 22:48:17.241
cmni2fxaz05cdk84w3ljulfzb	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.37336271	-122.14472699	5	0	33.53	325.2	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 22:48:17.242	2026-04-02 22:48:14.138	null	RAW_SHORT	2026-04-17 22:48:17.241
cmni2g52v05cok84w162krb9p	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.37550207	-122.14687494	5	0	34.21	317.81	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 22:48:27.319	2026-04-02 22:48:23.127	null	RAW_SHORT	2026-04-17 22:48:27.314
cmni2g8v405cuk84wllobwvh5	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.37755308	-122.14919429	5	0	33.76	319.57	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 22:48:32.224	2026-04-02 22:48:32.13	null	RAW_SHORT	2026-04-17 22:48:32.223
cmni2ggll05d5k84wq1awzp9q	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.37989138	-122.15096748	5	0	33.97	338.2	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 22:48:42.25	2026-04-02 22:48:41.139	null	RAW_SHORT	2026-04-17 22:48:42.249
cmni2gocb05dgk84w8988gdmo	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.3826398	-122.15178036	5	0	34.97	350.51	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 22:48:52.284	2026-04-02 22:48:50.139	null	RAW_SHORT	2026-04-17 22:48:52.283
cmni2gw3505drk84ww71tot65	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.3853594	-122.15250213	5	0	33.75	345.59	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 22:49:02.321	2026-04-02 22:48:59.139	null	RAW_SHORT	2026-04-17 22:49:02.32
cmni2h3ub05e2k84wfjjyahn8	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.38758433	-122.15481075	5	0	31.64	307.27	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 22:49:12.371	2026-04-02 22:49:09.14	null	RAW_SHORT	2026-04-17 22:49:12.371
cmni2hbl005edk84w6sn7gdr6	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.38863873	-122.158132	5	0	32.54	280.55	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 22:49:22.405	2026-04-02 22:49:19.14	null	RAW_SHORT	2026-04-17 22:49:22.404
cmni2hjcz05eok84wo6v7h5vt	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.38921159	-122.16173186	5	0	32.27	285.82	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 22:49:32.484	2026-04-02 22:49:29.137	null	RAW_SHORT	2026-04-17 22:49:32.482
cmni2hysn05fak84wv51u99zk	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.39195948	-122.16790371	5	0	33.32	287.58	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 22:49:52.488	2026-04-02 22:49:48.134	null	RAW_SHORT	2026-04-17 22:49:52.487
cmni2i6iw05flk84wyitnlyhl	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.39232727	-122.17156408	5	0	32.51	275.98	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 22:50:02.504	2026-04-02 22:49:58.134	null	RAW_SHORT	2026-04-17 22:50:02.503
cmni2im0w05g7k84wwp50dmay	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.39531442	-122.1776014	5	0	33.11	322.03	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 22:50:22.592	2026-04-02 22:50:18.14	null	RAW_SHORT	2026-04-17 22:50:22.591
cmni2ipvl05gdk84wf9kslmiy	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.39747477	-122.17969227	5	0	34.8	321.68	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 22:50:27.585	2026-04-02 22:50:27.221	null	RAW_SHORT	2026-04-17 22:50:27.585
cmni2ixmx05gok84wkwwao2y8	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.39971672	-122.18192127	5	0	35.22	321.68	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 22:50:37.641	2026-04-02 22:50:36.133	null	RAW_SHORT	2026-04-17 22:50:37.64
cmni2jd4c05hak84wrfw3y8oa	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.40408658	-122.18630827	5	0	34	321.33	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 22:50:57.709	2026-04-02 22:50:54.137	null	RAW_SHORT	2026-04-17 22:50:57.708
cmni2jkv405hlk84w7xwrtvwf	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.406187	-122.18845228	5	0	32.96	319.92	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 22:51:07.745	2026-04-02 22:51:03.134	null	RAW_SHORT	2026-04-17 22:51:07.743
cmni2k0dt05i7k84wv0eoz3f7	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.40924065	-122.19469587	5	0	33.01	291.09	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 22:51:27.858	2026-04-02 22:51:23.154	null	RAW_SHORT	2026-04-17 22:51:27.857
cmni2k47t05idk84wj6daitc4	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.41025751	-122.19788477	5	0	34.04	291.8	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 22:51:32.825	2026-04-02 22:51:32.137	null	RAW_SHORT	2026-04-17 22:51:32.825
cmni2kbyg05iok84wrw4r9zu1	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.41128521	-122.20114273	5	0	34.79	291.8	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 22:51:42.856	2026-04-02 22:51:41.137	null	RAW_SHORT	2026-04-17 22:51:42.855
cmni2kjon05izk84wwyarajsq	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.41233794	-122.20442475	5	0	34.65	291.8	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 22:51:52.872	2026-04-02 22:51:50.131	null	RAW_SHORT	2026-04-17 22:51:52.871
cmni2krfl05jak84w6s7a7ul4	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.41347243	-122.20759654	5	0	34.2	301.29	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 22:52:02.913	2026-04-02 22:51:59.138	null	RAW_SHORT	2026-04-17 22:52:02.912
cmni2kz6505jlk84wkkayy3w5	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.41535131	-122.21013769	5	0	34.26	321.33	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 22:52:12.941	2026-04-02 22:52:08.166	null	RAW_SHORT	2026-04-17 22:52:12.94
cmni2l6xa05jwk84wdo1mwtht	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.41751498	-122.21274345	5	0	33.08	305.51	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 22:52:22.99	2026-04-02 22:52:18.14	null	RAW_SHORT	2026-04-17 22:52:22.989
cmni2leny05k7k84wnrcv3y66	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.41862281	-122.2161253	5	0	32.23	281.95	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 22:52:33.022	2026-04-02 22:52:28.137	null	RAW_SHORT	2026-04-17 22:52:33.022
cmni2lq9j05kok84w7pcas3d3	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.42039831	-122.22300357	5	0	34.56	306.56	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 22:52:48.055	2026-04-02 22:52:47.134	null	RAW_SHORT	2026-04-17 22:52:48.054
cmni2ly0a05kzk84wn56jal2r	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.42221534	-122.22563264	5	0	34.15	310.78	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 22:52:58.09	2026-04-02 22:52:56.133	null	RAW_SHORT	2026-04-17 22:52:58.09
cmni2m4zv05lak84wg5uoyo4u	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.42404586	-122.22828543	5	0	35.16	310.78	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 22:53:07.147	2026-04-02 22:53:05.139	null	RAW_SHORT	2026-04-17 22:53:07.146
cmni2mdi105lqk84wkcqr887n	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.42602726	-122.23093034	5	0	35.64	316.05	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 22:53:18.169	2026-04-02 22:53:14.134	null	RAW_SHORT	2026-04-17 22:53:18.168
cmni2mhdf05lwk84wt8082dtx	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.42803355	-122.23345363	5	0	34.52	312.19	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 22:53:23.187	2026-04-02 22:53:23.139	null	RAW_SHORT	2026-04-17 22:53:23.187
cmni2mp4p05m7k84wm6hvrnnt	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.42981596	-122.23606668	5	0	32.93	310.43	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 22:53:33.242	2026-04-02 22:53:32.14	null	RAW_SHORT	2026-04-17 22:53:33.241
cmni2mwvr05mik84wjn30pe2c	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.43180499	-122.23884881	5	0	33.85	313.95	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 22:53:43.287	2026-04-02 22:53:42.146	null	RAW_SHORT	2026-04-17 22:53:43.287
cmni2n4l205mtk84wm67pesd0	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.43376254	-122.2412125	5	0	33.13	316.41	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 22:53:53.27	2026-04-02 22:53:51.138	null	RAW_SHORT	2026-04-17 22:53:53.269
cmni2ncb905n4k84w0a2ovm4s	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.43592675	-122.24376328	5	0	33.23	316.41	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 22:54:03.286	2026-04-02 22:54:01.158	null	RAW_SHORT	2026-04-17 22:54:03.285
cmni2nk1j05nfk84w2jrt6o5u	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.4378918	-122.24613695	5	0	33.5	316.41	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 22:54:13.303	2026-04-02 22:54:10.131	null	RAW_SHORT	2026-04-17 22:54:13.302
cmni2nrrs05nqk84wvupb4w3d	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.44000262	-122.24876996	5	0	32.88	314.3	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 22:54:23.32	2026-04-02 22:54:20.147	null	RAW_SHORT	2026-04-17 22:54:23.319
cmni2nzi705o1k84wjv7rdlxj	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.44207177	-122.25146784	5	0	32.88	312.89	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 22:54:33.343	2026-04-02 22:54:30.137	null	RAW_SHORT	2026-04-17 22:54:33.342
cmni2o78c05ock84w8ylah96b	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.44364246	-122.25458952	5	0	32.61	292.5	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 22:54:43.356	2026-04-02 22:54:40.145	null	RAW_SHORT	2026-04-17 22:54:43.355
cmni2oeyi05onk84w8m4fvbrl	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.44423451	-122.25815644	5	0	32.29	272.46	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 22:54:53.371	2026-04-02 22:54:50.141	null	RAW_SHORT	2026-04-17 22:54:53.37
cmni2omot05oyk84w932k6s4k	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.44401797	-122.26182293	5	0	32.35	264.02	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 22:55:03.389	2026-04-02 22:55:00.14	null	RAW_SHORT	2026-04-17 22:55:03.388
cmni2ouf005p9k84wqj7rwzqh	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.44381697	-122.26544651	5	0	32.14	272.46	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 22:55:13.405	2026-04-02 22:55:10.143	null	RAW_SHORT	2026-04-17 22:55:13.404
cmni2p25m05pkk84w3omfd8vh	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.4444387	-122.26900388	5	0	32.78	291.8	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 22:55:23.434	2026-04-02 22:55:20.142	null	RAW_SHORT	2026-04-17 22:55:23.434
cmni2p9vc05pvk84w9ofo977a	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.44578948	-122.27195431	5	0	34.08	307.62	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 22:55:33.433	2026-04-02 22:55:29.146	null	RAW_SHORT	2026-04-17 22:55:33.432
cmni2pdr005q1k84wireldazw	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.44763979	-122.27464045	5	0	35.01	311.13	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 22:55:38.46	2026-04-02 22:55:38.14	null	RAW_SHORT	2026-04-17 22:55:38.46
cmni2plhh05qck84wpxnttbnq	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.44952769	-122.27735443	5	0	35.54	310.08	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 22:55:48.486	2026-04-02 22:55:47.134	null	RAW_SHORT	2026-04-17 22:55:48.485
cmni2pt7605qnk84woik91y3z	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.45133281	-122.28009883	5	0	34.86	309.73	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 22:55:58.482	2026-04-02 22:55:56.144	null	RAW_SHORT	2026-04-17 22:55:58.481
cmni2qk9905rqk84w7i6b41nr	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.4591201	-122.28995444	5	0	34.45	337.85	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 22:56:33.549	2026-04-02 22:56:32.154	null	RAW_SHORT	2026-04-17 22:56:33.548
cmni2qzqh05sck84w3xv5nieh	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.46449927	-122.29080537	5	0	33.1	355.43	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 22:56:53.609	2026-04-02 22:56:50.141	null	RAW_SHORT	2026-04-17 22:56:53.608
cmni2r7gn05snk84w19egzfuz	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.46741706	-122.29164222	5	0	33.44	339.61	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 22:57:03.624	2026-04-02 22:57:00.147	null	RAW_SHORT	2026-04-17 22:57:03.623
cmni2rj2805t4k84wo6vv82g7	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.47193243	-122.29536731	5	0	33.52	321.33	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 22:57:18.657	2026-04-02 22:57:18.142	null	RAW_SHORT	2026-04-17 22:57:18.656
cmni2se0605uck84w71aiwkr0	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.48204679	-122.298808	5	0	34.51	7.03	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 22:57:58.759	2026-04-02 22:57:54.141	null	RAW_SHORT	2026-04-17 22:57:58.758
cmni2q0xl05qyk84wqtb8tvpg	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.45311074	-122.28279923	5	0	34.09	309.38	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 22:56:08.506	2026-04-02 22:56:05.143	null	RAW_SHORT	2026-04-17 22:56:08.505
cmni2q8nq05r9k84w01fmkd7u	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.45488322	-122.28547306	5	0	34.74	309.73	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 22:56:18.518	2026-04-02 22:56:14.141	null	RAW_SHORT	2026-04-17 22:56:18.517
cmni2qcja05rfk84wwrx4a9yq	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.45672979	-122.28811109	5	0	34.63	317.81	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 22:56:23.543	2026-04-02 22:56:23.146	null	RAW_SHORT	2026-04-17 22:56:23.542
cmni2qrzh05s1k84w3mc3un7c	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.4617959	-122.29070035	5	0	33.54	354.38	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 22:56:43.565	2026-04-02 22:56:41.146	null	RAW_SHORT	2026-04-17 22:56:43.564
cmni2rf7e05syk84wu822r6yu	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.46980661	-122.29324794	5	0	33.47	324.84	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 22:57:13.659	2026-04-02 22:57:09.144	null	RAW_SHORT	2026-04-17 22:57:13.658
cmni2rqt005tfk84wkx03l0rc	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.47407652	-122.29748533	5	0	33.71	324.84	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 22:57:28.692	2026-04-02 22:57:27.139	null	RAW_SHORT	2026-04-17 22:57:28.691
cmni2ryjq05tqk84wis116uxa	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.47654113	-122.29890078	5	0	33.88	343.83	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 22:57:38.727	2026-04-02 22:57:36.155	null	RAW_SHORT	2026-04-17 22:57:38.726
cmni2s69e05u1k84wlrgs171b	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.47928265	-122.29924209	5	0	33.95	3.52	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 22:57:48.723	2026-04-02 22:57:45.143	null	RAW_SHORT	2026-04-17 22:57:48.722
cmni2shvj05uik84www8s7hyc	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.48475481	-122.29834808	5	0	32.93	7.38	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 22:58:03.776	2026-04-02 22:58:03.143	null	RAW_SHORT	2026-04-17 22:58:03.775
cmni2splq05uyk84wy5azkicf	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.48769154	-122.29820324	5	0	33.23	353.32	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 22:58:13.79	2026-04-02 22:58:13.146	null	RAW_SHORT	2026-04-17 22:58:13.789
cmni2sxcf05v9k84wg3jh26m7	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.49056217	-122.29928702	5	0	32.99	333.98	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 22:58:23.823	2026-04-02 22:58:23.145	null	RAW_SHORT	2026-04-17 22:58:23.822
cmni2t53305vkk84wqrfx9cp9	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.49291363	-122.30150194	5	0	32.67	313.95	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 22:58:33.856	2026-04-02 22:58:33.162	null	RAW_SHORT	2026-04-17 22:58:33.855
cmni2tctt05vvk84wr8q1xu0i	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.49453457	-122.30464079	5	0	33.45	293.2	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 22:58:43.889	2026-04-02 22:58:43.144	null	RAW_SHORT	2026-04-17 22:58:43.888
cmni2tkkn05w6k84wouodrihu	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.49543424	-122.30818156	5	0	32.45	286.88	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 22:58:53.927	2026-04-02 22:58:53.146	null	RAW_SHORT	2026-04-17 22:58:53.926
cmni2tsbs05whk84w1f71kl77	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.4963855	-122.3116028	5	0	32.65	294.26	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 22:59:03.976	2026-04-02 22:59:03.146	null	RAW_SHORT	2026-04-17 22:59:03.975
cmni2u01z05wsk84w7qprlps8	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.49791545	-122.31482925	5	0	34.11	305.16	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 22:59:13.991	2026-04-02 22:59:13.161	null	RAW_SHORT	2026-04-17 22:59:13.99
cmni2u7sn05x3k84wdl9of0v9	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.49945868	-122.31765789	5	0	33.58	301.29	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 22:59:24.023	2026-04-02 22:59:22.14	null	RAW_SHORT	2026-04-17 22:59:24.022
cmni2ufiv05xek84wxphblpf5	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.50055478	-122.32105281	5	0	31.39	283.71	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 22:59:34.039	2026-04-02 22:59:32.144	null	RAW_SHORT	2026-04-17 22:59:34.039
cmni2unab05xpk84wtdtc6unz	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.50087108	-122.32460448	5	0	32.05	272.81	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 22:59:44.099	2026-04-02 22:59:42.144	null	RAW_SHORT	2026-04-17 22:59:44.098
cmni2uuzs05y0k84w4r5hbufz	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.50133564	-122.32819947	5	0	32.41	287.58	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 22:59:54.089	2026-04-02 22:59:52.141	null	RAW_SHORT	2026-04-17 22:59:54.088
cmni2v2r205ybk84wuuznhves	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.50272247	-122.33142131	5	0	33.04	307.27	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 23:00:04.142	2026-04-02 23:00:02.146	null	RAW_SHORT	2026-04-17 23:00:04.141
cmni2vai105ymk84wdlz6dtq0	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.50438925	-122.33410746	5	0	33.69	307.27	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 23:00:14.185	2026-04-02 23:00:11.146	null	RAW_SHORT	2026-04-17 23:00:14.184
cmni2vi8o05yxk84wfv75vtr6	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.50606869	-122.33688933	5	0	34.88	307.62	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 23:00:24.216	2026-04-02 23:00:20.142	null	RAW_SHORT	2026-04-17 23:00:24.215
cmni2vm3n05z3k84wcpaf0dlf	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.50780014	-122.33971445	5	0	35.12	307.97	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 23:00:29.22	2026-04-02 23:00:29.14	null	RAW_SHORT	2026-04-17 23:00:29.219
cmni2vtty05zek84we1a8m4dr	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.50948943	-122.34244552	5	0	33.34	309.73	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 23:00:39.239	2026-04-02 23:00:38.141	null	RAW_SHORT	2026-04-17 23:00:39.238
cmni2w1ka05zpk84wyg7vexs3	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.51158508	-122.3451284	5	0	33.63	317.11	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 23:00:49.258	2026-04-02 23:00:48.142	null	RAW_SHORT	2026-04-17 23:00:49.257
cmni2w9bf0600k84wsgq1whvt	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.51359988	-122.34743577	5	0	33.46	317.46	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 23:00:59.308	2026-04-02 23:00:57.141	null	RAW_SHORT	2026-04-17 23:00:59.307
cmni2wh0m060bk84wqnfbtpn9	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.51579153	-122.3499475	5	0	32.41	317.81	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 23:01:09.286	2026-04-02 23:01:07.145	null	RAW_SHORT	2026-04-17 23:01:09.286
cmni2woru060mk84w74yyifq6	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.51797837	-122.35239962	5	0	32.96	320.98	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 23:01:19.338	2026-04-02 23:01:17.144	null	RAW_SHORT	2026-04-17 23:01:19.337
cmni2wwhp060xk84wugshvaek	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.5202453	-122.35426233	5	0	33.74	332.23	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 23:01:29.341	2026-04-02 23:01:26.147	null	RAW_SHORT	2026-04-17 23:01:29.34
cmni2x47c0618k84wjsnoia10	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.52299544	-122.35580008	5	0	33.29	336.09	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 23:01:39.336	2026-04-02 23:01:36.144	null	RAW_SHORT	2026-04-17 23:01:39.335
cmni2xby6061jk84wztuxpu1y	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.52552611	-122.35781861	5	0	34.13	324.49	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 23:01:49.374	2026-04-02 23:01:46.14	null	RAW_SHORT	2026-04-17 23:01:49.374
cmni2xjoc061uk84wovyi3lp3	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.52800506	-122.35949985	5	0	34.9	341.02	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 23:01:59.389	2026-04-02 23:01:55.159	null	RAW_SHORT	2026-04-17 23:01:59.388
cmni2xnjq0620k84w1vrklqkd	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.53068496	-122.36063467	5	0	34.77	341.37	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 23:02:04.407	2026-04-02 23:02:04.14	null	RAW_SHORT	2026-04-17 23:02:04.406
cmni2xv9y062bk84wuldeww0p	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.53334395	-122.36177327	5	0	34.44	341.37	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 23:02:14.422	2026-04-02 23:02:13.14	null	RAW_SHORT	2026-04-17 23:02:14.421
cmni2y30d062mk84wb280ejb6	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.53591623	-122.36300097	5	0	33.5	336.45	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 23:02:24.445	2026-04-02 23:02:22.138	null	RAW_SHORT	2026-04-17 23:02:24.442
cmni2yaqg062xk84wmsma190g	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.53860477	-122.36458146	5	0	32.83	334.34	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 23:02:34.456	2026-04-02 23:02:32.146	null	RAW_SHORT	2026-04-17 23:02:34.456
cmni2yih10638k84wypec9xyk	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.54123564	-122.36620294	5	0	32.44	331.17	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 23:02:44.486	2026-04-02 23:02:42.143	null	RAW_SHORT	2026-04-17 23:02:44.485
cmni2yq7e063jk84wdxx1hnps	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.54365964	-122.36820328	5	0	32.86	320.98	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 23:02:54.506	2026-04-02 23:02:52.141	null	RAW_SHORT	2026-04-17 23:02:54.505
cmni2yxy6063uk84whj89jwpl	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.54598206	-122.37059682	5	0	33.29	320.62	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 23:03:04.542	2026-04-02 23:03:02.146	null	RAW_SHORT	2026-04-17 23:03:04.541
cmni2z5o6064ak84wg6sd8n1o	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.54827568	-122.3729751	5	0	32.68	320.27	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 23:03:14.551	2026-04-02 23:03:12.144	null	RAW_SHORT	2026-04-17 23:03:14.55
cmni2zdeu064lk84wm8xk7myq	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.55055158	-122.37533284	5	0	33.27	321.33	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 23:03:24.582	2026-04-02 23:03:22.146	null	RAW_SHORT	2026-04-17 23:03:24.581
cmni2zl4v064wk84wtb1bqvo9	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.5528237	-122.37738054	5	0	35.82	328.36	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 23:03:34.592	2026-04-02 23:03:31.147	null	RAW_SHORT	2026-04-17 23:03:34.591
cmni2zsvi0657k84wm5pwkolz	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.55541199	-122.37918458	5	0	36.43	332.23	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 23:03:44.622	2026-04-02 23:03:40.14	null	RAW_SHORT	2026-04-17 23:03:44.621
cmni2zwr1065dk84wn2m3l3yw	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.55792263	-122.38086842	5	0	33.86	330.82	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 23:03:49.645	2026-04-02 23:03:49.151	null	RAW_SHORT	2026-04-17 23:03:49.644
cmni304hn065ok84whkslixtk	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.56018092	-122.38291134	5	0	35.39	321.33	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 23:03:59.675	2026-04-02 23:03:58.141	null	RAW_SHORT	2026-04-17 23:03:59.674
cmni30rre066lk84wlq5yte0f	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.5662684	-122.39029697	5	0	32.91	292.85	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 23:04:29.835	2026-04-02 23:04:26.139	null	RAW_SHORT	2026-04-17 23:04:29.834
cmni30zg0066wk84wr8vvhlbx	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.56749438	-122.39332946	5	0	33.82	306.56	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 23:04:39.792	2026-04-02 23:04:35.139	null	RAW_SHORT	2026-04-17 23:04:39.792
cmni313bd0672k84wvbubst81	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.56950528	-122.39562543	5	0	33.97	323.09	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 23:04:44.809	2026-04-02 23:04:44.136	null	RAW_SHORT	2026-04-17 23:04:44.808
cmni31b1i067dk84wrlguuukd	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.57168001	-122.39767439	5	0	33.69	323.09	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 23:04:54.823	2026-04-02 23:04:53.145	null	RAW_SHORT	2026-04-17 23:04:54.822
cmni31zwg068nk84w8ugyw5d1	\N	alex@brspark.com	dev_szkcjr	cmni1npwo045ck84w2mp3uaqv	OS_ACCEPT	\N	\N	\N	\N	\N	\N	GPS	\N	\N	UNKNOWN	1.0.0	26.3.1	Simulator iOS	f	f	5	2026-04-02 23:05:27.04	2026-04-02 23:05:23.59	{"previousState": "IDLE"}	LEGAL	2031-04-02 23:05:27.039
cmni31zwg068ok84wuynlkujx	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.58005085	-122.40290788	5	0	32.41	329.41	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 23:05:27.04	2026-04-02 23:05:24.154	null	RAW_SHORT	2026-04-17 23:05:27.039
cmni327ui068zk84wzi1eest1	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.58259199	-122.40486589	5	0	33.67	328.71	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 23:05:37.337	2026-04-02 23:05:34.135	null	RAW_SHORT	2026-04-17 23:05:37.332
cmni32jm2069gk84w4e3jwqi0	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.58668202	-122.40947736	5	0	34.52	310.08	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 23:05:52.584	2026-04-02 23:05:52.149	null	RAW_SHORT	2026-04-17 23:05:52.583
cmni33xnw06bgk84wnb401jzz	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.6012209	-122.42531681	5	0	33.64	316.41	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 23:06:57.453	2026-04-02 23:06:55.145	null	RAW_SHORT	2026-04-17 23:06:57.451
cmni30c7u065zk84wqicci51i	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.56242844	-122.38515208	5	0	34.55	321.33	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 23:04:09.69	2026-04-02 23:04:07.143	null	RAW_SHORT	2026-04-17 23:04:09.689
cmni34d3u06c2k84wmzxtus81	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.60638205	-122.42801839	5	0	32.8	358.95	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 23:07:17.467	2026-04-02 23:07:14.169	null	RAW_SHORT	2026-04-17 23:07:17.466
cmni35jos06drk84wcdkvzrq1	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.6227911	-122.42733945	5	0	34.94	332.93	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 23:08:12.653	2026-04-02 23:08:12.138	null	RAW_SHORT	2026-04-17 23:08:12.651
cmni35rem06e2k84w1bzdd4m8	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.62525969	-122.42895322	5	0	34.47	330.47	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 23:08:22.654	2026-04-02 23:08:21.14	null	RAW_SHORT	2026-04-17 23:08:22.653
cmni30jyb066ak84wkn3q3akj	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.56457886	-122.387311	5	0	33.15	320.27	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 23:04:19.715	2026-04-02 23:04:16.142	null	RAW_SHORT	2026-04-17 23:04:19.714
cmni32r0k069rk84wjd52oeh3	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.58870185	-122.41186269	5	0	34.32	322.03	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 23:06:02.181	2026-04-02 23:06:01.144	null	RAW_SHORT	2026-04-17 23:06:02.18
cmni32fhw069ak84w7dzgpxcd	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.58480976	-122.40690337	5	0	34.05	317.81	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 23:05:47.251	2026-04-02 23:05:43.173	null	RAW_SHORT	2026-04-17 23:05:47.249
cmni32yse06a2k84w048iv5mg	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.59089234	-122.41402865	5	0	35.15	320.98	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 23:06:12.255	2026-04-02 23:06:10.142	null	RAW_SHORT	2026-04-17 23:06:12.254
cmni336ki06adk84wm6cqyiwd	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.59307729	-122.41618842	5	0	34.11	320.98	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 23:06:22.338	2026-04-02 23:06:19.158	null	RAW_SHORT	2026-04-17 23:06:22.337
cmni33eb406aok84ws2wvtlrz	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.59524887	-122.41829286	5	0	33.59	321.68	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 23:06:32.368	2026-04-02 23:06:28.141	null	RAW_SHORT	2026-04-17 23:06:32.368
cmni33i6i06auk84w4bxf6rf5	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.59731589	-122.42053569	5	0	33.64	315.7	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 23:06:37.386	2026-04-02 23:06:37.139	null	RAW_SHORT	2026-04-17 23:06:37.386
cmni33pwr06b5k84wno18yosw	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.59924335	-122.42293962	5	0	33.86	315.7	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 23:06:47.404	2026-04-02 23:06:46.154	null	RAW_SHORT	2026-04-17 23:06:47.403
cmni345dk06brk84wseoaeavh	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.6034719	-122.42725153	5	0	33.73	335.74	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 23:07:07.449	2026-04-02 23:07:04.14	null	RAW_SHORT	2026-04-17 23:07:07.448
cmni34kwx06cdk84wwuujghn7	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.60930046	-122.42741623	5	0	33.22	15.82	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 23:07:27.585	2026-04-02 23:07:24.155	null	RAW_SHORT	2026-04-17 23:07:27.584
cmni34sld06cok84wfbu668ym	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.61204076	-122.42587002	5	0	33.18	29.18	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 23:07:37.538	2026-04-02 23:07:34.21	null	RAW_SHORT	2026-04-17 23:07:37.537
cmni350cs06czk84w52268zp3	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.61473169	-122.42429095	5	0	33.57	15.12	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 23:07:47.596	2026-04-02 23:07:44.157	null	RAW_SHORT	2026-04-17 23:07:47.595
cmni3584806dak84w0g80eswf	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.61771095	-122.42432037	5	0	33.49	346.64	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 23:07:57.656	2026-04-02 23:07:54.14	null	RAW_SHORT	2026-04-17 23:07:57.654
cmni35fth06dlk84wjrm3mxvs	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.6202557	-122.42570557	5	0	34.87	332.23	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 23:08:07.637	2026-04-02 23:08:03.155	null	RAW_SHORT	2026-04-17 23:08:07.636
cmni35z5106edk84wz9dt8so5	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.62751237	-122.43105867	5	0	34.12	316.76	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 23:08:32.677	2026-04-02 23:08:30.143	null	RAW_SHORT	2026-04-17 23:08:32.676
cmni366w406eok84w1k0362p5	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.62940085	-122.43352924	5	0	33.65	313.59	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 23:08:42.724	2026-04-02 23:08:39.144	null	RAW_SHORT	2026-04-17 23:08:42.723
cmni36emk06ezk84wwlrqnb9a	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.63128427	-122.43601061	5	0	33.33	314.3	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 23:08:52.748	2026-04-02 23:08:48.195	null	RAW_SHORT	2026-04-17 23:08:52.746
cmni36ihq06f5k84wiytnth10	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.63349298	-122.43806368	5	0	34.47	331.52	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 23:08:57.759	2026-04-02 23:08:57.141	null	RAW_SHORT	2026-04-17 23:08:57.758
cmni36q7q06fgk84wok6228q8	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.63609125	-122.43938995	5	0	34.21	339.96	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 23:09:07.767	2026-04-02 23:09:06.141	null	RAW_SHORT	2026-04-17 23:09:07.766
cmni36xye06frk84wpc3v9rj5	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.63853126	-122.44089953	5	0	33.29	325.9	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 23:09:17.799	2026-04-02 23:09:15.143	null	RAW_SHORT	2026-04-17 23:09:17.798
cmni375pt06g2k84w1dpsv28p	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.64093544	-122.44298813	5	0	32.37	325.2	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 23:09:27.857	2026-04-02 23:09:25.141	null	RAW_SHORT	2026-04-17 23:09:27.856
cmni37dfh06gdk84ww3q3w7gt	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.64307505	-122.44550295	5	0	32.91	307.27	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 23:09:37.853	2026-04-02 23:09:35.248	null	RAW_SHORT	2026-04-17 23:09:37.853
cmni37l5t06gok84wtirllabj	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.64480118	-122.44856712	5	0	33.28	312.19	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 23:09:47.873	2026-04-02 23:09:45.143	null	RAW_SHORT	2026-04-17 23:09:47.872
cmni37swg06gzk84wa5a1ne4d	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.64724442	-122.45059714	5	0	32.66	334.34	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 23:09:57.905	2026-04-02 23:09:55.139	null	RAW_SHORT	2026-04-17 23:09:57.904
cmni37zw006hak84w7itutl87	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.64986665	-122.4521721	5	0	32.1	335.04	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 23:10:06.96	2026-04-02 23:10:05.142	null	RAW_SHORT	2026-04-17 23:10:06.959
cmni388dg06hqk84w5nh40byr	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.65232339	-122.45406641	5	0	31.79	318.52	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 23:10:17.956	2026-04-02 23:10:15.244	null	RAW_SHORT	2026-04-17 23:10:17.955
cmni38g3n06i1k84wzwjopomc	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.6543464	-122.45663554	5	0	32.34	314.65	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 23:10:27.971	2026-04-02 23:10:25.15	null	RAW_SHORT	2026-04-17 23:10:27.97
cmni38nuj06ick84wdmdozcxu	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.65643224	-122.45931348	5	0	33.68	314.65	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 23:10:38.011	2026-04-02 23:10:35.143	null	RAW_SHORT	2026-04-17 23:10:38.01
cmni38vlt06ink84wjd6jc49h	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.6585296	-122.46199854	5	0	33.24	314.3	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 23:10:48.065	2026-04-02 23:10:45.144	null	RAW_SHORT	2026-04-17 23:10:48.064
cmni393av06iyk84wo414f0qk	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.66051201	-122.46432619	5	0	33.43	324.84	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 23:10:58.039	2026-04-02 23:10:54.148	null	RAW_SHORT	2026-04-17 23:10:58.038
cmni39b1u06j9k84w5em04wy6	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.66331739	-122.46552707	5	0	33.46	355.08	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 23:11:08.083	2026-04-02 23:11:04.172	null	RAW_SHORT	2026-04-17 23:11:08.082
cmni39ptx06k4k84wn1d2vm1o	\N	alex@brspark.com	dev_szkcjr	cmni1npwo045ck84w2mp3uaqv	OS_ACCEPT	\N	\N	\N	\N	\N	\N	GPS	\N	\N	UNKNOWN	1.0.0	26.3.1	Simulator iOS	f	f	8	2026-04-02 23:11:27.238	2026-04-02 23:11:26.242	{"previousState": "IDLE"}	LEGAL	2031-04-02 23:11:27.236
cmni39ptx06k5k84wyvf1xfcn	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.66999366	-122.46600668	5	0	34.25	348.4	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 23:11:27.238	2026-04-02 23:11:26.769	null	RAW_SHORT	2026-04-17 23:11:27.236
cmni39xjl06kgk84w99yd5q12	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.67252508	-122.46730663	5	0	33.32	331.52	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 23:11:37.233	2026-04-02 23:11:35.14	null	RAW_SHORT	2026-04-17 23:11:37.232
cmni3a5be06krk84weh7b4qjl	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.67503877	-122.46932809	5	0	32.96	326.95	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 23:11:47.306	2026-04-02 23:11:45.166	null	RAW_SHORT	2026-04-17 23:11:47.304
cmni3ad0k06l2k84wqy4vh6jd	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.67751495	-122.47117463	5	0	31.21	337.85	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 23:11:57.284	2026-04-02 23:11:55.143	null	RAW_SHORT	2026-04-17 23:11:57.283
\.


--
-- Data for Name: Tenant; Type: TABLE DATA; Schema: public; Owner: alex
--

COPY public."Tenant" (id, name, slug, email, phone, "taxId", "defaultLang", status, "createdAt", "updatedAt", "avatarUrl", "localeId", "ownerName", "sectorCode") FROM stdin;
cmnhhqj5c000e3yrjmvwv50er	Alex	alex	alex@brspark.com	\N	\N	pt-BR	TRIAL	2026-04-02 13:08:40.176	2026-04-02 13:08:40.176	\N	\N	Alex	\N
\.


--
-- Data for Name: TranslationOverride; Type: TABLE DATA; Schema: public; Owner: alex
--

COPY public."TranslationOverride" (id, "tenantId", key, language, value, "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: User; Type: TABLE DATA; Schema: public; Owner: alex
--

COPY public."User" (id, "tenantId", email, name, password, role, "isActive", "lastLogin", "createdAt", "updatedAt", "avatarUrl") FROM stdin;
cmnhhqj5w000g3yrj2m7fnu6n	cmnhhqj5c000e3yrjmvwv50er	alex@brspark.com	Alex	$2a$10$eKNvxvkUGs4RfuO28hMEculRY80pNedDbiaZ6i5yLEciMgGLHmSyq	ADMIN	t	2026-04-02 17:35:15.977	2026-04-02 13:08:40.196	2026-04-02 21:12:44.63	http://localhost:3001/uploads/storage/avatars/cmnhhqj5w000g3yrj2m7fnu6n_1775164364565.jpg
\.


--
-- Data for Name: UserModuleData; Type: TABLE DATA; Schema: public; Owner: alex
--

COPY public."UserModuleData" (id, "ownerEmail", module, data, "updatedAt", "createdAt") FROM stdin;
cmnhgha6o0000edbotlvxyl8r	alex@brspark.com	stock_items	[{"id": "local_stock_1774732811358", "sku": "Qwewqe", "name": "Wqewq", "unit": "un", "category": "Suprimentos", "minStock": 2, "costPrice": 0, "locationId": null, "owner_email": "alex@brspark.com", "subLocation": null, "currentStock": 1, "asset_location_id": null}]	2026-04-02 23:12:02.295	2026-04-02 12:33:29.04
cmnhgha6q0001edboo6v4fuzq	alex@brspark.com	costs_expenses	[{"id": "exp-mn67vmfh-dy607", "date": "2026-03-25", "type": "EXPENSE", "amount": 532, "status": "PENDING", "assetId": "brsp-215880", "category": "OUTROS", "ownerEmail": "alex@brspark.com", "description": "Pneu"}, {"id": "exp-mn67xbkl-2bu76", "date": "2026-03-25", "type": "EXPENSE", "amount": 523.87, "status": "PENDING", "assetId": "brsp-585500", "category": "OUTROS", "ownerEmail": "alex@brspark.com", "description": "Pneu"}, {"id": "exp-mn684uwl-189lr", "date": "2026-03-25", "type": "EXPENSE", "amount": 582, "status": "PENDING", "assetId": "brsp-585500", "category": "OUTROS", "ownerEmail": "alex@brspark.com", "description": "Pmeu"}, {"id": "exp-mn68cwe3-e1zb0", "date": "2026-03-25", "type": "EXPENSE", "amount": 235, "status": "PENDING", "assetId": "brsp-215880", "category": "OUTROS", "ownerEmail": "alex@brspark.com", "description": "Pneu"}, {"id": "exp-mn6hn1bs-ka6kt", "date": "2026-03-25", "type": "EXPENSE", "amount": 152, "status": "PENDING", "assetId": "brsp-190135", "category": "OUTROS", "ownerEmail": "alex@brspark.com", "description": "Luz"}, {"id": "exp-mn6hp6c6-u9q2w", "date": "2026-03-25", "type": "EXPENSE", "amount": 500, "status": "PENDING", "assetId": "brsp-628386", "category": "OUTROS", "ownerEmail": "alex@brspark.com", "description": "Pmeu"}, {"id": "exp-mn7gcdd2-74nic", "date": "2026-03-26", "type": "REVENUE", "amount": 100, "status": "PENDING", "assetId": "brsp-756993", "category": "OUTROS", "ownerEmail": "alex@brspark.com", "description": "Testw"}, {"id": "exp-mn8wkyku-t309v", "date": "2026-03-27", "type": "REVENUE", "amount": 100, "status": "PENDING", "assetId": "brsp-134786", "category": "OUTROS", "ownerEmail": "alex@brspark.com", "description": "Teste"}, {"id": "exp-mn8wuoci-3bvk6", "date": "2026-03-27", "type": "EXPENSE", "amount": 25, "status": "PENDING", "assetId": "brsp-134786", "category": "OUTROS", "ownerEmail": "alex@brspark.com", "description": "Teste22"}]	2026-04-02 23:12:02.298	2026-04-02 12:33:29.043
cmnhgha7b0002edbo0e4apd4k	alex@brspark.com	asset_docs	[{"id": "qdce4o", "uri": "https://pub-5fc6db4a467f3070a46bf138e5b79edb.r2.dev/docs/alex_brspark_com/qdce4o.pdf", "type": "pdf", "title": "NF-e - Nota Fiscal Eletrônica de Serviços - São Paulo.pdf", "assetId": "brsp-190135", "version": 1, "category": "general", "createdAt": "2026-03-25T23:39:27.408Z", "description": ""}, {"id": "5b8tw4", "uri": "https://pub-5fc6db4a467f3070a46bf138e5b79edb.r2.dev/docs/alex_brspark_com/5b8tw4.pdf", "type": "pdf", "title": "Currículo Thais 2025.pdf", "assetId": "brsp-190135", "version": 1, "category": "general", "createdAt": "2026-03-25T23:39:33.198Z", "description": ""}, {"id": "nmft9b", "uri": "", "type": "folder", "title": "Teste", "assetId": "brsp-756993", "version": 1, "category": "general", "createdAt": "2026-03-26T18:13:09.048Z"}, {"id": "4oc4kl", "uri": "/BrSpark/docs/alex_brspark_com/4oc4kl.pdf", "type": "pdf", "title": "NF-e - Nota Fiscal Eletrônica de Serviços - São Paulo.pdf", "assetId": "brsp-756993", "version": 1, "category": "general", "parentId": "nmft9b", "createdAt": "2026-03-26T18:13:15.140Z", "description": ""}, {"id": "wf9ejb", "uri": "", "type": "folder", "title": "123", "assetId": "brsp-756993", "version": 1, "category": "general", "createdAt": "2026-03-26T18:16:09.617Z"}, {"id": "krsucl", "uri": "", "type": "folder", "title": "1", "assetId": "brsp-756993", "version": 1, "category": "general", "parentId": "nmft9b", "createdAt": "2026-03-26T18:20:06.259Z"}]	2026-04-02 23:12:02.301	2026-04-02 12:33:29.044
cmnhgha7b0003edboqnmkfzho	alex@brspark.com	costs_recurring	[{"id": "rec-mn69xf9l-h54zj", "type": "REVENUE", "amount": 2500, "status": "ACTIVE", "assetId": "brsp-215880", "frequency": "MONTHLY", "ownerEmail": "alex@brspark.com", "description": "Tedte", "nextDueDate": "2026-03-25", "alertDaysBefore": 1, "totalInstallments": 2, "remainingInstallments": 2}, {"id": "ins_cost_ins_1774477825766_cwk5h", "type": "EXPENSE", "amount": 0, "status": "ACTIVE", "assetId": "brsp-190135", "category": "SEGURO", "frequency": "YEARLY", "ownerEmail": "alex@brspark.com", "description": "Seguro Residencial — Teste", "nextDueDate": "209383", "alertDaysBefore": 10}, {"id": "ins_cost_ins_1774477826163_pyzx0", "type": "EXPENSE", "amount": 0, "status": "ACTIVE", "assetId": "brsp-190135", "category": "SEGURO", "frequency": "YEARLY", "ownerEmail": "alex@brspark.com", "description": "Seguro Residencial — Teste", "nextDueDate": "209383", "alertDaysBefore": 10}, {"id": "rec-mn8wim0o-uh9wo", "type": "REVENUE", "amount": 1000, "status": "ACTIVE", "assetId": "brsp-756993", "frequency": "MONTHLY", "ownerEmail": "alex@brspark.com", "description": "Aluguel", "nextDueDate": "2026-03-28", "alertDaysBefore": 1, "totalInstallments": 12, "remainingInstallments": 12}, {"id": "rec-mn8wlgmp-owx71", "type": "REVENUE", "amount": 300, "status": "ACTIVE", "assetId": "brsp-134786", "frequency": "MONTHLY", "ownerEmail": "alex@brspark.com", "description": "Aluguel", "nextDueDate": "2026-03-27", "alertDaysBefore": 1, "totalInstallments": 12, "remainingInstallments": 12}, {"id": "rec-mn8wma7d-j64lj", "type": "REVENUE", "amount": 50, "status": "ACTIVE", "assetId": "brsp-756993", "frequency": "MONTHLY", "ownerEmail": "alex@brspark.com", "description": "Teste", "nextDueDate": "2026-03-27", "alertDaysBefore": 1, "totalInstallments": 12, "remainingInstallments": 12}, {"id": "rec-mn8wmvf1-vx666", "type": "EXPENSE", "amount": 300, "status": "ACTIVE", "assetId": "brsp-756993", "frequency": "MONTHLY", "ownerEmail": "alex@brspark.com", "description": "Teste rec", "nextDueDate": "2026-03-27", "alertDaysBefore": 1, "totalInstallments": 12, "remainingInstallments": 12}, {"id": "rec-mn8wn9yc-roy0r", "type": "EXPENSE", "amount": 50, "status": "ACTIVE", "assetId": "brsp-756993", "frequency": "MONTHLY", "ownerEmail": "alex@brspark.com", "description": "2", "nextDueDate": "2026-03-27", "alertDaysBefore": 1, "totalInstallments": 12, "remainingInstallments": 12}, {"id": "rec-mn8wnmsw-3nbph", "type": "REVENUE", "amount": 100, "status": "ACTIVE", "assetId": "brsp-756993", "frequency": "MONTHLY", "ownerEmail": "alex@brspark.com", "description": "3", "nextDueDate": "2026-03-27", "alertDaysBefore": 1, "totalInstallments": 12, "remainingInstallments": 12}, {"id": "rec-mn8wo9xg-olj46", "type": "REVENUE", "amount": 100, "status": "ACTIVE", "assetId": "brsp-134786", "frequency": "MONTHLY", "ownerEmail": "alex@brspark.com", "description": "1", "nextDueDate": "2026-03-27", "alertDaysBefore": 1, "totalInstallments": 12, "remainingInstallments": 12}, {"id": "rec-mn8wolzq-k0t6i", "type": "EXPENSE", "amount": 200, "status": "ACTIVE", "assetId": "brsp-134786", "frequency": "MONTHLY", "ownerEmail": "alex@brspark.com", "description": "2", "nextDueDate": "2026-03-27", "alertDaysBefore": 1, "totalInstallments": 12, "remainingInstallments": 12}, {"id": "rec-mn8wwasg-y98d3", "type": "EXPENSE", "amount": 50, "status": "ACTIVE", "assetId": "brsp-134786", "frequency": "MONTHLY", "ownerEmail": "alex@brspark.com", "description": "Netflix", "nextDueDate": "2026-03-27", "alertDaysBefore": 1}, {"id": "ins_cost_ins_1774648334205_drxzi", "type": "EXPENSE", "amount": 0, "status": "ACTIVE", "assetId": "brsp-134786", "category": "SEGURO", "frequency": "YEARLY", "ownerEmail": "alex@brspark.com", "description": "Seguro Residencial — Teste", "nextDueDate": "2026-04-27", "alertDaysBefore": 1}, {"id": "ins_cost_ins_1774648335970_y32ey", "type": "EXPENSE", "amount": 0, "status": "ACTIVE", "assetId": "brsp-134786", "category": "SEGURO", "frequency": "YEARLY", "ownerEmail": "alex@brspark.com", "description": "Seguro Residencial — Teste", "nextDueDate": "2026-04-27", "alertDaysBefore": 1}, {"id": "ins_cost_ins_1774648337353_bjq8z", "type": "EXPENSE", "amount": 0, "status": "ACTIVE", "assetId": "brsp-134786", "category": "SEGURO", "frequency": "YEARLY", "ownerEmail": "alex@brspark.com", "description": "Seguro Residencial — Teste", "nextDueDate": "2026-04-27", "alertDaysBefore": 1}, {"id": "ins_cost_ins_1774648337620_kuvjy", "type": "EXPENSE", "amount": 0, "status": "ACTIVE", "assetId": "brsp-134786", "category": "SEGURO", "frequency": "YEARLY", "ownerEmail": "alex@brspark.com", "description": "Seguro Residencial — Teste", "nextDueDate": "2026-04-27", "alertDaysBefore": 1}, {"id": "ins_cost_ins_1774648337870_l14de", "type": "EXPENSE", "amount": 0, "status": "ACTIVE", "assetId": "brsp-134786", "category": "SEGURO", "frequency": "YEARLY", "ownerEmail": "alex@brspark.com", "description": "Seguro Residencial — Teste", "nextDueDate": "2026-04-27", "alertDaysBefore": 1}, {"id": "ins_cost_ins_1774648441070_05axk", "type": "EXPENSE", "amount": 0, "status": "ACTIVE", "assetId": "brsp-134786", "category": "SEGURO", "frequency": "YEARLY", "ownerEmail": "alex@brspark.com", "description": "Seguro Residencial — Teste", "nextDueDate": "2026-04-27", "alertDaysBefore": 1}]	2026-04-02 23:12:02.305	2026-04-02 12:33:29.046
cmnhgha7b0004edboe1zksx0k	alex@brspark.com	insurance_policies	[{"id": "ins_1774477825766_cwk5h", "type": "RESIDENTIAL", "status": "ACTIVE", "assetId": "brsp-190135", "endDate": "209383", "insurer": "Teste", "createdAt": "2026-03-25T22:30:25.766Z", "startDate": "2026-03-25", "brokerName": "", "deductible": 0, "ownerEmail": "alex@brspark.com", "brokerPhone": "", "documentUri": "file:///var/mobile/Containers/Data/Application/B49F90C2-F617-4081-910B-D71CE9F435F3/Library/Caches/ExponentExperienceData/@anonymous/BrsparkMobile-be63636c-8058-4d28-bef6-7ebf19f8191b/DocumentPicker/F0257E79-A544-48D8-AEC0-14D3CE2AB092.pages", "policyNumber": "123", "premiumValue": 0, "coverageAmount": 0, "alertDaysBefore": 10, "coverageDetails": ""}, {"id": "ins_1774477826163_pyzx0", "type": "RESIDENTIAL", "status": "ACTIVE", "assetId": "brsp-190135", "endDate": "209383", "insurer": "Teste", "createdAt": "2026-03-25T22:30:26.163Z", "startDate": "2026-03-25", "brokerName": "", "deductible": 0, "ownerEmail": "alex@brspark.com", "brokerPhone": "", "documentUri": "file:///var/mobile/Containers/Data/Application/B49F90C2-F617-4081-910B-D71CE9F435F3/Library/Caches/ExponentExperienceData/@anonymous/BrsparkMobile-be63636c-8058-4d28-bef6-7ebf19f8191b/DocumentPicker/F0257E79-A544-48D8-AEC0-14D3CE2AB092.pages", "policyNumber": "123", "premiumValue": 0, "coverageAmount": 0, "alertDaysBefore": 10, "coverageDetails": ""}, {"id": "ins_1774648334205_drxzi", "type": "RESIDENTIAL", "status": "ACTIVE", "assetId": "brsp-134786", "endDate": "2026-04-27", "insurer": "Teste", "createdAt": "2026-03-27T21:52:14.205Z", "startDate": "2026-03-27", "brokerName": "", "deductible": 0, "ownerEmail": "alex@brspark.com", "brokerPhone": "", "documentUri": "http://192.168.15.73:3001/uploads/storage/docs/alex_brspark_com/ins_1774648334205_drxzi.insurance_355", "policyNumber": "355", "premiumValue": 0, "coverageAmount": 0, "alertDaysBefore": 1, "coverageDetails": ""}, {"id": "ins_1774648335970_y32ey", "type": "RESIDENTIAL", "status": "ACTIVE", "assetId": "brsp-134786", "endDate": "2026-04-27", "insurer": "Teste", "createdAt": "2026-03-27T21:52:15.970Z", "startDate": "2026-03-27", "brokerName": "", "deductible": 0, "ownerEmail": "alex@brspark.com", "brokerPhone": "", "documentUri": "http://192.168.15.73:3001/uploads/storage/docs/alex_brspark_com/ins_1774648335970_y32ey.insurance_355", "policyNumber": "355", "premiumValue": 0, "coverageAmount": 0, "alertDaysBefore": 1, "coverageDetails": ""}, {"id": "ins_1774648337353_bjq8z", "type": "RESIDENTIAL", "status": "ACTIVE", "assetId": "brsp-134786", "endDate": "2026-04-27", "insurer": "Teste", "createdAt": "2026-03-27T21:52:17.353Z", "startDate": "2026-03-27", "brokerName": "", "deductible": 0, "ownerEmail": "alex@brspark.com", "brokerPhone": "", "documentUri": "http://192.168.15.73:3001/uploads/storage/docs/alex_brspark_com/ins_1774648337353_bjq8z.insurance_355", "policyNumber": "355", "premiumValue": 0, "coverageAmount": 0, "alertDaysBefore": 1, "coverageDetails": ""}, {"id": "ins_1774648337620_kuvjy", "type": "RESIDENTIAL", "status": "ACTIVE", "assetId": "brsp-134786", "endDate": "2026-04-27", "insurer": "Teste", "createdAt": "2026-03-27T21:52:17.620Z", "startDate": "2026-03-27", "brokerName": "", "deductible": 0, "ownerEmail": "alex@brspark.com", "brokerPhone": "", "documentUri": "http://192.168.15.73:3001/uploads/storage/docs/alex_brspark_com/ins_1774648337620_kuvjy.insurance_355", "policyNumber": "355", "premiumValue": 0, "coverageAmount": 0, "alertDaysBefore": 1, "coverageDetails": ""}, {"id": "ins_1774648337870_l14de", "type": "RESIDENTIAL", "status": "ACTIVE", "assetId": "brsp-134786", "endDate": "2026-04-27", "insurer": "Teste", "createdAt": "2026-03-27T21:52:17.870Z", "startDate": "2026-03-27", "brokerName": "", "deductible": 0, "ownerEmail": "alex@brspark.com", "brokerPhone": "", "documentUri": "http://192.168.15.73:3001/uploads/storage/docs/alex_brspark_com/ins_1774648337870_l14de.insurance_355", "policyNumber": "355", "premiumValue": 0, "coverageAmount": 0, "alertDaysBefore": 1, "coverageDetails": ""}]	2026-04-02 23:12:02.303	2026-04-02 12:33:29.047
\.


--
-- Data for Name: _prisma_migrations; Type: TABLE DATA; Schema: public; Owner: alex
--

COPY public._prisma_migrations (id, checksum, finished_at, migration_name, logs, rolled_back_at, started_at, applied_steps_count) FROM stdin;
bde75b4c-c3db-4c87-ad8f-4ddea978e83b	73224fe465c7de5be1d4f58cef71fe703fb824623c5ac8e5cb2f2f6321e13618	2026-04-02 09:29:07.113358-03	20260323143455_init	\N	\N	2026-04-02 09:29:06.610775-03	1
84bbcd60-be5b-45e6-900e-32306a1742e6	b00868e21b0ca2a3323cd88c3837296362a8462505fcd8fd176873fdd031d0e0	2026-04-02 09:29:07.13236-03	20260324001407_add_locale_profiles	\N	\N	2026-04-02 09:29:07.113955-03	1
f83613b8-779c-4e16-a62d-948470bdec9f	4aee8126753b087ae1d49fcb712baf2e1c6e24482a4c62352b79d536d572e4fe	2026-04-02 09:29:07.146501-03	20260324005528_add_translation_overrides	\N	\N	2026-04-02 09:29:07.133527-03	1
fa379f63-5407-4f05-a7dd-6d66af351e5b	9d60239b46e3f387ba472534b063e7b1ec3b3261abed0fc6518319807e150d9f	2026-04-02 09:29:07.148304-03	20260324173511_add_expense_revenue_metatag_types	\N	\N	2026-04-02 09:29:07.147179-03	1
e2963595-78f5-4441-9e46-2309eb8f2573	589531bd1df68a2b7555da033cb015bbcbd21f47a34108adc3062f3239503fdd	2026-04-02 09:29:07.154377-03	20260325225008_add_user_module_data	\N	\N	2026-04-02 09:29:07.148785-03	1
e5bde5ae-a5c2-4076-a92e-aa28036b3f05	69261f245187956b568acf26c08edaaa8f37d68a4f7837d767ad498780c8045e	2026-04-02 09:29:07.155548-03	20260325230353_add_media_category	\N	\N	2026-04-02 09:29:07.154849-03	1
40d54862-aae6-4c63-b3be-94f7b4bdaecf	78071a54b17cd3c1f7831a52989a8e4b26c043c6761ea11357637c77c6134b4e	2026-04-02 09:29:07.165256-03	20260326005347_init_asset_shares	\N	\N	2026-04-02 09:29:07.155935-03	1
753e0335-6db2-46bd-8091-20c9c2899850	dad8b317482d5cf9c3cae44bb195dd16d21ea33da651aa95bff6efc0876ae2f0	2026-04-02 09:29:08.614109-03	20260402122908_data_collection_foundation	\N	\N	2026-04-02 09:29:08.594042-03	1
\.


--
-- Name: Admin Admin_pkey; Type: CONSTRAINT; Schema: public; Owner: alex
--

ALTER TABLE ONLY public."Admin"
    ADD CONSTRAINT "Admin_pkey" PRIMARY KEY (id);


--
-- Name: AssetShare AssetShare_pkey; Type: CONSTRAINT; Schema: public; Owner: alex
--

ALTER TABLE ONLY public."AssetShare"
    ADD CONSTRAINT "AssetShare_pkey" PRIMARY KEY (id);


--
-- Name: Asset Asset_pkey; Type: CONSTRAINT; Schema: public; Owner: alex
--

ALTER TABLE ONLY public."Asset"
    ADD CONSTRAINT "Asset_pkey" PRIMARY KEY (id);


--
-- Name: AuditLog AuditLog_pkey; Type: CONSTRAINT; Schema: public; Owner: alex
--

ALTER TABLE ONLY public."AuditLog"
    ADD CONSTRAINT "AuditLog_pkey" PRIMARY KEY (id);


--
-- Name: ChatContact ChatContact_pkey; Type: CONSTRAINT; Schema: public; Owner: alex
--

ALTER TABLE ONLY public."ChatContact"
    ADD CONSTRAINT "ChatContact_pkey" PRIMARY KEY (id);


--
-- Name: ChatMessage ChatMessage_pkey; Type: CONSTRAINT; Schema: public; Owner: alex
--

ALTER TABLE ONLY public."ChatMessage"
    ADD CONSTRAINT "ChatMessage_pkey" PRIMARY KEY (id);


--
-- Name: ChatRoomMember ChatRoomMember_pkey; Type: CONSTRAINT; Schema: public; Owner: alex
--

ALTER TABLE ONLY public."ChatRoomMember"
    ADD CONSTRAINT "ChatRoomMember_pkey" PRIMARY KEY (id);


--
-- Name: ChatRoom ChatRoom_pkey; Type: CONSTRAINT; Schema: public; Owner: alex
--

ALTER TABLE ONLY public."ChatRoom"
    ADD CONSTRAINT "ChatRoom_pkey" PRIMARY KEY (id);


--
-- Name: ChecklistExecution ChecklistExecution_pkey; Type: CONSTRAINT; Schema: public; Owner: alex
--

ALTER TABLE ONLY public."ChecklistExecution"
    ADD CONSTRAINT "ChecklistExecution_pkey" PRIMARY KEY (id);


--
-- Name: ChecklistTemplate ChecklistTemplate_pkey; Type: CONSTRAINT; Schema: public; Owner: alex
--

ALTER TABLE ONLY public."ChecklistTemplate"
    ADD CONSTRAINT "ChecklistTemplate_pkey" PRIMARY KEY (id);


--
-- Name: CollectionPolicy CollectionPolicy_pkey; Type: CONSTRAINT; Schema: public; Owner: alex
--

ALTER TABLE ONLY public."CollectionPolicy"
    ADD CONSTRAINT "CollectionPolicy_pkey" PRIMARY KEY (id);


--
-- Name: ComplianceAcceptance ComplianceAcceptance_pkey; Type: CONSTRAINT; Schema: public; Owner: alex
--

ALTER TABLE ONLY public."ComplianceAcceptance"
    ADD CONSTRAINT "ComplianceAcceptance_pkey" PRIMARY KEY (id);


--
-- Name: ComplianceDoc ComplianceDoc_pkey; Type: CONSTRAINT; Schema: public; Owner: alex
--

ALTER TABLE ONLY public."ComplianceDoc"
    ADD CONSTRAINT "ComplianceDoc_pkey" PRIMARY KEY (id);


--
-- Name: ConsentRecord ConsentRecord_pkey; Type: CONSTRAINT; Schema: public; Owner: alex
--

ALTER TABLE ONLY public."ConsentRecord"
    ADD CONSTRAINT "ConsentRecord_pkey" PRIMARY KEY (id);


--
-- Name: ExecutionMetric ExecutionMetric_pkey; Type: CONSTRAINT; Schema: public; Owner: alex
--

ALTER TABLE ONLY public."ExecutionMetric"
    ADD CONSTRAINT "ExecutionMetric_pkey" PRIMARY KEY (id);


--
-- Name: FeatureFlag FeatureFlag_pkey; Type: CONSTRAINT; Schema: public; Owner: alex
--

ALTER TABLE ONLY public."FeatureFlag"
    ADD CONSTRAINT "FeatureFlag_pkey" PRIMARY KEY (id);


--
-- Name: Integration Integration_pkey; Type: CONSTRAINT; Schema: public; Owner: alex
--

ALTER TABLE ONLY public."Integration"
    ADD CONSTRAINT "Integration_pkey" PRIMARY KEY (id);


--
-- Name: Invoice Invoice_pkey; Type: CONSTRAINT; Schema: public; Owner: alex
--

ALTER TABLE ONLY public."Invoice"
    ADD CONSTRAINT "Invoice_pkey" PRIMARY KEY (id);


--
-- Name: LocaleProfile LocaleProfile_pkey; Type: CONSTRAINT; Schema: public; Owner: alex
--

ALTER TABLE ONLY public."LocaleProfile"
    ADD CONSTRAINT "LocaleProfile_pkey" PRIMARY KEY (id);


--
-- Name: Location Location_pkey; Type: CONSTRAINT; Schema: public; Owner: alex
--

ALTER TABLE ONLY public."Location"
    ADD CONSTRAINT "Location_pkey" PRIMARY KEY (id);


--
-- Name: Metatag Metatag_pkey; Type: CONSTRAINT; Schema: public; Owner: alex
--

ALTER TABLE ONLY public."Metatag"
    ADD CONSTRAINT "Metatag_pkey" PRIMARY KEY (id);


--
-- Name: NotificationLog NotificationLog_pkey; Type: CONSTRAINT; Schema: public; Owner: alex
--

ALTER TABLE ONLY public."NotificationLog"
    ADD CONSTRAINT "NotificationLog_pkey" PRIMARY KEY (id);


--
-- Name: NotificationTemplate NotificationTemplate_pkey; Type: CONSTRAINT; Schema: public; Owner: alex
--

ALTER TABLE ONLY public."NotificationTemplate"
    ADD CONSTRAINT "NotificationTemplate_pkey" PRIMARY KEY (id);


--
-- Name: Plan Plan_pkey; Type: CONSTRAINT; Schema: public; Owner: alex
--

ALTER TABLE ONLY public."Plan"
    ADD CONSTRAINT "Plan_pkey" PRIMARY KEY (id);


--
-- Name: PushToken PushToken_pkey; Type: CONSTRAINT; Schema: public; Owner: alex
--

ALTER TABLE ONLY public."PushToken"
    ADD CONSTRAINT "PushToken_pkey" PRIMARY KEY (id);


--
-- Name: ServiceProvider ServiceProvider_pkey; Type: CONSTRAINT; Schema: public; Owner: alex
--

ALTER TABLE ONLY public."ServiceProvider"
    ADD CONSTRAINT "ServiceProvider_pkey" PRIMARY KEY (id);


--
-- Name: StockItem StockItem_pkey; Type: CONSTRAINT; Schema: public; Owner: alex
--

ALTER TABLE ONLY public."StockItem"
    ADD CONSTRAINT "StockItem_pkey" PRIMARY KEY (id);


--
-- Name: StockMovement StockMovement_pkey; Type: CONSTRAINT; Schema: public; Owner: alex
--

ALTER TABLE ONLY public."StockMovement"
    ADD CONSTRAINT "StockMovement_pkey" PRIMARY KEY (id);


--
-- Name: Subscription Subscription_pkey; Type: CONSTRAINT; Schema: public; Owner: alex
--

ALTER TABLE ONLY public."Subscription"
    ADD CONSTRAINT "Subscription_pkey" PRIMARY KEY (id);


--
-- Name: TechnicianProfile TechnicianProfile_pkey; Type: CONSTRAINT; Schema: public; Owner: alex
--

ALTER TABLE ONLY public."TechnicianProfile"
    ADD CONSTRAINT "TechnicianProfile_pkey" PRIMARY KEY (id);


--
-- Name: TelemetryEvent TelemetryEvent_pkey; Type: CONSTRAINT; Schema: public; Owner: alex
--

ALTER TABLE ONLY public."TelemetryEvent"
    ADD CONSTRAINT "TelemetryEvent_pkey" PRIMARY KEY (id);


--
-- Name: Tenant Tenant_pkey; Type: CONSTRAINT; Schema: public; Owner: alex
--

ALTER TABLE ONLY public."Tenant"
    ADD CONSTRAINT "Tenant_pkey" PRIMARY KEY (id);


--
-- Name: TranslationOverride TranslationOverride_pkey; Type: CONSTRAINT; Schema: public; Owner: alex
--

ALTER TABLE ONLY public."TranslationOverride"
    ADD CONSTRAINT "TranslationOverride_pkey" PRIMARY KEY (id);


--
-- Name: UserModuleData UserModuleData_pkey; Type: CONSTRAINT; Schema: public; Owner: alex
--

ALTER TABLE ONLY public."UserModuleData"
    ADD CONSTRAINT "UserModuleData_pkey" PRIMARY KEY (id);


--
-- Name: User User_pkey; Type: CONSTRAINT; Schema: public; Owner: alex
--

ALTER TABLE ONLY public."User"
    ADD CONSTRAINT "User_pkey" PRIMARY KEY (id);


--
-- Name: _prisma_migrations _prisma_migrations_pkey; Type: CONSTRAINT; Schema: public; Owner: alex
--

ALTER TABLE ONLY public._prisma_migrations
    ADD CONSTRAINT _prisma_migrations_pkey PRIMARY KEY (id);


--
-- Name: Admin_email_key; Type: INDEX; Schema: public; Owner: alex
--

CREATE UNIQUE INDEX "Admin_email_key" ON public."Admin" USING btree (email);


--
-- Name: AssetShare_assetId_sharedWithEmail_key; Type: INDEX; Schema: public; Owner: alex
--

CREATE UNIQUE INDEX "AssetShare_assetId_sharedWithEmail_key" ON public."AssetShare" USING btree ("assetId", "sharedWithEmail");


--
-- Name: ChatContact_requesterId_addresseeId_key; Type: INDEX; Schema: public; Owner: alex
--

CREATE UNIQUE INDEX "ChatContact_requesterId_addresseeId_key" ON public."ChatContact" USING btree ("requesterId", "addresseeId");


--
-- Name: ChatRoomMember_roomId_userId_key; Type: INDEX; Schema: public; Owner: alex
--

CREATE UNIQUE INDEX "ChatRoomMember_roomId_userId_key" ON public."ChatRoomMember" USING btree ("roomId", "userId");


--
-- Name: ChecklistExecution_ownerEmail_idx; Type: INDEX; Schema: public; Owner: alex
--

CREATE INDEX "ChecklistExecution_ownerEmail_idx" ON public."ChecklistExecution" USING btree ("ownerEmail");


--
-- Name: ChecklistExecution_ownerEmail_status_idx; Type: INDEX; Schema: public; Owner: alex
--

CREATE INDEX "ChecklistExecution_ownerEmail_status_idx" ON public."ChecklistExecution" USING btree ("ownerEmail", status);


--
-- Name: ChecklistExecution_status_idx; Type: INDEX; Schema: public; Owner: alex
--

CREATE INDEX "ChecklistExecution_status_idx" ON public."ChecklistExecution" USING btree (status);


--
-- Name: CollectionPolicy_tenantId_idx; Type: INDEX; Schema: public; Owner: alex
--

CREATE INDEX "CollectionPolicy_tenantId_idx" ON public."CollectionPolicy" USING btree ("tenantId");


--
-- Name: CollectionPolicy_tenantId_sectorCode_key; Type: INDEX; Schema: public; Owner: alex
--

CREATE UNIQUE INDEX "CollectionPolicy_tenantId_sectorCode_key" ON public."CollectionPolicy" USING btree ("tenantId", "sectorCode");


--
-- Name: ConsentRecord_ownerEmail_idx; Type: INDEX; Schema: public; Owner: alex
--

CREATE INDEX "ConsentRecord_ownerEmail_idx" ON public."ConsentRecord" USING btree ("ownerEmail");


--
-- Name: ConsentRecord_ownerEmail_policyId_consentType_key; Type: INDEX; Schema: public; Owner: alex
--

CREATE UNIQUE INDEX "ConsentRecord_ownerEmail_policyId_consentType_key" ON public."ConsentRecord" USING btree ("ownerEmail", "policyId", "consentType");


--
-- Name: ConsentRecord_tenantId_idx; Type: INDEX; Schema: public; Owner: alex
--

CREATE INDEX "ConsentRecord_tenantId_idx" ON public."ConsentRecord" USING btree ("tenantId");


--
-- Name: ExecutionMetric_executionId_idx; Type: INDEX; Schema: public; Owner: alex
--

CREATE INDEX "ExecutionMetric_executionId_idx" ON public."ExecutionMetric" USING btree ("executionId");


--
-- Name: ExecutionMetric_executionId_key; Type: INDEX; Schema: public; Owner: alex
--

CREATE UNIQUE INDEX "ExecutionMetric_executionId_key" ON public."ExecutionMetric" USING btree ("executionId");


--
-- Name: ExecutionMetric_tenantId_ownerEmail_idx; Type: INDEX; Schema: public; Owner: alex
--

CREATE INDEX "ExecutionMetric_tenantId_ownerEmail_idx" ON public."ExecutionMetric" USING btree ("tenantId", "ownerEmail");


--
-- Name: FeatureFlag_key_tenantId_key; Type: INDEX; Schema: public; Owner: alex
--

CREATE UNIQUE INDEX "FeatureFlag_key_tenantId_key" ON public."FeatureFlag" USING btree (key, "tenantId");


--
-- Name: LocaleProfile_countryCode_key; Type: INDEX; Schema: public; Owner: alex
--

CREATE UNIQUE INDEX "LocaleProfile_countryCode_key" ON public."LocaleProfile" USING btree ("countryCode");


--
-- Name: Metatag_key_key; Type: INDEX; Schema: public; Owner: alex
--

CREATE UNIQUE INDEX "Metatag_key_key" ON public."Metatag" USING btree (key);


--
-- Name: NotificationTemplate_key_key; Type: INDEX; Schema: public; Owner: alex
--

CREATE UNIQUE INDEX "NotificationTemplate_key_key" ON public."NotificationTemplate" USING btree (key);


--
-- Name: Plan_name_key; Type: INDEX; Schema: public; Owner: alex
--

CREATE UNIQUE INDEX "Plan_name_key" ON public."Plan" USING btree (name);


--
-- Name: PushToken_token_key; Type: INDEX; Schema: public; Owner: alex
--

CREATE UNIQUE INDEX "PushToken_token_key" ON public."PushToken" USING btree (token);


--
-- Name: StockItem_assetId_sku_key; Type: INDEX; Schema: public; Owner: alex
--

CREATE UNIQUE INDEX "StockItem_assetId_sku_key" ON public."StockItem" USING btree ("assetId", sku);


--
-- Name: Subscription_tenantId_key; Type: INDEX; Schema: public; Owner: alex
--

CREATE UNIQUE INDEX "Subscription_tenantId_key" ON public."Subscription" USING btree ("tenantId");


--
-- Name: TechnicianProfile_userId_key; Type: INDEX; Schema: public; Owner: alex
--

CREATE UNIQUE INDEX "TechnicianProfile_userId_key" ON public."TechnicianProfile" USING btree ("userId");


--
-- Name: TelemetryEvent_executionId_idx; Type: INDEX; Schema: public; Owner: alex
--

CREATE INDEX "TelemetryEvent_executionId_idx" ON public."TelemetryEvent" USING btree ("executionId");


--
-- Name: TelemetryEvent_expiresAt_idx; Type: INDEX; Schema: public; Owner: alex
--

CREATE INDEX "TelemetryEvent_expiresAt_idx" ON public."TelemetryEvent" USING btree ("expiresAt");


--
-- Name: TelemetryEvent_ownerEmail_serverTimestamp_idx; Type: INDEX; Schema: public; Owner: alex
--

CREATE INDEX "TelemetryEvent_ownerEmail_serverTimestamp_idx" ON public."TelemetryEvent" USING btree ("ownerEmail", "serverTimestamp");


--
-- Name: TelemetryEvent_tenantId_eventType_serverTimestamp_idx; Type: INDEX; Schema: public; Owner: alex
--

CREATE INDEX "TelemetryEvent_tenantId_eventType_serverTimestamp_idx" ON public."TelemetryEvent" USING btree ("tenantId", "eventType", "serverTimestamp");


--
-- Name: Tenant_email_key; Type: INDEX; Schema: public; Owner: alex
--

CREATE UNIQUE INDEX "Tenant_email_key" ON public."Tenant" USING btree (email);


--
-- Name: Tenant_slug_key; Type: INDEX; Schema: public; Owner: alex
--

CREATE UNIQUE INDEX "Tenant_slug_key" ON public."Tenant" USING btree (slug);


--
-- Name: TranslationOverride_tenantId_key_language_key; Type: INDEX; Schema: public; Owner: alex
--

CREATE UNIQUE INDEX "TranslationOverride_tenantId_key_language_key" ON public."TranslationOverride" USING btree ("tenantId", key, language);


--
-- Name: UserModuleData_ownerEmail_idx; Type: INDEX; Schema: public; Owner: alex
--

CREATE INDEX "UserModuleData_ownerEmail_idx" ON public."UserModuleData" USING btree ("ownerEmail");


--
-- Name: UserModuleData_ownerEmail_module_key; Type: INDEX; Schema: public; Owner: alex
--

CREATE UNIQUE INDEX "UserModuleData_ownerEmail_module_key" ON public."UserModuleData" USING btree ("ownerEmail", module);


--
-- Name: User_email_tenantId_key; Type: INDEX; Schema: public; Owner: alex
--

CREATE UNIQUE INDEX "User_email_tenantId_key" ON public."User" USING btree (email, "tenantId");


--
-- Name: Asset Asset_locationId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: alex
--

ALTER TABLE ONLY public."Asset"
    ADD CONSTRAINT "Asset_locationId_fkey" FOREIGN KEY ("locationId") REFERENCES public."Location"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: Asset Asset_parentId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: alex
--

ALTER TABLE ONLY public."Asset"
    ADD CONSTRAINT "Asset_parentId_fkey" FOREIGN KEY ("parentId") REFERENCES public."Asset"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: Asset Asset_tenantId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: alex
--

ALTER TABLE ONLY public."Asset"
    ADD CONSTRAINT "Asset_tenantId_fkey" FOREIGN KEY ("tenantId") REFERENCES public."Tenant"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: AuditLog AuditLog_adminId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: alex
--

ALTER TABLE ONLY public."AuditLog"
    ADD CONSTRAINT "AuditLog_adminId_fkey" FOREIGN KEY ("adminId") REFERENCES public."Admin"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: AuditLog AuditLog_tenantId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: alex
--

ALTER TABLE ONLY public."AuditLog"
    ADD CONSTRAINT "AuditLog_tenantId_fkey" FOREIGN KEY ("tenantId") REFERENCES public."Tenant"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: AuditLog AuditLog_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: alex
--

ALTER TABLE ONLY public."AuditLog"
    ADD CONSTRAINT "AuditLog_userId_fkey" FOREIGN KEY ("userId") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: ChatMessage ChatMessage_roomId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: alex
--

ALTER TABLE ONLY public."ChatMessage"
    ADD CONSTRAINT "ChatMessage_roomId_fkey" FOREIGN KEY ("roomId") REFERENCES public."ChatRoom"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: ChatRoomMember ChatRoomMember_roomId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: alex
--

ALTER TABLE ONLY public."ChatRoomMember"
    ADD CONSTRAINT "ChatRoomMember_roomId_fkey" FOREIGN KEY ("roomId") REFERENCES public."ChatRoom"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: ChecklistExecution ChecklistExecution_templateId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: alex
--

ALTER TABLE ONLY public."ChecklistExecution"
    ADD CONSTRAINT "ChecklistExecution_templateId_fkey" FOREIGN KEY ("templateId") REFERENCES public."ChecklistTemplate"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: CollectionPolicy CollectionPolicy_tenantId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: alex
--

ALTER TABLE ONLY public."CollectionPolicy"
    ADD CONSTRAINT "CollectionPolicy_tenantId_fkey" FOREIGN KEY ("tenantId") REFERENCES public."Tenant"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: ComplianceAcceptance ComplianceAcceptance_docId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: alex
--

ALTER TABLE ONLY public."ComplianceAcceptance"
    ADD CONSTRAINT "ComplianceAcceptance_docId_fkey" FOREIGN KEY ("docId") REFERENCES public."ComplianceDoc"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: ComplianceDoc ComplianceDoc_tenantId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: alex
--

ALTER TABLE ONLY public."ComplianceDoc"
    ADD CONSTRAINT "ComplianceDoc_tenantId_fkey" FOREIGN KEY ("tenantId") REFERENCES public."Tenant"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: ConsentRecord ConsentRecord_docId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: alex
--

ALTER TABLE ONLY public."ConsentRecord"
    ADD CONSTRAINT "ConsentRecord_docId_fkey" FOREIGN KEY ("docId") REFERENCES public."ComplianceDoc"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: ConsentRecord ConsentRecord_policyId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: alex
--

ALTER TABLE ONLY public."ConsentRecord"
    ADD CONSTRAINT "ConsentRecord_policyId_fkey" FOREIGN KEY ("policyId") REFERENCES public."CollectionPolicy"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: FeatureFlag FeatureFlag_tenantId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: alex
--

ALTER TABLE ONLY public."FeatureFlag"
    ADD CONSTRAINT "FeatureFlag_tenantId_fkey" FOREIGN KEY ("tenantId") REFERENCES public."Tenant"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: Invoice Invoice_subscriptionId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: alex
--

ALTER TABLE ONLY public."Invoice"
    ADD CONSTRAINT "Invoice_subscriptionId_fkey" FOREIGN KEY ("subscriptionId") REFERENCES public."Subscription"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: Location Location_parentId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: alex
--

ALTER TABLE ONLY public."Location"
    ADD CONSTRAINT "Location_parentId_fkey" FOREIGN KEY ("parentId") REFERENCES public."Location"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: Location Location_tenantId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: alex
--

ALTER TABLE ONLY public."Location"
    ADD CONSTRAINT "Location_tenantId_fkey" FOREIGN KEY ("tenantId") REFERENCES public."Tenant"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: NotificationLog NotificationLog_templateId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: alex
--

ALTER TABLE ONLY public."NotificationLog"
    ADD CONSTRAINT "NotificationLog_templateId_fkey" FOREIGN KEY ("templateId") REFERENCES public."NotificationTemplate"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: PushToken PushToken_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: alex
--

ALTER TABLE ONLY public."PushToken"
    ADD CONSTRAINT "PushToken_userId_fkey" FOREIGN KEY ("userId") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: StockItem StockItem_assetId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: alex
--

ALTER TABLE ONLY public."StockItem"
    ADD CONSTRAINT "StockItem_assetId_fkey" FOREIGN KEY ("assetId") REFERENCES public."Asset"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: StockMovement StockMovement_itemId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: alex
--

ALTER TABLE ONLY public."StockMovement"
    ADD CONSTRAINT "StockMovement_itemId_fkey" FOREIGN KEY ("itemId") REFERENCES public."StockItem"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: Subscription Subscription_planId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: alex
--

ALTER TABLE ONLY public."Subscription"
    ADD CONSTRAINT "Subscription_planId_fkey" FOREIGN KEY ("planId") REFERENCES public."Plan"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: Subscription Subscription_tenantId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: alex
--

ALTER TABLE ONLY public."Subscription"
    ADD CONSTRAINT "Subscription_tenantId_fkey" FOREIGN KEY ("tenantId") REFERENCES public."Tenant"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: TechnicianProfile TechnicianProfile_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: alex
--

ALTER TABLE ONLY public."TechnicianProfile"
    ADD CONSTRAINT "TechnicianProfile_userId_fkey" FOREIGN KEY ("userId") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: Tenant Tenant_localeId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: alex
--

ALTER TABLE ONLY public."Tenant"
    ADD CONSTRAINT "Tenant_localeId_fkey" FOREIGN KEY ("localeId") REFERENCES public."LocaleProfile"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: TranslationOverride TranslationOverride_tenantId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: alex
--

ALTER TABLE ONLY public."TranslationOverride"
    ADD CONSTRAINT "TranslationOverride_tenantId_fkey" FOREIGN KEY ("tenantId") REFERENCES public."Tenant"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: User User_tenantId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: alex
--

ALTER TABLE ONLY public."User"
    ADD CONSTRAINT "User_tenantId_fkey" FOREIGN KEY ("tenantId") REFERENCES public."Tenant"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- PostgreSQL database dump complete
--

\unrestrict 2xt2YKOt8SNvgKsWdighBeBqcthyuESGpcMOKKfshXegsXwNRmFwzBAD1M4Tagd

