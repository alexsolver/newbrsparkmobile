--
-- PostgreSQL database dump
--

\restrict opCaI35CyroqLAd0Kv6DeazeDa6HzygdvGYYMVNg0JhW1SP6RNGBHfdnFoj56HH

-- Dumped from database version 14.20 (Homebrew)
-- Dumped by pg_dump version 14.20 (Homebrew)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: AssetType; Type: TYPE; Schema: public; Owner: alex
--

CREATE TYPE public."AssetType" AS ENUM (
    'REAL_ESTATE',
    'TERRESTRIAL',
    'AQUATIC',
    'SPECIAL',
    'OTHER'
);


ALTER TYPE public."AssetType" OWNER TO alex;

--
-- Name: AuditCategory; Type: TYPE; Schema: public; Owner: alex
--

CREATE TYPE public."AuditCategory" AS ENUM (
    'AUTH',
    'DATA',
    'ADMIN',
    'SYSTEM'
);


ALTER TYPE public."AuditCategory" OWNER TO alex;

--
-- Name: BillingCycle; Type: TYPE; Schema: public; Owner: alex
--

CREATE TYPE public."BillingCycle" AS ENUM (
    'MONTHLY',
    'YEARLY'
);


ALTER TYPE public."BillingCycle" OWNER TO alex;

--
-- Name: Channel; Type: TYPE; Schema: public; Owner: alex
--

CREATE TYPE public."Channel" AS ENUM (
    'EMAIL',
    'PUSH',
    'WHATSAPP',
    'SMS'
);


ALTER TYPE public."Channel" OWNER TO alex;

--
-- Name: DocType; Type: TYPE; Schema: public; Owner: alex
--

CREATE TYPE public."DocType" AS ENUM (
    'TERMS_OF_USE',
    'PRIVACY_POLICY',
    'LGPD_DPA',
    'COOKIE_POLICY'
);


ALTER TYPE public."DocType" OWNER TO alex;

--
-- Name: IntType; Type: TYPE; Schema: public; Owner: alex
--

CREATE TYPE public."IntType" AS ENUM (
    'AI_LLM',
    'EMAIL',
    'PUSH',
    'STORAGE',
    'WEBHOOK',
    'ERP',
    'PAYMENT',
    'MAPS'
);


ALTER TYPE public."IntType" OWNER TO alex;

--
-- Name: InvoiceStatus; Type: TYPE; Schema: public; Owner: alex
--

CREATE TYPE public."InvoiceStatus" AS ENUM (
    'PENDING',
    'PAID',
    'OVERDUE',
    'VOID'
);


ALTER TYPE public."InvoiceStatus" OWNER TO alex;

--
-- Name: LocationType; Type: TYPE; Schema: public; Owner: alex
--

CREATE TYPE public."LocationType" AS ENUM (
    'BUILDING',
    'FLOOR',
    'ROOM',
    'AREA',
    'WAREHOUSE',
    'OTHER'
);


ALTER TYPE public."LocationType" OWNER TO alex;

--
-- Name: MetatagType; Type: TYPE; Schema: public; Owner: alex
--

CREATE TYPE public."MetatagType" AS ENUM (
    'ASSET_TYPE',
    'STOCK_CATEGORY',
    'SERVICE_CATEGORY',
    'ASSET_STATUS',
    'GLOBAL_TAG',
    'EXPENSE_CATEGORY',
    'REVENUE_CATEGORY',
    'MEDIA_CATEGORY'
);


ALTER TYPE public."MetatagType" OWNER TO alex;

--
-- Name: MovementType; Type: TYPE; Schema: public; Owner: alex
--

CREATE TYPE public."MovementType" AS ENUM (
    'IN',
    'OUT',
    'TRANSFER'
);


ALTER TYPE public."MovementType" OWNER TO alex;

--
-- Name: NotifStatus; Type: TYPE; Schema: public; Owner: alex
--

CREATE TYPE public."NotifStatus" AS ENUM (
    'SENT',
    'DELIVERED',
    'FAILED',
    'BOUNCED'
);


ALTER TYPE public."NotifStatus" OWNER TO alex;

--
-- Name: SubStatus; Type: TYPE; Schema: public; Owner: alex
--

CREATE TYPE public."SubStatus" AS ENUM (
    'ACTIVE',
    'PAST_DUE',
    'CANCELLED',
    'TRIALING'
);


ALTER TYPE public."SubStatus" OWNER TO alex;

--
-- Name: TelemetryEventType; Type: TYPE; Schema: public; Owner: alex
--

CREATE TYPE public."TelemetryEventType" AS ENUM (
    'SESSION_OPEN',
    'SESSION_CLOSE',
    'OS_ACCEPT',
    'OS_START',
    'CHECKIN',
    'CHECKOUT',
    'TRANSIT_START',
    'TRANSIT_END',
    'HEARTBEAT',
    'GEOFENCE_ENTER',
    'GEOFENCE_EXIT',
    'PAUSE',
    'RESUME',
    'FRAUD_FLAG',
    'INTEGRITY_CHECK',
    'POLICY_VIOLATION'
);


ALTER TYPE public."TelemetryEventType" OWNER TO alex;

--
-- Name: TenantStatus; Type: TYPE; Schema: public; Owner: alex
--

CREATE TYPE public."TenantStatus" AS ENUM (
    'TRIAL',
    'ACTIVE',
    'SUSPENDED',
    'CANCELLED'
);


ALTER TYPE public."TenantStatus" OWNER TO alex;

--
-- Name: UserRole; Type: TYPE; Schema: public; Owner: alex
--

CREATE TYPE public."UserRole" AS ENUM (
    'ADMIN',
    'MANAGER',
    'USER'
);


ALTER TYPE public."UserRole" OWNER TO alex;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: Admin; Type: TABLE; Schema: public; Owner: alex
--

CREATE TABLE public."Admin" (
    id text NOT NULL,
    email text NOT NULL,
    name text NOT NULL,
    password text NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public."Admin" OWNER TO alex;

--
-- Name: Asset; Type: TABLE; Schema: public; Owner: alex
--

CREATE TABLE public."Asset" (
    id text NOT NULL,
    "tenantId" text NOT NULL,
    "parentId" text,
    title text NOT NULL,
    type public."AssetType" NOT NULL,
    status text DEFAULT 'Operacional'::text NOT NULL,
    description text,
    "imageUrl" text,
    "locationId" text,
    metadata jsonb,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL,
    "deletedAt" timestamp(3) without time zone
);


ALTER TABLE public."Asset" OWNER TO alex;

--
-- Name: AssetShare; Type: TABLE; Schema: public; Owner: alex
--

CREATE TABLE public."AssetShare" (
    id text NOT NULL,
    "assetId" text NOT NULL,
    "ownerEmail" text NOT NULL,
    "sharedWithEmail" text NOT NULL,
    permission text NOT NULL,
    modules jsonb NOT NULL,
    status text DEFAULT 'PENDING'::text NOT NULL,
    "invitedAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "expiresAt" timestamp(3) without time zone
);


ALTER TABLE public."AssetShare" OWNER TO alex;

--
-- Name: AuditLog; Type: TABLE; Schema: public; Owner: alex
--

CREATE TABLE public."AuditLog" (
    id text NOT NULL,
    "tenantId" text,
    "userId" text,
    "adminId" text,
    action text NOT NULL,
    resource text NOT NULL,
    category public."AuditCategory" NOT NULL,
    metadata jsonb,
    "ipAddress" text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public."AuditLog" OWNER TO alex;

--
-- Name: ChatContact; Type: TABLE; Schema: public; Owner: alex
--

CREATE TABLE public."ChatContact" (
    id text NOT NULL,
    "requesterId" text NOT NULL,
    "addresseeId" text NOT NULL,
    status text DEFAULT 'PENDING'::text NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public."ChatContact" OWNER TO alex;

--
-- Name: ChatMessage; Type: TABLE; Schema: public; Owner: alex
--

CREATE TABLE public."ChatMessage" (
    id text NOT NULL,
    "roomId" text NOT NULL,
    "senderId" text NOT NULL,
    "senderName" text NOT NULL,
    type text DEFAULT 'text'::text NOT NULL,
    content text,
    "mediaUrl" text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public."ChatMessage" OWNER TO alex;

--
-- Name: ChatRoom; Type: TABLE; Schema: public; Owner: alex
--

CREATE TABLE public."ChatRoom" (
    id text NOT NULL,
    name text,
    description text,
    "avatarColor" text DEFAULT '#2563EB'::text,
    "isGroup" boolean DEFAULT false NOT NULL,
    "creatorId" text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public."ChatRoom" OWNER TO alex;

--
-- Name: ChatRoomMember; Type: TABLE; Schema: public; Owner: alex
--

CREATE TABLE public."ChatRoomMember" (
    id text NOT NULL,
    "roomId" text NOT NULL,
    "userId" text NOT NULL,
    role text DEFAULT 'MEMBER'::text NOT NULL,
    "joinedAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "lastReadAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public."ChatRoomMember" OWNER TO alex;

--
-- Name: ChecklistExecution; Type: TABLE; Schema: public; Owner: alex
--

CREATE TABLE public."ChecklistExecution" (
    id text NOT NULL,
    "templateId" text,
    "ownerEmail" text NOT NULL,
    "assetId" text,
    status text DEFAULT 'PENDING'::text NOT NULL,
    responses jsonb,
    metadata jsonb,
    "locationAddress" text,
    "locationLat" double precision,
    "locationLng" double precision,
    "locationRadius" integer,
    "locationZoneType" text,
    "locationPolygon" jsonb,
    "gpsLocation" jsonb,
    "startedAt" timestamp(3) without time zone,
    "completedAt" timestamp(3) without time zone,
    "syncedAt" timestamp(3) without time zone,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "etaMinutes" integer
);


ALTER TABLE public."ChecklistExecution" OWNER TO alex;

--
-- Name: ChecklistTemplate; Type: TABLE; Schema: public; Owner: alex
--

CREATE TABLE public."ChecklistTemplate" (
    id text NOT NULL,
    "tenantId" text,
    title text NOT NULL,
    description text,
    settings jsonb NOT NULL,
    "schemaData" jsonb NOT NULL,
    metadata jsonb,
    version integer DEFAULT 1 NOT NULL,
    "isActive" boolean DEFAULT true NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public."ChecklistTemplate" OWNER TO alex;

--
-- Name: CollectionPolicy; Type: TABLE; Schema: public; Owner: alex
--

CREATE TABLE public."CollectionPolicy" (
    id text NOT NULL,
    "tenantId" text,
    "sectorCode" text,
    label text DEFAULT 'Padrão'::text NOT NULL,
    "locationEnabled" boolean DEFAULT true NOT NULL,
    "locationBackgroundEnabled" boolean DEFAULT true NOT NULL,
    "locationIntervalIdleMin" integer DEFAULT 30 NOT NULL,
    "locationIntervalTransitMin" integer DEFAULT 2 NOT NULL,
    "locationIntervalOnSiteMin" integer DEFAULT 5 NOT NULL,
    "locationDistanceFilterMeters" integer DEFAULT 200 NOT NULL,
    "retentionGpsRawDays" integer DEFAULT 15 NOT NULL,
    "retentionEventsYears" integer DEFAULT 5 NOT NULL,
    "retentionAuditDays" integer DEFAULT 180 NOT NULL,
    "retentionMetricsDays" integer DEFAULT 730 NOT NULL,
    "mockGpsAction" text DEFAULT 'WARN'::text NOT NULL,
    "rootJailbreakAction" text DEFAULT 'WARN'::text NOT NULL,
    "clockDriftMaxSeconds" integer DEFAULT 300 NOT NULL,
    "requireExplicitConsent" boolean DEFAULT true NOT NULL,
    "consentGranular" boolean DEFAULT true NOT NULL,
    "legalBasis" text DEFAULT 'LGPD'::text NOT NULL,
    "requireCheckinPhoto" boolean DEFAULT false NOT NULL,
    "allowOfflineCheckin" boolean DEFAULT true NOT NULL,
    "minOnSiteMinutes" integer DEFAULT 0 NOT NULL,
    "outOfPolicyAction" text DEFAULT 'PROCEED_FLAG'::text NOT NULL,
    "isActive" boolean DEFAULT true NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public."CollectionPolicy" OWNER TO alex;

--
-- Name: ComplianceAcceptance; Type: TABLE; Schema: public; Owner: alex
--

CREATE TABLE public."ComplianceAcceptance" (
    id text NOT NULL,
    "docId" text NOT NULL,
    "userId" text,
    "tenantId" text,
    "ipAddress" text,
    "acceptedAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public."ComplianceAcceptance" OWNER TO alex;

--
-- Name: ComplianceDoc; Type: TABLE; Schema: public; Owner: alex
--

CREATE TABLE public."ComplianceDoc" (
    id text NOT NULL,
    type public."DocType" NOT NULL,
    version text NOT NULL,
    title text NOT NULL,
    content text NOT NULL,
    "isActive" boolean DEFAULT false NOT NULL,
    "publishedAt" timestamp(3) without time zone,
    "createdBy" text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL,
    "sectorCode" text,
    "tenantId" text
);


ALTER TABLE public."ComplianceDoc" OWNER TO alex;

--
-- Name: ConsentRecord; Type: TABLE; Schema: public; Owner: alex
--

CREATE TABLE public."ConsentRecord" (
    id text NOT NULL,
    "tenantId" text,
    "ownerEmail" text NOT NULL,
    "policyId" text,
    "docId" text,
    "consentType" text NOT NULL,
    accepted boolean NOT NULL,
    "ipAddress" text,
    "deviceId" text,
    "appVersion" text,
    "acceptedAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "revokedAt" timestamp(3) without time zone
);


ALTER TABLE public."ConsentRecord" OWNER TO alex;

--
-- Name: ExecutionMetric; Type: TABLE; Schema: public; Owner: alex
--

CREATE TABLE public."ExecutionMetric" (
    id text NOT NULL,
    "tenantId" text,
    "executionId" text NOT NULL,
    "ownerEmail" text NOT NULL,
    "transitDurationMin" integer,
    "siteArrivalDelayMin" integer,
    "onSiteDurationMin" integer,
    "idleTimeMin" integer,
    "distanceKm" double precision,
    "geofenceBreaches" integer DEFAULT 0 NOT NULL,
    "routeDeviationMaxMeters" integer,
    "scoreExecution" integer,
    "scoreReliability" integer,
    "scoreRisk" integer,
    "fraudFlags" jsonb,
    "calculatedAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    source text DEFAULT 'BATCH'::text NOT NULL,
    "etaMinutes" integer
);


ALTER TABLE public."ExecutionMetric" OWNER TO alex;

--
-- Name: FeatureFlag; Type: TABLE; Schema: public; Owner: alex
--

CREATE TABLE public."FeatureFlag" (
    id text NOT NULL,
    key text NOT NULL,
    label text NOT NULL,
    description text NOT NULL,
    icon text,
    enabled boolean DEFAULT true NOT NULL,
    "tenantId" text,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public."FeatureFlag" OWNER TO alex;

--
-- Name: Integration; Type: TABLE; Schema: public; Owner: alex
--

CREATE TABLE public."Integration" (
    id text NOT NULL,
    name text NOT NULL,
    type public."IntType" NOT NULL,
    icon text,
    "apiKey" text,
    "baseUrl" text,
    "webhookUrl" text,
    "lastTestedAt" timestamp(3) without time zone,
    metadata jsonb,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL,
    description text,
    status text DEFAULT 'ACTIVE'::text NOT NULL
);


ALTER TABLE public."Integration" OWNER TO alex;

--
-- Name: Invoice; Type: TABLE; Schema: public; Owner: alex
--

CREATE TABLE public."Invoice" (
    id text NOT NULL,
    "subscriptionId" text NOT NULL,
    amount numeric(10,2) NOT NULL,
    status public."InvoiceStatus" DEFAULT 'PENDING'::public."InvoiceStatus" NOT NULL,
    "dueDate" timestamp(3) without time zone NOT NULL,
    "paidAt" timestamp(3) without time zone,
    "externalId" text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public."Invoice" OWNER TO alex;

--
-- Name: LocaleProfile; Type: TABLE; Schema: public; Owner: alex
--

CREATE TABLE public."LocaleProfile" (
    id text NOT NULL,
    "countryCode" text NOT NULL,
    name text NOT NULL,
    language text DEFAULT 'pt-BR'::text NOT NULL,
    currency text DEFAULT 'BRL'::text NOT NULL,
    "currencySymbol" text DEFAULT 'R$'::text NOT NULL,
    "dateFormat" text DEFAULT 'DD/MM/YYYY'::text NOT NULL,
    "numberFormat" text DEFAULT 'PT_STYLE'::text NOT NULL,
    timezone text DEFAULT 'UTC'::text NOT NULL,
    "taxIdLabel" text DEFAULT 'Tax ID'::text NOT NULL,
    "postalCodeLabel" text DEFAULT 'Postal Code'::text NOT NULL,
    "measureSystem" text DEFAULT 'METRIC'::text NOT NULL,
    "isActive" boolean DEFAULT true NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public."LocaleProfile" OWNER TO alex;

--
-- Name: Location; Type: TABLE; Schema: public; Owner: alex
--

CREATE TABLE public."Location" (
    id text NOT NULL,
    "tenantId" text NOT NULL,
    name text NOT NULL,
    type public."LocationType" DEFAULT 'BUILDING'::public."LocationType" NOT NULL,
    address text,
    floor text,
    room text,
    icon text,
    latitude double precision,
    longitude double precision,
    "parentId" text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public."Location" OWNER TO alex;

--
-- Name: Metatag; Type: TABLE; Schema: public; Owner: alex
--

CREATE TABLE public."Metatag" (
    id text NOT NULL,
    type public."MetatagType" NOT NULL,
    key text NOT NULL,
    "ptBr" text NOT NULL,
    "enUs" text NOT NULL,
    "esEs" text NOT NULL,
    icon text,
    color text,
    "isActive" boolean DEFAULT true NOT NULL,
    "sortOrder" integer DEFAULT 0 NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public."Metatag" OWNER TO alex;

--
-- Name: NotificationLog; Type: TABLE; Schema: public; Owner: alex
--

CREATE TABLE public."NotificationLog" (
    id text NOT NULL,
    "templateId" text NOT NULL,
    recipient text NOT NULL,
    channel public."Channel" NOT NULL,
    status public."NotifStatus" DEFAULT 'SENT'::public."NotifStatus" NOT NULL,
    "sentAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    metadata jsonb
);


ALTER TABLE public."NotificationLog" OWNER TO alex;

--
-- Name: NotificationTemplate; Type: TABLE; Schema: public; Owner: alex
--

CREATE TABLE public."NotificationTemplate" (
    id text NOT NULL,
    key text NOT NULL,
    label text NOT NULL,
    channel public."Channel" NOT NULL,
    subject text,
    body text NOT NULL,
    variables jsonb,
    "isActive" boolean DEFAULT true NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public."NotificationTemplate" OWNER TO alex;

--
-- Name: Plan; Type: TABLE; Schema: public; Owner: alex
--

CREATE TABLE public."Plan" (
    id text NOT NULL,
    name text NOT NULL,
    "priceMonthly" numeric(10,2) NOT NULL,
    "priceYearly" numeric(10,2) NOT NULL,
    "maxAssets" integer NOT NULL,
    "maxUsers" integer NOT NULL,
    "storageGb" integer NOT NULL,
    features jsonb NOT NULL,
    "isActive" boolean DEFAULT true NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public."Plan" OWNER TO alex;

--
-- Name: PushToken; Type: TABLE; Schema: public; Owner: alex
--

CREATE TABLE public."PushToken" (
    id text NOT NULL,
    "userId" text NOT NULL,
    token text NOT NULL,
    device text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public."PushToken" OWNER TO alex;

--
-- Name: ServiceProvider; Type: TABLE; Schema: public; Owner: alex
--

CREATE TABLE public."ServiceProvider" (
    id text NOT NULL,
    name text NOT NULL,
    category text NOT NULL,
    rating double precision DEFAULT 0 NOT NULL,
    reviews integer DEFAULT 0 NOT NULL,
    photo text,
    tags jsonb,
    keywords text,
    phone text,
    email text,
    city text,
    state text DEFAULT 'SP'::text NOT NULL,
    verified boolean DEFAULT false NOT NULL,
    "isActive" boolean DEFAULT true NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public."ServiceProvider" OWNER TO alex;

--
-- Name: StockItem; Type: TABLE; Schema: public; Owner: alex
--

CREATE TABLE public."StockItem" (
    id text NOT NULL,
    "assetId" text NOT NULL,
    name text NOT NULL,
    sku text NOT NULL,
    "currentStock" integer DEFAULT 0 NOT NULL,
    "minStock" integer DEFAULT 1 NOT NULL,
    unit text DEFAULT 'un'::text NOT NULL,
    "subLocation" text,
    "unitPrice" numeric(10,2),
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public."StockItem" OWNER TO alex;

--
-- Name: StockMovement; Type: TABLE; Schema: public; Owner: alex
--

CREATE TABLE public."StockMovement" (
    id text NOT NULL,
    "itemId" text NOT NULL,
    type public."MovementType" NOT NULL,
    quantity integer NOT NULL,
    reason text,
    "fromAssetId" text,
    "toAssetId" text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public."StockMovement" OWNER TO alex;

--
-- Name: Subscription; Type: TABLE; Schema: public; Owner: alex
--

CREATE TABLE public."Subscription" (
    id text NOT NULL,
    "tenantId" text NOT NULL,
    "planId" text NOT NULL,
    "billingCycle" public."BillingCycle" DEFAULT 'MONTHLY'::public."BillingCycle" NOT NULL,
    status public."SubStatus" DEFAULT 'ACTIVE'::public."SubStatus" NOT NULL,
    "currentStart" timestamp(3) without time zone NOT NULL,
    "currentEnd" timestamp(3) without time zone NOT NULL,
    "cancelledAt" timestamp(3) without time zone,
    "trialEndsAt" timestamp(3) without time zone,
    "externalId" text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public."Subscription" OWNER TO alex;

--
-- Name: TechnicianProfile; Type: TABLE; Schema: public; Owner: alex
--

CREATE TABLE public."TechnicianProfile" (
    id text NOT NULL,
    "userId" text NOT NULL,
    status text DEFAULT 'PENDING'::text NOT NULL,
    score double precision DEFAULT 5.0 NOT NULL,
    cft text,
    specialty text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public."TechnicianProfile" OWNER TO alex;

--
-- Name: TelemetryEvent; Type: TABLE; Schema: public; Owner: alex
--

CREATE TABLE public."TelemetryEvent" (
    id text NOT NULL,
    "tenantId" text,
    "ownerEmail" text NOT NULL,
    "deviceId" text,
    "executionId" text,
    "eventType" public."TelemetryEventType" NOT NULL,
    lat double precision,
    lng double precision,
    accuracy double precision,
    altitude double precision,
    speed double precision,
    heading double precision,
    "locationSource" text,
    "batteryLevel" double precision,
    "batteryCharging" boolean,
    "networkType" text,
    "appVersion" text,
    "osVersion" text,
    "deviceModel" text,
    "isMockLocation" boolean DEFAULT false NOT NULL,
    "isRooted" boolean DEFAULT false NOT NULL,
    "clockDriftMs" integer,
    "serverTimestamp" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "deviceTimestamp" timestamp(3) without time zone,
    payload jsonb,
    "retentionTier" text DEFAULT 'OPERATIONAL'::text NOT NULL,
    "expiresAt" timestamp(3) without time zone
);


ALTER TABLE public."TelemetryEvent" OWNER TO alex;

--
-- Name: Tenant; Type: TABLE; Schema: public; Owner: alex
--

CREATE TABLE public."Tenant" (
    id text NOT NULL,
    name text NOT NULL,
    slug text NOT NULL,
    email text NOT NULL,
    phone text,
    "taxId" text,
    "defaultLang" text DEFAULT 'pt-BR'::text NOT NULL,
    status public."TenantStatus" DEFAULT 'TRIAL'::public."TenantStatus" NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL,
    "avatarUrl" text,
    "localeId" text,
    "ownerName" text NOT NULL,
    "sectorCode" text
);


ALTER TABLE public."Tenant" OWNER TO alex;

--
-- Name: TranslationOverride; Type: TABLE; Schema: public; Owner: alex
--

CREATE TABLE public."TranslationOverride" (
    id text NOT NULL,
    "tenantId" text NOT NULL,
    key text NOT NULL,
    language text NOT NULL,
    value text NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public."TranslationOverride" OWNER TO alex;

--
-- Name: User; Type: TABLE; Schema: public; Owner: alex
--

CREATE TABLE public."User" (
    id text NOT NULL,
    "tenantId" text NOT NULL,
    email text NOT NULL,
    name text NOT NULL,
    password text NOT NULL,
    role public."UserRole" DEFAULT 'USER'::public."UserRole" NOT NULL,
    "isActive" boolean DEFAULT true NOT NULL,
    "lastLogin" timestamp(3) without time zone,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL,
    "avatarUrl" text
);


ALTER TABLE public."User" OWNER TO alex;

--
-- Name: UserModuleData; Type: TABLE; Schema: public; Owner: alex
--

CREATE TABLE public."UserModuleData" (
    id text NOT NULL,
    "ownerEmail" text NOT NULL,
    module text NOT NULL,
    data jsonb NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public."UserModuleData" OWNER TO alex;

--
-- Name: _prisma_migrations; Type: TABLE; Schema: public; Owner: alex
--

CREATE TABLE public._prisma_migrations (
    id character varying(36) NOT NULL,
    checksum character varying(64) NOT NULL,
    finished_at timestamp with time zone,
    migration_name character varying(255) NOT NULL,
    logs text,
    rolled_back_at timestamp with time zone,
    started_at timestamp with time zone DEFAULT now() NOT NULL,
    applied_steps_count integer DEFAULT 0 NOT NULL
);


ALTER TABLE public._prisma_migrations OWNER TO alex;

--
-- Data for Name: Admin; Type: TABLE DATA; Schema: public; Owner: alex
--

COPY public."Admin" (id, email, name, password, "createdAt", "updatedAt") FROM stdin;
cmnhrwhb50000l828dmz8w1u0	admin@brspark.com	Administrador Demo	$2a$10$K5Gw6YEgD8dKkFReUMkvrOWrSyDk3gQVybAA8bCTSAGk5r0SGkesW	2026-04-02 17:53:13.87	2026-04-02 17:53:24.554
\.


--
-- Data for Name: Asset; Type: TABLE DATA; Schema: public; Owner: alex
--

COPY public."Asset" (id, "tenantId", "parentId", title, type, status, description, "imageUrl", "locationId", metadata, "createdAt", "updatedAt", "deletedAt") FROM stdin;
brsp-920512	cmnjl5fzm00ugrohkuk34ncb6	\N	Casa	REAL_ESTATE	OPERACIONAL	\N	\N	\N	{"cep": "06056320", "city": "Osasco", "brand": "", "model": "", "owner": "", "state": "SP", "photos": [], "street": "Rua Avedis Kamalakian", "complement": "", "costCenter": "", "customIcon": "home-outline", "department": "", "inventoryId": "", "customFields": [], "neighborhood": "City Bussocaba", "serialNumber": "", "streetNumber": "", "gpsCoordinates": "", "acquisitionValue": ""}	2026-04-04 00:20:45.959	2026-04-04 00:20:45.959	\N
brsp-566812	cmnhhqj5c000e3yrjmvwv50er	\N	Casa de praia	REAL_ESTATE	OPERACIONAL	\N	\N	\N	{"cep": "", "city": "", "brand": "", "model": "", "owner": "", "state": "", "photos": [], "street": "", "complement": "", "costCenter": "", "customIcon": "home-outline", "department": "", "customColor": "#8B5CF6", "inventoryId": "", "customFields": [], "neighborhood": "", "serialNumber": "", "streetNumber": "", "gpsCoordinates": "", "acquisitionValue": ""}	2026-04-04 00:34:29.439	2026-04-04 00:34:29.766	\N
\.


--
-- Data for Name: AssetShare; Type: TABLE DATA; Schema: public; Owner: alex
--

COPY public."AssetShare" (id, "assetId", "ownerEmail", "sharedWithEmail", permission, modules, status, "invitedAt", "expiresAt") FROM stdin;
\.


--
-- Data for Name: AuditLog; Type: TABLE DATA; Schema: public; Owner: alex
--

COPY public."AuditLog" (id, "tenantId", "userId", "adminId", action, resource, category, metadata, "ipAddress", "createdAt") FROM stdin;
cmnhhqj64000i3yrjoyd41ka7	cmnhhqj5c000e3yrjmvwv50er	cmnhhqj5w000g3yrj2m7fnu6n	\N	USER_REGISTER	alex@brspark.com	AUTH	\N	\N	2026-04-02 13:08:40.204
cmnhhqp3i000k3yrj3ksacor8	cmnhhqj5c000e3yrjmvwv50er	cmnhhqj5w000g3yrj2m7fnu6n	\N	USER_LOGIN	alex@brspark.com	AUTH	\N	\N	2026-04-02 13:08:47.887
cmnhhrrqf000m3yrj8k5f9izk	cmnhhqj5c000e3yrjmvwv50er	cmnhhqj5w000g3yrj2m7fnu6n	\N	USER_LOGIN	alex@brspark.com	AUTH	\N	\N	2026-04-02 13:09:37.959
cmnhhz6p8007i3yrjuoi7xhv8	cmnhhqj5c000e3yrjmvwv50er	cmnhhqj5w000g3yrj2m7fnu6n	\N	USER_LOGIN	alex@brspark.com	AUTH	\N	\N	2026-04-02 13:15:23.949
cmnhr9dmh0a309g8mueiw933b	cmnhhqj5c000e3yrjmvwv50er	cmnhhqj5w000g3yrj2m7fnu6n	\N	USER_LOGIN	alex@brspark.com	AUTH	\N	\N	2026-04-02 17:35:16.025
cmnhrxx3p003nl0zim1gwwksj	\N	\N	\N	SYNC_OS_COMPLETED	ChecklistExecution	DATA	{"hasGps": false, "ownerEmail": "alex@brspark.com", "templateId": "chk_mnhro4is", "executionId": "cmnhrqhbi0b9j9g8mtnd7ocdb"}	\N	2026-04-02 17:54:21.012
cmnhrxx4k003ol0zioziegn64	\N	\N	\N	SYNC_OS_COMPLETED	ChecklistExecution	DATA	{"hasGps": false, "ownerEmail": "alex@brspark.com", "templateId": "chk_mnhro4is", "executionId": "cmnhrqhbi0b9j9g8mtnd7ocdb"}	\N	2026-04-02 17:54:21.045
cmnhrxx5a003pl0zi4pm4gmjp	\N	\N	\N	SYNC_OS_COMPLETED	ChecklistExecution	DATA	{"hasGps": false, "ownerEmail": "alex@brspark.com", "templateId": "chk_mnhro4is", "executionId": "cmnhrqhbi0b9j9g8mtnd7ocdb"}	\N	2026-04-02 17:54:21.071
cmnhrxx8a003ql0zitnj8vstt	\N	\N	\N	SYNC_OS_COMPLETED	ChecklistExecution	DATA	{"hasGps": false, "ownerEmail": "alex@brspark.com", "templateId": "chk_mnhro4is", "executionId": "cmnhrqhbi0b9j9g8mtnd7ocdb"}	\N	2026-04-02 17:54:21.178
cmnhry81x0052l0zieauhrl16	\N	\N	cmnhrwhb50000l828dmz8w1u0	LOGIN	Admin Console	AUTH	\N	\N	2026-04-02 17:54:35.204
cmnht03e800k2quvgtwftftfm	\N	\N	cmnhrwhb50000l828dmz8w1u0	LOGIN	Admin Console	AUTH	\N	\N	2026-04-02 18:24:02.096
cmnht46ox00pjquvgqqijwp9b	\N	\N	cmnhrwhb50000l828dmz8w1u0	LOGIN	Admin Console	AUTH	\N	\N	2026-04-02 18:27:12.993
cmnhtb56h00z2quvgaotk0p0n	\N	\N	\N	SYNC_OS_COMPLETED	ChecklistExecution	DATA	{"hasGps": false, "ownerEmail": "alex@brspark.com", "templateId": "chk_mnhro4is", "executionId": "cmnht8qog00vkquvgverzll77"}	\N	2026-04-02 18:32:37.625
cmnhtb56l00z3quvgehlfcmk0	\N	\N	\N	SYNC_OS_COMPLETED	ChecklistExecution	DATA	{"hasGps": false, "ownerEmail": "alex@brspark.com", "templateId": "chk_mnhro4is", "executionId": "cmnht8qog00vkquvgverzll77"}	\N	2026-04-02 18:32:37.629
cmnhtrfo7006sf5jr99vysotq	\N	\N	\N	SYNC_OS_COMPLETED	ChecklistExecution	DATA	{"hasGps": false, "ownerEmail": "alex@brspark.com", "templateId": "chk_mnhro4is", "executionId": "cmnhtnyp4001zf5jrvv0r23qa"}	\N	2026-04-02 18:45:17.72
cmnhtrfob006tf5jraizt9s64	\N	\N	\N	SYNC_OS_COMPLETED	ChecklistExecution	DATA	{"hasGps": false, "ownerEmail": "alex@brspark.com", "templateId": "chk_mnhro4is", "executionId": "cmnhtnyp4001zf5jrvv0r23qa"}	\N	2026-04-02 18:45:17.724
cmnhv5qhn0215f5jrmh1cr3px	\N	\N	cmnhrwhb50000l828dmz8w1u0	LOGIN	Admin Console	AUTH	\N	\N	2026-04-02 19:24:24.539
cmnhv9qg9026hf5jr9oty8kbv	\N	\N	cmnhrwhb50000l828dmz8w1u0	LOGIN	Admin Console	AUTH	\N	\N	2026-04-02 19:27:31.113
cmnhwj49a0001k84ws2tksgg4	\N	\N	cmnhrwhb50000l828dmz8w1u0	LOGIN	Admin Console	AUTH	\N	\N	2026-04-02 20:02:48.526
cmnhyj5fh0003k84we7wyje15	\N	\N	cmnhrwhb50000l828dmz8w1u0	LOGIN	Admin Console	AUTH	\N	\N	2026-04-02 20:58:49.277
cmnhz0llw00gck84wcp6w8aj9	\N	\N	\N	SYNC_OS_COMPLETED	ChecklistExecution	DATA	{"hasGps": false, "ownerEmail": "alex@brspark.com", "templateId": "chk_mnhro4is", "executionId": "cmnhykdhy0005k84w6xci9f1x"}	\N	2026-04-02 21:12:23.396
cmnhz0lmr00gdk84wyxyvcjpz	\N	\N	\N	SYNC_OS_COMPLETED	ChecklistExecution	DATA	{"hasGps": false, "ownerEmail": "alex@brspark.com", "templateId": "chk_mnhro4is", "executionId": "cmnhykdhy0005k84w6xci9f1x"}	\N	2026-04-02 21:12:23.427
cmni0w9bb0314k84we0fsy9v7	\N	\N	\N	SYNC_OS_COMPLETED	ChecklistExecution	DATA	{"hasGps": false, "ownerEmail": "alex@brspark.com", "templateId": "chk_mnhro4is", "executionId": "cmni0qayq02sqk84wy5bpuvea"}	\N	2026-04-02 22:05:00.071
cmni0w9be0315k84w7bw6y5pw	\N	\N	\N	SYNC_OS_COMPLETED	ChecklistExecution	DATA	{"hasGps": false, "ownerEmail": "alex@brspark.com", "templateId": "chk_mnhro4is", "executionId": "cmni0qayq02sqk84wy5bpuvea"}	\N	2026-04-02 22:05:00.074
cmni14irv03e9k84w5os3u3lt	\N	\N	\N	SYNC_OS_COMPLETED	ChecklistExecution	DATA	{"hasGps": false, "ownerEmail": "alex@brspark.com", "templateId": "chk_mnhro4is", "executionId": "cmni0zakf035wk84wuzy84yix"}	\N	2026-04-02 22:11:25.579
cmni14irw03eak84wdcjrv2a9	\N	\N	\N	SYNC_OS_COMPLETED	ChecklistExecution	DATA	{"hasGps": false, "ownerEmail": "alex@brspark.com", "templateId": "chk_mnhro4is", "executionId": "cmni0zakf035wk84wuzy84yix"}	\N	2026-04-02 22:11:25.58
cmni4u9oi007ikaefpr3mv6k6	\N	\N	cmnhrwhb50000l828dmz8w1u0	LOGIN	Admin Console	AUTH	\N	\N	2026-04-02 23:55:25.698
cmni5dup800hjkaefc3x48ah8	\N	\N	\N	SYNC_OS_COMPLETED	ChecklistExecution	DATA	{"hasGps": false, "ownerEmail": "alex@brspark.com", "templateId": "chk_mnhro4is", "executionId": "cmni1npwo045ck84w2mp3uaqv"}	\N	2026-04-03 00:10:39.404
cmni5dupf00hkkaefx8dkdy9f	\N	\N	\N	SYNC_OS_COMPLETED	ChecklistExecution	DATA	{"hasGps": false, "ownerEmail": "alex@brspark.com", "templateId": "chk_mnhro4is", "executionId": "cmni1npwo045ck84w2mp3uaqv"}	\N	2026-04-03 00:10:39.411
cmni5eh5g00j1kaefo54w9szm	\N	\N	\N	SYNC_OS_COMPLETED	ChecklistExecution	DATA	{"hasGps": false, "ownerEmail": "alex@brspark.com", "templateId": "chk_mnhro4is", "executionId": "cmni0ykni034tk84w4shu4k67"}	\N	2026-04-03 00:11:08.501
cmni5eh5l00j2kaefy7te8wfd	\N	\N	\N	SYNC_OS_COMPLETED	ChecklistExecution	DATA	{"hasGps": false, "ownerEmail": "alex@brspark.com", "templateId": "chk_mnhro4is", "executionId": "cmni0ykni034tk84w4shu4k67"}	\N	2026-04-03 00:11:08.505
cmni5i6pj00okkaeftd41o9ic	\N	\N	\N	SYNC_OS_COMPLETED	ChecklistExecution	DATA	{"hasGps": false, "ownerEmail": "alex@brspark.com", "templateId": "chk_mnhro4is", "executionId": "cmni5h43y00mpkaef20ijrtel"}	\N	2026-04-03 00:14:01.592
cmni5i6pq00olkaef0xrdhph5	\N	\N	\N	SYNC_OS_COMPLETED	ChecklistExecution	DATA	{"hasGps": false, "ownerEmail": "alex@brspark.com", "templateId": "chk_mnhro4is", "executionId": "cmni5h43y00mpkaef20ijrtel"}	\N	2026-04-03 00:14:01.599
cmni5p4bx00zjkaef1jfqr76h	\N	\N	cmnhrwhb50000l828dmz8w1u0	LOGIN	Admin Console	AUTH	\N	\N	2026-04-03 00:19:25.101
cmni6094k01ggkaefzvzdutpy	\N	\N	\N	SYNC_OS_COMPLETED	ChecklistExecution	DATA	{"hasGps": false, "ownerEmail": "alex@brspark.com", "templateId": "chk_mnhro4is", "executionId": "cmni5glfq00lykaefxv4igyw0"}	\N	2026-04-03 00:28:04.533
cmni6094t01ghkaef9ila9wuv	\N	\N	\N	SYNC_OS_COMPLETED	ChecklistExecution	DATA	{"hasGps": false, "ownerEmail": "alex@brspark.com", "templateId": "chk_mnhro4is", "executionId": "cmni5glfq00lykaefxv4igyw0"}	\N	2026-04-03 00:28:04.541
cmni6095k01gikaefjj9exqu9	\N	\N	\N	SYNC_OS_COMPLETED	ChecklistExecution	DATA	{"hasGps": false, "ownerEmail": "alex@brspark.com", "templateId": "chk_mnhro4is", "executionId": "cmni5glfq00lykaefxv4igyw0"}	\N	2026-04-03 00:28:04.568
cmni6fcis0016708nfozr8zi1	\N	\N	\N	SYNC_OS_COMPLETED	ChecklistExecution	DATA	{"hasGps": false, "ownerEmail": "alex@brspark.com", "templateId": "chk_mni0xdfi", "executionId": "cmni5g3d100lckaef6qeeg4y5"}	\N	2026-04-03 00:39:48.772
cmni6fcix0017708nxjjcou7o	\N	\N	\N	SYNC_OS_COMPLETED	ChecklistExecution	DATA	{"hasGps": false, "ownerEmail": "alex@brspark.com", "templateId": "chk_mni0xdfi", "executionId": "cmni5g3d100lckaef6qeeg4y5"}	\N	2026-04-03 00:39:48.778
cmni6w7iy00r4708nvx2xe8wr	\N	\N	cmnhrwhb50000l828dmz8w1u0	LOGIN	Admin Console	AUTH	\N	\N	2026-04-03 00:52:55.45
cmni838c102h1708nz9adhmak	\N	\N	\N	SYNC_OS_COMPLETED	ChecklistExecution	DATA	{"hasGps": false, "ownerEmail": "alex@brspark.com", "templateId": "chk_mnhro4is", "executionId": "cmni0yc0l034gk84wpt1ucqfp"}	\N	2026-04-03 01:26:22.705
cmni838ca02h2708n9daaqj1q	\N	\N	\N	SYNC_OS_COMPLETED	ChecklistExecution	DATA	{"hasGps": false, "ownerEmail": "alex@brspark.com", "templateId": "chk_mnhro4is", "executionId": "cmni0yc0l034gk84wpt1ucqfp"}	\N	2026-04-03 01:26:22.714
cmni8hvgf02r5708n3p2tctp3	\N	\N	cmnhrwhb50000l828dmz8w1u0	LOGIN	Admin Console	AUTH	\N	\N	2026-04-03 01:37:45.853
cmni9ssc902ra708npkzgabrh	cmnhhqj5c000e3yrjmvwv50er	cmnhhqj5w000g3yrj2m7fnu6n	\N	USER_LOGIN	alex@brspark.com	AUTH	\N	\N	2026-04-03 02:14:14.649
cmni9ztjj03a4708nja5twuia	\N	\N	\N	SYNC_OS_COMPLETED	ChecklistExecution	DATA	{"hasGps": false, "ownerEmail": "alex@brspark.com", "templateId": "chk_mnhro4is", "executionId": "cmni8cwga02p1708nrb9ddvxg"}	\N	2026-04-03 02:19:42.798
cmni9ztjo03a5708n6elbfzwn	\N	\N	\N	SYNC_OS_COMPLETED	ChecklistExecution	DATA	{"hasGps": false, "ownerEmail": "alex@brspark.com", "templateId": "chk_mnhro4is", "executionId": "cmni8cwga02p1708nrb9ddvxg"}	\N	2026-04-03 02:19:42.804
cmnibg0ru00t4za8g6opaeucz	\N	\N	\N	SYNC_OS_COMPLETED	ChecklistExecution	DATA	{"hasGps": false, "ownerEmail": "alex@brspark.com", "templateId": "chk_mnhro4is", "executionId": "cmni8bpkq02oz708nzfdg04oc"}	\N	2026-04-03 03:00:18.278
cmnibg0ru00t3za8g7e925zre	\N	\N	\N	SYNC_OS_COMPLETED	ChecklistExecution	DATA	{"hasGps": false, "ownerEmail": "alex@brspark.com", "templateId": "chk_mnhro4is", "executionId": "cmni8bpkq02oz708nzfdg04oc"}	\N	2026-04-03 03:00:18.278
cmnibwcns01f4za8gyk9wtbjs	\N	\N	\N	SYNC_OS_COMPLETED	ChecklistExecution	DATA	{"hasGps": false, "ownerEmail": "alex@brspark.com", "templateId": "chk_mnhro4is", "executionId": "cmni8b8rv02ox708n5s952fjt"}	\N	2026-04-03 03:13:00.184
cmnibwcnm01f3za8grpf5lnnh	\N	\N	\N	SYNC_OS_COMPLETED	ChecklistExecution	DATA	{"hasGps": false, "ownerEmail": "alex@brspark.com", "templateId": "chk_mnhro4is", "executionId": "cmni8b8rv02ox708n5s952fjt"}	\N	2026-04-03 03:13:00.178
cmnizqpjv0001hieezxcy95gr	\N	\N	cmnhrwhb50000l828dmz8w1u0	LOGIN	Admin Console	AUTH	\N	\N	2026-04-03 14:20:27.739
cmnizr3bv0003hieeuednz9dg	\N	\N	cmnhrwhb50000l828dmz8w1u0	LOGIN	Admin Console	AUTH	\N	\N	2026-04-03 14:20:45.595
cmnizsf870005hiee1tjalcg7	\N	\N	cmnhrwhb50000l828dmz8w1u0	LOGIN	Admin Console	AUTH	\N	\N	2026-04-03 14:21:47.671
cmnizv1iu0001cnmvtu91qqy3	\N	\N	cmnhrwhb50000l828dmz8w1u0	LOGIN	Admin Console	AUTH	\N	\N	2026-04-03 14:23:49.877
cmnj0iyvp0001j3y6igcv1qik	\N	\N	cmnhrwhb50000l828dmz8w1u0	LOGIN	Admin Console	AUTH	\N	\N	2026-04-03 14:42:26.196
cmnj0y0yr0003hw8y3820q7vs	cmnhhqj5c000e3yrjmvwv50er	cmnhhqj5w000g3yrj2m7fnu6n	\N	USER_LOGIN	alex@brspark.com	AUTH	\N	\N	2026-04-03 14:54:08.739
cmnj3alq300buhoja8e6kbaes	\N	\N	\N	SYNC_OS_COMPLETED	ChecklistExecution	DATA	{"hasGps": false, "ownerEmail": "alex@brspark.com", "templateId": "chk_mnj0nb63", "executionId": "cmnj1u3d401z3hw8yw2e5hqnc"}	\N	2026-04-03 15:59:54.747
cmnj3alq300bvhojae8xbtapr	\N	\N	\N	SYNC_OS_COMPLETED	ChecklistExecution	DATA	{"hasGps": false, "ownerEmail": "alex@brspark.com", "templateId": "chk_mnj0nb63", "executionId": "cmnj1u3d401z3hw8yw2e5hqnc"}	\N	2026-04-03 15:59:54.747
cmnjjjn980001bddjv378o8cc	cmnhhqj5c000e3yrjmvwv50er	cmnhhqj5w000g3yrj2m7fnu6n	\N	USER_LOGIN	alex@brspark.com	AUTH	\N	\N	2026-04-03 23:34:50.492
cmnjjkzx3003kbddjkvuvfxyq	\N	\N	\N	SYNC_OS_COMPLETED	ChecklistExecution	DATA	{"hasGps": false, "ownerEmail": "alex@brspark.com", "templateId": "chk_mnj0nb63", "executionId": "cmnj0qdf70003j3y6z9zcptf7"}	\N	2026-04-03 23:35:53.56
cmnjjkzx6003lbddjbyq1zrxa	\N	\N	\N	SYNC_OS_COMPLETED	ChecklistExecution	DATA	{"hasGps": false, "ownerEmail": "alex@brspark.com", "templateId": "chk_mnj0nb63", "executionId": "cmnj0qdf70003j3y6z9zcptf7"}	\N	2026-04-03 23:35:53.563
cmnjjoojx00cvbddjda4klxkq	\N	\N	\N	SYNC_OS_COMPLETED	ChecklistExecution	DATA	{"hasGps": false, "ownerEmail": "alex@brspark.com", "templateId": "chk_mnhro4is", "executionId": "cmnj3zrof019dhojaj8wfptwn"}	\N	2026-04-03 23:38:45.454
cmnjjoorv00dbbddjdxun5394	\N	\N	\N	SYNC_OS_COMPLETED	ChecklistExecution	DATA	{"hasGps": false, "ownerEmail": "alex@brspark.com", "templateId": "chk_mnhro4is", "executionId": "cmnj3zrof019dhojaj8wfptwn"}	\N	2026-04-03 23:38:45.739
cmnjjrayg00l3bddjx7zvrydq	\N	\N	\N	SYNC_OS_COMPLETED	ChecklistExecution	DATA	{"hasGps": false, "ownerEmail": "alex@brspark.com", "templateId": "chk_mnhro4is", "executionId": "cmnj3yrf4017vhojacp14gc5a"}	\N	2026-04-03 23:40:47.8
cmnjjrayn00l4bddjqkon3zix	\N	\N	\N	SYNC_OS_COMPLETED	ChecklistExecution	DATA	{"hasGps": false, "ownerEmail": "alex@brspark.com", "templateId": "chk_mnhro4is", "executionId": "cmnj3yrf4017vhojacp14gc5a"}	\N	2026-04-03 23:40:47.808
cmnjjxgsw00q0bddjk4ogzn6k	\N	\N	\N	SYNC_OS_COMPLETED	ChecklistExecution	DATA	{"hasGps": false, "ownerEmail": "alex@brspark.com", "templateId": "chk_mnj0nb63", "executionId": "cmnj1lkhy01n1hw8y4bohk7qw"}	\N	2026-04-03 23:45:35.311
cmnjjxgsw00q1bddjv73b63r8	\N	\N	\N	SYNC_OS_COMPLETED	ChecklistExecution	DATA	{"hasGps": false, "ownerEmail": "alex@brspark.com", "templateId": "chk_mnj0nb63", "executionId": "cmnj1lkhy01n1hw8y4bohk7qw"}	\N	2026-04-03 23:45:35.312
cmnjk2qx000w1bddjlsehdadw	cmnhhqj5c000e3yrjmvwv50er	cmnhhqj5w000g3yrj2m7fnu6n	\N	USER_LOGIN	alex@brspark.com	AUTH	\N	\N	2026-04-03 23:49:41.7
cmnjkm9tm000krohknbnq6rrs	cmnhhqj5c000e3yrjmvwv50er	cmnhhqj5w000g3yrj2m7fnu6n	\N	USER_LOGIN	alex@brspark.com	AUTH	\N	\N	2026-04-04 00:04:52.667
cmnjkq0ks00asrohk1lds806b	cmnhhqj5c000e3yrjmvwv50er	cmnhhqj5w000g3yrj2m7fnu6n	\N	USER_LOGIN	alex@brspark.com	AUTH	\N	\N	2026-04-04 00:07:47.308
cmnjl14so00n3rohkclg479j0	cmnhhqj5c000e3yrjmvwv50er	cmnhhqj5w000g3yrj2m7fnu6n	\N	USER_LOGIN	alex@brspark.com	AUTH	\N	\N	2026-04-04 00:16:25.992
cmnjl5g0200ukrohkn76bdbvm	cmnjl5fzm00ugrohkuk34ncb6	cmnjl5g0000uirohkljbrswtz	\N	USER_REGISTER	qualquecoisa@gmail.com	AUTH	\N	\N	2026-04-04 00:19:47.138
cmnjl6pek00umrohkt4vtfgpw	cmnjl5fzm00ugrohkuk34ncb6	cmnjl5g0000uirohkljbrswtz	\N	SYNC_PUSH	ASSET	DATA	{"message": "Sincronizados 1 itens da fila offline."}	\N	2026-04-04 00:20:45.981
cmnjlcua000uyrohkg4iqpd9k	cmnjl5fzm00ugrohkuk34ncb6	cmnjl5g0000uirohkljbrswtz	\N	SYNC_PUSH	ASSET	DATA	{"message": "Sincronizados 1 itens da fila offline."}	\N	2026-04-04 00:25:32.232
cmnjlcua300v2rohkf8vo2iec	cmnjl5fzm00ugrohkuk34ncb6	cmnjl5g0000uirohkljbrswtz	\N	SYNC_PUSH	ASSET	DATA	{"message": "Sincronizados 1 itens da fila offline."}	\N	2026-04-04 00:25:32.236
cmnjlcua200v0rohkqwov5ulr	cmnjl5fzm00ugrohkuk34ncb6	cmnjl5g0000uirohkljbrswtz	\N	SYNC_PUSH	ASSET	DATA	{"message": "Sincronizados 1 itens da fila offline."}	\N	2026-04-04 00:25:32.235
cmnjlcua400v4rohkrqcogwhy	cmnjl5fzm00ugrohkuk34ncb6	cmnjl5g0000uirohkljbrswtz	\N	SYNC_PUSH	ASSET	DATA	{"message": "Sincronizados 1 itens da fila offline."}	\N	2026-04-04 00:25:32.237
cmnjlcu9z00uwrohkmeobtdsf	cmnjl5fzm00ugrohkuk34ncb6	cmnjl5g0000uirohkljbrswtz	\N	SYNC_PUSH	ASSET	DATA	{"message": "Sincronizados 1 itens da fila offline."}	\N	2026-04-04 00:25:32.231
cmnjlcua500v6rohkhjt6idvh	cmnjl5fzm00ugrohkuk34ncb6	cmnjl5g0000uirohkljbrswtz	\N	SYNC_PUSH	ASSET	DATA	{"message": "Sincronizados 1 itens da fila offline."}	\N	2026-04-04 00:25:32.238
cmnjlcub700v8rohklgu6y9qk	cmnjl5fzm00ugrohkuk34ncb6	cmnjl5g0000uirohkljbrswtz	\N	SYNC_PUSH	ASSET	DATA	{"message": "Sincronizados 1 itens da fila offline."}	\N	2026-04-04 00:25:32.276
cmnjlcub900varohkm2g5ijmc	cmnjl5fzm00ugrohkuk34ncb6	cmnjl5g0000uirohkljbrswtz	\N	SYNC_PUSH	ASSET	DATA	{"message": "Sincronizados 1 itens da fila offline."}	\N	2026-04-04 00:25:32.277
cmnjlhsuw00vqrohkezscjsyl	cmnhhqj5c000e3yrjmvwv50er	cmnhhqj5w000g3yrj2m7fnu6n	\N	USER_LOGIN	alex@brspark.com	AUTH	\N	\N	2026-04-04 00:29:23.672
cmnjljwfz011wrohk2sj0pri4	\N	\N	\N	SYNC_OS_COMPLETED	ChecklistExecution	DATA	{"hasGps": false, "ownerEmail": "alex@brspark.com", "templateId": "chk_mnhro4is", "executionId": "cmnj3xzrq016shojah2dyzntn"}	\N	2026-04-04 00:31:01.631
cmnjljwiz011xrohkxyi5f0ch	\N	\N	\N	SYNC_OS_COMPLETED	ChecklistExecution	DATA	{"hasGps": false, "ownerEmail": "alex@brspark.com", "templateId": "chk_mnhro4is", "executionId": "cmnj3xzrq016shojah2dyzntn"}	\N	2026-04-04 00:31:01.739
cmnjlod1n01e7rohkdjr5xe5z	cmnhhqj5c000e3yrjmvwv50er	cmnhhqj5w000g3yrj2m7fnu6n	\N	SYNC_PUSH	ASSET	DATA	{"message": "Sincronizados 1 itens da fila offline."}	\N	2026-04-04 00:34:29.771
cmnjlod1n01e9rohkqeow4vai	cmnhhqj5c000e3yrjmvwv50er	cmnhhqj5w000g3yrj2m7fnu6n	\N	SYNC_PUSH	ASSET	DATA	{"message": "Sincronizados 1 itens da fila offline."}	\N	2026-04-04 00:34:29.771
cmnjloshy01egrohke48b6pi2	cmnhhqj5c000e3yrjmvwv50er	cmnhhqj5w000g3yrj2m7fnu6n	\N	SYNC_PUSH	ASSET	DATA	{"message": "Sincronizados 1 itens da fila offline."}	\N	2026-04-04 00:34:49.798
cmnjmb5lm01ghrohk4hob1xjj	cmnhhqj5c000e3yrjmvwv50er	cmnhhqj5w000g3yrj2m7fnu6n	\N	SYNC_PUSH	ASSET	DATA	{"message": "Sincronizados 1 itens da fila offline."}	\N	2026-04-04 00:52:13.209
cmnjmb5lo01gjrohkoxnz55ad	cmnhhqj5c000e3yrjmvwv50er	cmnhhqj5w000g3yrj2m7fnu6n	\N	SYNC_PUSH	ASSET	DATA	{"message": "Sincronizados 1 itens da fila offline."}	\N	2026-04-04 00:52:13.212
cmnjmhnv401gurohklcq32glf	cmnjmhnpx01gqrohk7zart6bt	cmnjmhnub01gsrohkw88ub2kd	\N	USER_REGISTER	ze@ze.com	AUTH	\N	\N	2026-04-04 00:57:16.816
cmnjmpxva01h1rohkiqwnre3w	cmnjmhnpx01gqrohk7zart6bt	cmnjmhnub01gsrohkw88ub2kd	\N	USER_LOGIN	ze@ze.com	AUTH	\N	\N	2026-04-04 01:03:43.029
\.


--
-- Data for Name: ChatContact; Type: TABLE DATA; Schema: public; Owner: alex
--

COPY public."ChatContact" (id, "requesterId", "addresseeId", status, "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: ChatMessage; Type: TABLE DATA; Schema: public; Owner: alex
--

COPY public."ChatMessage" (id, "roomId", "senderId", "senderName", type, content, "mediaUrl", "createdAt") FROM stdin;
\.


--
-- Data for Name: ChatRoom; Type: TABLE DATA; Schema: public; Owner: alex
--

COPY public."ChatRoom" (id, name, description, "avatarColor", "isGroup", "creatorId", "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: ChatRoomMember; Type: TABLE DATA; Schema: public; Owner: alex
--

COPY public."ChatRoomMember" (id, "roomId", "userId", role, "joinedAt", "lastReadAt") FROM stdin;
\.


--
-- Data for Name: ChecklistExecution; Type: TABLE DATA; Schema: public; Owner: alex
--

COPY public."ChecklistExecution" (id, "templateId", "ownerEmail", "assetId", status, responses, metadata, "locationAddress", "locationLat", "locationLng", "locationRadius", "locationZoneType", "locationPolygon", "gpsLocation", "startedAt", "completedAt", "syncedAt", "createdAt", "etaMinutes") FROM stdin;
cmnj0qdf70003j3y6z9zcptf7	chk_mnj0nb63	alex@brspark.com	\N	COMPLETED	{"field_39132": "http://192.168.15.73:3001/uploads/storage/checklists/unknown_empresa_com/cmnj0qdf70003j3y6z9zcptf7_field_39132_1775259353467.jpg", "__time_field_39132": "2026-04-03T23:35:49.040Z", "__section_end_page_1": "2026-04-03T23:35:53.429Z", "__section_start_page_1": "2026-04-03T23:35:49.054Z"}	{"icon": "build-outline", "refId": "chk_mnj0nb63", "title": "face", "acceptedAt": "2026-04-03T23:35:35.455Z", "appVersion": "1.0", "receivedAt": "2026-04-03T14:54:09.454Z", "description": "Tarefa de rotina despachada.", "devicePlatform": "AppMovel", "durationSeconds": 17}	\N	-16.49074	-47.966309	200	radius	null	null	2026-04-03 23:35:35.497	2026-04-03 23:35:53.429	2026-04-03 23:35:53.556	2026-04-03 14:48:11.625	692
cmnhrqhbi0b9j9g8mtnd7ocdb	chk_mnhro4is	alex@brspark.com	\N	COMPLETED	{"field_4248": "{\\"action\\":\\"CHEGADA\\",\\"timestamp\\":\\"2026-04-02T17:52:04.330Z\\",\\"coordinates\\":{\\"lat\\":-23.569983,\\"lng\\":-46.7851655},\\"address\\":\\"Parque Chico Mendes,  - Jd Bussocaba City, Osasco - SP\\",\\"traversedPath\\":[[-23.569983,-46.7851655]]}", "field_21036": "file:///Users/alex/Library/Developer/CoreSimulator/Devices/99E0B8BD-911F-42C8-A707-E7AA58227EEE/data/Containers/Data/Application/63BD2007-9626-4C9B-920B-136B093842C7/Library/Caches/ImagePicker/A7F606A3-78BC-4282-B393-F5A8E2158EE6.heic", "field_66812": "Sim", "field_75000": "SIG_V1|meta:{\\"lat\\":-23.569983,\\"lng\\":-46.7851655,\\"address\\":\\",  - Osasco, SP\\",\\"ip\\":\\"2804:7f0:9383:8b58:b9fe:d321:ec05:865c\\"}|M60.33333333333333,179.00000127156574 L61,179.00000127156574 L92,169.66666793823242 L166,140.33333460489905 L187.66666666666666,119.66666793823242 L191,102.33333460489905 L191.66666666666666,100.66666793823242 L191.66666666666666,100.33333460489905 L191.66666666666666,99.66666793823242 L191.66666666666666,99.33333460489905 L191.66666666666666,99.66666793823242|M191.66666666666666,101.00000127156574 L191.66666666666666,100.66666793823242 L103.33333333333333,73.33333460489905 L77,78.66666793823242 L58.66666666666666,100.00000127156574 L58,104.66666793823242|M59.66666666666666,99.66666793823242 L128,218.00000127156568 L133.66666666666666,222.66666793823242 L172.33333333333331,183.00000127156568 L173,173.66666793823242 L181,192.00000127156568 L213.33333333333331,199.66666793823242 L248.33333333333331,178.66666793823242 L249,178.33333460489905 L249.33333333333331,178.66666793823242 L253.66666666666663,184.33333460489905 L260.66666666666663,201.66666793823242 L262.3333333333333,207.33333460489905 L257.3333333333333,222.66666793823242 L252,228.33333460489905 L240.66666666666663,230.33333460489905 L229,230.33333460489905 L203.66666666666666,225.00000127156568 L186,218.33333460489905 L164.33333333333331,201.66666793823242 L161,188.33333460489905 L171,179.33333460489905 L174.66666666666666,177.33333460489905 L203.66666666666666,172.66666793823242 L233,169.66666793823242 L240.66666666666663,169.66666793823242 L247.66666666666663,167.00000127156574 L249.33333333333331,165.66666793823242 L256.66666666666663,157.33333460489905 L258,156.00000127156574 L282.66666666666663,150.66666793823242 L317.66666666666663,140.66666793823242 L319,140.33333460489905 L319.3333333333333,140.00000127156574 L328.66666666666663,120.66666793823242 L330.66666666666663,109.66666793823242 L330.66666666666663,108.33333460489905 L330.66666666666663,109.33333460489905 L336.3333333333333,139.33333460489905 L336.66666666666663,139.33333460489905 L336.66666666666663,138.66666793823242", "field_75975": "{\\"action\\":\\"SAIDA\\",\\"timestamp\\":\\"2026-04-02T17:51:36.803Z\\",\\"coordinates\\":{\\"lat\\":-23.569983,\\"lng\\":-46.7851655},\\"address\\":\\"Parque Chico Mendes,  - Jd Bussocaba City, Osasco - SP\\"}", "__time_field_4248": "2026-04-02T17:52:04.330Z", "__time_field_21036": "2026-04-02T17:54:01.637Z", "__time_field_66812": "2026-04-02T17:52:10.089Z", "__time_field_75000": "2026-04-02T17:54:17.283Z", "__time_field_75975": "2026-04-02T17:51:36.804Z", "__section_end_page_1": "2026-04-02T17:54:19.304Z", "__section_start_page_1": "2026-04-02T17:51:37.044Z"}	{"icon": "build-outline", "refId": "chk_mnhro4is", "title": "Rota", "acceptedAt": "2026-04-02T17:50:40.054Z", "appVersion": "1.0", "receivedAt": "2026-04-02T17:48:35.018Z", "description": "Tarefa de rotina despachada.", "devicePlatform": "AppMovel", "durationSeconds": 214}	\N	44.8492	7.343651	150	segment	[[44.849368, 7.343243], [44.849033, 7.34406]]	null	2026-04-02 17:50:44.616	2026-04-02 17:54:19.305	2026-04-02 17:54:21.044	2026-04-02 17:48:33.965	\N
cmnht8qog00vkquvgverzll77	chk_mnhro4is	alex@brspark.com	\N	COMPLETED	{"field_4248": "{\\"action\\":\\"CHEGADA\\",\\"timestamp\\":\\"2026-04-02T18:31:40.775Z\\",\\"coordinates\\":{\\"lat\\":-23.569983,\\"lng\\":-46.7851655},\\"address\\":\\"Parque Chico Mendes,  - Jd Bussocaba City, Osasco - SP\\",\\"traversedPath\\":[[-23.569983,-46.7851655],[-23.569983,-46.7851655]]}", "field_21036": "file:///Users/alex/Library/Developer/CoreSimulator/Devices/99E0B8BD-911F-42C8-A707-E7AA58227EEE/data/Containers/Data/Application/63BD2007-9626-4C9B-920B-136B093842C7/Library/Caches/ImagePicker/01481CF1-D738-41CB-8EB6-EC38B439637C.jpg", "field_66812": "Sim", "field_75000": "SIG_V1|meta:{\\"lat\\":-23.569983,\\"lng\\":-46.7851655,\\"address\\":\\",  - Osasco, SP\\",\\"ip\\":\\"2804:7f0:9383:8b58:b9fe:d321:ec05:865c\\"}|M144,217.66666793823242 L186.6666666666667,196.66666793823242 L233.00000000000003,174.66666793823242 L335.6666666666667,120.33333460489908 L366.00000000000006,101.33333460489908 L366.6666666666667,100.33333460489908 L365.6666666666667,101.00000127156574 L343.6666666666667,126.66666793823242 L335.33333333333337,133.66666793823242 L306.6666666666667,152.66666793823242 L266.33333333333337,172.66666793823242 L232.33333333333337,187.33333460489905 L207.00000000000003,192.00000127156574 L195.33333333333337,193.33333460489905 L185.6666666666667,190.00000127156574 L174.00000000000003,185.33333460489905 L168.6666666666667,176.33333460489908 L159.6666666666667,145.00000127156574 L158.33333333333337,133.33333460489908 L159.00000000000006,131.66666793823242 L165.33333333333337,131.33333460489908 L177.00000000000003,135.33333460489908 L192.33333333333337,148.00000127156574 L218.00000000000003,172.00000127156574 L238.33333333333337,197.33333460489905 L249.66666666666669,210.00000127156574 L278.6666666666667,238.00000127156574 L335.6666666666667,235.00000127156574 L392.00000000000006,205.00000127156574 L392.33333333333337,204.66666793823242 L392.33333333333337,205.33333460489905 L393.6666666666667,206.66666793823242 L393.6666666666667,207.00000127156574 L394.33333333333337,207.00000127156574 L398.00000000000006,204.66666793823242 L411.00000000000006,194.33333460489905 L423.00000000000006,180.66666793823242 L426.6666666666667,171.00000127156574 L426.6666666666667,170.00000127156574 L423.00000000000006,168.66666793823242 L409.33333333333337,168.66666793823242 L401.6666666666667,173.33333460489908 L400.6666666666667,175.66666793823242 L400.6666666666667,176.00000127156574 L402.6666666666667,176.33333460489908 L421.6666666666667,166.66666793823242 L436.6666666666667,156.00000127156574 L448.33333333333337,150.00000127156574 L449,150.66666793823242 L450.6666666666667,161.00000127156574 L447.6666666666667,168.66666793823242 L426.33333333333337,186.66666793823242 L410.6666666666667,190.66666793823242 L403.6666666666667,189.66666793823242 L402.00000000000006,182.00000127156574 L402.00000000000006,172.66666793823242 L409.00000000000006,162.00000127156574 L418.33333333333337,159.00000127156574 L434,163.33333460489908 L444.33333333333337,169.00000127156574 L461.6666666666667,183.66666793823242 L469,190.00000127156574 L478.6666666666667,193.00000127156574 L486.33333333333337,193.00000127156574 L495.66666666666674,186.00000127156574 L501,174.66666793823242 L502.33333333333337,170.33333460489908 L502.66666666666674,170.33333460489908 L504,171.00000127156574 L507.66666666666674,174.66666793823242 L515.3333333333334,178.66666793823242 L526.6666666666667,179.66666793823242 L532.3333333333334,178.00000127156574 L542,173.66666793823242 L563,165.00000127156574 L564.3333333333334,165.00000127156574 L564.3333333333334,165.33333460489908 L565.3333333333334,165.33333460489908 L570.6666666666667,164.66666793823242 L576.3333333333334,164.00000127156574 L586,164.00000127156574 L588.6666666666667,164.00000127156574 L590.6666666666667,164.00000127156574 L595,164.00000127156574 L604.6666666666666,163.33333460489908 L616,162.33333460489908 L617.6666666666666,163.66666793823242 L618.6666666666666,165.00000127156574 L620.3333333333334,166.00000127156574 L634.3333333333334,158.33333460489908 L643,152.00000127156574 L653.3333333333334,146.00000127156574 L656.6666666666666,145.66666793823242 L658,147.33333460489908 L661.6666666666666,152.00000127156574 L664,151.33333460489908 L671.3333333333334,138.00000127156574 L675,126.33333460489908 L678.6666666666666,112.66666793823242 L682.6666666666666,95.00000127156574 L686,85.33333460489908 L686.6666666666666,84.33333460489908 L687.3333333333334,84.33333460489908 L687.6666666666666,84.66666793823242 L694,94.00000127156574 L700.6666666666666,109.33333460489908 L705.3333333333334,199.00000127156574 L686.6666666666666,222.00000127156574 L652.6666666666666,236.33333460489905 L613,239.66666793823242 L569.3333333333334,229.66666793823242 L529.3333333333334,213.00000127156574 L495,193.33333460489905 L472,179.33333460489908 L472.6666666666667,175.00000127156574 L474.6666666666667,169.66666793823242 L480,161.00000127156574 L489.6666666666667,156.00000127156574 L501,154.00000127156574 L526.6666666666667,152.66666793823242 L612,168.00000127156574 L645.6666666666666,177.66666793823242 L665.3333333333334,186.00000127156574 L668,187.33333460489905 L672,192.00000127156574 L687.6666666666666,205.33333460489905 L693.3333333333334,206.66666793823242 L709,208.00000127156574 L730.3333333333334,202.33333460489905 L742.6666666666666,194.66666793823242 L759.3333333333334,173.66666793823242 L763.6666666666666,148.00000127156574 L765,130.33333460489908 L762.6666666666666,126.66666793823242 L761,125.00000127156574 L756.3333333333334,123.33333460489908 L745,123.33333460489908 L737.3333333333334,128.00000127156574 L722,144.33333460489908 L720.3333333333334,148.33333460489908 L719.6666666666666,146.33333460489908 L718.6666666666666,136.66666793823242 L718.6666666666666,127.00000127156574 L724.6666666666666,113.33333460489908 L741,105.33333460489908 L764.6666666666666,103.66666793823242 L796,113.66666793823242 L801.3333333333334,116.66666793823242 L807,119.00000127156574 L817.3333333333334,117.66666793823242 L818,115.00000127156574 L817,110.00000127156574 L816.3333333333334,109.00000127156574 L816,109.00000127156574", "field_75975": "{\\"action\\":\\"SAIDA\\",\\"timestamp\\":\\"2026-04-02T18:31:01.016Z\\",\\"coordinates\\":{\\"lat\\":-23.569983,\\"lng\\":-46.7851655},\\"address\\":\\"Parque Chico Mendes,  - Jd Bussocaba City, Osasco - SP\\"}", "__time_field_4248": "2026-04-02T18:31:40.775Z", "__time_field_21036": "2026-04-02T18:32:08.565Z", "__time_field_66812": "2026-04-02T18:31:53.660Z", "__time_field_75000": "2026-04-02T18:32:31.588Z", "__time_field_75975": "2026-04-02T18:31:01.016Z", "__section_end_page_1": "2026-04-02T18:32:37.205Z", "__section_start_page_1": "2026-04-02T18:31:01.039Z"}	{"icon": "build-outline", "refId": "chk_mnhro4is", "title": "Rota", "acceptedAt": "2026-04-02T18:30:53.912Z", "appVersion": "1.0", "receivedAt": "2026-04-02T18:30:48.175Z", "description": "Tarefa de rotina despachada.", "devicePlatform": "AppMovel", "durationSeconds": 103}	\N	-17.20713	-49.918002	150	segment	[[-17.205391, -49.946573], [-17.208869, -49.889431]]	null	2026-04-02 18:30:53.941	2026-04-02 18:32:37.205	2026-04-02 18:32:37.615	2026-04-02 18:30:45.52	\N
cmnhtnyp4001zf5jrvv0r23qa	chk_mnhro4is	alex@brspark.com	\N	COMPLETED	{"field_4248": "{\\"action\\":\\"CHEGADA\\",\\"timestamp\\":\\"2026-04-02T18:44:07.697Z\\",\\"coordinates\\":{\\"lat\\":-23.569983,\\"lng\\":-46.7851655},\\"address\\":\\"Parque Chico Mendes,  - Jd Bussocaba City, Osasco - SP\\",\\"traversedPath\\":[[-23.569983,-46.7851655],[-23.569983,-46.7851655],[37.33240731,-122.03046898],[37.33240731,-122.03046898],[37.33233141,-122.0312186],[37.33233141,-122.0312186],[37.33233141,-122.0312186],[37.33233141,-122.0312186],[37.33233141,-122.0312186],[37.33233141,-122.0312186]]}", "field_21036": "http://localhost:3001/uploads/storage/checklists/unknown_empresa_com/cmnhtnyp4001zf5jrvv0r23qa_field_21036_1775155517486.jpg", "field_75000": "SIG_V1|meta:{\\"lat\\":-23.569983,\\"lng\\":-46.7851655,\\"address\\":\\",  - Osasco, SP\\",\\"ip\\":\\"2804:7f0:9383:8b58:b9fe:d321:ec05:865c\\"}|M57.66666666666674,189.66666793823242 L230.00000000000003,106.33333460489908 L266.00000000000006,92.00000127156574 L320.00000000000006,69.00000127156574 L352.00000000000006,56.33333460489908 L346.00000000000006,60.000001271565736 L331.00000000000006,72.33333460489908 L316.6666666666667,82.66666793823242 L282.33333333333337,102.33333460489908 L206.00000000000003,135.33333460489908 L154.33333333333337,154.33333460489908 L116.66666666666671,169.00000127156574 L99.00000000000004,177.33333460489908 L99.00000000000004,177.66666793823242 L99.66666666666671,177.33333460489908 L125.33333333333337,169.66666793823242 L193.00000000000003,152.00000127156574 L262.6666666666667,137.66666793823242 L332.33333333333337,125.00000127156574 L372.00000000000006,120.33333460489908 L372.33333333333337,120.33333460489908 L365.00000000000006,125.00000127156574 L339.33333333333337,135.66666793823242 L325.6666666666667,141.66666793823242 L298.00000000000006,151.00000127156574 L268.33333333333337,160.33333460489908 L256.6666666666667,164.66666793823242 L238.66666666666669,170.00000127156574 L239.33333333333337,170.00000127156574 L244.66666666666669,170.66666793823242 L247.33333333333337,170.66666793823242 L247.66666666666669,170.66666793823242 L248.00000000000006,171.00000127156574 L248.66666666666669,171.00000127156574 L254.00000000000006,169.00000127156574 L284.00000000000006,155.00000127156574 L306.33333333333337,144.66666793823242 L372.33333333333337,114.33333460489908 L448.33333333333337,87.00000127156574 L514,73.00000127156574 L545.6666666666667,74.00000127156574 L552.6666666666667,84.33333460489908 L554,104.00000127156574 L534,142.00000127156574 L525,153.33333460489908 L517.3333333333334,157.33333460489908 L509.66666666666674,159.66666793823242 L506.33333333333337,160.00000127156574 L498.66666666666674,161.00000127156574 L489,164.00000127156574 L486.33333333333337,165.66666793823242 L485,166.66666793823242 L485,167.00000127156574 L484.6666666666667,167.00000127156574 L470.33333333333337,168.33333460489908 L462.6666666666667,168.33333460489908 L449,168.33333460489908 L433.6666666666667,168.33333460489908 L416.00000000000006,165.66666793823242 L413.33333333333337,165.00000127156574 L413.00000000000006,164.66666793823242 L412.33333333333337,163.33333460489908|M455.33333333333337,132.33333460489908 L459.6666666666667,133.33333460489908 L471,134.66666793823242 L490.6666666666667,137.00000127156574 L506,138.33333460489908 L514.3333333333334,138.33333460489908|M407.66666666666674,96.00000127156574 L483,82.33333460489908 L556.6666666666667,73.33333460489908 L688,66.33333460489908 L708.3333333333334,68.33333460489908 L675.3333333333334,91.33333460489908 L619.6666666666666,105.33333460489908 L558,114.33333460489908 L532.3333333333334,117.66666793823242 L531.6666666666667,118.00000127156574 L545.3333333333334,118.00000127156574 L601,112.66666793823242 L668.6666666666666,111.00000127156574 L734.3333333333334,111.00000127156574 L782.3333333333334,126.33333460489908 L723.6666666666666,189.00000127156574 L658,208.66666793823242 L578.3333333333334,216.00000127156574 L494.66666666666674,216.00000127156574 L409.00000000000006,206.66666793823242 L341.33333333333337,194.33333460489905 L293.6666666666667,182.33333460489908 L276.00000000000006,178.66666793823242 L276.33333333333337,178.66666793823242 L288.00000000000006,178.66666793823242|M503.33333333333337,172.66666793823242 L504.33333333333337,172.66666793823242 L505.66666666666674,172.66666793823242 L515.3333333333334,171.33333460489908 L551,170.00000127156574 L610.6666666666666,164.66666793823242 L734,148.66666793823242 L773.6666666666666,142.00000127156574 L807,139.00000127156574 L810.3333333333334,138.33333460489908 L811.3333333333334,138.33333460489908 L811.6666666666666,139.00000127156574 L813.6666666666666,140.00000127156574 L823.6666666666666,147.33333460489908 L827.3333333333334,151.00000127156574 L829,152.66666793823242 L831.3333333333334,156.33333460489908 L833.6666666666666,160.00000127156574 L834,160.66666793823242 L834,160.33333460489908 L836.3333333333334,148.66666793823242 L837.6666666666666,137.00000127156574 L839.6666666666666,126.66666793823242 L840,126.66666793823242 L840.3333333333334,128.00000127156574 L847.3333333333334,138.33333460489908 L850.3333333333334,144.00000127156574 L853.6666666666666,147.66666793823242 L855,148.66666793823242 L853.6666666666666,140.33333460489908 L853.6666666666666,135.00000127156574 L854.3333333333334,135.33333460489908 L855.3333333333334,136.66666793823242 L855.6666666666666,137.33333460489908 L856.3333333333334,138.33333460489908|M40.33333333333337,239.66666793823242 L41.00000000000005,239.00000127156574 L53.00000000000004,225.00000127156574 L58.666666666666714,222.00000127156574 L66.33333333333339,219.00000127156574 L69.66666666666671,219.00000127156574 L73.33333333333339,220.66666793823242 L88.66666666666671,233.33333460489905 L101.66666666666671,242.33333460489905 L109.33333333333337,247.00000127156574 L131.6666666666667,257.33333460489905 L147.33333333333337,261.33333460489905 L176.33333333333337,255.33333460489905 L188.00000000000003,243.66666793823242 L194.00000000000003,232.00000127156574 L196.33333333333337,220.33333460489905 L196.6666666666667,218.00000127156574 L197.33333333333337,218.00000127156574 L198.00000000000003,218.00000127156574 L258.6666666666667,243.33333460489905 L321.6666666666667,256.00000127156574 L341.33333333333337,256.00000127156574 L343.6666666666667,256.00000127156574 L343.6666666666667,255.33333460489905 L347.6666666666667,250.33333460489905 L361.6666666666667,241.33333460489905 L375.33333333333337,234.00000127156574 L397.33333333333337,222.00000127156574 L423.00000000000006,213.00000127156574 L464.33333333333337,207.00000127156574 L486,207.00000127156574 L505.66666666666674,211.33333460489905 L527,219.66666793823242 L530.3333333333334,220.33333460489905 L536,219.66666793823242 L541.6666666666667,218.33333460489905 L551.3333333333334,216.00000127156574 L558.6666666666667,213.33333460489905 L570.3333333333334,210.66666793823242 L575,209.66666793823242 L590.3333333333334,210.66666793823242 L598,212.66666793823242 L607.6666666666666,214.66666793823242 L617,214.66666793823242 L624.6666666666666,214.66666793823242 L640.3333333333334,212.33333460489905 L664,207.66666793823242 L685.6666666666666,205.00000127156574 L697,203.33333460489905 L707.3333333333334,205.33333460489905 L720.6666666666666,209.66666793823242 L724.3333333333334,210.33333460489905 L728,209.66666793823242 L729.6666666666666,209.00000127156574 L732,208.33333460489905 L735.6666666666666,208.33333460489905 L736.6666666666666,208.33333460489905 L738.6666666666666,210.00000127156574 L748.3333333333334,214.33333460489905 L758,219.33333460489905 L769.6666666666666,223.00000127156574 L779,223.33333460489905 L790.3333333333334,222.33333460489905 L796,220.00000127156574 L800.6666666666666,217.66666793823242 L801.3333333333334,217.33333460489905 L803,218.00000127156574 L811.6666666666666,223.33333460489905 L825.6666666666666,231.33333460489905 L833.3333333333334,234.33333460489905 L838,234.33333460489905 L843,234.00000127156574 L845.3333333333334,233.33333460489905 L847.6666666666666,233.33333460489905 L853.3333333333334,235.33333460489905 L861,238.33333460489905 L865.6666666666666,238.66666793823242 L867.6666666666666,238.66666793823242 L867.6666666666666,238.33333460489905 L876.3333333333334,233.66666793823242 L887.6666666666666,231.66666793823242 L889.6666666666666,231.00000127156574 L890,231.00000127156574", "field_75975": "{\\"action\\":\\"SAIDA\\",\\"timestamp\\":\\"2026-04-02T18:43:34.763Z\\",\\"coordinates\\":{\\"lat\\":-23.569983,\\"lng\\":-46.7851655},\\"address\\":\\"Parque Chico Mendes,  - Jd Bussocaba City, Osasco - SP\\"}", "__time_field_4248": "2026-04-02T18:44:07.697Z", "__time_field_21036": "2026-04-02T18:44:18.060Z", "__time_field_75000": "2026-04-02T18:44:32.150Z", "__time_field_75975": "2026-04-02T18:43:34.763Z", "__section_end_page_1": "2026-04-02T18:45:17.414Z", "__section_start_page_1": "2026-04-02T18:43:34.808Z"}	{"icon": "build-outline", "refId": "chk_mnhro4is", "title": "Rota", "acceptedAt": "2026-04-02T18:42:53.337Z", "appVersion": "1.0", "receivedAt": "2026-04-02T18:42:40.125Z", "description": "Tarefa de rotina despachada.", "devicePlatform": "AppMovel", "durationSeconds": 144}	\N	-16.174903	-51.91452	150	segment	[[-16.153347, -51.70166], [-16.19646, -52.12738]]	null	2026-04-02 18:42:53.356	2026-04-02 18:45:17.414	2026-04-02 18:45:17.714	2026-04-02 18:42:35.752	\N
cmnhykdhy0005k84w6xci9f1x	chk_mnhro4is	alex@brspark.com	\N	COMPLETED	{"field_4248": "{\\"action\\":\\"CHEGADA\\",\\"timestamp\\":\\"2026-04-02T21:12:10.632Z\\",\\"coordinates\\":{\\"lat\\":37.34154237,\\"lng\\":-122.09108423},\\"address\\":\\"I-280,  - The Highlands, Los Altos - CA\\",\\"traversedPath\\":[[37.33485843,-122.03334424],[37.33485843,-122.03334424],[37.33485843,-122.03334424],[37.33485843,-122.03334424],[37.33482105,-122.03350886],[37.33482105,-122.03350886],[37.33477977,-122.03369603],[37.33477977,-122.03369603],[37.33474691,-122.03389325],[37.33474691,-122.03389325],[37.33470894,-122.03411085],[37.33470894,-122.03411085],[37.33467638,-122.03432425],[37.33467638,-122.03432425],[37.33464561,-122.03455442],[37.33464561,-122.03455442],[37.33461946,-122.03478727],[37.33461946,-122.03478727],[37.33460316,-122.0350347],[37.33460316,-122.0350347],[37.33458564,-122.03529395],[37.33458564,-122.03529395],[37.3345628,-122.03556217],[37.3345628,-122.03556217],[37.3345597,-122.03583308],[37.3345597,-122.03583308],[37.33454847,-122.03611286],[37.33454847,-122.03611286],[37.33454218,-122.03638578],[37.33454218,-122.03638578],[37.33454235,-122.03666775],[37.33454235,-122.03666775],[37.33453849,-122.03695223],[37.33453849,-122.03695223],[37.33453874,-122.03724626],[37.33453874,-122.03724626],[37.33453652,-122.03753997],[37.33453652,-122.03753997],[37.33452613,-122.03783266],[37.33452613,-122.03783266],[37.33451917,-122.03813827],[37.33451917,-122.03813827],[37.33451284,-122.03845141],[37.33451284,-122.03845141],[37.33450379,-122.03875937],[37.33450379,-122.03875937],[37.33449629,-122.03908048],[37.33449629,-122.03908048],[37.33448791,-122.03941089],[37.33448791,-122.03941089],[37.33447622,-122.0397398],[37.33447622,-122.0397398],[37.33447068,-122.04007348],[37.33447068,-122.04007348],[37.33446519,-122.04041597],[37.33446519,-122.04041597],[37.3344584,-122.04077831],[37.3344584,-122.04077831],[37.33445283,-122.04113765],[37.33445283,-122.04113765],[37.3344499,-122.04149924],[37.3344499,-122.04149924],[37.33444604,-122.04187567],[37.33444604,-122.04187567],[37.33444843,-122.04226334],[37.33444843,-122.04226334],[37.33444952,-122.04265083],[37.33444952,-122.04265083],[37.33445363,-122.04302852],[37.33445363,-122.04302852],[37.33445945,-122.04342255],[37.33445945,-122.04342255],[37.33446146,-122.04380955],[37.33446146,-122.04380955],[37.33445832,-122.04420408],[37.33445832,-122.04420408],[37.33445442,-122.04458579],[37.33445442,-122.04458579],[37.33444763,-122.04496063],[37.33444763,-122.04496063],[37.33444244,-122.045341],[37.33444244,-122.045341],[37.33443657,-122.04571727],[37.33443657,-122.04571727],[37.33441708,-122.04607568],[37.33441708,-122.04607568],[37.3343947,-122.04644121],[37.3343947,-122.04644121],[37.33436235,-122.04681002],[37.33436235,-122.04681002],[37.33431797,-122.04716524],[37.33431797,-122.04716524],[37.33426985,-122.04751058],[37.33426985,-122.04751058],[37.33420971,-122.04784191],[37.33420971,-122.04784191],[37.33414287,-122.04818683],[37.33414287,-122.04818683],[37.33406324,-122.04853007],[37.33406324,-122.04853007],[37.33398776,-122.04886543],[37.33398776,-122.04886543],[37.33390604,-122.04921638],[37.33390604,-122.04921638],[37.3338288,-122.04956959],[37.3338288,-122.04956959],[37.33375445,-122.04992666],[37.33375445,-122.04992666],[37.33367998,-122.05028306],[37.33367998,-122.05028306],[37.33360693,-122.05063996],[37.33360693,-122.05063996],[37.33352458,-122.05100549],[37.33352458,-122.05100549],[37.33344889,-122.05137547],[37.33344889,-122.05137547],[37.33336511,-122.05174034],[37.33336511,-122.05174034],[37.33328787,-122.05209673],[37.33328787,-122.05209673],[37.33321101,-122.05246948],[37.33321101,-122.05246948],[37.33313411,-122.05283635],[37.33313411,-122.05283635],[37.33305632,-122.05318781],[37.33305632,-122.05318781],[37.33298105,-122.0535463],[37.33298105,-122.0535463],[37.33290406,-122.05391527],[37.33290406,-122.05391527],[37.33282486,-122.05427997],[37.33282486,-122.05427997],[37.33275353,-122.05462472],[37.33275353,-122.05462472],[37.33268517,-122.05498531],[37.33268517,-122.05498531],[37.33260475,-122.05535361],[37.33260475,-122.05535361],[37.33252881,-122.05571688],[37.33252881,-122.05571688],[37.33245639,-122.05608208],[37.33245639,-122.05608208],[37.33238246,-122.05644652],[37.33238246,-122.05644652],[37.33236209,-122.05682698],[37.33236209,-122.05682698],[37.33232211,-122.05719234],[37.33232211,-122.05719234],[37.33229772,-122.05757204],[37.33229772,-122.05757204],[37.332289,-122.05795133],[37.332289,-122.05795133],[37.33228724,-122.05833354],[37.33228724,-122.05833354],[37.33230505,-122.05871525],[37.33230505,-122.05871525],[37.33233606,-122.05909629],[37.33233606,-122.05909629],[37.33238246,-122.0594718],[37.33238246,-122.0594718],[37.33244004,-122.05984991],[37.33244004,-122.05984991],[37.33251376,-122.06021989],[37.33251376,-122.06021989],[37.33260198,-122.06059221],[37.33260198,-122.06059221],[37.33270432,-122.06095339],[37.33270432,-122.06095339],[37.33282574,-122.06131389],[37.33282574,-122.06131389],[37.3329513,-122.06167465],[37.3329513,-122.06167465],[37.33307736,-122.06203541],[37.33307736,-122.06203541],[37.33320782,-122.06239181],[37.33320782,-122.06239181],[37.33333498,-122.06274686],[37.33333498,-122.06274686],[37.33346293,-122.06310662],[37.33346293,-122.06310662],[37.33358639,-122.06346075],[37.33358639,-122.06346075],[37.33370957,-122.06381723],[37.33370957,-122.06381723],[37.33383844,-122.06417204],[37.33383844,-122.06417204],[37.33395407,-122.06452986],[37.33395407,-122.06452986],[37.33405917,-122.06489607],[37.33405917,-122.06489607],[37.33414928,-122.06526437],[37.33414928,-122.06526437],[37.33422447,-122.06562781],[37.33422447,-122.06562781],[37.33429383,-122.06600055],[37.33429383,-122.06600055],[37.33435409,-122.06636961],[37.33435409,-122.06636961],[37.33440019,-122.06674461],[37.33440019,-122.06674461],[37.33442928,-122.06711736],[37.33442928,-122.06711736],[37.3344465,-122.06749672],[37.3344465,-122.06749672],[37.3344543,-122.06787986],[37.3344543,-122.06787986],[37.33444654,-122.06826065],[37.33444654,-122.06826065],[37.33442613,-122.06864035],[37.33442613,-122.06864035],[37.33439537,-122.06901468],[37.33439537,-122.06901468],[37.33435661,-122.06939204],[37.33435661,-122.06939204],[37.33430397,-122.06976336],[37.33430397,-122.06976336],[37.33424182,-122.07013275],[37.33424182,-122.07013275],[37.33417438,-122.07050306],[37.33417438,-122.07050306],[37.33410968,-122.07087404],[37.33410968,-122.07087404],[37.33403923,-122.07123245],[37.33403923,-122.07123245],[37.33396475,-122.07160897],[37.33396475,-122.07160897],[37.33389384,-122.07197743],[37.33389384,-122.07197743],[37.33382775,-122.07235512],[37.33382775,-122.07235512],[37.33375801,-122.07272963],[37.33375801,-122.07272963],[37.33369775,-122.07309474],[37.33369775,-122.07309474],[37.33363907,-122.07346522],[37.33363907,-122.07346522],[37.33359159,-122.07381886],[37.33359159,-122.07381886],[37.33355651,-122.07417592],[37.33355651,-122.07417592],[37.33353728,-122.07453283],[37.33353728,-122.07453283],[37.33353065,-122.07488445],[37.33353065,-122.07488445],[37.33353363,-122.07523112],[37.33353363,-122.07523112],[37.33355228,-122.07558936],[37.33355228,-122.07558936],[37.33358308,-122.07595104],[37.33358308,-122.07595104],[37.33362663,-122.0763056],[37.33362663,-122.0763056],[37.33368006,-122.07665613],[37.33368006,-122.07665613],[37.33374934,-122.07700482],[37.33374934,-122.07700482],[37.33382825,-122.07735141],[37.33382825,-122.07735141],[37.33392322,-122.07769942],[37.33392322,-122.07769942],[37.33402871,-122.07804543],[37.33402871,-122.07804543],[37.33415037,-122.07838406],[37.33415037,-122.07838406],[37.3342805,-122.07872034],[37.3342805,-122.07872034],[37.33442102,-122.07904631],[37.33442102,-122.07904631],[37.33457244,-122.0793639],[37.33457244,-122.0793639],[37.33473735,-122.0796747],[37.33473735,-122.0796747],[37.33492184,-122.07997503],[37.33492184,-122.07997503],[37.33511119,-122.08026077],[37.33511119,-122.08026077],[37.33531428,-122.08054952],[37.33531428,-122.08054952],[37.33552177,-122.08082252],[37.33552177,-122.08082252],[37.33573891,-122.08110667],[37.33573891,-122.08110667],[37.33595575,-122.08138403],[37.33595575,-122.08138403],[37.33617167,-122.08165962],[37.33617167,-122.08165962],[37.33638536,-122.08193111],[37.33638536,-122.08193111],[37.33659906,-122.08220411],[37.33659906,-122.08220411],[37.33680278,-122.08247812],[37.33680278,-122.08247812],[37.3370055,-122.0827595],[37.3370055,-122.0827595],[37.33720302,-122.08304213],[37.33720302,-122.08304213],[37.3373963,-122.08332863],[37.3373963,-122.08332863],[37.33758129,-122.08362627],[37.33758129,-122.08362627],[37.33775509,-122.08392617],[37.33775509,-122.08392617],[37.33793145,-122.0842275],[37.33793145,-122.0842275],[37.33810893,-122.08454124],[37.33810893,-122.08454124],[37.3382842,-122.08484542],[37.3382842,-122.08484542],[37.3384549,-122.08515152],[37.3384549,-122.08515152],[37.33862249,-122.08545696],[37.33862249,-122.08545696],[37.33879885,-122.08577472],[37.33879885,-122.08577472],[37.3389669,-122.08608946],[37.3389669,-122.08608946],[37.33913576,-122.08640269],[37.33913576,-122.08640269],[37.33930008,-122.08670293],[37.33930008,-122.08670293],[37.33947623,-122.08701088],[37.33947623,-122.08701088],[37.3396502,-122.08732093],[37.3396502,-122.08732093],[37.33981846,-122.08762326],[37.33981846,-122.08762326],[37.33998434,-122.08792937],[37.33998434,-122.08792937],[37.3401493,-122.08824042],[37.3401493,-122.08824042],[37.34031484,-122.08856086],[37.34031484,-122.08856086],[37.34046597,-122.08886286],[37.34046597,-122.08886286],[37.34061718,-122.08917878],[37.34061718,-122.08917878],[37.34077165,-122.08949679],[37.34077165,-122.08949679],[37.34092739,-122.08983097],[37.34092739,-122.08983097],[37.34107194,-122.09015057],[37.34107194,-122.09015057],[37.34121879,-122.09045668],[37.34121879,-122.09045668],[37.34137909,-122.09077234],[37.34137909,-122.09077234],[37.34154237,-122.09108423],[37.34154237,-122.09108423]]}", "field_66812": "Não", "field_75000": "SIG_V1|meta:{\\"lat\\":37.34394974,\\"lng\\":-122.09415478,\\"address\\":\\"I-280,  - Los Altos, CA\\",\\"ip\\":\\"2804:7f0:9383:8b58:2cf9:997d:bbdb:7ecb\\"}|M154,194.66666793823242 L152,211.00000127156568 L131,209.00000127156568 L118,198.33333460489905 L99.66666666666666,179.00000127156574 L83.66666666666666,146.33333460489905 L77,108.66666793823242 L80,81.33333460489905 L93,64.00000127156574 L115.33333333333331,55.33333460489905 L163,68.00000127156574 L191,94.00000127156574 L211.66666666666666,121.33333460489905 L233.33333333333331,143.33333460489905 L247.66666666666663,152.33333460489905 L261.3333333333333,152.00000127156574 L281.3333333333333,140.66666793823242 L301.3333333333333,120.66666793823242 L316.66666666666663,96.00000127156574 L325.66666666666663,70.66666793823242 L328.66666666666663,51.000001271565736 L328.66666666666663,50.66666793823242 L326.3333333333333,56.66666793823242 L325,78.00000127156574 L325,109.66666793823242 L323.3333333333333,143.33333460489905 L322,167.00000127156574 L313.66666666666663,183.33333460489905 L306.3333333333333,185.00000127156568 L282.66666666666663,185.00000127156568 L241,181.66666793823242 L205.33333333333331,175.00000127156574 L171.66666666666666,168.66666793823242 L142,164.00000127156574 L108.66666666666666,154.00000127156574 L102.33333333333333,149.66666793823242 L103.33333333333333,150.33333460489905 L119.66666666666666,159.33333460489905 L143.33333333333331,165.33333460489905 L181,170.00000127156574 L244.33333333333331,173.33333460489905 L278,175.00000127156574 L305.66666666666663,176.66666793823242 L307.66666666666663,176.66666793823242 L307.3333333333333,176.66666793823242 L307,176.66666793823242", "field_75975": "{\\"action\\":\\"SAIDA\\",\\"timestamp\\":\\"2026-04-02T21:09:19.276Z\\",\\"coordinates\\":{\\"lat\\":37.33485843,\\"lng\\":-122.03334424},\\"address\\":\\"N De Anza Blvd, 10889 - Santa Clara, Cupertino - CA\\"}", "__time_field_4248": "2026-04-02T21:12:10.633Z", "__time_field_66812": "2026-04-02T21:12:16.012Z", "__time_field_75000": "2026-04-02T21:12:22.238Z", "__time_field_75975": "2026-04-02T21:09:19.276Z", "__section_end_page_1": "2026-04-02T21:12:23.147Z", "__section_start_page_1": "2026-04-02T21:09:19.301Z"}	{"icon": "build-outline", "refId": "chk_mnhro4is", "title": "Rota", "acceptedAt": "2026-04-02T21:08:34.389Z", "appVersion": "1.0", "receivedAt": "2026-04-02T21:03:42.530Z", "description": "Tarefa de rotina despachada.", "devicePlatform": "AppMovel", "durationSeconds": 228}	\N	-15.388346	-49.145966	150	segment	[[-15.380536, -49.21875], [-15.396156, -49.073181]]	null	2026-04-02 21:08:34.48	2026-04-02 21:12:23.147	2026-04-02 21:12:23.244	2026-04-02 20:59:46.389	\N
cmnjfk8rd000113umj9nh2mw1	\N	alex@brspark.com	\N	RECEIVED	\N	{"icon": "navigate-circle", "title": "OS-02 (Médio, Vence Hoje)", "dueDate": "2026-04-04T05:43:19.897Z", "receivedAt": "2026-04-03T21:49:06.500Z"}	Local Simulado - OS-02 (Médio, Vence Hoje)	-23.5455	-46.6283	\N	\N	\N	\N	\N	\N	\N	2026-04-03 21:43:19.897	\N
cmni1npwo045ck84w2mp3uaqv	chk_mnhro4is	alex@brspark.com	\N	COMPLETED	{"field_4248": "{\\"action\\":\\"CHEGADA\\",\\"timestamp\\":\\"2026-04-03T00:10:35.503Z\\",\\"coordinates\\":{\\"lat\\":37.45094125,\\"lng\\":-122.27950028},\\"address\\":\\"I-280,  - San Mateo, Woodside - CA\\",\\"traversedPath\\":[[37.42556261,-122.23036783]]}", "field_75975": "{\\"action\\":\\"SAIDA\\",\\"timestamp\\":\\"2026-04-02T22:27:58.339Z\\",\\"coordinates\\":{\\"lat\\":37.5784743,\\"lng\\":-122.40192879},\\"address\\":\\"I-280,  - Mills Estates, Burlingame - CA\\"}", "__time_field_4248": "2026-04-03T00:10:35.503Z", "__time_field_75975": "2026-04-02T22:27:58.339Z", "__section_end_page_1": "2026-04-03T00:10:39.118Z", "__section_start_page_1": "2026-04-02T22:27:58.372Z"}	{"icon": "build-outline", "refId": "chk_mnhro4is", "title": "Rota", "acceptedAt": "2026-04-02T22:27:45.283Z", "appVersion": "1.0", "receivedAt": "2026-04-02T22:26:22.530Z", "description": "Tarefa de rotina despachada.", "devicePlatform": "AppMovel", "durationSeconds": 166}	apple	42.764352	-84.514731	200	radius	null	null	2026-04-03 00:07:52.398	2026-04-03 00:10:39.119	2026-04-03 00:10:39.294	2026-04-02 22:26:21.288	2474
cmni5h43y00mpkaef20ijrtel	chk_mnhro4is	alex@brspark.com	\N	COMPLETED	{"field_75000": "SIG_V1|meta:{\\"lat\\":37.49913263,\\"lng\\":-122.31702405,\\"address\\":\\"I-280,  - Belmont, CA\\",\\"ip\\":\\"2804:7f0:9383:8b58:2cf9:997d:bbdb:7ecb\\"}|M274,194.33333460489905 L241,212.66666793823242 L180,209.33333460489905 L147.66666666666666,196.66666793823242 L116.66666666666666,172.00000127156574 L93.33333333333333,133.33333460489905 L90.33333333333333,99.66666793823242 L96,74.00000127156574 L112,59.66666793823242 L139.66666666666666,53.66666793823242 L171,58.33333460489905 L193.33333333333331,68.66666793823242 L204.33333333333331,78.66666793823242 L210.33333333333331,89.00000127156574 L211.33333333333331,100.66666793823242 L208,112.33333460489905 L198.66666666666666,121.33333460489905 L175.33333333333331,130.66666793823242 L147.66666666666666,132.00000127156574 L120,132.00000127156574 L98.33333333333333,127.66666793823242 L96,125.66666793823242 L95.66666666666666,122.00000127156574 L99,110.66666793823242 L111.66666666666666,105.00000127156574 L137.33333333333331,102.00000127156574 L163,105.00000127156574 L188.33333333333331,114.00000127156574 L214.66666666666666,127.66666793823242 L247.33333333333331,147.33333460489905 L263,153.66666793823242 L269,155.00000127156574", "field_75975": "{\\"action\\":\\"SAIDA\\",\\"timestamp\\":\\"2026-04-03T00:13:28.654Z\\",\\"coordinates\\":{\\"lat\\":37.4950032,\\"lng\\":-122.30641809},\\"address\\":\\"I-280,  - Belmont Heights, Redwood City - CA\\"}", "__time_field_75000": "2026-04-03T00:14:00.646Z", "__time_field_75975": "2026-04-03T00:13:28.654Z", "__section_end_page_1": "2026-04-03T00:14:01.352Z", "__section_start_page_1": "2026-04-03T00:13:28.685Z"}	{"icon": "build-outline", "refId": "chk_mnhro4is", "title": "Rota", "acceptedAt": "2026-04-03T00:13:21.045Z", "appVersion": "1.0", "receivedAt": "2026-04-03T00:13:12.466Z", "description": "Tarefa de rotina despachada.", "devicePlatform": "AppMovel", "durationSeconds": 40}	nyc	40.712728	-74.006015	200	radius	null	null	2026-04-03 00:13:21.065	2026-04-03 00:14:01.352	2026-04-03 00:14:01.54	2026-04-03 00:13:11.566	3108
cmni0qayq02sqk84wy5bpuvea	chk_mnhro4is	alex@brspark.com	\N	COMPLETED	{"field_4248": "{\\"action\\":\\"CHEGADA\\",\\"timestamp\\":\\"2026-04-02T22:04:50.463Z\\",\\"coordinates\\":{\\"lat\\":37.33500926,\\"lng\\":-122.03272188},\\"address\\":\\"N De Anza Blvd, 10889 - Santa Clara, Cupertino - CA\\",\\"traversedPath\\":[[37.33021988,-122.02396374],[37.33021988,-122.02396374],[37.33021988,-122.02396374],[37.33021988,-122.02396374],[37.33021717,-122.02382845],[37.33021717,-122.02382845],[37.33021864,-122.02370753],[37.33021864,-122.02370753],[37.33022668,-122.02358845],[37.33022668,-122.02358845],[37.33022057,-122.023459],[37.33022057,-122.023459],[37.33020882,-122.0233343],[37.33020882,-122.0233343],[37.33019792,-122.02320222],[37.33019792,-122.02320222],[37.33019502,-122.02306835],[37.33019502,-122.02306835],[37.33019527,-122.02294631],[37.33019527,-122.02294631],[37.33019055,-122.02282064],[37.33019055,-122.02282064],[37.3301749,-122.02269435],[37.3301749,-122.02269435],[37.33015856,-122.02257019],[37.33015856,-122.02257019],[37.33013541,-122.02244406],[37.33013541,-122.02244406],[37.3301169,-122.02230795],[37.3301169,-122.02230795],[37.33010689,-122.02216391],[37.33010689,-122.02216391],[37.33010478,-122.02202626],[37.33010478,-122.02202626],[37.33010093,-122.02188644],[37.33010093,-122.02188644],[37.33009437,-122.02175602],[37.33009437,-122.02175602],[37.33008848,-122.02162795],[37.33008848,-122.02162795],[37.33008277,-122.02149879],[37.33008277,-122.02149879],[37.33008066,-122.02136042],[37.33008066,-122.02136042],[37.33007095,-122.02122343],[37.33007095,-122.02122343],[37.33006472,-122.02108977],[37.33006472,-122.02108977]]}", "field_75000": "SIG_V1|meta:{\\"lat\\":37.33470894,\\"lng\\":-122.03411085,\\"address\\":\\"I-280,  - Cupertino, CA\\",\\"ip\\":\\"2804:7f0:9383:8b58:2cf9:997d:bbdb:7ecb\\"}|M100,187.00000127156568 L98.66666666666666,158.00000127156574 L108,112.33333460489905 L115.66666666666666,110.00000127156574 L127,111.00000127156574 L133,114.33333460489905 L140.33333333333331,122.00000127156574 L186,191.66666793823242 L202,220.00000127156568 L208.33333333333331,228.33333460489905 L212,230.66666793823242 L218.33333333333331,230.66666793823242 L225,225.00000127156568 L241.66666666666663,202.00000127156568 L256,172.00000127156574 L265.3333333333333,142.33333460489905 L269.3333333333333,124.00000127156574 L269.3333333333333,124.66666793823242 L274.3333333333333,133.33333460489905 L282.3333333333333,142.66666793823242 L296.66666666666663,161.33333460489905 L300.3333333333333,165.00000127156574 L300.66666666666663,165.00000127156574 L300.3333333333333,164.33333460489905", "field_75975": "{\\"action\\":\\"SAIDA\\",\\"timestamp\\":\\"2026-04-02T22:00:41.378Z\\",\\"coordinates\\":{\\"lat\\":37.33021988,\\"lng\\":-122.02396374},\\"address\\":\\"Merritt Dr, 20046 - Santa Clara, Cupertino - CA\\"}", "__time_field_4248": "2026-04-02T22:04:50.463Z", "__time_field_75000": "2026-04-02T22:04:59.124Z", "__time_field_75975": "2026-04-02T22:00:41.378Z", "__section_end_page_1": "2026-04-02T22:04:59.870Z", "__section_start_page_1": "2026-04-02T22:00:41.412Z"}	{"icon": "build-outline", "refId": "chk_mnhro4is", "title": "Rota", "acceptedAt": "2026-04-02T22:00:29.125Z", "appVersion": "1.0", "receivedAt": "2026-04-02T22:00:25.014Z", "description": "Tarefa de rotina despachada.", "devicePlatform": "AppMovel", "durationSeconds": 270}	\N	-15.68897	-51.010208	150	segment	[[-15.688493, -51.020508], [-15.689447, -50.999908]]	null	2026-04-02 22:00:29.202	2026-04-02 22:04:59.87	2026-04-02 22:04:59.945	2026-04-02 22:00:22.274	\N
cmni0yc0l034gk84wpt1ucqfp	chk_mnhro4is	alex@brspark.com	\N	COMPLETED	{"field_4248": "{\\"action\\":\\"CHEGADA\\",\\"timestamp\\":\\"2026-04-03T00:52:31.240Z\\",\\"coordinates\\":{\\"lat\\":37.50799594,\\"lng\\":-122.34003061},\\"address\\":\\"I-280,  - San Mateo, San Mateo - CA\\",\\"traversedPath\\":[[37.36921459,-122.14094005],[37.36921459,-122.14094005],[37.36945654,-122.1411796],[37.3697059,-122.14141823],[37.36994839,-122.1416339],[37.37019243,-122.14186189],[37.37043777,-122.14209172],[37.37068524,-122.14231367],[37.37092857,-122.14253931],[37.37117332,-122.14276269],[37.37142067,-122.14297886],[37.37167049,-122.14320232],[37.37190954,-122.14341883],[37.37215601,-122.14364204],[37.37240005,-122.14386038],[37.37263743,-122.14409064],[37.37287229,-122.14430781],[37.37311268,-122.14451887],[37.37336271,-122.14472699],[37.37361371,-122.14495984],[37.37385134,-122.14517802],[37.37409077,-122.14540877],[37.37433481,-122.14563986],[37.37457281,-122.14588663],[37.37481249,-122.14611939],[37.37503792,-122.14636347],[37.37527039,-122.14662055],[37.37550207,-122.14687494],[37.37572427,-122.14713511],[37.37595557,-122.14739872],[37.37618545,-122.14766024],[37.37641444,-122.14792309],[37.37664016,-122.14817958],[37.37686895,-122.14843858],[37.37709618,-122.14869624],[37.37732484,-122.14894979],[37.37755308,-122.14919429],[37.37778312,-122.14944148],[37.3780272,-122.14968145],[37.37828075,-122.14990349],[37.37854172,-122.15010976],[37.3787954,-122.15030297],[37.37906991,-122.15049139],[37.37933964,-122.15066314],[37.37961188,-122.15082139],[37.37989138,-122.15096748],[37.38018479,-122.15110721],[37.38048092,-122.15123277],[37.38078049,-122.15133956],[37.38107985,-122.15143117],[37.38139635,-122.15151398],[37.38170908,-122.15158724],[37.38201841,-122.1516569],[37.38232167,-122.15171758],[37.3826398,-122.15178036],[37.38294604,-122.15184264],[37.38325235,-122.15190458],[37.38355637,-122.15196543],[37.38386583,-122.15203945],[37.38417047,-122.1521117],[37.38447544,-122.1522008],[37.3847595,-122.15231454],[37.38505698,-122.15241395],[37.3853594,-122.15250213],[37.38560981,-122.15272559],[37.38587685,-122.15289608],[37.38612831,-122.15307537],[37.386369,-122.15330226],[37.38660109,-122.15352321],[37.38681491,-122.15376042],[37.38703695,-122.15399578],[37.38723661,-122.15426073],[37.38741594,-122.15453155],[37.38758433,-122.15481075],[37.38774539,-122.15510789],[37.38789928,-122.15540746],[37.38803876,-122.15572505],[37.38816025,-122.156047],[37.38827425,-122.1563775],[37.38837114,-122.1567204],[37.38845823,-122.15706146],[37.38852302,-122.15740629],[37.38858496,-122.15776739],[37.38863873,-122.158132],[37.38869141,-122.15849049],[37.38875059,-122.15884924],[37.38880101,-122.1592167],[37.38885423,-122.15958014],[37.38890729,-122.15994434],[37.38896215,-122.16030945],[37.38901726,-122.16067063],[37.38907593,-122.16102912],[37.38913788,-122.16138829],[37.38921159,-122.16173186],[37.38931302,-122.16207476],[37.38941926,-122.16241959],[37.3895291,-122.16275705],[37.38966543,-122.16308369],[37.38980415,-122.16341017],[37.38995968,-122.16372751],[37.39012296,-122.1640311],[37.39029043,-122.16432732],[37.39046125,-122.16462739],[37.39063719,-122.16493601],[37.39081987,-122.1652427],[37.39099698,-122.16555409],[37.39117204,-122.16586866],[37.3913512,-122.16618625],[37.3915027,-122.16651214],[37.39163715,-122.16684775],[37.3917638,-122.16719669],[37.3918726,-122.16754831],[37.39195948,-122.16790371],[37.39203734,-122.16826622],[37.39210109,-122.16863067],[37.39215096,-122.16899562],[37.39218696,-122.16936325],[37.39221512,-122.16972115],[37.39223168,-122.17009373],[37.39225456,-122.17045658],[37.39228038,-122.17082706],[37.39229995,-122.17118816],[37.39232727,-122.17156408],[37.3923673,-122.17192878],[37.39242056,-122.17227965],[37.39248364,-122.1726285],[37.39256301,-122.17298624],[37.3926514,-122.17333149],[37.39275592,-122.17367289],[37.39286883,-122.17400749],[37.39299238,-122.17434528],[37.39312741,-122.17466882],[37.39327728,-122.17497485],[37.39343838,-122.17526897],[37.39361482,-122.17556879],[37.39379704,-122.17585612],[37.3939863,-122.17612996],[37.39418919,-122.17640321],[37.39440066,-122.17665986],[37.39462396,-122.17690042],[37.39485119,-122.17713419],[37.3950793,-122.17736604],[37.39531442,-122.1776014],[37.39555665,-122.17782746],[37.39578711,-122.17805511],[37.39602298,-122.17827723],[37.3962622,-122.17851528],[37.39650092,-122.1787452],[37.3967429,-122.17897754],[37.39698455,-122.17921131],[37.39723081,-122.17945213],[37.39747477,-122.17969227],[37.39771939,-122.17994381],[37.39796347,-122.18018889],[37.39821434,-122.18044236],[37.3984663,-122.18069307],[37.39871722,-122.18093396],[37.39896494,-122.18117586],[37.39921816,-122.1814238],[37.39946853,-122.181674],[37.39971672,-122.18192127],[37.39996889,-122.18216065],[37.4002115,-122.18241295],[37.40046241,-122.18266432],[37.40071157,-122.18290622],[37.400959,-122.183155],[37.40120241,-122.18340059],[37.40145169,-122.18364475],[37.40169564,-122.1838916],[37.40193507,-122.18412948],[37.40217513,-122.18438102],[37.40241452,-122.18462099],[37.40265001,-122.18486407],[37.40289006,-122.18510882],[37.40313012,-122.18535374],[37.40336963,-122.1855891],[37.40360986,-122.18583235],[37.40384703,-122.1860652],[37.40408658,-122.18630827],[37.40432366,-122.18655336],[37.4045589,-122.18679358],[37.40479565,-122.1870328],[37.40503252,-122.18726691],[37.40526516,-122.18750898],[37.40549529,-122.18774837],[37.40572269,-122.18797644],[37.40595558,-122.18821616],[37.406187,-122.18845228],[37.40641352,-122.18869619],[37.40662722,-122.18894731],[37.40684142,-122.18921084],[37.40704434,-122.18948518],[37.40723826,-122.18975642],[37.40741516,-122.19004383],[37.40759705,-122.19035128],[37.40776758,-122.19065295],[37.40792864,-122.19096048],[37.40807192,-122.19127153],[37.4082122,-122.19160295],[37.40834241,-122.19193731],[37.40846332,-122.19227342],[37.4085771,-122.19260911],[37.4086895,-122.19295621],[37.40879583,-122.19330498],[37.40890928,-122.19364872],[37.4090174,-122.19399146],[37.40913001,-122.19434853],[37.40924065,-122.19469587],[37.40934673,-122.19504967],[37.40945674,-122.19540213],[37.40957019,-122.19575593],[37.40968519,-122.19611107],[37.40979918,-122.19646479],[37.40991313,-122.19680962],[37.41002813,-122.19717013],[37.41013974,-122.1975256],[37.41025751,-122.19788477],[37.41036953,-122.19824251],[37.41048306,-122.19859798],[37.41059111,-122.19895765],[37.41070502,-122.19932176],[37.41082094,-122.19968311],[37.41093715,-122.20005677],[37.41105102,-122.20042583],[37.4111682,-122.20078524],[37.41128521,-122.20114273],[37.41140537,-122.20150659],[37.41152166,-122.20187338],[37.41163599,-122.20224059],[37.4117546,-122.20260026],[37.41187169,-122.20296881],[37.41198812,-122.20333192],[37.41210932,-122.20369519],[37.41221975,-122.20406123],[37.41233794,-122.20442475],[37.41245025,-122.20479062],[37.41256089,-122.20514618],[37.412672,-122.20550149],[37.4127875,-122.20586509],[37.41290506,-122.20622074],[37.41302483,-122.20658359],[37.41316012,-122.20691443],[37.41331028,-122.20726311],[37.41347243,-122.20759654],[37.41363889,-122.20791833],[37.41381696,-122.20823265],[37.4140136,-122.20853406],[37.41421573,-122.20883313],[37.41442675,-122.20911895],[37.41464292,-122.20938734],[37.41487543,-122.2096481],[37.41511369,-122.2099019],[37.41535131,-122.21013769],[37.41558768,-122.21037783],[37.41583072,-122.2106204],[37.41606407,-122.21084956],[37.41629629,-122.21107403],[37.41652076,-122.21132892],[37.41674342,-122.21159681],[37.41694823,-122.2118667],[37.41715007,-122.21215672],[37.41733217,-122.21244011],[37.41751498,-122.21274345],[37.41767838,-122.2130587],[37.41782917,-122.21338064],[37.41796601,-122.21370276],[37.41809689,-122.21404449],[37.41821562,-122.21438304],[37.41832178,-122.21472125],[37.41841264,-122.21506373],[37.41849109,-122.21541158],[37.41856183,-122.21577393],[37.41862281,-122.2161253],[37.41867524,-122.21647315],[37.41872658,-122.21683566],[37.41878215,-122.21719827],[37.41883236,-122.2175664],[37.41888362,-122.21793663],[37.41894149,-122.21831725],[37.41900025,-122.2186972],[37.41905687,-122.21907137],[37.41911693,-122.21945669],[37.41919475,-122.21983287],[37.41926445,-122.22021307],[37.41935866,-122.22058933],[37.41947328,-122.22094841],[37.41959201,-122.22131613],[37.41973228,-122.2216711],[37.41987612,-122.22201677],[37.42003034,-122.22234886],[37.42020951,-122.22268498],[37.42039831,-122.22300357],[37.42059239,-122.22330339],[37.42079209,-122.22359156],[37.4209964,-122.22388736],[37.42120016,-122.22417637],[37.42140481,-122.22446999],[37.42160254,-122.22475346],[37.42180622,-122.225047],[37.42201069,-122.22533902],[37.42221534,-122.22563264],[37.42241462,-122.22592475],[37.42261989,-122.22622172],[37.4228281,-122.22651609],[37.42303224,-122.22680837],[37.42323378,-122.22710299],[37.4234391,-122.22739879],[37.42364424,-122.22769744],[37.42384553,-122.22799483],[37.42404586,-122.22828543],[37.42425797,-122.228585],[37.42447057,-122.22888717],[37.42467819,-122.22918858],[37.42488967,-122.22949008],[37.42510651,-122.22979057],[37.42533181,-122.230081],[37.42556261,-122.23036783],[37.42579001,-122.23064896],[37.42602726,-122.23093034],[37.42625701,-122.23121884],[37.42648156,-122.23149125],[37.42670804,-122.23176442],[37.42693422,-122.2320453],[37.42715911,-122.23231779],[37.42738525,-122.23260102],[37.42760419,-122.23287838],[37.42782208,-122.23316965],[37.42803355,-122.23345363],[37.4282366,-122.23374641],[37.42843241,-122.23403357],[37.42864388,-122.23433674],[37.42884257,-122.23462642],[37.42904315,-122.23491979],[37.42923061,-122.23520217],[37.42942843,-122.23549663],[37.4296205,-122.23578187],[37.42981596,-122.23606668],[37.43000183,-122.23633968],[37.43019797,-122.23662618],[37.43039276,-122.23690446],[37.43058329,-122.23718642],[37.43077117,-122.23745867],[37.43097283,-122.23774147],[37.43117949,-122.23802512],[37.4313864,-122.23829728],[37.43159783,-122.23857312],[37.43180499,-122.23884881],[37.43201856,-122.23912625],[37.43223557,-122.23939589],[37.43245161,-122.2396533],[37.43267436,-122.23992789],[37.43289145,-122.2401848],[37.43311575,-122.24044723],[37.4333289,-122.24069492],[37.43354365,-122.24095367],[37.43376254,-122.2412125],[37.43397854,-122.24146731],[37.43419065,-122.24171885],[37.43441436,-122.24197802],[37.43463237,-122.24223434],[37.43484389,-122.24249443],[37.43505231,-122.24274589],[37.43527279,-122.24300522],[37.4354937,-122.24325056],[37.4357105,-122.24350931],[37.43592675,-122.24376328],[37.43614275,-122.24402287],[37.43636085,-122.24428128],[37.43657798,-122.24454213],[37.43679541,-122.24480163],[37.43701413,-122.24506994],[37.43723487,-122.24533942],[37.43745284,-122.24560906],[37.43767153,-122.24587351],[37.4378918,-122.24613695],[37.43811023,-122.24639931],[37.43832108,-122.24665353],[37.43853587,-122.24691999],[37.43875183,-122.24718427],[37.43896456,-122.24745174],[37.43917407,-122.24771351],[37.43938236,-122.2479746],[37.43958193,-122.24823553],[37.43979265,-122.24850384],[37.44000262,-122.24876996],[37.44020462,-122.24902871],[37.4404132,-122.24929609],[37.44063097,-122.24957228],[37.44083486,-122.2498348],[37.44103455,-122.25010327],[37.44124096,-122.25037308],[37.44145696,-122.25065195],[37.4416554,-122.25091933],[37.44186575,-122.25118672],[37.44207177,-122.25146784],[37.44226175,-122.25174277],[37.44244976,-122.2520301],[37.4426298,-122.25232825],[37.44279802,-122.25263335],[37.44296361,-122.25294834],[37.4431162,-122.2532692],[37.4432615,-122.25358947],[37.44339993,-122.25391846],[37.44352696,-122.25425533],[37.44364246,-122.25458952],[37.44374342,-122.25493183],[37.44384262,-122.25528153],[37.44392589,-122.25564044],[37.44400414,-122.25598745],[37.44406453,-122.25634385],[37.44411847,-122.25671014],[37.44416092,-122.25706779],[37.44419763,-122.25743668],[37.44422018,-122.2577904],[37.44423451,-122.25815644],[37.444239,-122.25851887],[37.44423414,-122.25888331],[37.44422039,-122.25925044],[37.44420115,-122.25962444],[37.44417706,-122.25999425],[37.44414135,-122.2603566],[37.44411151,-122.26071711],[37.44407878,-122.26109077],[37.44404961,-122.26145748],[37.44401797,-122.26182293],[37.4439888,-122.26217958],[37.44395519,-122.26255308],[37.4439248,-122.26291149],[37.44389345,-122.26327367],[37.44386206,-122.26362152],[37.44383398,-122.26398513],[37.44382032,-122.26434982],[37.44380955,-122.26471217],[37.44380964,-122.26507343],[37.44381697,-122.26544651],[37.44383755,-122.26580291],[37.44387418,-122.2661656],[37.4439116,-122.26651906],[37.44395875,-122.2668851],[37.44401474,-122.26724552],[37.44407484,-122.26760192],[37.44414998,-122.26795069],[37.44423405,-122.26830767],[37.4443312,-122.26865661],[37.4444387,-122.26900388],[37.44455051,-122.26933513],[37.44466932,-122.2696948],[37.44480641,-122.27002035],[37.44494848,-122.27035697],[37.44509613,-122.2706904],[37.44525815,-122.27101285],[37.44542697,-122.27132935],[37.44559578,-122.27164133],[37.44578948,-122.27195431],[37.44598499,-122.27225807],[37.44618796,-122.27255411],[37.44638988,-122.27285016],[37.44658966,-122.27313817],[37.4467998,-122.27344452],[37.44701194,-122.27374359],[37.44721944,-122.27404475],[37.44742701,-122.27433854],[37.44763979,-122.27464045],[37.44784481,-122.27493843],[37.44805758,-122.27523289],[37.44826202,-122.275525],[37.44847416,-122.27582658],[37.448683,-122.27613252],[37.44889519,-122.27643795],[37.44910327,-122.27674381],[37.44931173,-122.27705394],[37.44952769,-122.27735443],[37.44973334,-122.27765291],[37.44993366,-122.27796229],[37.45014137,-122.27827786],[37.45033956,-122.27858925],[37.45054416,-122.27890148],[37.45073833,-122.27919962],[37.45094125,-122.27950028],[37.45113567,-122.27979667],[37.45133281,-122.28009883],[37.45152933,-122.28040075],[37.45173531,-122.28071046],[37.45193614,-122.28100978],[37.45213903,-122.28131706],[37.45233453,-122.28161336],[37.45253138,-122.2819136],[37.45272358,-122.28220948],[37.45291645,-122.28250536],[37.45311074,-122.28279923],[37.45331094,-122.28309729],[37.4535041,-122.28339124],[37.45369182,-122.28369081],[37.45388669,-122.28397991],[37.45408782,-122.28428358],[37.45428831,-122.28458122],[37.45448608,-122.28487643],[37.4546849,-122.28517332],[37.45488322,-122.28547306],[37.45508011,-122.28577665],[37.45527792,-122.28607664],[37.45547402,-122.28638241],[37.45567627,-122.28668651],[37.45587534,-122.28698641],[37.45607437,-122.28728422],[37.45627918,-122.2875661],[37.45649921,-122.28784438],[37.45672979,-122.28811109],[37.45696847,-122.28836834],[37.45721393,-122.28861267],[37.45747289,-122.28884594],[37.45773575,-122.28906747],[37.45799802,-122.28927291],[37.45827194,-122.28946385],[37.45855399,-122.28964389],[37.45883663,-122.2898065],[37.4591201,-122.28995444],[37.45940794,-122.29009543],[37.45970105,-122.29022333],[37.46000272,-122.29033506],[37.4603017,-122.29043087],[37.46059989,-122.29050438],[37.46090604,-122.29058057],[37.46120146,-122.29063145],[37.46150337,-122.29066665],[37.4617959,-122.29070035],[37.46211156,-122.29069557],[37.46240946,-122.29070345],[37.46270563,-122.29070404],[37.46299866,-122.29070546],[37.46330188,-122.29072667],[37.46359839,-122.29073807],[37.46390399,-122.29075357],[37.46419317,-122.29077419],[37.46449927,-122.29080537],[37.46480278,-122.29083781],[37.46509996,-122.29088517],[37.46539392,-122.29094711],[37.46569047,-122.29101039],[37.46598459,-122.29109271],[37.46627448,-122.2911808],[37.46656022,-122.29127786],[37.46685325,-122.2913901],[37.46713857,-122.2915087],[37.46741706,-122.29164222],[37.46768876,-122.29178052],[37.46797307,-122.29193961],[37.46825147,-122.29210281],[37.46852845,-122.29226818],[37.46878976,-122.29244219],[37.46905295,-122.29263363],[37.46930994,-122.29282659],[37.46956224,-122.2930368],[37.46980661,-122.29324794],[37.47004943,-122.29347317],[37.47029083,-122.29370551],[37.47052113,-122.29393953],[37.47074882,-122.29417431],[37.47098645,-122.29441454],[37.47121917,-122.29465652],[37.47146019,-122.2948939],[37.47169204,-122.29512775],[37.47193243,-122.29536731],[37.47216892,-122.29559597],[37.4724045,-122.29584441],[37.47263575,-122.29607826],[37.47287359,-122.29631245],[37.47310992,-122.29655586],[37.47335094,-122.29678896],[37.47358589,-122.2970276],[37.47382733,-122.29725927],[37.47407652,-122.29748533],[37.47432651,-122.29770016],[37.47457788,-122.29788741],[37.47484795,-122.29807718],[37.47511504,-122.29823928],[37.47539512,-122.29839703],[37.47567109,-122.29853676],[37.47596509,-122.29866961],[37.47624844,-122.2987909],[37.47654113,-122.29890078],[37.47684146,-122.29899726],[37.47714065,-122.29908334],[37.47744621,-122.29914235],[37.47775391,-122.29919189],[37.47805503,-122.29923078],[37.47836852,-122.29925626],[37.47867584,-122.29926607],[37.47898412,-122.29925944],[37.47928265,-122.29924209],[37.47959504,-122.29920555],[37.47990379,-122.2991675],[37.4802021,-122.29911704],[37.48050104,-122.29907018],[37.48081016,-122.29901151],[37.48112252,-122.29896314],[37.48143034,-122.2989116],[37.48173368,-122.29885946],[37.48204679,-122.298808],[37.48235759,-122.2987603],[37.48267635,-122.29871948],[37.48296448,-122.29865444],[37.48327373,-122.29860566],[37.48356664,-122.29855578],[37.48386847,-122.29850608],[37.48415014,-122.29845126],[37.48445327,-122.29839963],[37.48475481,-122.29834808],[37.48503934,-122.29830106],[37.48532885,-122.29825278],[37.48563043,-122.29819888],[37.48591847,-122.29817122],[37.48621553,-122.29814482],[37.48651279,-122.29812764],[37.4868127,-122.2981216],[37.48710786,-122.29813317],[37.48739461,-122.29817064],[37.48769154,-122.29820324],[37.48799584,-122.29825412],[37.48829411,-122.29831883],[37.48859201,-122.29839276],[37.48888495,-122.29847339],[37.48917912,-122.29858571],[37.48946004,-122.29870481],[37.48974125,-122.29883038],[37.49001354,-122.2989727],[37.49029144,-122.29912802],[37.49056217,-122.29928702],[37.49082205,-122.29946086],[37.49107368,-122.29964744],[37.49132392,-122.29984542],[37.49157223,-122.30005455],[37.49181631,-122.30027064],[37.49204087,-122.30049762],[37.49226793,-122.30073474],[37.49248645,-122.30098033],[37.49270362,-122.30124361],[37.49291363,-122.30150194],[37.49311425,-122.30178114],[37.4933028,-122.30206319],[37.49348327,-122.30235572],[37.49365765,-122.30264875],[37.49382537,-122.3029686],[37.49398501,-122.30329282],[37.49413538,-122.3036213],[37.4942736,-122.30394979],[37.49440854,-122.30430233],[37.49453457,-122.30464079],[37.49465019,-122.30499317],[37.49474508,-122.30534303],[37.49483455,-122.30570278],[37.49492022,-122.30606044],[37.4950032,-122.30641809],[37.49508765,-122.30676787],[37.4951695,-122.30711999],[37.49526052,-122.30747757],[37.49534774,-122.3078343],[37.49543424,-122.30818156],[37.49551793,-122.30853058],[37.49560338,-122.30887726],[37.49568959,-122.30922528],[37.49577391,-122.30957279],[37.49585849,-122.30990413],[37.49594792,-122.31024913],[37.49605031,-122.31058583],[37.49615642,-122.31092429],[37.49627109,-122.3112651],[37.4963855,-122.3116028],[37.49651253,-122.31193732],[37.49664228,-122.31227193],[37.49677685,-122.31259857],[37.4969214,-122.3129258],[37.49707671,-122.31324792],[37.49722931,-122.31356593],[37.49739544,-122.3138981],[37.49756731,-122.31420698],[37.49773922,-122.31452188],[37.49791545,-122.31482925],[37.49809315,-122.31513904],[37.49826623,-122.31545236],[37.49844611,-122.31576031],[37.49861551,-122.31606927],[37.49878972,-122.31639398],[37.49896071,-122.3167052],[37.49913263,-122.31702405],[37.49929918,-122.31733326],[37.49945868,-122.31765789],[37.49961262,-122.31799141],[37.49975176,-122.31832375],[37.4998836,-122.31865844],[37.50000963,-122.31899774],[37.50012324,-122.31933419],[37.50022097,-122.31968044],[37.50031464,-122.32001857],[37.50040366,-122.32036315],[37.50048014,-122.32070412],[37.50055478,-122.32105281],[37.50061761,-122.32139966],[37.50067142,-122.32174776],[37.50071626,-122.32209695],[37.50075222,-122.32244974],[37.50077879,-122.32279709],[37.50080075,-122.32315935],[37.50081869,-122.32352505],[37.50083658,-122.32388539],[37.50085414,-122.32423844],[37.50087108,-122.32460448],[37.50088822,-122.32496557],[37.50090716,-122.32532817],[37.5009279,-122.32568004],[37.5009559,-122.32605421],[37.50098964,-122.32641698],[37.50103859,-122.32677815],[37.50110145,-122.32713539],[37.50117039,-122.32749548],[37.50124793,-122.32784417],[37.50133564,-122.32819947],[37.50142772,-122.32853953],[37.5015348,-122.32888352],[37.50165151,-122.32922148],[37.50177946,-122.32955407],[37.50191839,-122.32988348],[37.50206047,-122.33020769],[37.50221411,-122.33052126],[37.50237035,-122.33083005],[37.50254205,-122.33112878],[37.50272247,-122.33142131],[37.50290511,-122.33172046],[37.50308189,-122.33201986],[37.50326432,-122.33231474],[37.50345136,-122.33261204],[37.5036348,-122.33291144],[37.5038171,-122.33321034],[37.50401014,-122.33350505],[37.50420426,-122.33381577],[37.50438925,-122.33410746],[37.50457248,-122.33441357],[37.50475667,-122.33470618],[37.50494397,-122.33500575],[37.50513223,-122.33533541],[37.50532023,-122.33564227],[37.50550258,-122.33594871],[37.5056856,-122.33626303],[37.50587968,-122.33657258],[37.50606869,-122.33688933],[37.50625289,-122.33719083],[37.50645233,-122.33750892],[37.50664554,-122.33782793],[37.50683681,-122.33813589],[37.50702897,-122.33844744],[37.50722033,-122.33876671],[37.50740674,-122.33908229],[37.50760535,-122.33940046],[37.50780014,-122.33971445],[37.50799594,-122.34003061]]}", "field_75000": "SIG_V1|meta:{\\"lat\\":37.46741706,\\"lng\\":-122.29164222,\\"address\\":\\"I-280,  - Redwood City, CA\\",\\"ip\\":\\"2804:7f0:9383:8b58:2cf9:997d:bbdb:7ecb\\"}|M242.33333333333331,117.33333460489905 L208.33333333333331,163.00000127156574 L175.66666666666666,182.66666793823242 L140,191.00000127156568 L82.66666666666666,186.66666793823242 L67.33333333333333,174.00000127156574 L55.66666666666666,152.00000127156574 L46.66666666666666,126.33333460489905 L53.33333333333333,96.33333460489905 L68,108.66666793823242 L81.33333333333333,121.00000127156574 L129.33333333333331,155.00000127156574 L159.33333333333331,170.66666793823242 L181,178.00000127156574 L189.66666666666666,180.66666793823242 L190.33333333333331,179.66666793823242", "field_75975": "{\\"action\\":\\"SAIDA\\",\\"timestamp\\":\\"2026-04-03T00:39:57.722Z\\",\\"coordinates\\":{\\"lat\\":37.36921459,\\"lng\\":-122.14094005},\\"address\\":\\"I-280,  - Santa Clara, Los Altos Hills - CA\\"}", "__time_field_4248": "2026-04-03T00:52:31.241Z", "__time_field_75000": "2026-04-03T01:26:21.423Z", "__time_field_75975": "2026-04-03T00:39:57.722Z", "__section_end_page_1": "2026-04-03T01:26:22.337Z", "__section_start_page_1": "2026-04-03T00:39:57.750Z"}	{"icon": "build-outline", "refId": "chk_mnhro4is", "title": "Rota", "acceptedAt": "2026-04-03T00:39:52.830Z", "appVersion": "1.0", "receivedAt": "2026-04-02T22:06:41.098Z", "description": "alex@brspark.com", "trackingToken": "7f661d543f084c747bdc969c", "devicePlatform": "AppMovel", "durationSeconds": 634, "trackingExpiredAt": null, "trackingStartedAt": "2026-04-03T00:39:57.482Z"}	\N	-14.840603	-51.328125	200	radius	null	null	2026-04-03 01:15:47.717	2026-04-03 01:26:22.337	2026-04-03 01:26:22.498	2026-04-02 22:06:36.885	\N
cmnj3zrof019dhojaj8wfptwn	chk_mnhro4is	alex@brspark.com	\N	COMPLETED	{"field_4248": "{\\"action\\":\\"CHEGADA\\",\\"timestamp\\":\\"2026-04-03T23:37:59.515Z\\",\\"coordinates\\":{\\"lat\\":-23.56719990594579,\\"lng\\":-46.78624607857089},\\"address\\":\\"Avenida Avedis Kamalakian, 27 - Bussocaba, Osasco - SP\\",\\"traversedPath\\":[[-23.567192890805433,-46.78624951054749],[-23.56719289080536,-46.78624951054763],[-23.56719176861247,-46.78624942803273]]}", "field_21036": "http://192.168.15.73:3001/uploads/storage/checklists/unknown_empresa_com/cmnj3zrof019dhojaj8wfptwn_field_21036_1775259525339.jpg", "field_40882": "http://192.168.15.73:3001/uploads/storage/checklists/unknown_empresa_com/cmnj3zrof019dhojaj8wfptwn_field_40882_1775259525172.jpg", "field_57585": "http://192.168.15.73:3001/uploads/storage/checklists/unknown_empresa_com/cmnj3zrof019dhojaj8wfptwn_field_57585_1775259524433.png", "field_66812": "Não", "field_75000": "SIG_V1|meta:{\\"lat\\":-23.56714827050559,\\"lng\\":-46.78624997313588,\\"address\\":\\"Avenida Avedis Kamalakian, 27 - Osasco, SP\\",\\"ip\\":\\"2804:7f0:9383:8b58:f5d4:b6b0:401e:cf7f\\"}|M58.66666666666666,201.9999987284342 L63,198.6666653951009 L85.66666666666666,181.6666653951009 L96.33333333333333,171.6666653951009 L108,158.6666653951009 L121.66666666666666,143.9999987284342 L148,112.9999987284342 L159.33333333333331,98.9999987284342 L168.66666666666666,87.66666539510089 L178.66666666666666,76.33333206176758 L179.33333333333331,76.33333206176758 L178.33333333333331,79.33333206176758 L167,95.66666539510089 L158.66666666666666,106.66666539510089 L138.33333333333331,131.33333206176758 L128.33333333333331,143.6666653951009 L114.33333333333331,161.33333206176758 L111.33333333333331,165.6666653951009 L111,166.33333206176758 L115.33333333333331,163.9999987284342 L123.66666666666666,156.6666653951009 L144.33333333333331,135.9999987284342 L155,123.9999987284342 L178,100.9999987284342 L188.66666666666666,91.33333206176758 L204.33333333333331,80.9999987284342 L207.66666666666666,80.33333206176758 L208.66666666666666,82.66666539510089 L208.33333333333331,88.33333206176758 L201,103.66666539510089 L195,113.33333206176758 L182.33333333333331,132.33333206176758 L176.33333333333331,140.33333206176758 L165,154.33333206176758 L159.33333333333331,159.9999987284342 L154.33333333333331,164.33333206176758 L144.33333333333331,168.6666653951009 L135.33333333333331,168.9999987284342 L130.33333333333331,167.6666653951009 L125,163.6666653951009 L114,154.33333206176758 L102.66666666666666,145.6666653951009 L98,142.33333206176758 L94,139.6666653951009 L89.33333333333333,137.33333206176758 L90.33333333333333,137.33333206176758 L94,137.6666653951009 L99,138.6666653951009 L115,142.33333206176758 L125.33333333333331,143.9999987284342 L148.66666666666666,147.9999987284342 L161,149.9999987284342 L187,153.9999987284342 L200.33333333333331,154.9999987284342 L225.33333333333331,155.6666653951009 L236.33333333333331,155.6666653951009 L253.33333333333331,153.9999987284342 L258.3333333333333,151.9999987284342 L260.66666666666663,151.33333206176758 L259,151.33333206176758 L254,151.9999987284342 L245.66666666666663,155.6666653951009 L221.66666666666666,164.33333206176758 L207,168.33333206176758 L176,174.6666653951009 L160.33333333333331,176.9999987284342 L129.66666666666666,179.9999987284342 L116.66666666666666,180.6666653951009 L100.66666666666666,181.33333206176758 L99.66666666666666,181.33333206176758 L101.33333333333333,181.33333206176758 L121.66666666666666,180.9999987284342 L137.66666666666666,179.9999987284342 L174.66666666666666,177.33333206176758 L185.66666666666666,177.33333206176758", "field_75975": "{\\"action\\":\\"SAIDA\\",\\"timestamp\\":\\"2026-04-03T23:36:56.033Z\\",\\"coordinates\\":{\\"lat\\":-23.567192890805433,\\"lng\\":-46.78624951054749},\\"address\\":\\"Avenida Avedis Kamalakian, 27 - Bussocaba, Osasco - SP\\"}", "__time_field_4248": "2026-04-03T23:37:59.515Z", "__time_field_21036": "2026-04-03T23:38:37.981Z", "__time_field_40882": "2026-04-03T23:38:30.399Z", "__time_field_57585": "2026-04-03T23:38:15.234Z", "__time_field_66812": "2026-04-03T23:38:01.977Z", "__time_field_75000": "2026-04-03T23:38:43.549Z", "__time_field_75975": "2026-04-03T23:36:56.033Z", "__section_end_page_1": "2026-04-03T23:38:44.391Z", "__section_start_page_1": "2026-04-03T23:36:56.065Z"}	{"icon": "build-outline", "refId": "chk_mnhro4is", "title": "Rota", "acceptedAt": "2026-04-03T23:36:52.223Z", "appVersion": "1.0", "receivedAt": "2026-04-03T16:19:30.339Z", "description": "Tarefa de rotina despachada.", "trackingToken": "22a161f47e9cf8dc8fe1e4ab", "devicePlatform": "AppMovel", "durationSeconds": 112, "trackingEndedAt": "2026-04-03T23:37:59.559Z", "trackingExpiredAt": "2026-04-03T23:52:59.559Z", "trackingStartedAt": "2026-04-03T23:36:55.873Z"}	\N	-23.563294	-46.829739	200	radius	null	null	2026-04-03 23:36:52.305	2026-04-03 23:38:44.391	2026-04-03 23:38:45.601	2026-04-03 16:19:28.863	8
cmni8b8rv02ox708n5s952fjt	chk_mnhro4is	alex@brspark.com	\N	COMPLETED	{"field_4248": "{\\"action\\":\\"CHEGADA\\",\\"timestamp\\":\\"2026-04-03T03:12:50.359Z\\",\\"coordinates\\":{\\"lat\\":-23.569983,\\"lng\\":-46.7851655},\\"address\\":\\"Parque Chico Mendes,  - Jd Bussocaba City, Osasco - SP\\",\\"traversedPath\\":[[-23.569983,-46.7851655],[-23.569983,-46.7851655]]}", "field_75000": "SIG_V1|meta:{\\"lat\\":-23.569983,\\"lng\\":-46.7851655,\\"address\\":\\",  - Osasco, SP\\",\\"ip\\":\\"2804:7f0:9383:8b58:2cf9:997d:bbdb:7ecb\\"}|M244.33333333333331,194.00000127156568 L225,226.66666793823242 L189.66666666666666,225.33333460489905 L167.66666666666666,213.33333460489905 L134.66666666666666,187.00000127156568 L106.66666666666666,160.66666793823242 L76.33333333333333,117.33333460489905 L73.66666666666666,101.66666793823242 L76.66666666666666,93.00000127156574 L88.33333333333333,87.33333460489905 L111.66666666666666,86.33333460489905 L135.33333333333331,87.66666793823242 L159,95.00000127156574 L168,102.66666793823242 L175,113.33333460489905 L176.33333333333331,117.00000127156574 L176.66666666666666,120.33333460489905 L176.33333333333331,125.00000127156574 L171,134.66666793823242 L164,144.00000127156574 L158.66666666666666,151.00000127156574 L158.66666666666666,151.33333460489905 L158.66666666666666,151.66666793823242 L158.66666666666666,154.00000127156574", "field_75975": "{\\"action\\":\\"SAIDA\\",\\"timestamp\\":\\"2026-04-03T03:00:27.087Z\\",\\"coordinates\\":{\\"lat\\":-23.569983,\\"lng\\":-46.7851655},\\"address\\":\\"Parque Chico Mendes,  - Jd Bussocaba City, Osasco - SP\\"}", "__time_field_4248": "2026-04-03T03:12:50.359Z", "__time_field_75000": "2026-04-03T03:12:58.241Z", "__time_field_75975": "2026-04-03T03:00:27.087Z", "__section_end_page_1": "2026-04-03T03:12:59.054Z", "__section_start_page_1": "2026-04-03T03:00:27.124Z"}	{"icon": "build-outline", "refId": "chk_mnhro4is", "title": "Rota", "acceptedAt": "2026-04-03T03:00:24.843Z", "appVersion": "1.0", "receivedAt": "2026-04-03T01:33:58.933Z", "description": "Tarefa de rotina despachada.", "trackingToken": "614b99f9547ec80d7ae271f6", "devicePlatform": "AppMovel", "durationSeconds": 754, "trackingExpiredAt": null, "trackingStartedAt": "2026-04-03T03:00:26.867Z"}	Rua primitiva vianco osasco brasil	-23.52844	-46.77564	200	radius	null	null	2026-04-03 03:00:24.877	2026-04-03 03:12:59.055	2026-04-03 03:12:59.56	2026-04-03 01:32:36.522	10
cmni0zakf035wk84wuzy84yix	chk_mnhro4is	alex@brspark.com	\N	COMPLETED	{"field_4248": "{\\"action\\":\\"CHEGADA\\",\\"timestamp\\":\\"2026-04-02T22:11:11.258Z\\",\\"coordinates\\":{\\"lat\\":37.37709618,\\"lng\\":-122.14869624},\\"address\\":\\"I-280,  - Santa Clara, Los Altos Hills - CA\\",\\"traversedPath\\":[[37.34415677,-122.09439031],[37.34415677,-122.09439031],[37.34415677,-122.09439031],[37.34415677,-122.09439031],[37.34434595,-122.09463741],[37.34434595,-122.09463741],[37.34453978,-122.09489641],[37.34453978,-122.09489641],[37.34472464,-122.09516438],[37.34472464,-122.09516438],[37.3448932,-122.0954383],[37.3448932,-122.0954383],[37.34505141,-122.09572596],[37.34505141,-122.09572596],[37.34520782,-122.0960117],[37.34520782,-122.0960117],[37.34534964,-122.09631924],[37.34534964,-122.09631924],[37.34548953,-122.096638],[37.34548953,-122.096638],[37.34562364,-122.09695274],[37.34562364,-122.09695274],[37.34576798,-122.09727888],[37.34576798,-122.09727888],[37.34590884,-122.09760787],[37.34590884,-122.09760787],[37.34604924,-122.0979434],[37.34604924,-122.0979434],[37.34619047,-122.09828781],[37.34619047,-122.09828781],[37.34633112,-122.09862728],[37.34633112,-122.09862728],[37.3464786,-122.09896549],[37.3464786,-122.09896549],[37.3466164,-122.09929791],[37.3466164,-122.09929791],[37.34676434,-122.09963352],[37.34676434,-122.09963352],[37.34690805,-122.09997509],[37.34690805,-122.09997509],[37.34705171,-122.10032243],[37.34705171,-122.10032243],[37.34719244,-122.1006624],[37.34719244,-122.1006624],[37.34733473,-122.10099349],[37.34733473,-122.10099349],[37.34747663,-122.10131879],[37.34747663,-122.10131879],[37.34762491,-122.1016513],[37.34762491,-122.1016513],[37.34777737,-122.10196336],[37.34777737,-122.10196336],[37.34794036,-122.10227399],[37.34794036,-122.10227399],[37.34812405,-122.10257499],[37.34812405,-122.10257499],[37.34831482,-122.10286198],[37.34831482,-122.10286198],[37.34851318,-122.10314001],[37.34851318,-122.10314001],[37.34872189,-122.10340186],[37.34872189,-122.10340186],[37.34894824,-122.1036539],[37.34894824,-122.1036539],[37.34918436,-122.10389589],[37.34918436,-122.10389589],[37.34941931,-122.10411164],[37.34941931,-122.10411164],[37.34966435,-122.10431859],[37.34966435,-122.10431859],[37.34991623,-122.10451573],[37.34991623,-122.10451573],[37.35016915,-122.1047086],[37.35016915,-122.1047086],[37.35042203,-122.10490214],[37.35042203,-122.10490214],[37.3506804,-122.10509685],[37.3506804,-122.10509685],[37.3509353,-122.10529449],[37.3509353,-122.10529449],[37.35119518,-122.1054944],[37.35119518,-122.1054944],[37.35145376,-122.10569934],[37.35145376,-122.10569934],[37.35170078,-122.10589849],[37.35170078,-122.10589849],[37.35194528,-122.10610938],[37.35194528,-122.10610938],[37.35218349,-122.10633762],[37.35218349,-122.10633762],[37.35240938,-122.10656821],[37.35240938,-122.10656821],[37.35262907,-122.10682025],[37.35262907,-122.10682025],[37.35283833,-122.10707414],[37.35283833,-122.10707414],[37.35304318,-122.1073468],[37.35304318,-122.1073468],[37.35322775,-122.10761167],[37.35322775,-122.10761167],[37.35340125,-122.10789012],[37.35340125,-122.10789012],[37.35357644,-122.10818206],[37.35357644,-122.10818206],[37.35373217,-122.10847987],[37.35373217,-122.10847987],[37.35388229,-122.10878137],[37.35388229,-122.10878137],[37.35402763,-122.10909116],[37.35402763,-122.10909116],[37.35416275,-122.10941512],[37.35416275,-122.10941512],[37.354285,-122.10973833],[37.354285,-122.10973833],[37.35439853,-122.1100721],[37.35439853,-122.1100721],[37.35450989,-122.11040469],[37.35450989,-122.11040469],[37.35460422,-122.11074625],[37.35460422,-122.11074625],[37.35470108,-122.11109678],[37.35470108,-122.11109678],[37.35478615,-122.11144128],[37.35478615,-122.11144128],[37.35486926,-122.11178469],[37.35486926,-122.11178469],[37.3549592,-122.11213723],[37.3549592,-122.11213723],[37.35504792,-122.11248818],[37.35504792,-122.11248818],[37.35513836,-122.11282957],[37.35513836,-122.11282957],[37.35522226,-122.11317885],[37.35522226,-122.11317885],[37.35532071,-122.11352779],[37.35532071,-122.11352779],[37.35543424,-122.11386968],[37.35543424,-122.11386968],[37.35555758,-122.11420421],[37.35555758,-122.11420421],[37.35568444,-122.11452423],[37.35568444,-122.11452423],[37.35583234,-122.11484701],[37.35583234,-122.11484701],[37.35598347,-122.11516142],[37.35598347,-122.11516142],[37.35614335,-122.11546778],[37.35614335,-122.11546778],[37.35630592,-122.11577145],[37.35630592,-122.11577145],[37.35647419,-122.11607907],[37.35647419,-122.11607907],[37.35667204,-122.11636489],[37.35667204,-122.11636489],[37.35687073,-122.11663286],[37.35687073,-122.11663286],[37.35707534,-122.11689874],[37.35707534,-122.11689874],[37.35728082,-122.11715581],[37.35728082,-122.11715581],[37.3575003,-122.11741087],[37.3575003,-122.11741087],[37.35772158,-122.11764607],[37.35772158,-122.11764607],[37.35796495,-122.11787221],[37.35796495,-122.11787221],[37.35821377,-122.11808519],[37.35821377,-122.11808519],[37.35846644,-122.11829223],[37.35846644,-122.11829223],[37.35872263,-122.11848501],[37.35872263,-122.11848501],[37.3589945,-122.11866179],[37.3589945,-122.11866179],[37.35928216,-122.11883998],[37.35928216,-122.11883998],[37.35955814,-122.11901575],[37.35955814,-122.11901575],[37.35983897,-122.11918616],[37.35983897,-122.11918616],[37.36011952,-122.1193553],[37.36011952,-122.1193553],[37.36040727,-122.11952001],[37.36040727,-122.11952001],[37.36069305,-122.11969553],[37.36069305,-122.11969553],[37.3609743,-122.11986677],[37.3609743,-122.11986677],[37.36126096,-122.12003751],[37.36126096,-122.12003751],[37.36154377,-122.1202173],[37.36154377,-122.1202173],[37.36181958,-122.1204183],[37.36181958,-122.1204183],[37.36207862,-122.12062282],[37.36207862,-122.12062282],[37.36233305,-122.12084385],[37.36233305,-122.12084385],[37.36258266,-122.12108055],[37.36258266,-122.12108055],[37.36281941,-122.12133444],[37.36281941,-122.12133444],[37.36303768,-122.12160442],[37.36303768,-122.12160442],[37.36324345,-122.12188572],[37.36324345,-122.12188572],[37.36344328,-122.12218294],[37.36344328,-122.12218294],[37.36362588,-122.12248745],[37.36362588,-122.12248745],[37.36380169,-122.12279364],[37.36380169,-122.12279364],[37.36396061,-122.12310285],[37.36396061,-122.12310285],[37.36410876,-122.12341793],[37.36410876,-122.12341793],[37.36424153,-122.12374717],[37.36424153,-122.12374717],[37.36436332,-122.12407817],[37.36436332,-122.12407817],[37.36447237,-122.12441747],[37.36447237,-122.12441747],[37.36457081,-122.12476867],[37.36457081,-122.12476867],[37.36465673,-122.12512859],[37.36465673,-122.12512859],[37.36472923,-122.12549681],[37.36472923,-122.12549681],[37.3647884,-122.12586327],[37.3647884,-122.12586327],[37.36483488,-122.12623861],[37.36483488,-122.12623861],[37.36486694,-122.12661646],[37.36486694,-122.12661646],[37.36488463,-122.12699926],[37.36488463,-122.12699926],[37.36489573,-122.12737863],[37.36489573,-122.12737863],[37.36489494,-122.12775531],[37.36489494,-122.12775531],[37.36489561,-122.12814457],[37.36489561,-122.12814457],[37.36489536,-122.12851823],[37.36489536,-122.12851823],[37.36490102,-122.12889651],[37.36490102,-122.12889651],[37.364913,-122.12927755],[37.364913,-122.12927755],[37.36492641,-122.12966111],[37.36492641,-122.12966111],[37.36495642,-122.13002966],[37.36495642,-122.13002966],[37.36500231,-122.13039762],[37.36500231,-122.13039762],[37.36505801,-122.13076299],[37.36505801,-122.13076299],[37.36513495,-122.13112023],[37.36513495,-122.13112023],[37.36522619,-122.13147671],[37.36522619,-122.13147671],[37.36533088,-122.13182204],[37.36533088,-122.13182204],[37.36543834,-122.13217241],[37.36543834,-122.13217241],[37.36554852,-122.13253006],[37.36554852,-122.13253006],[37.36565505,-122.13287858],[37.36565505,-122.13287858],[37.36576171,-122.13322476],[37.36576171,-122.13322476],[37.3658664,-122.13358057],[37.3658664,-122.13358057],[37.36597474,-122.1339342],[37.36597474,-122.1339342],[37.36607239,-122.13427694],[37.36607239,-122.13427694],[37.36617599,-122.13462026],[37.36617599,-122.13462026],[37.36627984,-122.13496408],[37.36627984,-122.13496408],[37.36637342,-122.13530514],[37.36637342,-122.13530514],[37.3664761,-122.13564763],[37.3664761,-122.13564763],[37.36657341,-122.13598643],[37.36657341,-122.13598643],[37.36667454,-122.13633075],[37.36667454,-122.13633075],[37.3667825,-122.13667173],[37.3667825,-122.13667173],[37.3668918,-122.13700784],[37.3668918,-122.13700784],[37.36700588,-122.13734664],[37.36700588,-122.13734664],[37.36714083,-122.13768569],[37.36714083,-122.13768569],[37.36728357,-122.13801602],[37.36728357,-122.13801602],[37.36743034,-122.13834434],[37.36743034,-122.13834434],[37.36759001,-122.13866201],[37.36759001,-122.13866201],[37.36776176,-122.13898061],[37.36776176,-122.13898061],[37.36794754,-122.13929619],[37.36794754,-122.13929619],[37.36813371,-122.13959391],[37.36813371,-122.13959391],[37.36833646,-122.13988803],[37.36833646,-122.13988803],[37.36854278,-122.1401674],[37.36854278,-122.1401674],[37.36876231,-122.14043713],[37.36876231,-122.14043713],[37.36898397,-122.14069152],[37.36898397,-122.14069152],[37.36921459,-122.14094005],[37.36921459,-122.14094005],[37.36945654,-122.1411796],[37.36945654,-122.1411796],[37.3697059,-122.14141823],[37.3697059,-122.14141823],[37.36994839,-122.1416339],[37.36994839,-122.1416339],[37.37019243,-122.14186189],[37.37019243,-122.14186189],[37.37043777,-122.14209172],[37.37043777,-122.14209172],[37.37068524,-122.14231367],[37.37068524,-122.14231367],[37.37092857,-122.14253931],[37.37092857,-122.14253931],[37.37117332,-122.14276269],[37.37117332,-122.14276269],[37.37142067,-122.14297886],[37.37142067,-122.14297886],[37.37167049,-122.14320232],[37.37167049,-122.14320232],[37.37190954,-122.14341883],[37.37190954,-122.14341883],[37.37215601,-122.14364204],[37.37215601,-122.14364204],[37.37240005,-122.14386038],[37.37240005,-122.14386038],[37.37263743,-122.14409064],[37.37263743,-122.14409064],[37.37287229,-122.14430781],[37.37287229,-122.14430781],[37.37311268,-122.14451887],[37.37311268,-122.14451887],[37.37336271,-122.14472699],[37.37336271,-122.14472699],[37.37361371,-122.14495984],[37.37361371,-122.14495984],[37.37385134,-122.14517802],[37.37385134,-122.14517802],[37.37409077,-122.14540877],[37.37409077,-122.14540877],[37.37433481,-122.14563986],[37.37433481,-122.14563986],[37.37457281,-122.14588663],[37.37457281,-122.14588663],[37.37481249,-122.14611939],[37.37481249,-122.14611939],[37.37503792,-122.14636347],[37.37503792,-122.14636347],[37.37527039,-122.14662055],[37.37527039,-122.14662055],[37.37550207,-122.14687494],[37.37550207,-122.14687494],[37.37572427,-122.14713511],[37.37572427,-122.14713511],[37.37595557,-122.14739872],[37.37595557,-122.14739872],[37.37618545,-122.14766024],[37.37618545,-122.14766024],[37.37641444,-122.14792309],[37.37641444,-122.14792309],[37.37664016,-122.14817958],[37.37664016,-122.14817958],[37.37686895,-122.14843858],[37.37686895,-122.14843858],[37.37709618,-122.14869624],[37.37709618,-122.14869624]]}", "field_66812": "Sim", "field_75000": "SIG_V1|meta:{\\"lat\\":37.38078049,\\"lng\\":-122.15133956,\\"address\\":\\"I-280,  - Los Altos Hills, CA\\",\\"ip\\":\\"2804:7f0:9383:8b58:2cf9:997d:bbdb:7ecb\\"}|M209.66666666666666,150.33333460489905 L201,169.66666793823242 L191.33333333333331,172.66666793823242 L181.66666666666666,172.66666793823242 L172,171.00000127156574 L152,160.66666793823242 L129.33333333333331,145.66666793823242 L106,125.33333460489905 L87.66666666666666,102.33333460489905 L81,87.00000127156574 L79.66666666666666,69.33333460489905 L91,50.33333460489905 L105,42.33333460489905 L126.66666666666666,38.33333460489905 L144.33333333333331,38.33333460489905 L160,39.33333460489905 L178,49.33333460489905 L191,59.66666793823242 L201.33333333333331,74.00000127156574 L207.66666666666666,87.66666793823242 L208.66666666666666,99.00000127156574 L206.33333333333331,110.66666793823242 L198.33333333333331,119.00000127156574 L177,129.00000127156574 L165.33333333333331,131.00000127156574 L157.66666666666666,131.00000127156574 L155,131.00000127156574 L154.66666666666666,130.66666793823242 L154.33333333333331,130.66666793823242", "field_75975": "{\\"action\\":\\"SAIDA\\",\\"timestamp\\":\\"2026-04-02T22:08:00.448Z\\",\\"coordinates\\":{\\"lat\\":37.34415677,\\"lng\\":-122.09439031},\\"address\\":\\"I-280,  - West Loyola, Los Altos - CA\\"}", "__time_field_4248": "2026-04-02T22:11:11.258Z", "__time_field_66812": "2026-04-02T22:11:13.663Z", "__time_field_75000": "2026-04-02T22:11:24.775Z", "__time_field_75975": "2026-04-02T22:08:00.449Z", "__section_end_page_1": "2026-04-02T22:11:25.377Z", "__section_start_page_1": "2026-04-02T22:08:00.476Z"}	{"icon": "build-outline", "refId": "chk_mnhro4is", "title": "Rota", "acceptedAt": "2026-04-02T22:07:37.343Z", "appVersion": "1.0", "receivedAt": "2026-04-02T22:07:24.081Z", "description": "Tarefa de rotina despachada.", "devicePlatform": "AppMovel", "durationSeconds": 227}	\N	-15.646864	-54.615226	150	segment	[[-15.64618, -54.624023], [-15.647548, -54.606428]]	null	2026-04-02 22:07:37.379	2026-04-02 22:11:25.377	2026-04-02 22:11:25.567	2026-04-02 22:07:21.663	\N
cmnj3ycod0179hojan64s2qh5	chk_mnj0nb63	alex@brspark.com	\N	IN_PROGRESS	null	{"icon": "build-outline", "refId": "chk_mnj0nb63", "title": "face", "acceptedAt": "2026-04-03T23:49:55.345Z", "receivedAt": "2026-04-03T16:18:25.196Z", "description": "Tarefa de rotina despachada."}	\N	-23.564097	-46.774828	200	radius	null	\N	2026-04-04 00:05:47.938	\N	\N	2026-04-03 16:18:22.765	4
cmni0ykni034tk84w4shu4k67	chk_mnhro4is	alex@brspark.com	\N	COMPLETED	{"field_4248": "{\\"action\\":\\"CHEGADA\\",\\"timestamp\\":\\"2026-04-03T00:11:04.257Z\\",\\"coordinates\\":{\\"lat\\":37.45672979,\\"lng\\":-122.28811109},\\"address\\":\\"I-280,  - San Mateo, Woodside - CA\\",\\"traversedPath\\":[[37.45428831,-122.28458122]]}", "field_75975": "{\\"action\\":\\"SAIDA\\",\\"timestamp\\":\\"2026-04-02T23:20:51.220Z\\",\\"coordinates\\":{\\"lat\\":37.33228724,\\"lng\\":-122.05833354},\\"address\\":\\"I-280,  - Homestead, Cupertino - CA\\"}", "__time_field_4248": "2026-04-03T00:11:04.257Z", "__time_field_75975": "2026-04-02T23:20:51.220Z", "__section_end_page_1": "2026-04-03T00:11:08.330Z", "__section_start_page_1": "2026-04-02T23:20:51.258Z"}	{"icon": "build-outline", "refId": "chk_mnhro4is", "title": "Rota", "acceptedAt": "2026-04-02T23:20:44.918Z", "appVersion": "1.0", "receivedAt": "2026-04-02T22:06:51.150Z", "description": "Tarefa de rotina despachada.", "devicePlatform": "AppMovel", "durationSeconds": 20}	\N	-14.841123	-51.31804	200	radius	null	null	2026-04-03 00:10:47.565	2026-04-03 00:11:08.33	2026-04-03 00:11:08.435	2026-04-02 22:06:48.079	\N
cmnj3z62f018hhoja01gvq115	chk_mnhro4is	alex@brspark.com	\N	RECEIVED	null	{"icon": "build-outline", "refId": "chk_mnhro4is", "title": "Rota", "receivedAt": "2026-04-03T16:19:02.173Z", "description": "Tarefa de rotina despachada."}	\N	-23.565057	-46.827936	200	radius	null	\N	\N	\N	\N	2026-04-03 16:19:00.856	\N
cmni5g3d100lckaef6qeeg4y5	chk_mni0xdfi	alex@brspark.com	\N	COMPLETED	{"__section_end_page_1": "2026-04-03T00:39:48.701Z"}	{"icon": "build-outline", "refId": "chk_mni0xdfi", "title": "NOVO CHECKLIST", "acceptedAt": "2026-04-03T00:39:39.550Z", "appVersion": "1.0", "receivedAt": "2026-04-03T00:12:27.415Z", "description": "Tarefa de rotina despachada.", "devicePlatform": "AppMovel", "durationSeconds": 9}	apple	42.764352	-84.514731	200	radius	null	null	2026-04-03 00:39:39.581	2026-04-03 00:39:48.701	2026-04-03 00:39:48.765	2026-04-03 00:12:23.941	\N
cmni5glfq00lykaefxv4igyw0	chk_mnhro4is	alex@brspark.com	\N	COMPLETED	{"field_4248": "{\\"action\\":\\"CHEGADA\\",\\"timestamp\\":\\"2026-04-03T00:27:51.946Z\\",\\"coordinates\\":{\\"lat\\":37.69942554,\\"lng\\":-122.47129524},\\"address\\":\\"I-280,  - Peninsula Gateway, Daly City - CA\\",\\"traversedPath\\":[[37.50048014,-122.32070412]]}", "field_75000": "SIG_V1|meta:{\\"lat\\":37.70230325,\\"lng\\":-122.47132718,\\"address\\":\\"I-280,  - Daly City, CA\\",\\"ip\\":\\"2804:7f0:9383:8b58:2cf9:997d:bbdb:7ecb\\"}|M269.66666666666663,150.66666793823242 L247.66666666666663,171.00000127156574 L232.33333333333331,176.00000127156574 L161,164.66666793823242 L139,154.66666793823242 L58,107.33333460489905 L20,41.66666793823242 L24.666666666666664,26.000001271565736 L47,16.33333460489905 L94.66666666666666,14.666667938232422 L146.33333333333331,21.33333460489905 L304.3333333333333,103.00000127156574 L317,133.00000127156574 L317,147.00000127156574 L255,188.33333460489905 L209.33333333333331,188.33333460489905 L153.66666666666666,174.33333460489905 L131.66666666666666,166.00000127156574 L79.66666666666666,134.66666793823242 L79.66666666666666,121.00000127156574 L111,107.00000127156574 L144.66666666666666,110.33333460489905 L175,124.33333460489905 L180.66666666666666,132.66666793823242 L174,147.00000127156574 L146,161.00000127156574 L64.66666666666666,172.66666793823242 L33,172.66666793823242 L13.333333333333329,169.66666793823242 L10.333333333333332,169.33333460489905 L10.333333333333332,170.00000127156574 L10.333333333333332,179.66666793823242 L10.333333333333332,193.33333460489905 L11,201.00000127156568 L11,203.00000127156568 L14.666666666666664,208.66666793823242 L37,217.33333460489905 L80.66666666666666,217.33333460489905 L108.66666666666666,210.33333460489905 L172.66666666666666,183.66666793823242 L229.33333333333331,153.66666793823242 L279,130.33333460489905 L283.66666666666663,134.00000127156574 L281.66666666666663,143.66666793823242 L275.3333333333333,159.00000127156574 L272.66666666666663,165.33333460489905 L272.66666666666663,165.00000127156574 L274,153.33333460489905 L276,147.66666793823242 L277.3333333333333,147.00000127156574 L282.66666666666663,144.00000127156574 L284,143.33333460489905 L285,143.33333460489905 L285.66666666666663,143.33333460489905 L297.3333333333333,155.33333460489905 L305.3333333333333,164.33333460489905 L308,167.33333460489905 L308,169.00000127156574 L322,149.33333460489905 L325.66666666666663,165.33333460489905 L325.66666666666663,172.66666793823242 L325.3333333333333,173.66666793823242 L324.3333333333333,173.66666793823242 L318.66666666666663,174.66666793823242", "field_75975": "{\\"action\\":\\"SAIDA\\",\\"timestamp\\":\\"2026-04-03T00:14:11.871Z\\",\\"coordinates\\":{\\"lat\\":37.50048014,\\"lng\\":-122.32070412},\\"address\\":\\"I-280,  - Belmont Heights, Belmont - CA\\"}", "__time_field_4248": "2026-04-03T00:27:51.946Z", "__time_field_75000": "2026-04-03T00:28:01.628Z", "__time_field_75975": "2026-04-03T00:14:11.871Z", "__section_end_page_1": "2026-04-03T00:28:04.262Z", "__section_start_page_1": "2026-04-03T00:14:11.903Z"}	{"icon": "build-outline", "refId": "chk_mnhro4is", "title": "Rota", "acceptedAt": "2026-04-03T00:14:05.968Z", "appVersion": "1.0", "receivedAt": "2026-04-03T00:12:47.434Z", "description": "Tarefa de rotina despachada.", "devicePlatform": "AppMovel", "durationSeconds": 838}	mit	42.358253	-71.096627	200	radius	null	null	2026-04-03 00:14:05.981	2026-04-03 00:28:04.262	2026-04-03 00:28:04.565	2026-04-03 00:12:47.366	3320
cmni8cwga02p1708nrb9ddvxg	chk_mnhro4is	alex@brspark.com	\N	COMPLETED	{"field_4248": "{\\"action\\":\\"CHEGADA\\",\\"timestamp\\":\\"2026-04-03T02:19:33.494Z\\",\\"coordinates\\":{\\"lat\\":-23.569983,\\"lng\\":-46.7851655},\\"address\\":\\"Parque Chico Mendes,  - Jd Bussocaba City, Osasco - SP\\",\\"traversedPath\\":[[-23.569983,-46.7851655],[-23.569983,-46.7851655]]}", "field_75000": "SIG_V1|meta:{\\"lat\\":-23.569983,\\"lng\\":-46.7851655,\\"address\\":\\",  - Osasco, SP\\",\\"ip\\":\\"2804:7f0:9383:8b58:2cf9:997d:bbdb:7ecb\\"}|M244.33333333333331,200.33333460489905 L209.33333333333331,194.33333460489905 L149,162.33333460489905 L116,137.66666793823242 L91.66666666666666,112.00000127156574 L77.66666666666666,82.00000127156574 L71,48.33333460489905 L71,16.666667938232422 L81,-3.333332061767578 L103,-13.66666539510095 L138.66666666666666,-10.333332061767578 L171.33333333333331,11.000001271565736 L202.66666666666666,60.33333460489905 L214.33333333333331,102.00000127156574 L216,139.66666793823242 L208.33333333333331,167.00000127156574 L193,181.00000127156574 L127.66666666666666,188.66666793823242 L92,180.66666793823242 L68,167.33333460489905 L51.66666666666666,149.66666793823242 L47.33333333333333,126.00000127156574 L51,90.66666793823242 L64.66666666666666,77.00000127156574 L90.33333333333333,74.00000127156574 L128.33333333333331,89.00000127156574 L160,119.00000127156574 L176,151.00000127156574 L181,182.66666793823242 L178,206.33333460489905 L176.33333333333331,207.66666793823242 L176,207.66666793823242 L175,205.33333460489905 L172,197.66666793823242 L167.33333333333331,178.33333460489905 L167.66666666666666,177.00000127156574 L168.66666666666666,177.00000127156574 L171.33333333333331,179.00000127156574 L175.33333333333331,183.66666793823242 L179,187.33333460489905 L180,187.66666793823242 L179.66666666666666,187.66666793823242 L178,186.33333460489905 L174.33333333333331,174.66666793823242 L173,157.00000127156574 L176.66666666666666,144.66666793823242 L188,141.33333460489905 L217.66666666666666,143.00000127156574 L254,162.66666793823242 L275.66666666666663,181.00000127156574 L284.66666666666663,195.00000127156568 L285,196.00000127156568 L286.3333333333333,186.00000127156568 L285,166.33333460489905 L282,144.66666793823242 L280.3333333333333,136.00000127156574 L281.66666666666663,144.33333460489905 L284.66666666666663,154.00000127156574 L289,171.66666793823242 L293.66666666666663,185.00000127156568 L298.3333333333333,196.66666793823242", "field_75975": "{\\"action\\":\\"SAIDA\\",\\"timestamp\\":\\"2026-04-03T01:34:37.316Z\\",\\"coordinates\\":{\\"lat\\":-23.569983,\\"lng\\":-46.7851655},\\"address\\":\\"Parque Chico Mendes,  - Jd Bussocaba City, Osasco - SP\\"}", "__time_field_4248": "2026-04-03T02:19:33.494Z", "__time_field_75000": "2026-04-03T02:19:41.352Z", "__time_field_75975": "2026-04-03T01:34:37.316Z", "__section_end_page_1": "2026-04-03T02:19:42.448Z", "__section_start_page_1": "2026-04-03T01:34:37.354Z"}	{"icon": "build-outline", "refId": "chk_mnhro4is", "title": "Rota", "acceptedAt": "2026-04-03T01:34:10.159Z", "appVersion": "1.0", "receivedAt": "2026-04-03T01:33:58.850Z", "description": "Tarefa de rotina despachada.", "trackingToken": "78a8fda19d4b324eb2165e14", "devicePlatform": "AppMovel", "durationSeconds": 126, "trackingExpiredAt": null, "trackingStartedAt": "2026-04-03T01:34:37.045Z"}	shopping morumbi	-23.623417	-46.698544	200	radius	null	null	2026-04-03 02:17:35.768	2026-04-03 02:19:42.448	2026-04-03 02:19:42.544	2026-04-03 01:33:53.866	22
cmni8bpkq02oz708nzfdg04oc	chk_mnhro4is	alex@brspark.com	\N	COMPLETED	{"field_4248": "{\\"action\\":\\"CHEGADA\\",\\"timestamp\\":\\"2026-04-03T03:00:07.553Z\\",\\"coordinates\\":{\\"lat\\":-23.569983,\\"lng\\":-46.7851655},\\"address\\":\\"Parque Chico Mendes,  - Jd Bussocaba City, Osasco - SP\\",\\"traversedPath\\":[[-23.569983,-46.7851655],[-23.569983,-46.7851655]]}", "field_75975": "{\\"action\\":\\"SAIDA\\",\\"timestamp\\":\\"2026-04-03T02:20:20.433Z\\",\\"coordinates\\":{\\"lat\\":-23.569983,\\"lng\\":-46.7851655},\\"address\\":\\"Parque Chico Mendes,  - Jd Bussocaba City, Osasco - SP\\"}", "__time_field_4248": "2026-04-03T03:00:07.553Z", "__time_field_75975": "2026-04-03T02:20:20.433Z", "__section_end_page_1": "2026-04-03T03:00:17.571Z", "__section_start_page_1": "2026-04-03T02:20:20.476Z"}	{"icon": "build-outline", "refId": "chk_mnhro4is", "title": "Rota", "acceptedAt": "2026-04-03T02:20:00.175Z", "appVersion": "1.0", "receivedAt": "2026-04-03T01:33:58.610Z", "description": "Tarefa de rotina despachada.", "trackingToken": "36b3a05c3dacf0235f35f4d6", "devicePlatform": "AppMovel", "durationSeconds": 2, "trackingExpiredAt": null, "trackingStartedAt": "2026-04-03T02:20:20.163Z"}	Osasco plaza	-23.529294	-46.777856	200	radius	null	null	2026-04-03 03:00:14.586	2026-04-03 03:00:17.571	2026-04-03 03:00:18.237	2026-04-03 01:32:58.298	10
cmnj3yrf4017vhojacp14gc5a	chk_mnhro4is	alex@brspark.com	\N	COMPLETED	{"field_4248": "{\\"action\\":\\"CHEGADA\\",\\"timestamp\\":\\"2026-04-03T23:40:15.449Z\\",\\"coordinates\\":{\\"lat\\":-23.567253250708056,\\"lng\\":-46.7862092345896},\\"address\\":\\"Avenida Avedis Kamalakian, 27 - Bussocaba, Osasco - SP\\",\\"traversedPath\\":[[-23.56719453129495,-46.7862439702355],[-23.56719453129495,-46.7862439702355],[-23.567099228749434,-46.78631057139639],[-23.567184996432125,-46.78626208347792]]}", "field_21036": "http://192.168.15.73:3001/uploads/storage/checklists/unknown_empresa_com/cmnj3yrf4017vhojacp14gc5a_field_21036_1775259647561.jpg", "field_66812": "Sim", "field_75000": "SIG_V1|meta:{\\"lat\\":-23.567249949658557,\\"lng\\":-46.78622617034731,\\"address\\":\\"Avenida Avedis Kamalakian, 27 - Osasco, SP\\",\\"ip\\":\\"2804:7f0:9383:8b58:f5d4:b6b0:401e:cf7f\\"}|M71.33333333333333,91.33333206176758 L71.66666666666666,88.9999987284342 L79,89.66666539510089 L95.33333333333333,98.33333206176758 L119.33333333333331,108.9999987284342 L133.33333333333331,113.33333206176758 L147.33333333333331,116.33333206176758 L162.33333333333331,117.33333206176758 L192.66666666666666,113.33333206176758 L205.66666666666666,106.66666539510089 L216.33333333333331,99.9999987284342 L232.33333333333331,86.33333206176758 L237.66666666666663,80.66666539510089 L240.33333333333331,77.66666539510089 L239.66666666666663,76.9999987284342 L236.66666666666663,78.33333206176758 L228,82.9999987284342 L215,91.33333206176758 L183,113.66666539510089 L167,125.33333206176758 L150.33333333333331,136.33333206176758 L117,156.6666653951009 L103,164.6666653951009 L82,171.9999987284342 L74.66666666666666,171.6666653951009 L70,168.9999987284342 L67.33333333333333,151.9999987284342 L67.66666666666666,142.33333206176758 L70,133.33333206176758 L83.33333333333333,116.33333206176758 L90.66666666666666,110.33333206176758 L98,105.9999987284342 L104.33333333333333,104.66666539510089 L109,105.9999987284342 L108.66666666666666,109.66666539510089 L107.33333333333333,115.33333206176758 L100.66666666666666,122.66666539510089 L79,145.33333206176758 L69,156.9999987284342 L61.33333333333333,166.6666653951009 L55,178.6666653951009 L55,180.33333206176758 L55.66666666666666,180.6666653951009 L69.33333333333333,178.6666653951009 L85,171.6666653951009 L100.66666666666666,163.33333206176758 L114.66666666666666,156.9999987284342 L131.33333333333331,152.6666653951009 L134,152.6666653951009 L134,152.9999987284342 L130.66666666666666,161.9999987284342 L123,169.6666653951009 L114,179.33333206176758 L104.66666666666666,189.9999987284342 L91,207.33333206176758 L88,212.6666653951009 L88,214.33333206176758 L93,214.33333206176758 L104.33333333333333,211.6666653951009 L122,203.6666653951009 L140.33333333333331,193.6666653951009 L166.33333333333331,182.9999987284342 L173,181.33333206176758 L175.33333333333331,181.6666653951009 L172.66666666666666,186.33333206176758 L164.33333333333331,193.9999987284342 L152,203.9999987284342 L138.33333333333331,214.6666653951009 L116.66666666666666,232.9999987284342 L110.66666666666666,239.33333206176758 L109,242.6666653951009 L111.66666666666666,242.9999987284342 L122,239.33333206176758 L141.66666666666666,227.33333206176758 L164.66666666666666,211.33333206176758 L202.66666666666666,186.9999987284342 L213,179.33333206176758 L219,175.33333206176758 L219,175.6666653951009 L216.66666666666666,177.9999987284342 L208.66666666666666,183.9999987284342 L198.33333333333331,192.33333206176758 L177,212.9999987284342 L168.33333333333331,222.9999987284342 L163.66666666666666,229.9999987284342 L162,234.9999987284342 L164.66666666666666,236.9999987284342 L175.33333333333331,235.6666653951009 L196,228.6666653951009 L239.33333333333331,206.9999987284342", "field_75975": "{\\"action\\":\\"SAIDA\\",\\"timestamp\\":\\"2026-04-03T23:38:58.859Z\\",\\"coordinates\\":{\\"lat\\":-23.56719453129495,\\"lng\\":-46.7862439702355},\\"address\\":\\"Avenida Avedis Kamalakian, 27 - Bussocaba, Osasco - SP\\"}", "__time_field_4248": "2026-04-03T23:40:15.449Z", "__time_field_21036": "2026-04-03T23:40:38.433Z", "__time_field_66812": "2026-04-03T23:40:27.407Z", "__time_field_75000": "2026-04-03T23:40:46.628Z", "__time_field_75975": "2026-04-03T23:38:58.859Z", "__section_end_page_1": "2026-04-03T23:40:47.518Z", "__section_start_page_1": "2026-04-03T23:38:58.892Z"}	{"icon": "build-outline", "refId": "chk_mnhro4is", "title": "Rota", "acceptedAt": "2026-04-03T23:38:56.982Z", "appVersion": "1.0", "receivedAt": "2026-04-03T16:18:45.271Z", "description": "Tarefa de rotina despachada.", "trackingToken": "9d92db9ec7f7090d9ef41446", "devicePlatform": "AppMovel", "durationSeconds": 110, "trackingEndedAt": "2026-04-03T23:40:15.495Z", "trackingExpiredAt": "2026-04-03T23:55:15.495Z", "trackingStartedAt": "2026-04-03T23:38:58.713Z"}	\N	-23.565946	-46.801994	200	radius	null	null	2026-04-03 23:38:57.007	2026-04-03 23:40:47.518	2026-04-03 23:40:47.803	2026-04-03 16:18:41.872	3
cmnj1u3d401z3hw8yw2e5hqnc	chk_mnj0nb63	alex@brspark.com	\N	COMPLETED	{"field_39132": "http://localhost:3001/uploads/storage/checklists/unknown_empresa_com/cmnj1u3d401z3hw8yw2e5hqnc_field_39132_1775231994434.jpg", "__time_field_39132": "2026-04-03T15:59:40.915Z", "__section_end_page_1": "2026-04-03T15:59:54.383Z", "__section_start_page_1": "2026-04-03T15:35:13.837Z"}	{"icon": "build-outline", "refId": "chk_mnj0nb63", "title": "face", "acceptedAt": "2026-04-03T15:19:13.068Z", "appVersion": "1.0", "receivedAt": "2026-04-03T15:19:08.121Z", "description": "Tarefa de rotina despachada.", "devicePlatform": "AppMovel", "durationSeconds": 36}	parque vila lobos	-23.454201	-46.523216	200	radius	null	null	2026-04-03 15:59:17.911	2026-04-03 15:59:54.383	2026-04-03 15:59:54.74	2026-04-03 15:19:04.84	41
cmnj1lkhy01n1hw8y4bohk7qw	chk_mnj0nb63	alex@brspark.com	\N	COMPLETED	{"__section_end_page_1": "2026-04-03T23:45:35.276Z"}	{"icon": "build-outline", "refId": "chk_mnj0nb63", "title": "face", "acceptedAt": "2026-04-03T23:45:32.640Z", "appVersion": "1.0", "receivedAt": "2026-04-03T15:12:27.270Z", "description": "Tarefa de rotina despachada.", "devicePlatform": "AppMovel", "durationSeconds": 2}	\N	-17.331631	-46.867676	200	radius	null	null	2026-04-03 23:45:32.729	2026-04-03 23:45:35.276	2026-04-03 23:45:35.308	2026-04-03 15:12:27.142	715
cmnjfk8p9000013umjxwktuk3	\N	alex@brspark.com	\N	RECEIVED	\N	{"icon": "navigate-circle", "title": "OS-01 (Muito Perto, Vence Amanhã)", "dueDate": "2026-04-04T21:43:19.727Z", "receivedAt": "2026-04-03T21:49:06.500Z"}	Local Simulado - OS-01 (Muito Perto, Vence Amanhã)	-23.5495	-46.6323	\N	\N	\N	\N	\N	\N	\N	2026-04-03 21:43:19.82	\N
cmnjfk8rf000213umdyidq0k4	\N	alex@brspark.com	\N	RECEIVED	\N	{"icon": "navigate-circle", "title": "OS-03 (Longe, ATRASADA Crítica)", "dueDate": "2026-04-03T19:43:19.899Z", "receivedAt": "2026-04-03T21:49:06.500Z"}	Local Simulado - OS-03 (Longe, ATRASADA Crítica)	-23.5005	-46.5833	\N	\N	\N	\N	\N	\N	\N	2026-04-03 21:43:19.9	\N
cmnjkskbz00m2rohksun8q8vw	chk_mnhro4is	alex@brspark.com	\N	IN_PROGRESS	null	{"icon": "build-outline", "refId": "chk_mnhro4is", "title": "Rota", "acceptedAt": "2026-04-04T00:35:40.585Z", "receivedAt": "2026-04-04T00:14:40.443Z", "description": "Tarefa de rotina despachada.", "trackingToken": "8c4612e768a4219acedbbe1a", "trackingExpiredAt": null, "trackingStartedAt": "2026-04-04T00:35:43.609Z"}	\N	\N	\N	\N	\N	null	\N	2026-04-04 00:35:43.786	\N	\N	2026-04-04 00:09:46.223	\N
cmnjfk8rh000413umtgtrj8m0	\N	alex@brspark.com	\N	RECEIVED	\N	{"icon": "navigate-circle", "title": "OS-05 (Mais Longe, Vence em 3 Dias)", "dueDate": "2026-04-06T21:43:19.901Z", "receivedAt": "2026-04-03T21:49:06.500Z"}	Local Simulado - OS-05 (Mais Longe, Vence em 3 Dias)	-23.4005	-46.4833	\N	\N	\N	\N	\N	\N	\N	2026-04-03 21:43:19.901	\N
cmnj3xzrq016shojah2dyzntn	chk_mnhro4is	alex@brspark.com	\N	COMPLETED	{"field_4248": "{\\"action\\":\\"CHEGADA\\",\\"timestamp\\":\\"2026-04-04T00:30:21.174Z\\",\\"coordinates\\":{\\"lat\\":-23.567130397712827,\\"lng\\":-46.786198507117625},\\"address\\":\\"Rua Xavantes, 30 - Bussocaba, Osasco - SP\\",\\"traversedPath\\":[[-23.56713016945786,-46.78618701739954],[-23.56713016945786,-46.78618701739955]]}", "field_40882": "http://192.168.15.73:3001/uploads/storage/checklists/unknown_empresa_com/cmnj3xzrq016shojah2dyzntn_field_40882_1775262661329.jpg", "field_57585": "http://192.168.15.73:3001/uploads/storage/checklists/unknown_empresa_com/cmnj3xzrq016shojah2dyzntn_field_57585_1775262661194.pdf", "field_66812": "Não", "field_75000": "SIG_V1|meta:{\\"lat\\":-23.56714224316359,\\"lng\\":-46.786178867212975,\\"address\\":\\"Rua Xavantes, 30 - Osasco, SP\\",\\"ip\\":\\"2804:7f0:9383:8b58:e0e1:875d:5d4d:3047\\"}|M238.33333333333331,127.33333460489905 L238.33333333333331,131.66666793823242 L233.66666666666666,136.66666793823242 L226.33333333333331,142.00000127156574 L222,144.66666793823242 L211.66666666666666,149.33333460489905 L205.66666666666666,151.00000127156574 L193,154.00000127156574 L186.66666666666666,155.33333460489905 L180.33333333333331,156.00000127156574 L168.66666666666666,156.66666793823242 L163,157.00000127156574 L152,157.00000127156574 L146.66666666666666,157.00000127156574 L141.33333333333331,157.00000127156574 L129.66666666666666,157.00000127156574 L123.66666666666666,157.00000127156574 L118,157.00000127156574 L107.33333333333333,156.33333460489905 L102.33333333333333,155.00000127156574 L95,150.66666793823242 L92.33333333333333,148.33333460489905 L91.33333333333333,145.66666793823242 L91,140.33333460489905 L91,137.66666793823242 L91,134.66666793823242 L94.66666666666666,128.33333460489905 L98,124.66666793823242 L106.66666666666666,117.00000127156574 L112,113.33333460489905 L118.33333333333331,109.33333460489905 L131.66666666666666,101.66666793823242 L138.66666666666666,98.00000127156574 L153.66666666666666,92.00000127156574 L161.33333333333331,89.33333460489905 L169,88.00000127156574 L183.66666666666666,86.00000127156574 L190.66666666666666,85.66666793823242 L202.66666666666666,85.66666793823242 L207.66666666666666,85.66666793823242 L212,87.00000127156574 L219,90.00000127156574 L222.33333333333331,91.66666793823242 L225.33333333333331,93.00000127156574 L231.66666666666666,96.00000127156574 L234.66666666666666,97.33333460489905 L237.66666666666663,98.33333460489905 L243.66666666666663,101.00000127156574 L246.33333333333331,102.33333460489905 L251.66666666666663,104.66666793823242 L254.33333333333331,105.66666793823242 L256,107.00000127156574 L259,109.33333460489905 L260,110.66666793823242 L260.3333333333333,112.33333460489905 L260.66666666666663,115.66666793823242 L260.66666666666663,118.00000127156574 L260.66666666666663,120.00000127156574 L258.66666666666663,124.66666793823242 L256,127.33333460489905 L250,133.00000127156574 L246.33333333333331,135.66666793823242 L242.66666666666663,138.66666793823242 L235.66666666666666,144.33333460489905 L232.66666666666666,147.00000127156574 L226.33333333333331,151.66666793823242 L220.33333333333331,155.66666793823242 L217.33333333333331,157.00000127156574 L210.33333333333331,159.33333460489905 L206.66666666666666,159.66666793823242 L197.66666666666666,160.66666793823242 L192.33333333333331,160.66666793823242 L187,160.66666793823242 L176,160.66666793823242 L170.66666666666666,160.33333460489905 L160.66666666666666,158.66666793823242 L156,158.00000127156574 L147.66666666666666,156.66666793823242 L144.66666666666666,155.33333460489905 L141,153.00000127156574 L140,151.66666793823242 L140,150.00000127156574 L140,146.33333460489905 L140.66666666666666,143.33333460489905 L147.33333333333331,136.00000127156574 L152,131.66666793823242 L164,121.00000127156574 L171.33333333333331,115.00000127156574 L187,103.66666793823242 L195,98.00000127156574 L210.66666666666666,88.33333460489905 L218,83.66666793823242 L231.33333333333331,76.00000127156574 L236.66666666666663,73.33333460489905 L241.33333333333331,70.66666793823242 L246.66666666666663,67.66666793823242 L248.33333333333331,67.00000127156574 L250,66.00000127156574 L250,65.66666793823242 L250,65.33333460489905 L250,65.00000127156574 L249.33333333333331,65.00000127156574 L248,65.00000127156574 L243.66666666666663,65.00000127156574 L240.33333333333331,66.33333460489905 L232.33333333333331,70.66666793823242 L227.66666666666666,73.33333460489905 L222.33333333333331,77.00000127156574 L211,86.00000127156574 L205,91.00000127156574 L193.66666666666666,102.33333460489905 L188.33333333333331,107.66666793823242 L178.66666666666666,118.66666793823242 L174,124.00000127156574 L165.33333333333331,133.66666793823242 L161.33333333333331,138.33333460489905 L153.33333333333331,147.33333460489905 L149,151.33333460489905 L141.33333333333331,159.00000127156574 L137.33333333333331,162.33333460489905 L130.33333333333331,167.33333460489905 L127,169.00000127156574 L121,171.33333460489905 L118.33333333333331,172.33333460489905 L113,173.00000127156574 L110,173.66666793823242 L104,174.33333460489905 L101,175.00000127156574 L98,175.33333460489905 L93,175.66666793823242 L91,175.66666793823242 L88.66666666666666,175.66666793823242 L88,175.66666793823242 L88,173.66666793823242 L88,172.00000127156574 L91,167.33333460489905 L94,164.66666793823242 L101.66666666666666,159.00000127156574 L106,156.33333460489905 L115.33333333333331,152.00000127156574 L120,151.00000127156574 L129,150.66666793823242 L133.33333333333331,150.66666793823242 L137.66666666666666,150.66666793823242 L146.33333333333331,154.66666793823242 L151,157.66666793823242 L160.66666666666666,163.66666793823242 L165.33333333333331,166.66666793823242 L177,171.66666793823242 L183.33333333333331,173.66666793823242 L198.33333333333331,175.66666793823242 L206.66666666666666,176.66666793823242 L223.33333333333331,177.33333460489905 L232.33333333333331,177.66666793823242 L251,177.66666793823242 L260.66666666666663,177.66666793823242 L270.3333333333333,177.66666793823242 L288.66666666666663,176.66666793823242 L297.66666666666663,174.33333460489905 L315.66666666666663,167.00000127156574", "field_75975": "{\\"action\\":\\"SAIDA\\",\\"timestamp\\":\\"2026-04-04T00:29:58.381Z\\",\\"coordinates\\":{\\"lat\\":-23.56713016945786,\\"lng\\":-46.78618701739954},\\"address\\":\\"Rua Xavantes, 30 - Bussocaba, Osasco - SP\\"}", "__time_field_4248": "2026-04-04T00:30:21.174Z", "__time_field_40882": "2026-04-04T00:30:45.096Z", "__time_field_57585": "2026-04-04T00:30:36.257Z", "__time_field_66812": "2026-04-04T00:30:25.942Z", "__time_field_75000": "2026-04-04T00:30:59.317Z", "__time_field_75975": "2026-04-04T00:29:58.381Z", "__section_end_page_1": "2026-04-04T00:31:01.151Z", "__section_start_page_1": "2026-04-04T00:29:58.431Z"}	{"icon": "build-outline", "refId": "chk_mnhro4is", "title": "Rota", "acceptedAt": "2026-04-03T23:48:05.829Z", "appVersion": "1.0", "receivedAt": "2026-04-03T16:18:10.171Z", "description": "Tarefa de rotina despachada.", "trackingToken": "e5a1db24781b3ad642374c62", "devicePlatform": "AppMovel", "durationSeconds": 69, "trackingEndedAt": "2026-04-04T00:30:21.228Z", "trackingExpiredAt": "2026-04-04T00:45:21.228Z", "trackingStartedAt": "2026-04-04T00:29:58.076Z"}	\N	-23.566654	-46.783369	200	radius	null	null	2026-04-04 00:29:51.344	2026-04-04 00:31:01.151	2026-04-04 00:31:01.453	2026-04-03 16:18:06.039	2
cmnjfk8rg000313um61b9768i	\N	alex@brspark.com	\N	RECEIVED	\N	{"icon": "navigate-circle", "title": "OS-04 (Muito Longe, Vence daqui a 1 hora)", "dueDate": "2026-04-03T22:43:19.900Z", "receivedAt": "2026-04-03T21:49:06.500Z"}	Local Simulado - OS-04 (Muito Longe, Vence daqui a 1 hora)	-23.4505	-46.5333	\N	\N	\N	\N	\N	\N	\N	2026-04-03 21:43:19.901	\N
cmnj0xh1v0001hw8ycw1mvicf	chk_mnj0nb63	alex@brspark.com	\N	IN_PROGRESS	null	{"icon": "build-outline", "refId": "chk_mnj0nb63", "title": "face", "acceptedAt": "2026-04-03T23:45:45.281Z", "receivedAt": "2026-04-03T14:54:09.454Z", "description": "Tarefa de rotina despachada."}	\N	-18.691781	-45.395508	200	radius	null	\N	2026-04-03 23:45:54.212	\N	\N	2026-04-03 14:53:42.932	647
\.


--
-- Data for Name: ChecklistTemplate; Type: TABLE DATA; Schema: public; Owner: alex
--

COPY public."ChecklistTemplate" (id, "tenantId", title, description, settings, "schemaData", metadata, version, "isActive", "createdAt", "updatedAt") FROM stdin;
chk_mnhro4is	\N	Rota		{"rules": [], "globalGeofenceRadius": 200, "requireGlobalGeofence": false}	[{"id": "field_75975", "icon": "arrow-up", "type": "transit_start", "label": "Iniciar Deslocamento", "options": null, "required": false, "textMask": null, "iconColor": "#0F172A", "calcFormula": null, "dependsOnId": "", "description": "", "iconLibrary": "FontAwesome", "defaultValue": "", "dependsOnValue": "", "geofenceRadius": null, "dependsOnOperator": "=="}, {"id": "field_4248", "icon": "arrows-alt", "type": "transit_end", "label": "Finalizar Deslocamento", "options": null, "required": false, "textMask": null, "iconColor": "#0F172A", "calcFormula": null, "dependsOnId": "", "description": "", "iconLibrary": "FontAwesome", "defaultValue": "", "dependsOnValue": "", "geofenceRadius": null, "dependsOnOperator": "=="}, {"id": "field_66812", "icon": "aliwangwang", "type": "yes_no", "label": "Sim / Não (Toggle)", "options": null, "required": false, "textMask": null, "iconColor": "#1c50ca", "calcFormula": null, "dependsOnId": "", "description": "", "iconLibrary": "AntDesign", "defaultValue": "", "dependsOnValue": "", "geofenceRadius": null, "dependsOnOperator": "=="}, {"id": "field_57585", "icon": "", "type": "file_upload", "label": "Enviar PDF/Doc", "options": null, "required": false, "textMask": null, "calcFormula": null, "dependsOnId": "", "description": "", "defaultValue": "", "dependsOnValue": "", "geofenceRadius": null, "dependsOnOperator": "=="}, {"id": "field_40882", "icon": "", "type": "photo_stamped", "label": "Foto Carimbada (Ao Vivo)", "options": null, "required": false, "textMask": null, "calcFormula": null, "dependsOnId": "", "description": "", "defaultValue": "", "dependsOnValue": "", "geofenceRadius": null, "dependsOnOperator": "=="}, {"id": "field_21036", "icon": "", "type": "photo", "label": "Foto (Galeria Livre)", "options": null, "required": false, "textMask": null, "calcFormula": null, "dependsOnId": "", "description": "", "defaultValue": "", "dependsOnValue": "", "geofenceRadius": null, "dependsOnOperator": "=="}, {"id": "field_75000", "icon": "", "type": "signature", "label": "Assinatura", "options": null, "required": false, "textMask": null, "calcFormula": null, "dependsOnId": "", "description": "", "defaultValue": "", "dependsOnValue": "", "geofenceRadius": null, "dependsOnOperator": "=="}, {"id": "field_82052", "icon": "", "type": "hidden", "label": "Campo Oculto", "options": null, "required": false, "textMask": null, "calcFormula": null, "dependsOnId": "", "description": "", "defaultValue": "", "dependsOnValue": "", "geofenceRadius": null, "dependsOnOperator": "=="}]	{"icon": ""}	1	t	2026-04-02 17:46:44.14	2026-04-02 17:46:44.14
chk_mni0xdfi	\N	NOVO CHECKLIST		{"rules": [], "globalGeofenceRadius": 200, "requireGlobalGeofence": false}	[]	{"icon": ""}	1	t	2026-04-02 22:05:52.08	2026-04-02 22:05:56.458
chk_mnj1jgtr	\N	NOVO CHECKLIST		{"rules": [], "globalGeofenceRadius": 200, "requireGlobalGeofence": false}	[{"id": "field_65823", "icon": "", "type": "facial_recognition", "label": "Reconhecimento Facial (IA)", "options": null, "required": false, "textMask": null, "cameraMode": "scanner", "calcFormula": null, "dependsOnId": "", "description": "", "defaultValue": "", "dependsOnValue": "", "geofenceRadius": null, "dependsOnOperator": "==", "requireOnlineValidation": false}]	{"icon": ""}	1	t	2026-04-03 15:10:49.098	2026-04-03 15:10:49.098
chk_mnj0nb63	\N	face		{"rules": [], "globalGeofenceRadius": 200, "requireGlobalGeofence": false}	[{"id": "field_39132", "icon": "", "type": "facial_recognition", "label": "Reconhecimento Facial (IA)", "options": null, "required": false, "textMask": null, "cameraMode": "scanner", "calcFormula": null, "dependsOnId": "", "description": "", "defaultValue": "", "dependsOnValue": "", "geofenceRadius": null, "dependsOnOperator": "==", "requireOnlineValidation": false}]	{"icon": ""}	1	t	2026-04-03 14:45:48.773	2026-04-03 15:18:33.343
\.


--
-- Data for Name: CollectionPolicy; Type: TABLE DATA; Schema: public; Owner: alex
--

COPY public."CollectionPolicy" (id, "tenantId", "sectorCode", label, "locationEnabled", "locationBackgroundEnabled", "locationIntervalIdleMin", "locationIntervalTransitMin", "locationIntervalOnSiteMin", "locationDistanceFilterMeters", "retentionGpsRawDays", "retentionEventsYears", "retentionAuditDays", "retentionMetricsDays", "mockGpsAction", "rootJailbreakAction", "clockDriftMaxSeconds", "requireExplicitConsent", "consentGranular", "legalBasis", "requireCheckinPhoto", "allowOfflineCheckin", "minOnSiteMinutes", "outOfPolicyAction", "isActive", "createdAt", "updatedAt") FROM stdin;
cmnhgi1rs000cedboz4pbavp7	\N	\N	Padrão Global	t	t	30	2	5	200	15	5	180	730	WARN	WARN	300	t	t	LGPD	f	t	0	PROCEED_FLAG	t	2026-04-02 12:34:04.793	2026-04-02 12:34:04.793
cmnhgi1rs000aedbo1qs68ys2	\N	\N	Padrão Global	t	t	30	2	5	200	15	5	180	730	WARN	WARN	300	t	t	LGPD	f	t	0	PROCEED_FLAG	t	2026-04-02 12:34:04.792	2026-04-02 12:34:04.792
cmnhgi1u2000ledbo2e4s9nne	\N	\N	Padrão Global	t	t	30	2	5	200	15	5	180	730	WARN	WARN	300	t	t	LGPD	f	t	0	PROCEED_FLAG	t	2026-04-02 12:34:04.874	2026-04-02 12:34:04.874
\.


--
-- Data for Name: ComplianceAcceptance; Type: TABLE DATA; Schema: public; Owner: alex
--

COPY public."ComplianceAcceptance" (id, "docId", "userId", "tenantId", "ipAddress", "acceptedAt") FROM stdin;
\.


--
-- Data for Name: ComplianceDoc; Type: TABLE DATA; Schema: public; Owner: alex
--

COPY public."ComplianceDoc" (id, type, version, title, content, "isActive", "publishedAt", "createdBy", "createdAt", "updatedAt", "sectorCode", "tenantId") FROM stdin;
\.


--
-- Data for Name: ConsentRecord; Type: TABLE DATA; Schema: public; Owner: alex
--

COPY public."ConsentRecord" (id, "tenantId", "ownerEmail", "policyId", "docId", "consentType", accepted, "ipAddress", "deviceId", "appVersion", "acceptedAt", "revokedAt") FROM stdin;
cmnhguuaz00023yrjny5gnwh2	\N	tech@brspark.com	\N	\N	LOCATION_BACKGROUND	t	::1	\N	1.0	2026-04-02 12:44:01.643	\N
\.


--
-- Data for Name: ExecutionMetric; Type: TABLE DATA; Schema: public; Owner: alex
--

COPY public."ExecutionMetric" (id, "tenantId", "executionId", "ownerEmail", "transitDurationMin", "siteArrivalDelayMin", "onSiteDurationMin", "idleTimeMin", "distanceKm", "geofenceBreaches", "routeDeviationMaxMeters", "scoreExecution", "scoreReliability", "scoreRisk", "fraudFlags", "calculatedAt", source, "etaMinutes") FROM stdin;
cmnhrxwy5003ml0zixdixrenr	\N	cmnhrqhbi0b9j9g8mtnd7ocdb	alex@brspark.com	\N	\N	\N	\N	0	0	\N	40	100	0	null	2026-04-02 17:54:20.812	REALTIME	\N
cmnhtb51a00z1quvgbhcgbaa0	\N	cmnht8qog00vkquvgverzll77	alex@brspark.com	\N	\N	\N	\N	0	0	\N	40	100	0	null	2026-04-02 18:32:37.439	REALTIME	\N
cmnhtrflg006rf5jrs5550t0z	\N	cmnhtnyp4001zf5jrvv0r23qa	alex@brspark.com	\N	\N	\N	\N	0	0	\N	40	50	45	[{"lat": 37.33240731, "lng": -122.03046898, "reason": "MOCK_LOCATION", "severity": "HIGH"}]	2026-04-02 18:45:17.621	REALTIME	\N
cmnhz0liz00gbk84wsvfj6p2v	\N	cmnhykdhy0005k84w6xci9f1x	alex@brspark.com	\N	\N	\N	\N	0	0	\N	40	100	0	null	2026-04-02 21:12:23.291	REALTIME	\N
cmni0w9850313k84wfi6itx34	\N	cmni0qayq02sqk84wy5bpuvea	alex@brspark.com	\N	\N	\N	\N	0	0	\N	40	100	0	null	2026-04-02 22:04:59.958	REALTIME	\N
cmni14ips03e6k84wqt4znm2o	\N	cmni0zakf035wk84wuzy84yix	alex@brspark.com	\N	\N	\N	\N	0	0	\N	40	100	0	null	2026-04-02 22:11:25.504	REALTIME	\N
cmni5duol00hikaef59qhd0mk	\N	cmni1npwo045ck84w2mp3uaqv	alex@brspark.com	\N	\N	\N	\N	0	0	\N	40	100	0	null	2026-04-03 00:10:39.381	REALTIME	\N
cmni5eh3300j0kaef0hj292xw	\N	cmni0ykni034tk84w4shu4k67	alex@brspark.com	\N	\N	\N	\N	9405.15	0	\N	40	50	90	[{"lat": 37.45672979, "lng": -122.28811109, "reason": "MOCK_LOCATION", "severity": "HIGH"}, {"lat": 37.45721393, "lng": -122.28861267, "reason": "MOCK_LOCATION", "severity": "HIGH"}]	2026-04-03 00:11:08.415	REALTIME	\N
cmni5i6ow00ojkaef76h7ho2t	\N	cmni5h43y00mpkaef20ijrtel	alex@brspark.com	\N	\N	\N	\N	0	0	\N	40	100	0	null	2026-04-03 00:14:01.569	REALTIME	\N
cmni6094701gfkaeffaj4x03a	\N	cmni5glfq00lykaefxv4igyw0	alex@brspark.com	\N	\N	\N	\N	0	0	\N	40	100	0	null	2026-04-03 00:28:04.52	REALTIME	\N
cmni6fciy0018708n9r85y7rd	\N	cmni5g3d100lckaef6qeeg4y5	alex@brspark.com	\N	\N	\N	\N	0	0	\N	40	100	0	null	2026-04-03 00:39:48.779	REALTIME	\N
cmni838au02h0708n34hr43hm	\N	cmni0yc0l034gk84wpt1ucqfp	alex@brspark.com	\N	\N	\N	\N	0	0	\N	40	100	0	null	2026-04-03 01:26:22.663	REALTIME	\N
cmni9zteg03a3708nqp1jxxdu	\N	cmni8cwga02p1708nrb9ddvxg	alex@brspark.com	\N	\N	\N	\N	0	0	\N	40	100	0	null	2026-04-03 02:19:42.617	REALTIME	\N
cmnibg0iv00t2za8goxtpqelo	\N	cmni8bpkq02oz708nzfdg04oc	alex@brspark.com	\N	\N	\N	\N	0	0	\N	40	100	0	null	2026-04-03 03:00:17.959	REALTIME	\N
cmnibwcd501f2za8gx3da791p	\N	cmni8b8rv02ox708n5s952fjt	alex@brspark.com	\N	\N	\N	\N	0	0	\N	40	100	0	null	2026-04-03 03:12:59.801	REALTIME	\N
cmnj3alk000bthojalxarjdnj	\N	cmnj1u3d401z3hw8yw2e5hqnc	alex@brspark.com	\N	\N	\N	\N	0	0	\N	40	100	0	null	2026-04-03 15:59:54.528	REALTIME	\N
cmnjjkzw9003jbddjwygaceob	\N	cmnj0qdf70003j3y6z9zcptf7	alex@brspark.com	\N	\N	\N	\N	0	0	\N	40	100	0	null	2026-04-03 23:35:53.529	REALTIME	\N
cmnjjoo7000cubddj646ketp9	\N	cmnj3zrof019dhojaj8wfptwn	alex@brspark.com	\N	\N	\N	\N	0	0	\N	40	100	20	[{"lat": -23.56719287955252, "lng": -46.78624953196547, "reason": "MOCK_LOCATION", "severity": "HIGH"}]	2026-04-03 23:38:44.985	REALTIME	\N
cmnjjrauw00l2bddj6vax1204	\N	cmnj3yrf4017vhojacp14gc5a	alex@brspark.com	\N	\N	\N	\N	0	0	\N	40	50	90	[{"lat": -23.56719453129495, "lng": -46.7862439702355, "reason": "MOCK_LOCATION", "severity": "HIGH"}, {"lat": -23.56719453129495, "lng": -46.7862439702355, "reason": "MOCK_LOCATION", "severity": "HIGH"}]	2026-04-03 23:40:47.672	REALTIME	\N
cmnjjxgss00pzbddjsmqkkdo9	\N	cmnj1lkhy01n1hw8y4bohk7qw	alex@brspark.com	\N	\N	\N	\N	0	0	\N	40	100	0	null	2026-04-03 23:45:35.308	REALTIME	\N
cmnjljw66011trohkv1xkey1v	\N	cmnj3xzrq016shojah2dyzntn	alex@brspark.com	\N	\N	\N	\N	0.01	0	\N	40	100	80	[{"lat": -23.56719284864866, "lng": -46.78624959075722, "reason": "MOCK_LOCATION", "severity": "HIGH"}, {"lat": -23.56719284864866, "lng": -46.78624959075722, "reason": "MOCK_LOCATION", "severity": "HIGH"}, {"lat": -23.56719284864866, "lng": -46.78624959075722, "reason": "MOCK_LOCATION", "severity": "HIGH"}, {"lat": -23.56719284864866, "lng": -46.78624959075722, "reason": "MOCK_LOCATION", "severity": "HIGH"}]	2026-04-04 00:31:01.279	REALTIME	\N
\.


--
-- Data for Name: FeatureFlag; Type: TABLE DATA; Schema: public; Owner: alex
--

COPY public."FeatureFlag" (id, key, label, description, icon, enabled, "tenantId", "updatedAt") FROM stdin;
\.


--
-- Data for Name: Integration; Type: TABLE DATA; Schema: public; Owner: alex
--

COPY public."Integration" (id, name, type, icon, "apiKey", "baseUrl", "webhookUrl", "lastTestedAt", metadata, "createdAt", "updatedAt", description, status) FROM stdin;
\.


--
-- Data for Name: Invoice; Type: TABLE DATA; Schema: public; Owner: alex
--

COPY public."Invoice" (id, "subscriptionId", amount, status, "dueDate", "paidAt", "externalId", "createdAt") FROM stdin;
\.


--
-- Data for Name: LocaleProfile; Type: TABLE DATA; Schema: public; Owner: alex
--

COPY public."LocaleProfile" (id, "countryCode", name, language, currency, "currencySymbol", "dateFormat", "numberFormat", timezone, "taxIdLabel", "postalCodeLabel", "measureSystem", "isActive", "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: Location; Type: TABLE DATA; Schema: public; Owner: alex
--

COPY public."Location" (id, "tenantId", name, type, address, floor, room, icon, latitude, longitude, "parentId", "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: Metatag; Type: TABLE DATA; Schema: public; Owner: alex
--

COPY public."Metatag" (id, type, key, "ptBr", "enUs", "esEs", icon, color, "isActive", "sortOrder", "createdAt", "updatedAt") FROM stdin;
cmnhgwp9000033yrjo4bw7jf1	MEDIA_CATEGORY	foto	Foto	Foto	Foto	camera-outline	#3B82F6	t	0	2026-04-02 12:45:28.404	2026-04-02 12:45:28.404
cmnhgwpa900043yrjwalyd0mk	MEDIA_CATEGORY	video	Vídeo	Vídeo	Vídeo	videocam-outline	#8B5CF6	t	1	2026-04-02 12:45:28.449	2026-04-02 12:45:28.449
cmnhgwpab00053yrjqpxn2ki9	MEDIA_CATEGORY	documento	Documento	Documento	Documento	document-text-outline	#F59E0B	t	2	2026-04-02 12:45:28.452	2026-04-02 12:45:28.452
cmnhgwpae00063yrj5odh568a	MEDIA_CATEGORY	planta_baixa	Planta Baixa	Planta Baixa	Planta Baixa	map-outline	#10B981	t	3	2026-04-02 12:45:28.454	2026-04-02 12:45:28.454
cmnhgwpah00073yrjczi6purf	MEDIA_CATEGORY	nota_fiscal	Nota Fiscal	Nota Fiscal	Nota Fiscal	receipt-outline	#EF4444	t	4	2026-04-02 12:45:28.457	2026-04-02 12:45:28.457
cmnhgwpak00083yrjoflalzze	MEDIA_CATEGORY	contrato	Contrato	Contrato	Contrato	reader-outline	#6366F1	t	5	2026-04-02 12:45:28.46	2026-04-02 12:45:28.46
cmnhgwpal00093yrjy14vtvom	MEDIA_CATEGORY	laudo	Laudo / Relatório	Laudo / Relatório	Laudo / Relatório	clipboard-outline	#F97316	t	6	2026-04-02 12:45:28.462	2026-04-02 12:45:28.462
cmnhgwpao000a3yrj1q154hb1	MEDIA_CATEGORY	manutencao	Manutenção	Manutenção	Manutenção	construct-outline	#64748B	t	7	2026-04-02 12:45:28.464	2026-04-02 12:45:28.464
cmnhgwpaq000b3yrj03ikvtl4	MEDIA_CATEGORY	seguro	Seguro	Seguro	Seguro	shield-outline	#0EA5E9	t	8	2026-04-02 12:45:28.467	2026-04-02 12:45:28.467
cmnhgwpas000c3yrjwh11nnlq	MEDIA_CATEGORY	outro	Outro	Outro	Outro	ellipsis-horizontal-outline	#9CA3AF	t	9	2026-04-02 12:45:28.468	2026-04-02 12:45:28.468
\.


--
-- Data for Name: NotificationLog; Type: TABLE DATA; Schema: public; Owner: alex
--

COPY public."NotificationLog" (id, "templateId", recipient, channel, status, "sentAt", metadata) FROM stdin;
\.


--
-- Data for Name: NotificationTemplate; Type: TABLE DATA; Schema: public; Owner: alex
--

COPY public."NotificationTemplate" (id, key, label, channel, subject, body, variables, "isActive", "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: Plan; Type: TABLE DATA; Schema: public; Owner: alex
--

COPY public."Plan" (id, name, "priceMonthly", "priceYearly", "maxAssets", "maxUsers", "storageGb", features, "isActive", "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: PushToken; Type: TABLE DATA; Schema: public; Owner: alex
--

COPY public."PushToken" (id, "userId", token, device, "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: ServiceProvider; Type: TABLE DATA; Schema: public; Owner: alex
--

COPY public."ServiceProvider" (id, name, category, rating, reviews, photo, tags, keywords, phone, email, city, state, verified, "isActive", "createdAt", "updatedAt") FROM stdin;
cmnjl2khv000010umoeli4rrf	Eletro Rápido SP	Elétrica	4	243	https://randomuser.me/api/portraits/men/1.jpg	"[\\"Gerador\\",\\"Painel\\",\\"Certificado\\"]"	eletrica instalacao quadro tomada luz iluminacao spda gerador urgencia emergencia	(11) 93098-3158	\N	Santos	SP	t	t	2026-04-04 00:17:32.996	2026-04-04 00:17:32.996
cmnjl2kia000110umekvcdgk3	Hidro Fix Encanamentos	Elétrica	4.5	155	https://randomuser.me/api/portraits/men/2.jpg	"[\\"Tomadas\\",\\"Iluminação\\",\\"Rápido\\"]"	eletrica instalacao quadro tomada luz iluminacao spda gerador urgencia emergencia	(19) 94431-3766	\N	São Paulo	SP	f	t	2026-04-04 00:17:33.011	2026-04-04 00:17:33.011
cmnjl2kib000210uml75g14ha	Spick & Span Limpeza	Elétrica	4.2	145	https://randomuser.me/api/portraits/men/3.jpg	"[\\"Industrial\\",\\"Residencial\\",\\"Urgência\\"]"	eletrica instalacao quadro tomada luz iluminacao spda gerador urgencia emergencia	(11) 97074-7059	\N	Osasco	SP	t	t	2026-04-04 00:17:33.012	2026-04-04 00:17:33.012
cmnjl2kic000310um1yw1xy4a	ReformaMax SP	Elétrica	4.9	299	https://randomuser.me/api/portraits/men/4.jpg	"[\\"24h\\",\\"Emergência\\",\\"Confiável\\"]"	eletrica instalacao quadro tomada luz iluminacao spda gerador urgencia emergencia	(11) 95489-6519	\N	Ribeirão Preto	SP	t	t	2026-04-04 00:17:33.012	2026-04-04 00:17:33.012
cmnjl2kic000410umib98g2pe	Verde Jardins	Elétrica	4.7	153	https://randomuser.me/api/portraits/men/5.jpg	"[\\"Tomadas\\",\\"Iluminação\\",\\"Rápido\\"]"	eletrica instalacao quadro tomada luz iluminacao spda gerador urgencia emergencia	(11) 92134-6601	\N	Guarulhos	SP	t	t	2026-04-04 00:17:33.013	2026-04-04 00:17:33.013
cmnjl2kid000510umv5tf2uzv	SecureHome SP	Hidráulica	4.3	56	https://randomuser.me/api/portraits/men/6.jpg	"[\\"Esgoto\\",\\"Residencial\\",\\"Vistoria\\"]"	hidraulica encanamento cano vazamento desentupimento fossa bomba agua aquecedor	(19) 93898-7916	\N	Piracicaba	SP	t	t	2026-04-04 00:17:33.013	2026-04-04 00:17:33.013
cmnjl2kid000610umzk2iwte1	ClimaTech SP	Hidráulica	3.8	137	https://randomuser.me/api/portraits/men/7.jpg	"[\\"Caixa d'Água\\",\\"Encanamento\\",\\"Rápido\\"]"	hidraulica encanamento cano vazamento desentupimento fossa bomba agua aquecedor	(11) 97916-9673	\N	Campinas	SP	f	t	2026-04-04 00:17:33.014	2026-04-04 00:17:33.014
cmnjl2kie000710umijmt5gtn	TechSupport Brasil	Hidráulica	4.3	75	https://randomuser.me/api/portraits/men/8.jpg	"[\\"Esgoto\\",\\"Residencial\\",\\"Vistoria\\"]"	hidraulica encanamento cano vazamento desentupimento fossa bomba agua aquecedor	(11) 92472-6233	\N	São Paulo	SP	t	t	2026-04-04 00:17:33.014	2026-04-04 00:17:33.014
cmnjl2kie000810um6ayyg46i	Dedetizadora Alpha SP	Hidráulica	4.5	123	https://randomuser.me/api/portraits/men/9.jpg	"[\\"Aquecimento\\",\\"Chuveiro\\",\\"Infiltração\\"]"	hidraulica encanamento cano vazamento desentupimento fossa bomba agua aquecedor	(19) 99703-7342	\N	Campinas	SP	f	t	2026-04-04 00:17:33.015	2026-04-04 00:17:33.015
cmnjl2kif000910umkukclav9	Mudança Fácil SP	Hidráulica	4.4	101	https://randomuser.me/api/portraits/men/10.jpg	"[\\"Vazamento\\",\\"Registro\\",\\"Urgência\\"]"	hidraulica encanamento cano vazamento desentupimento fossa bomba agua aquecedor	(19) 98824-3699	\N	São Paulo	SP	t	t	2026-04-04 00:17:33.015	2026-04-04 00:17:33.015
cmnjl2kif000a10um1ziq53m9	Gastech Instalações	Limpeza	4.1	35	https://randomuser.me/api/portraits/men/11.jpg	"[\\"Hospitalar\\",\\"Especializada\\",\\"Certificada\\"]"	limpeza faxina residencial comercial predial condominio pos obra vidros fachada	(15) 97133-1622	\N	Jundiaí	SP	f	t	2026-04-04 00:17:33.016	2026-04-04 00:17:33.016
cmnjl2kik000b10umcix4e7mp	Pintor Pro SP	Limpeza	4	113	https://randomuser.me/api/portraits/men/12.jpg	"[\\"Pós Obra\\",\\"Profissional\\",\\"Rápido\\"]"	limpeza faxina residencial comercial predial condominio pos obra vidros fachada	(13) 91630-4422	\N	Jundiaí	SP	t	t	2026-04-04 00:17:33.021	2026-04-04 00:17:33.021
cmnjl2kil000c10umpenc0a6p	Elétrica 24h Santos	Limpeza	4	129	https://randomuser.me/api/portraits/men/13.jpg	"[\\"Pós Obra\\",\\"Profissional\\",\\"Rápido\\"]"	limpeza faxina residencial comercial predial condominio pos obra vidros fachada	(19) 96363-1110	\N	Jundiaí	SP	t	t	2026-04-04 00:17:33.021	2026-04-04 00:17:33.021
cmnjl2kil000d10um3yagbh0i	AquaPro Hidráulica	Limpeza	4.8	155	https://randomuser.me/api/portraits/men/14.jpg	"[\\"Condomínio\\",\\"Predial\\",\\"Empresa\\"]"	limpeza faxina residencial comercial predial condominio pos obra vidros fachada	(19) 93647-8189	\N	Campinas	SP	t	t	2026-04-04 00:17:33.022	2026-04-04 00:17:33.022
cmnjl2kim000e10umr5l8sjlr	CleanSpace SP	Limpeza	4.5	110	https://randomuser.me/api/portraits/men/15.jpg	"[\\"Hospitalar\\",\\"Especializada\\",\\"Certificada\\"]"	limpeza faxina residencial comercial predial condominio pos obra vidros fachada	(11) 98065-2749	\N	Ribeirão Preto	SP	t	t	2026-04-04 00:17:33.022	2026-04-04 00:17:33.022
cmnjl2kim000f10um0ykathop	MultiServ Elétrica	Reformas	4.6	109	https://randomuser.me/api/portraits/men/16.jpg	"[\\"Alvenaria\\",\\"Acabamento\\",\\"Pontual\\"]"	reforma alvenaria construcao acabamento banheiro cozinha azulejo porcelanato gesseiro	(11) 91737-7641	\N	São Paulo	SP	t	t	2026-04-04 00:17:33.022	2026-04-04 00:17:33.022
cmnjl2kim000g10umd46jo6kf	HidroMestre	Reformas	3.9	268	https://randomuser.me/api/portraits/men/17.jpg	"[\\"Alvenaria\\",\\"Acabamento\\",\\"Pontual\\"]"	reforma alvenaria construcao acabamento banheiro cozinha azulejo porcelanato gesseiro	(15) 91898-8777	\N	Santos	SP	t	t	2026-04-04 00:17:33.023	2026-04-04 00:17:33.023
cmnjl2kin000h10umpt19pdad	LimpaMax	Reformas	4.9	204	https://randomuser.me/api/portraits/men/18.jpg	"[\\"Banheiro\\",\\"Cozinha\\",\\"Design\\"]"	reforma alvenaria construcao acabamento banheiro cozinha azulejo porcelanato gesseiro	(11) 94143-8672	\N	Sorocaba	SP	f	t	2026-04-04 00:17:33.023	2026-04-04 00:17:33.023
cmnjl2kin000i10umml6u2kwo	ConstruFácil	Reformas	4.9	286	https://randomuser.me/api/portraits/men/19.jpg	"[\\"Pintura\\",\\"Textura\\",\\"Remodelação\\"]"	reforma alvenaria construcao acabamento banheiro cozinha azulejo porcelanato gesseiro	(11) 91896-7950	\N	Osasco	SP	t	t	2026-04-04 00:17:33.023	2026-04-04 00:17:33.023
cmnjl2kin000j10umjg4x3hc7	JardimVerde	Reformas	4.4	20	https://randomuser.me/api/portraits/men/20.jpg	"[\\"Gesseiro\\",\\"Forro de Gesso\\",\\"Acabamento\\"]"	reforma alvenaria construcao acabamento banheiro cozinha azulejo porcelanato gesseiro	(11) 99034-5793	\N	São Bernardo do Campo	SP	f	t	2026-04-04 00:17:33.024	2026-04-04 00:17:33.024
cmnjl2kio000k10umbcu9rctw	GuardaSeuLar	Jardinagem	4	313	https://randomuser.me/api/portraits/men/21.jpg	"[\\"Árvores\\",\\"Poda\\",\\"Certificado\\"]"	jardinagem poda paisagismo jardim grama adubacao irrigacao arvore horta organico	(11) 97957-3264	\N	Campinas	SP	f	t	2026-04-04 00:17:33.024	2026-04-04 00:17:33.024
cmnjl2kio000l10umfdgb7687	FrioCerto	Jardinagem	4.3	142	https://randomuser.me/api/portraits/men/22.jpg	"[\\"Árvores\\",\\"Poda\\",\\"Certificado\\"]"	jardinagem poda paisagismo jardim grama adubacao irrigacao arvore horta organico	(11) 95980-9668	\N	Bauru	SP	t	t	2026-04-04 00:17:33.024	2026-04-04 00:17:33.024
cmnjl2kio000m10umfwreuw19	NetFix TI	Jardinagem	4.5	251	https://randomuser.me/api/portraits/men/23.jpg	"[\\"Poda\\",\\"Paisagismo\\",\\"Manutenção\\"]"	jardinagem poda paisagismo jardim grama adubacao irrigacao arvore horta organico	(11) 92518-2907	\N	Osasco	SP	t	t	2026-04-04 00:17:33.025	2026-04-04 00:17:33.025
cmnjl2kio000n10umnptln8qg	PragaZero	Jardinagem	4.2	121	https://randomuser.me/api/portraits/men/24.jpg	"[\\"Jardim\\",\\"Horta\\",\\"Orgânico\\"]"	jardinagem poda paisagismo jardim grama adubacao irrigacao arvore horta organico	(11) 93934-8797	\N	Santo André	SP	t	t	2026-04-04 00:17:33.025	2026-04-04 00:17:33.025
cmnjl2kip000o10umzzoa12l6	CarregaFácil	Jardinagem	4.1	269	https://randomuser.me/api/portraits/men/25.jpg	"[\\"Poda\\",\\"Paisagismo\\",\\"Manutenção\\"]"	jardinagem poda paisagismo jardim grama adubacao irrigacao arvore horta organico	(11) 98607-6417	\N	Osasco	SP	f	t	2026-04-04 00:17:33.025	2026-04-04 00:17:33.025
cmnjl2kiq000p10um63cse273	Eletro Norte SP	Segurança	4.1	14	https://randomuser.me/api/portraits/men/26.jpg	"[\\"Alarme\\",\\"Monitoramento\\",\\"Residencial\\"]"	seguranca cameras alarme monitoramento cftv cerca eletrica portao residencial	(11) 97877-6345	\N	Ribeirão Preto	SP	f	t	2026-04-04 00:17:33.027	2026-04-04 00:17:33.027
cmnjl2kiq000q10umj7i8wjqp	CanoMestre	Segurança	4.1	288	https://randomuser.me/api/portraits/men/27.jpg	"[\\"Câmeras\\",\\"CFTV\\",\\"24h\\"]"	seguranca cameras alarme monitoramento cftv cerca eletrica portao residencial	(11) 91009-1537	\N	Ribeirão Preto	SP	f	t	2026-04-04 00:17:33.027	2026-04-04 00:17:33.027
cmnjl2kir000r10umn878i8s9	BrilhoTotal	Segurança	4.6	155	https://randomuser.me/api/portraits/men/28.jpg	"[\\"Câmeras\\",\\"CFTV\\",\\"24h\\"]"	seguranca cameras alarme monitoramento cftv cerca eletrica portao residencial	(11) 99473-6486	\N	Jundiaí	SP	f	t	2026-04-04 00:17:33.027	2026-04-04 00:17:33.027
cmnjl2kir000s10umf5e1tvne	AlvenariaMax	Climatização	4.5	217	https://randomuser.me/api/portraits/men/29.jpg	"[\\"Central\\",\\"Comercial\\",\\"Certificado\\"]"	ar condicionado split inverter climatizacao limpeza instalacao manutencao central	(11) 92675-9633	\N	Osasco	SP	f	t	2026-04-04 00:17:33.027	2026-04-04 00:17:33.027
cmnjl2kir000t10umjnx4e1fc	EcoJardim	Climatização	4.7	86	https://randomuser.me/api/portraits/men/30.jpg	"[\\"Ar Condicionado\\",\\"Instalação\\",\\"Manutenção\\"]"	ar condicionado split inverter climatizacao limpeza instalacao manutencao central	(13) 94917-4304	\N	Osasco	SP	f	t	2026-04-04 00:17:33.028	2026-04-04 00:17:33.028
\.


--
-- Data for Name: StockItem; Type: TABLE DATA; Schema: public; Owner: alex
--

COPY public."StockItem" (id, "assetId", name, sku, "currentStock", "minStock", unit, "subLocation", "unitPrice", "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: StockMovement; Type: TABLE DATA; Schema: public; Owner: alex
--

COPY public."StockMovement" (id, "itemId", type, quantity, reason, "fromAssetId", "toAssetId", "createdAt") FROM stdin;
\.


--
-- Data for Name: Subscription; Type: TABLE DATA; Schema: public; Owner: alex
--

COPY public."Subscription" (id, "tenantId", "planId", "billingCycle", status, "currentStart", "currentEnd", "cancelledAt", "trialEndsAt", "externalId", "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: TechnicianProfile; Type: TABLE DATA; Schema: public; Owner: alex
--

COPY public."TechnicianProfile" (id, "userId", status, score, cft, specialty, "createdAt", "updatedAt") FROM stdin;
cmnhr8sw90a2j9g8m4sk391vj	cmnhhqj5w000g3yrj2m7fnu6n	ACTIVE	5	\N	\N	2026-04-02 17:34:49.161	2026-04-02 17:34:49.161
cmnjlghup00vcrohkxw1weglx	cmnjl5g0000uirohkljbrswtz	ACTIVE	5	\N	\N	2026-04-04 00:28:22.753	2026-04-04 00:28:22.753
\.


--
-- Data for Name: TelemetryEvent; Type: TABLE DATA; Schema: public; Owner: alex
--

COPY public."TelemetryEvent" (id, "tenantId", "ownerEmail", "deviceId", "executionId", "eventType", lat, lng, accuracy, altitude, speed, heading, "locationSource", "batteryLevel", "batteryCharging", "networkType", "appVersion", "osVersion", "deviceModel", "isMockLocation", "isRooted", "clockDriftMs", "serverTimestamp", "deviceTimestamp", payload, "retentionTier", "expiresAt") FROM stdin;
cmnhgupgc00003yrj16djy6ut	\N	test@brspark.com	\N	\N	SESSION_OPEN	-23.5505	-46.6333	15	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 12:43:55.356	\N	null	OPERATIONAL	2026-09-29 12:43:55.354
cmnhid0hx00rz3yrjx67fssf3	\N	unknown	dev_szkcjr	cmngw885r005p7y155oxu7qiw	OS_ACCEPT	\N	\N	\N	\N	\N	\N	GPS	\N	\N	UNKNOWN	1.0.0	26.3.1	Simulator iOS	f	f	4	2026-04-02 13:26:09.093	2026-04-02 13:26:08.883	{"previousState": "IDLE"}	LEGAL	2031-04-02 13:26:09.092
cmnhidbh600sf3yrjfgzwv9iz	\N	unknown	\N	\N	HEARTBEAT	-23.569983	-46.7851655	5	0	-1	-1	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 13:26:23.323	2026-04-02 13:26:17.669	null	RAW_SHORT	2026-04-17 13:26:23.322
cmnhidmvs00sv3yrjqupyu2vh	\N	unknown	dev_szkcjr	cmngw885r005p7y155oxu7qiw	OS_ACCEPT	\N	\N	\N	\N	\N	\N	GPS	\N	\N	UNKNOWN	1.0.0	26.3.1	Simulator iOS	f	f	-1	2026-04-02 13:26:38.105	2026-04-02 13:26:37.933	{"previousState": "DISPATCHED"}	LEGAL	2031-04-02 13:26:38.102
cmnhidmvs00sw3yrj435sc22k	\N	unknown	\N	\N	HEARTBEAT	-23.569983	-46.7851655	5	0	-1	-1	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 13:26:38.105	2026-04-02 13:26:37.749	null	RAW_SHORT	2026-04-17 13:26:38.102
cmnhif5be00v53yrj9sahfgfl	\N	unknown	dev_szkcjr	cmngw885r005p7y155oxu7qiw	OS_ACCEPT	\N	\N	\N	\N	\N	\N	GPS	\N	\N	UNKNOWN	1.0.0	26.3.1	Simulator iOS	f	f	8	2026-04-02 13:27:48.65	2026-04-02 13:27:45.286	{"previousState": "IDLE"}	LEGAL	2031-04-02 13:27:48.649
cmnhif5be00v63yrjdg10zh7l	\N	unknown	\N	\N	HEARTBEAT	-23.569983	-46.7851655	5	0	-1	-1	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 13:27:48.65	2026-04-02 13:27:45.042	null	RAW_SHORT	2026-04-17 13:27:48.649
cmnhif96q00vh3yrjnhto9zam	\N	unknown	dev_szkcjr	cmngw885r005p7y155oxu7qiw	OS_ACCEPT	\N	\N	\N	\N	\N	\N	GPS	\N	\N	UNKNOWN	1.0.0	26.3.1	Simulator iOS	f	f	-2	2026-04-02 13:27:53.666	2026-04-02 13:27:49.304	{"previousState": "DISPATCHED"}	LEGAL	2031-04-02 13:27:53.665
cmnhif96q00vi3yrj9g46y0hj	\N	unknown	\N	\N	HEARTBEAT	-23.569983	-46.7851655	5	0	-1	-1	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 13:27:53.666	2026-04-02 13:27:49.051	null	RAW_SHORT	2026-04-17 13:27:53.665
cmnhigepx00x23yrjcc0g2duk	\N	unknown	dev_szkcjr	cmngw885r005p7y155oxu7qiw	OS_ACCEPT	\N	\N	\N	\N	\N	\N	GPS	\N	\N	UNKNOWN	1.0.0	26.3.1	Simulator iOS	f	f	9	2026-04-02 13:28:47.493	2026-04-02 13:28:47.366	{"previousState": "DISPATCHED"}	LEGAL	2031-04-02 13:28:47.492
cmnhigfr100x83yrjyr6gw7wk	\N	unknown	\N	\N	HEARTBEAT	-23.569983	-46.7851655	5	0	-1	-1	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 13:28:48.829	2026-04-02 13:28:47.339	null	RAW_SHORT	2026-04-17 13:28:48.828
cmnhivt0w01he3yrjibb378vq	\N	unknown	dev_szkcjr	cmngw885r005p7y155oxu7qiw	OS_ACCEPT	\N	\N	\N	\N	\N	\N	GPS	\N	\N	UNKNOWN	1.0.0	26.3.1	Simulator iOS	f	f	-116	2026-04-02 13:40:45.872	2026-04-02 13:40:41.567	{"previousState": "DISPATCHED"}	LEGAL	2031-04-02 13:40:45.87
cmnhivt0w01hf3yrjjm5hycq7	\N	unknown	\N	\N	HEARTBEAT	-23.569983	-46.7851655	5	0	-1	-1	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 13:40:45.872	2026-04-02 13:40:41.161	null	RAW_SHORT	2026-04-17 13:40:45.87
cmnhr9hmq0a3d9g8mkgcxvg3z	cmnhhqj5c000e3yrjmvwv50er	alex@brspark.com	dev_szkcjr	\N	SESSION_OPEN	\N	\N	\N	\N	\N	\N	GPS	\N	\N	UNKNOWN	1.0.0	26.3.1	Simulator iOS	f	f	-106	2026-04-02 17:35:21.218	2026-04-02 17:35:16.922	{}	OPERATIONAL	2026-09-29 17:35:21.216
cmnhrb85j0a5r9g8mckgo44l2	\N	unknown	dev_szkcjr	\N	SESSION_OPEN	\N	\N	\N	\N	\N	\N	GPS	\N	\N	UNKNOWN	1.0.0	26.3.1	Simulator iOS	f	f	6	2026-04-02 17:36:42.248	2026-04-02 17:36:42.087	{}	OPERATIONAL	2026-09-29 17:36:42.247
cmnhrtfrb0bh09g8m3rdlnrcp	\N	unknown	dev_szkcjr	cmnhrqhbi0b9j9g8mtnd7ocdb	OS_ACCEPT	\N	\N	\N	\N	\N	\N	GPS	\N	\N	UNKNOWN	1.0.0	26.3.1	Simulator iOS	f	f	-45	2026-04-02 17:50:51.911	2026-04-02 17:50:40.178	{"previousState": "IDLE"}	LEGAL	2031-04-02 17:50:51.884
cmnhrtfiz0bgw9g8meixc78k2	\N	unknown	dev_szkcjr	cmnhrqhbi0b9j9g8mtnd7ocdb	OS_ACCEPT	\N	\N	\N	\N	\N	\N	GPS	\N	\N	UNKNOWN	1.0.0	26.3.1	Simulator iOS	f	f	-45	2026-04-02 17:50:51.611	2026-04-02 17:50:40.178	{"previousState": "IDLE"}	LEGAL	2031-04-02 17:50:51.611
cmnhrtf8n0bgu9g8m5z2rf4f5	\N	unknown	dev_szkcjr	cmnhrqhbi0b9j9g8mtnd7ocdb	OS_ACCEPT	\N	\N	\N	\N	\N	\N	GPS	\N	\N	UNKNOWN	1.0.0	26.3.1	Simulator iOS	f	f	-45	2026-04-02 17:50:51.239	2026-04-02 17:50:40.178	{"previousState": "IDLE"}	LEGAL	2031-04-02 17:50:51.208
cmnhrtfkc0bgy9g8mr1drf0g1	\N	unknown	dev_szkcjr	cmnhrqhbi0b9j9g8mtnd7ocdb	OS_ACCEPT	\N	\N	\N	\N	\N	\N	GPS	\N	\N	UNKNOWN	1.0.0	26.3.1	Simulator iOS	f	f	-45	2026-04-02 17:50:51.66	2026-04-02 17:50:40.178	{"previousState": "IDLE"}	LEGAL	2031-04-02 17:50:51.659
cmnhrtf7b0bgs9g8mw1z5rekj	\N	unknown	dev_szkcjr	cmnhrqhbi0b9j9g8mtnd7ocdb	OS_ACCEPT	\N	\N	\N	\N	\N	\N	GPS	\N	\N	UNKNOWN	1.0.0	26.3.1	Simulator iOS	f	f	-45	2026-04-02 17:50:51.184	2026-04-02 17:50:40.178	{"previousState": "IDLE"}	LEGAL	2031-04-02 17:50:50.967
cmnhrtfkc0bgz9g8m4o9coxew	\N	unknown	\N	\N	HEARTBEAT	-23.569983	-46.7851655	5	0	-1	-1	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 17:50:51.66	2026-04-02 17:50:40.752	null	RAW_SHORT	2026-04-17 17:50:51.659
cmnhrtfiz0bgx9g8m9jf22zmm	\N	unknown	\N	\N	HEARTBEAT	-23.569983	-46.7851655	5	0	-1	-1	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 17:50:51.611	2026-04-02 17:50:40.752	null	RAW_SHORT	2026-04-17 17:50:51.611
cmnhrtf7j0bgt9g8mpc2clbzt	\N	unknown	\N	\N	HEARTBEAT	-23.569983	-46.7851655	5	0	-1	-1	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 17:50:51.184	2026-04-02 17:50:40.752	null	RAW_SHORT	2026-04-17 17:50:50.967
cmnhrtf8n0bgv9g8mdjkh25lo	\N	unknown	\N	\N	HEARTBEAT	-23.569983	-46.7851655	5	0	-1	-1	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 17:50:51.239	2026-04-02 17:50:40.752	null	RAW_SHORT	2026-04-17 17:50:51.208
cmnhrtfrb0bh19g8melp76gxq	\N	unknown	\N	\N	HEARTBEAT	-23.569983	-46.7851655	5	0	-1	-1	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 17:50:51.911	2026-04-02 17:50:40.752	null	RAW_SHORT	2026-04-17 17:50:51.884
cmnhrufd00bk49g8mkhakgz4u	\N	unknown	dev_szkcjr	cmnhrqhbi0b9j9g8mtnd7ocdb	TRANSIT_START	\N	\N	\N	\N	\N	\N	GPS	\N	\N	UNKNOWN	1.0.0	26.3.1	Simulator iOS	f	f	-4	2026-04-02 17:51:38.051	2026-04-02 17:51:36.074	{"previousState": "DISPATCHED"}	LEGAL	2031-04-02 17:51:38.048
cmnhrufd00bk59g8mumlxae5f	\N	unknown	\N	\N	HEARTBEAT	-23.569983	-46.7851655	5	0	-1	-1	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 17:51:38.051	2026-04-02 17:51:36.082	null	RAW_SHORT	2026-04-17 17:51:38.048
cmnhrxyhk003wl0zikj60jev4	\N	unknown@empresa.com	dev_szkcjr	cmnhrqhbi0b9j9g8mtnd7ocdb	SESSION_CLOSE	\N	\N	\N	\N	\N	\N	GPS	\N	\N	UNKNOWN	1.0.0	26.3.1	Simulator iOS	f	f	-35	2026-04-02 17:54:22.808	2026-04-02 17:54:20.099	{"previousState": "IN_TRANSIT"}	OPERATIONAL	2026-09-29 17:54:22.807
cmnhrxyhm003xl0zinfo86p1o	\N	unknown@empresa.com	dev_szkcjr	cmnhrqhbi0b9j9g8mtnd7ocdb	SESSION_CLOSE	\N	\N	\N	\N	\N	\N	GPS	\N	\N	UNKNOWN	1.0.0	26.3.1	Simulator iOS	f	f	-35	2026-04-02 17:54:22.811	2026-04-02 17:54:20.099	{"previousState": "IN_TRANSIT"}	OPERATIONAL	2026-09-29 17:54:22.81
cmnhslt190014quvgeygqf2z7	\N	unknown	dev_szkcjr	cmnhrqhbi0b9j9g8mtnd7ocdb	OS_ACCEPT	\N	\N	\N	\N	\N	\N	GPS	\N	\N	UNKNOWN	1.0.0	26.3.1	Simulator iOS	f	f	6	2026-04-02 18:12:55.485	2026-04-02 18:12:55.438	{"previousState": "IDLE"}	LEGAL	2031-04-02 18:12:55.484
cmnht90hm00w0quvgb26boerv	\N	unknown	dev_szkcjr	cmnht8qog00vkquvgverzll77	OS_ACCEPT	\N	\N	\N	\N	\N	\N	GPS	\N	\N	UNKNOWN	1.0.0	26.3.1	Simulator iOS	f	f	0	2026-04-02 18:30:58.234	2026-04-02 18:30:53.922	{"previousState": "DISPATCHED"}	LEGAL	2031-04-02 18:30:58.231
cmnht90hm00w1quvgvy7tuptg	\N	unknown	\N	\N	HEARTBEAT	-23.569983	-46.7851655	5	0	-1	-1	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 18:30:58.234	2026-04-02 18:30:53.973	null	RAW_SHORT	2026-04-17 18:30:58.231
cmnht94cs00w7quvgmalrzbb8	\N	unknown	dev_szkcjr	cmnht8qog00vkquvgverzll77	TRANSIT_START	\N	\N	\N	\N	\N	\N	GPS	\N	\N	UNKNOWN	1.0.0	26.3.1	Simulator iOS	f	f	19	2026-04-02 18:31:03.245	2026-04-02 18:31:00.835	{"previousState": "DISPATCHED"}	LEGAL	2031-04-02 18:31:03.242
cmnht94ct00w8quvg6uc7wrpm	\N	unknown	\N	\N	HEARTBEAT	-23.569983	-46.7851655	5	0	-1	-1	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 18:31:03.245	2026-04-02 18:31:00.799	null	RAW_SHORT	2026-04-17 18:31:03.242
cmnhtb5ur00z9quvgtcvokbkh	\N	unknown@empresa.com	dev_szkcjr	cmnht8qog00vkquvgverzll77	SESSION_CLOSE	\N	\N	\N	\N	\N	\N	GPS	\N	\N	UNKNOWN	1.0.0	26.3.1	Simulator iOS	f	f	-30	2026-04-02 18:32:38.5	2026-04-02 18:32:37.306	{"previousState": "IN_TRANSIT"}	OPERATIONAL	2026-09-29 18:32:38.499
cmnhtodp8002kf5jr53ojt1fj	\N	unknown	dev_szkcjr	cmnhtnyp4001zf5jrvv0r23qa	OS_ACCEPT	\N	\N	\N	\N	\N	\N	GPS	\N	\N	UNKNOWN	1.0.0	26.3.1	Simulator iOS	f	f	2	2026-04-02 18:42:55.196	2026-04-02 18:42:53.355	{"previousState": "IDLE"}	LEGAL	2031-04-02 18:42:55.195
cmnhtodp8002lf5jr6dfeu396	\N	unknown	\N	\N	HEARTBEAT	-23.569983	-46.7851655	5	0	-1	-1	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 18:42:55.196	2026-04-02 18:42:52.846	null	RAW_SHORT	2026-04-17 18:42:55.195
cmnhtp8or003qf5jrdo5o3nqh	\N	unknown	dev_szkcjr	cmnhtnyp4001zf5jrvv0r23qa	TRANSIT_START	\N	\N	\N	\N	\N	\N	GPS	\N	\N	UNKNOWN	1.0.0	26.3.1	Simulator iOS	f	f	22	2026-04-02 18:43:35.356	2026-04-02 18:43:34.526	{"previousState": "DISPATCHED"}	LEGAL	2031-04-02 18:43:35.355
cmnhtp8or003rf5jrvi6ttfuu	\N	unknown	\N	\N	HEARTBEAT	-23.569983	-46.7851655	5	0	-1	-1	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 18:43:35.356	2026-04-02 18:43:30.993	null	RAW_SHORT	2026-04-17 18:43:35.355
cmnhtp8or003sf5jrqh8mara0	\N	unknown	dev_szkcjr	cmnhtnyp4001zf5jrvv0r23qa	FRAUD_FLAG	37.33240731	-122.03046898	\N	\N	\N	\N	GPS	\N	\N	UNKNOWN	1.0.0	26.3.1	Simulator iOS	t	f	-8	2026-04-02 18:43:35.356	2026-04-02 18:43:34.872	{"lat": 37.33240731, "lng": -122.03046898, "reason": "MOCK_LOCATION", "severity": "HIGH"}	LEGAL	2031-04-02 18:43:35.355
cmnhtp8or003tf5jr84hv6jbp	\N	unknown	\N	\N	HEARTBEAT	37.33240731	-122.03046898	65	0	-1	-1	\N	\N	\N	\N	\N	\N	\N	t	f	\N	2026-04-02 18:43:35.356	2026-04-02 18:43:34.802	null	RAW_SHORT	2026-04-17 18:43:35.355
cmnhtrhzl006zf5jrb2167vkh	\N	unknown@empresa.com	dev_szkcjr	cmnhtnyp4001zf5jrvv0r23qa	SESSION_CLOSE	\N	\N	\N	\N	\N	\N	GPS	\N	\N	UNKNOWN	1.0.0	26.3.1	Simulator iOS	f	f	-44	2026-04-02 18:45:20.721	2026-04-02 18:45:17.527	{"previousState": "IN_TRANSIT"}	OPERATIONAL	2026-09-29 18:45:20.72
cmnhyvreh008xk84w92e0f1zw	\N	unknown	dev_szkcjr	cmnhykdhy0005k84w6xci9f1x	OS_ACCEPT	\N	\N	\N	\N	\N	\N	GPS	\N	\N	UNKNOWN	1.0.0	26.3.1	Simulator iOS	f	f	-3	2026-04-02 21:08:37.626	2026-04-02 21:08:34.411	{"previousState": "IDLE"}	LEGAL	2031-04-02 21:08:37.623
cmnhyvreh008yk84w9t6pjag6	\N	unknown	\N	\N	HEARTBEAT	-23.569983	-46.7851655	5	0	-1	-1	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 21:08:37.626	2026-04-02 21:08:34.008	null	RAW_SHORT	2026-04-17 21:08:37.623
cmnhywq4600adk84wknlp6ede	\N	unknown	dev_szkcjr	cmnhykdhy0005k84w6xci9f1x	TRANSIT_START	\N	\N	\N	\N	\N	\N	GPS	\N	\N	UNKNOWN	1.0.0	26.3.1	Simulator iOS	f	f	24	2026-04-02 21:09:22.615	2026-04-02 21:09:18.466	{"previousState": "DISPATCHED"}	LEGAL	2031-04-02 21:09:22.611
cmnhywq4600aek84w95laywt5	\N	unknown	\N	\N	HEARTBEAT	37.33485843	-122.03334424	5	0	14.82	254.88	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 21:09:22.615	2026-04-02 21:09:18.63	null	RAW_SHORT	2026-04-17 21:09:22.611
cmnhywxts00apk84w2c8qcus8	\N	unknown	\N	\N	HEARTBEAT	37.3345597	-122.03583308	5	0	24.28	267.19	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 21:09:32.609	2026-04-02 21:09:28.883	null	RAW_SHORT	2026-04-17 21:09:32.608
cmnhyx1oi00avk84wnems85du	\N	unknown	\N	\N	HEARTBEAT	37.33451917	-122.03813827	5	0	27.07	268.95	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 21:09:37.602	2026-04-02 21:09:36.883	null	RAW_SHORT	2026-04-17 21:09:37.601
cmnhyx9eh00b6k84wbnyc591j	\N	unknown	\N	\N	HEARTBEAT	37.33446519	-122.04041597	5	0	31.11	268.59	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 21:09:47.61	2026-04-02 21:09:43.892	null	RAW_SHORT	2026-04-17 21:09:47.609
cmnhyxd9w00bck84wh2rob6nk	\N	unknown	\N	\N	HEARTBEAT	37.33445363	-122.04302852	5	0	34.3	270	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 21:09:52.629	2026-04-02 21:09:50.892	null	RAW_SHORT	2026-04-17 21:09:52.628
cmnhyxh4q00bik84wz63sb06k	\N	unknown	\N	\N	HEARTBEAT	37.33444244	-122.045341	5	0	33.15	269.3	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 21:09:57.626	2026-04-02 21:09:56.88	null	RAW_SHORT	2026-04-17 21:09:57.625
cmnhyxout00btk84wtslp8wpk	\N	unknown	\N	\N	HEARTBEAT	37.33420971	-122.04784191	5	0	30.78	256.64	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 21:10:07.637	2026-04-02 21:10:03.881	null	RAW_SHORT	2026-04-17 21:10:07.636
cmnhyxsph00bzk84wfuxwn789	\N	unknown	\N	\N	HEARTBEAT	37.33367998	-122.05028306	5	0	32.98	255.59	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 21:10:12.629	2026-04-02 21:10:10.894	null	RAW_SHORT	2026-04-17 21:10:12.627
cmnhyxwkc00c5k84wfda5j6uc	\N	unknown	\N	\N	HEARTBEAT	37.33321101	-122.05246948	5	0	33.49	254.88	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 21:10:17.629	2026-04-02 21:10:16.886	null	RAW_SHORT	2026-04-17 21:10:17.628
cmnhyy4a300cgk84wamthky10	\N	unknown	\N	\N	HEARTBEAT	37.33268517	-122.05498531	5	0	33.08	254.88	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 21:10:27.627	2026-04-02 21:10:23.885	null	RAW_SHORT	2026-04-17 21:10:27.626
cmnhyy84z00cmk84w3k6qhux3	\N	unknown	\N	\N	HEARTBEAT	37.33229772	-122.05757204	5	0	33.77	266.48	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 21:10:32.627	2026-04-02 21:10:30.89	null	RAW_SHORT	2026-04-17 21:10:32.626
cmnhyybzw00csk84winayrmj1	\N	unknown	\N	\N	HEARTBEAT	37.33244004	-122.05984991	5	0	34	282.3	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 21:10:37.628	2026-04-02 21:10:36.886	null	RAW_SHORT	2026-04-17 21:10:37.627
cmnhyyjpm00d3k84wqg7ulg6w	\N	unknown	\N	\N	HEARTBEAT	37.33307736	-122.06203541	5	0	34.54	294.26	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 21:10:47.626	2026-04-02 21:10:42.892	null	RAW_SHORT	2026-04-17 21:10:47.625
cmnhyynkg00d9k84wp3hgpse8	\N	unknown	\N	\N	HEARTBEAT	37.33383844	-122.06417204	5	0	34.46	293.91	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 21:10:52.624	2026-04-02 21:10:48.883	null	RAW_SHORT	2026-04-17 21:10:52.623
cmnhyyrfh00dfk84w7nn4vnee	\N	unknown	\N	\N	HEARTBEAT	37.33435409	-122.06636961	5	0	33.82	279.84	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 21:10:57.629	2026-04-02 21:10:54.886	null	RAW_SHORT	2026-04-17 21:10:57.628
cmnhyyva900dlk84wl3y9s9cn	\N	unknown	\N	\N	HEARTBEAT	37.33442613	-122.06864035	5	0	33.67	266.13	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 21:11:02.625	2026-04-02 21:11:00.89	null	RAW_SHORT	2026-04-17 21:11:02.624
cmnhyyz4y00drk84w6milyv11	\N	unknown	\N	\N	HEARTBEAT	37.33410968	-122.07087404	5	0	33.62	256.99	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 21:11:07.618	2026-04-02 21:11:06.883	null	RAW_SHORT	2026-04-17 21:11:07.617
cmnhyz6uq00e2k84wr6s0bh6o	\N	unknown	\N	\N	HEARTBEAT	37.33369775	-122.07309474	5	0	33.08	258.05	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 21:11:17.619	2026-04-02 21:11:12.878	null	RAW_SHORT	2026-04-17 21:11:17.618
cmnhyzapt00e8k84wcen9iwui	\N	unknown	\N	\N	HEARTBEAT	37.33355228	-122.07558936	5	0	31.58	274.57	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 21:11:22.625	2026-04-02 21:11:19.888	null	RAW_SHORT	2026-04-17 21:11:22.624
cmnhyzekq00eek84w3iztijd4	\N	unknown	\N	\N	HEARTBEAT	37.33402871	-122.07804543	5	0	32.47	292.15	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 21:11:27.626	2026-04-02 21:11:26.893	null	RAW_SHORT	2026-04-17 21:11:27.625
cmnhyzmak00epk84wcqpy9h9y	\N	unknown	\N	\N	HEARTBEAT	37.33511119	-122.08026077	5	0	33.53	310.78	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 21:11:37.629	2026-04-02 21:11:33.884	null	RAW_SHORT	2026-04-17 21:11:37.627
cmnhyzq5g00evk84we3b0wiaq	\N	unknown	\N	\N	HEARTBEAT	37.33638536	-122.08193111	5	0	33.88	314.3	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 21:11:42.628	2026-04-02 21:11:39.882	null	RAW_SHORT	2026-04-17 21:11:42.627
cmnhyzu0p00f1k84weoqq0zmh	\N	unknown	\N	\N	HEARTBEAT	37.33758129	-122.08362627	5	0	33.46	307.27	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 21:11:47.642	2026-04-02 21:11:45.889	null	RAW_SHORT	2026-04-17 21:11:47.641
cmnhz01qk00fck84wmhkpld0i	\N	unknown	\N	\N	HEARTBEAT	37.33879885	-122.08577472	5	0	33.54	304.45	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 21:11:57.644	2026-04-02 21:11:52.879	null	RAW_SHORT	2026-04-17 21:11:57.643
cmnhz05m700fik84wstcioevu	\N	unknown	\N	\N	HEARTBEAT	37.33998434	-122.08792937	5	0	32.79	304.45	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 21:12:02.671	2026-04-02 21:11:59.895	null	RAW_SHORT	2026-04-17 21:12:02.67
cmnhz09h300fok84wvrdr8aeh	\N	unknown	\N	\N	HEARTBEAT	37.34107194	-122.09015057	5	0	33.16	299.88	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 21:12:07.671	2026-04-02 21:12:06.888	null	RAW_SHORT	2026-04-17 21:12:07.67
cmnhz0h6l00fzk84wpqa87c2i	\N	unknown	\N	\N	HEARTBEAT	37.34229154	-122.092223	5	0	32.66	314.3	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 21:12:17.662	2026-04-02 21:12:13.884	null	RAW_SHORT	2026-04-17 21:12:17.661
cmnhz0l1e00g5k84w0us6iclf	\N	unknown	\N	\N	HEARTBEAT	37.34374576	-122.09392	5	0	31.14	317.46	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 21:12:22.659	2026-04-02 21:12:20.878	null	RAW_SHORT	2026-04-17 21:12:22.658
cmnhz0ox100gjk84w044ojlxq	\N	unknown@empresa.com	dev_szkcjr	cmnhykdhy0005k84w6xci9f1x	SESSION_CLOSE	\N	\N	\N	\N	\N	\N	GPS	\N	\N	UNKNOWN	1.0.0	26.3.1	Simulator iOS	f	f	-30	2026-04-02 21:12:27.685	2026-04-02 21:12:23.227	{"previousState": "IN_TRANSIT"}	OPERATIONAL	2026-09-29 21:12:27.684
cmni0bjvo027wk84waxxdyg02	cmnhhqj5c000e3yrjmvwv50er	alex@brspark.com	dev_szkcjr	cmnhykdhy0005k84w6xci9f1x	SESSION_OPEN	\N	\N	\N	\N	\N	\N	GPS	\N	\N	UNKNOWN	1.0.0	26.3.1	Simulator iOS	f	f	1	2026-04-02 21:48:53.988	2026-04-02 21:48:51.464	{}	OPERATIONAL	2026-09-29 21:48:53.987
cmni0brlf028ck84wzdkcipvx	cmnhhqj5c000e3yrjmvwv50er	alex@brspark.com	dev_szkcjr	cmnhykdhy0005k84w6xci9f1x	SESSION_OPEN	\N	\N	\N	\N	\N	\N	GPS	\N	\N	UNKNOWN	1.0.0	26.3.1	Simulator iOS	f	f	6	2026-04-02 21:49:03.987	2026-04-02 21:49:01.195	{}	OPERATIONAL	2026-09-29 21:49:03.986
cmni0hjo402gkk84wujipynw1	cmnhhqj5c000e3yrjmvwv50er	alex@brspark.com	dev_szkcjr	\N	SESSION_OPEN	\N	\N	\N	\N	\N	\N	GPS	\N	\N	UNKNOWN	1.0.0	26.3.1	Simulator iOS	f	f	7	2026-04-02 21:53:33.653	2026-04-02 21:53:33.479	{}	OPERATIONAL	2026-09-29 21:53:33.652
cmni0hnjr02gqk84wnannaf3k	cmnhhqj5c000e3yrjmvwv50er	alex@brspark.com	dev_szkcjr	\N	SESSION_OPEN	\N	\N	\N	\N	\N	\N	GPS	\N	\N	UNKNOWN	1.0.0	26.3.1	Simulator iOS	f	f	6	2026-04-02 21:53:38.68	2026-04-02 21:53:34.129	{}	OPERATIONAL	2026-09-29 21:53:38.679
cmni0qgy302tbk84wmyzhct36	cmnhhqj5c000e3yrjmvwv50er	alex@brspark.com	dev_szkcjr	cmni0qayq02sqk84wy5bpuvea	OS_ACCEPT	\N	\N	\N	\N	\N	\N	GPS	\N	\N	UNKNOWN	1.0.0	26.3.1	Simulator iOS	f	f	-3	2026-04-02 22:00:30.028	2026-04-02 22:00:29.162	{"previousState": "IDLE"}	LEGAL	2031-04-02 22:00:30.027
cmni0qgy302tck84w2appofd9	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.33019806	-122.02462051	10	0	3.74	88.4	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 22:00:30.028	2026-04-02 22:00:29.134	null	RAW_SHORT	2026-04-17 22:00:30.027
cmni0qsir02txk84w6707ilke	cmnhhqj5c000e3yrjmvwv50er	alex@brspark.com	dev_szkcjr	cmni0qayq02sqk84wy5bpuvea	TRANSIT_START	\N	\N	\N	\N	\N	\N	GPS	\N	\N	UNKNOWN	1.0.0	26.3.1	Simulator iOS	f	f	21	2026-04-02 22:00:45.028	2026-04-02 22:00:40.17	{"previousState": "DISPATCHED"}	LEGAL	2031-04-02 22:00:45.027
cmni0qsir02tyk84wqp1r8juh	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.33020867	-122.024012	30	0	3.9	91.39	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 22:00:45.028	2026-04-02 22:00:40.13	null	RAW_SHORT	2026-04-17 22:00:45.027
cmni0rv8l02vdk84wzvej8crg	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.33009437	-122.02175602	5	0	3.68	97.01	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 22:01:35.205	2026-04-02 22:01:32.143	null	RAW_SHORT	2026-04-17 22:01:35.204
cmni0w9vs031bk84wyku8cpzu	cmnhhqj5c000e3yrjmvwv50er	alex@brspark.com	dev_szkcjr	cmni0qayq02sqk84wy5bpuvea	SESSION_CLOSE	\N	\N	\N	\N	\N	\N	GPS	\N	\N	UNKNOWN	1.0.0	26.3.1	Simulator iOS	f	f	-31	2026-04-02 22:05:00.808	2026-04-02 22:04:59.946	{"previousState": "IN_TRANSIT"}	OPERATIONAL	2026-09-29 22:05:00.807
cmni0w9vs031ck84w7u35bcb9	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.33467638	-122.03432425	5	0	20.07	259.45	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 22:05:00.808	2026-04-02 22:04:59.826	null	RAW_SHORT	2026-04-17 22:05:00.807
cmni0wpdf031xk84wzy8d1uqw	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.33447068	-122.04007348	5	0	30.45	267.89	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 22:05:20.884	2026-04-02 22:05:19.82	null	RAW_SHORT	2026-04-17 22:05:20.883
cmni0x0zr032ik84w10qf00yv	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.33443657	-122.04571727	5	0	33.01	267.54	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 22:05:35.943	2026-04-02 22:05:34.828	null	RAW_SHORT	2026-04-17 22:05:35.942
cmni0xcl0032yk84w48p8db73	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.33344889	-122.05137547	5	0	33.73	255.59	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 22:05:50.964	2026-04-02 22:05:50.817	null	RAW_SHORT	2026-04-17 22:05:50.963
cmni0xs1v033jk84w4ppjohru	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.33232211	-122.05719234	5	0	33.56	264.38	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 22:06:11.012	2026-04-02 22:06:06.82	null	RAW_SHORT	2026-04-17 22:06:11.011
cmni0y3nw033zk84wavq2joml	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.33333498	-122.06274686	5	0	34.33	294.61	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 22:06:26.061	2026-04-02 22:06:21.819	null	RAW_SHORT	2026-04-17 22:06:26.059
cmni0yfa8034hk84wdwfw532y	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.33444654	-122.06826065	5	0	33.67	268.24	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 22:06:41.121	2026-04-02 22:06:36.827	null	RAW_SHORT	2026-04-17 22:06:41.12
cmni0yqvz034zk84wp4qxddn6	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.33359159	-122.07381886	5	0	32.16	261.21	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 22:06:56.159	2026-04-02 22:06:51.832	null	RAW_SHORT	2026-04-17 22:06:56.158
cmni0z2ih035fk84wpv52f3vr	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.33457244	-122.0793639	5	0	33.02	301.99	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 22:07:11.225	2026-04-02 22:07:07.818	null	RAW_SHORT	2026-04-17 22:07:11.224
cmni0zce3035xk84wjjd2u0k8	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.33758129	-122.08362627	5	0	33.46	307.27	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 22:07:24.028	2026-04-02 22:07:22.824	null	RAW_SHORT	2026-04-17 22:07:24.027
cmni0zppi036sk84wyycp3ei1	cmnhhqj5c000e3yrjmvwv50er	alex@brspark.com	dev_szkcjr	cmni0zakf035wk84wuzy84yix	OS_ACCEPT	\N	\N	\N	\N	\N	\N	GPS	\N	\N	UNKNOWN	1.0.0	26.3.1	Simulator iOS	f	f	6	2026-04-02 22:07:41.287	2026-04-02 22:07:37.361	{"previousState": "IDLE"}	LEGAL	2031-04-02 22:07:41.286
cmni0zppj036tk84ws1c9y0tl	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.33998434	-122.08792937	5	0	32.79	304.45	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 22:07:41.287	2026-04-02 22:07:36.831	null	RAW_SHORT	2026-04-17 22:07:41.286
cmni0zxfx0374k84wwno6sqav	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.34154237	-122.09108423	5	0	32.97	304.1	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 22:07:51.31	2026-04-02 22:07:46.821	null	RAW_SHORT	2026-04-17 22:07:51.309
cmni1056j037fk84w04o2x6fd	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.34353735	-122.09368045	5	0	31.14	317.46	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 22:08:01.34	2026-04-02 22:07:56.827	null	RAW_SHORT	2026-04-17 22:08:01.339
cmni1056j037gk84wyscftrde	cmnhhqj5c000e3yrjmvwv50er	alex@brspark.com	dev_szkcjr	cmni0zakf035wk84wuzy84yix	TRANSIT_START	\N	\N	\N	\N	\N	\N	GPS	\N	\N	UNKNOWN	1.0.0	26.3.1	Simulator iOS	f	f	-9	2026-04-02 22:08:01.34	2026-04-02 22:08:00.228	{"previousState": "DISPATCHED"}	LEGAL	2031-04-02 22:08:01.339
cmni1056j037hk84wg6r2pzdm	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.34415677	-122.09439031	5	0	30.74	316.41	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 22:08:01.34	2026-04-02 22:07:59.816	null	RAW_SHORT	2026-04-17 22:08:01.339
cmni10cws037sk84wk0djaki8	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.34534964	-122.09631924	5	0	31.26	300.23	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 22:08:11.356	2026-04-02 22:08:06.821	null	RAW_SHORT	2026-04-17 22:08:11.355
cmni10gsq037yk84wtipz185i	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.34633112	-122.09862728	5	0	34.15	298.12	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 22:08:16.394	2026-04-02 22:08:13.846	null	RAW_SHORT	2026-04-17 22:08:16.393
cmni10ko20384k84wzthgwtqc	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.34719244	-122.1006624	5	0	33.72	297.77	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 22:08:21.41	2026-04-02 22:08:19.834	null	RAW_SHORT	2026-04-17 22:08:21.409
cmni10sn3038fk84wiyf9iwie	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.34831482	-122.10286198	5	0	33.08	310.78	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 22:08:31.743	2026-04-02 22:08:26.825	null	RAW_SHORT	2026-04-17 22:08:31.742
cmni10wag038lk84whmsyd1gx	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.34991623	-122.10451573	5	0	33.2	328.01	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 22:08:36.472	2026-04-02 22:08:33.828	null	RAW_SHORT	2026-04-17 22:08:36.471
cmni1105j038rk84waeyleizz	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.35145376	-122.10569934	5	0	33.23	327.66	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 22:08:41.48	2026-04-02 22:08:39.843	null	RAW_SHORT	2026-04-17 22:08:41.479
cmni117v80392k84wxxx062rt	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.35304318	-122.1073468	5	0	32.43	312.19	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 22:08:51.476	2026-04-02 22:08:46.829	null	RAW_SHORT	2026-04-17 22:08:51.475
cmni11bqo0398k84wbxl7p56j	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.35416275	-122.10941512	5	0	31.82	297.07	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 22:08:56.497	2026-04-02 22:08:53.83	null	RAW_SHORT	2026-04-17 22:08:56.496
cmni11fm1039ek84wu6cz5303	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.35486926	-122.11178469	5	0	32.5	287.58	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 22:09:01.513	2026-04-02 22:09:00.829	null	RAW_SHORT	2026-04-17 22:09:01.512
cmni11nbn039pk84wq65qgct9	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.35555758	-122.11420421	5	0	32.28	295.31	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 22:09:11.507	2026-04-02 22:09:07.828	null	RAW_SHORT	2026-04-17 22:09:11.507
cmni11r71039vk84w2kd307tw	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.35667204	-122.11636489	5	0	32.76	310.43	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 22:09:16.525	2026-04-02 22:09:14.829	null	RAW_SHORT	2026-04-17 22:09:16.524
cmni11yxb03a6k84wy17wzpnl	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.35821377	-122.11808519	5	0	33.51	325.9	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 22:09:26.543	2026-04-02 22:09:21.888	null	RAW_SHORT	2026-04-17 22:09:26.542
cmni122t803ack84w85714rj8	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.35983897	-122.11918616	5	0	34.77	333.98	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 22:09:31.58	2026-04-02 22:09:27.82	null	RAW_SHORT	2026-04-17 22:09:31.579
cmni126nh03aik84w9js3qco5	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.36154377	-122.1202173	5	0	34.65	332.23	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 22:09:36.558	2026-04-02 22:09:33.828	null	RAW_SHORT	2026-04-17 22:09:36.557
cmni12aif03aok84w45p3vbhg	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.36303768	-122.12160442	5	0	34.35	315.35	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 22:09:41.56	2026-04-02 22:09:39.82	null	RAW_SHORT	2026-04-17 22:09:41.559
cmni12i9503azk84wynhzhwrg	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.36424153	-122.12374717	5	0	32.83	296.72	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 22:09:51.593	2026-04-02 22:09:46.826	null	RAW_SHORT	2026-04-17 22:09:51.592
cmni12m4j03b5k84wkllg23x8	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.36483488	-122.12623861	5	0	33.57	278.09	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 22:09:56.611	2026-04-02 22:09:53.822	null	RAW_SHORT	2026-04-17 22:09:56.61
cmni12pzd03bbk84wjggdfe3g	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.36489536	-122.12851823	5	0	33.32	270.35	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 22:10:01.609	2026-04-02 22:09:59.826	null	RAW_SHORT	2026-04-17 22:10:01.608
cmni12xq303bmk84w96d7dqi6	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.36513495	-122.13112023	5	0	33.14	285.82	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 22:10:11.643	2026-04-02 22:10:06.821	null	RAW_SHORT	2026-04-17 22:10:11.642
cmni131mf03bsk84wuhxfs87f	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.3658664	-122.13358057	5	0	33.38	290.74	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 22:10:16.696	2026-04-02 22:10:13.826	null	RAW_SHORT	2026-04-17 22:10:16.695
cmni135gw03byk84wq90gg5hq	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.36657341	-122.13598643	5	0	32.22	290.39	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 22:10:21.681	2026-04-02 22:10:20.831	null	RAW_SHORT	2026-04-17 22:10:21.68
cmni13d7i03c9k84w2wmvsbm4	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.36743034	-122.13834434	5	0	33.46	300.59	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 22:10:31.711	2026-04-02 22:10:27.824	null	RAW_SHORT	2026-04-17 22:10:31.71
cmni1449f03djk84wb5kzi1c8	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.37595557	-122.14739872	5	0	34.41	317.81	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 22:11:06.771	2026-04-02 22:11:04.826	null	RAW_SHORT	2026-04-17 22:11:06.77
cmni14ipu03e8k84wdbedlax4	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.38048092	-122.15123277	5	0	34.49	342.42	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 22:11:25.506	2026-04-02 22:11:22.828	null	RAW_SHORT	2026-04-17 22:11:25.505
cmni16l9y03h8k84w9upi2htw	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.39602298	-122.17827723	5	0	33.26	322.03	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 22:13:02.135	2026-04-02 22:13:00.837	null	RAW_SHORT	2026-04-17 22:13:02.134
cmni178js03i4k84w176mnkcm	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.40336963	-122.1855891	5	0	34.12	321.33	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 22:13:32.296	2026-04-02 22:13:30.826	null	RAW_SHORT	2026-04-17 22:13:32.295
cmni187bp03jgk84wvbi9egkl	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.41082094	-122.19968311	5	0	34.81	291.8	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 22:14:17.365	2026-04-02 22:14:16.831	null	RAW_SHORT	2026-04-17 22:14:17.365
cmni7ud1s023y708nhvpkm27e	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.39286883	-122.17400749	5	0	32.29	293.55	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-03 01:19:28.912	2026-04-03 01:19:25.562	null	RAW_SHORT	2026-04-18 01:19:28.911
cmnj3ann200c1hoja9anbflal	\N	alex@brspark.com	dev_szkcjr	cmnj1u3d401z3hw8yw2e5hqnc	SESSION_CLOSE	\N	\N	\N	\N	\N	\N	GPS	\N	\N	UNKNOWN	1.0.0	26.3.1	Simulator iOS	f	f	-33	2026-04-03 15:59:57.231	2026-04-03 15:59:54.486	{"previousState": "DISPATCHED"}	OPERATIONAL	2026-09-30 15:59:57.23
cmnjmq1x801h2rohkuz4jkepf	cmnjmhnpx01gqrohk7zart6bt	ze@ze.com	dev_or2xj4	\N	SESSION_OPEN	\N	\N	\N	\N	\N	\N	GPS	\N	\N	UNKNOWN	1.0.0	26.4	iPhone 17 Pro Max	f	f	-31	2026-04-04 01:03:48.284	2026-04-04 01:03:43.61	{}	OPERATIONAL	2026-10-01 01:03:48.284
cmnjmq20201h4rohkz3oom2qp	cmnjmhnpx01gqrohk7zart6bt	ze@ze.com	dev_or2xj4	\N	SESSION_OPEN	\N	\N	\N	\N	\N	\N	GPS	\N	\N	UNKNOWN	1.0.0	26.4	iPhone 17 Pro Max	f	f	-31	2026-04-04 01:03:48.386	2026-04-04 01:03:43.61	{}	OPERATIONAL	2026-10-01 01:03:48.386
cmni13f5503cfk84wyxoxbwgt	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.36854278	-122.1401674	5	0	34.22	312.89	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 22:10:34.217	2026-04-02 22:10:33.827	null	RAW_SHORT	2026-04-17 22:10:34.217
cmni13kya03cqk84wzij3f4jj	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.36994839	-122.1416339	5	0	34.01	324.14	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 22:10:41.747	2026-04-02 22:10:39.827	null	RAW_SHORT	2026-04-17 22:10:41.746
cmni13osq03cwk84wvd7snzrz	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.37142067	-122.14297886	5	0	33.47	324.14	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 22:10:46.731	2026-04-02 22:10:45.826	null	RAW_SHORT	2026-04-17 22:10:46.73
cmni14vcx03evk84wav5n23hq	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.38560981	-122.15272559	5	0	33.44	335.74	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 22:11:41.89	2026-04-02 22:11:39.829	null	RAW_SHORT	2026-04-17 22:11:41.889
cmni156za03fbk84wuz1reza1	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.38852302	-122.15740629	5	0	32.12	283.36	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 22:11:56.95	2026-04-02 22:11:56.832	null	RAW_SHORT	2026-04-17 22:11:56.949
cmni15mgl03fwk84w1t8vf04z	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.38966543	-122.16308369	5	0	32.49	297.07	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 22:12:17.014	2026-04-02 22:12:12.834	null	RAW_SHORT	2026-04-17 22:12:17.013
cmni17vq203j0k84whgk4hiii	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.40913001	-122.19434853	5	0	33.41	291.8	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 22:14:02.33	2026-04-02 22:14:01.83	null	RAW_SHORT	2026-04-17 22:14:02.329
cmni19unc03ltk84wx5odysbu	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.42180622	-122.225047	5	0	34.15	310.78	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 22:15:34.248	2026-04-02 22:15:33.828	null	RAW_SHORT	2026-04-17 22:15:34.247
cmni7uku6024e708ndpiah9wk	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.39462396	-122.17690042	5	0	32.4	319.92	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-03 01:19:39.006	2026-04-03 01:19:35.571	null	RAW_SHORT	2026-04-18 01:19:39.005
cmni7v06h0250708n5t8s5gfn	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.39921816	-122.1814238	5	0	35.33	321.68	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-03 01:19:58.889	2026-04-03 01:19:54.56	null	RAW_SHORT	2026-04-18 01:19:58.888
cmni7v4180256708nlf1zk349	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.40145169	-122.18364475	5	0	34.88	320.98	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-03 01:20:03.885	2026-04-03 01:20:03.562	null	RAW_SHORT	2026-04-18 01:20:03.884
cmni7vbr2025h708nw2olszf0	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.40360986	-122.18583235	5	0	34.11	321.33	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-03 01:20:13.887	2026-04-03 01:20:12.563	null	RAW_SHORT	2026-04-18 01:20:13.886
cmni7vr750263708nivtoszc1	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.40776758	-122.19065295	5	0	32.48	304.45	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-03 01:20:33.906	2026-04-03 01:20:31.559	null	RAW_SHORT	2026-04-18 01:20:33.905
cmni7wi980276708nzhi78szp	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.41210932	-122.20369519	5	0	34.73	291.45	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-03 01:21:08.972	2026-04-03 01:21:08.563	null	RAW_SHORT	2026-04-18 01:21:08.971
cmni7xslz0290708nbnv229ft	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.41987612	-122.22201677	5	0	34.81	298.83	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-03 01:22:09.048	2026-04-03 01:22:04.564	null	RAW_SHORT	2026-04-18 01:22:09.047
cmni7y47h029h708nrz0nxp45	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.4234391	-122.22739879	5	0	34.4	310.78	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-03 01:22:24.078	2026-04-03 01:22:22.558	null	RAW_SHORT	2026-04-18 01:22:24.077
cmni7yre902ae708npttqfe76	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.42923061	-122.23520217	5	0	33.5	310.78	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-03 01:22:54.129	2026-04-03 01:22:49.639	null	RAW_SHORT	2026-04-18 01:22:54.128
cmni805mn02ce708nhwhdw8mt	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.4431162	-122.2532692	5	0	32.88	299.88	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-03 01:23:59.232	2026-04-03 01:23:56.564	null	RAW_SHORT	2026-04-18 01:23:59.231
cmnjjjr7y0002bddjwt0b9u1o	cmnhhqj5c000e3yrjmvwv50er	alex@brspark.com	dev_or2xj4	\N	SESSION_OPEN	\N	\N	\N	\N	\N	\N	GPS	\N	\N	UNKNOWN	1.0.0	26.4	iPhone 17 Pro Max	f	f	-26	2026-04-03 23:34:55.631	2026-04-03 23:34:50.788	{}	OPERATIONAL	2026-09-30 23:34:55.629
cmnjjl1jg003rbddjgent0fwz	\N	alex@brspark.com	dev_or2xj4	cmnj0qdf70003j3y6z9zcptf7	SESSION_CLOSE	\N	\N	\N	\N	\N	\N	GPS	\N	\N	UNKNOWN	1.0.0	26.4	iPhone 17 Pro Max	f	f	-12	2026-04-03 23:35:55.66	2026-04-03 23:35:53.493	{"previousState": "DISPATCHED"}	OPERATIONAL	2026-09-30 23:35:55.659
cmnjjm99r006rbddjc6morc6h	\N	alex@brspark.com	dev_or2xj4	cmnj3zrof019dhojaj8wfptwn	OS_ACCEPT	\N	\N	\N	\N	\N	\N	GPS	\N	\N	UNKNOWN	1.0.0	26.4	iPhone 17 Pro Max	f	f	-18	2026-04-03 23:36:52.335	2026-04-03 23:36:52.295	{"previousState": "IDLE"}	LEGAL	2031-04-03 23:36:52.334
cmnjjm99r006sbddjms45bn9u	\N	alex@brspark.com	\N	\N	HEARTBEAT	-23.56719453129495	-46.7862439702355	7.928586564459389	790.6075881195069	-1	-1	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-03 23:36:52.335	2026-04-03 23:36:11.556	null	RAW_SHORT	2026-04-18 23:36:52.334
cmnjjm99r006tbddjzw6nan78	\N	alex@brspark.com	dev_or2xj4	cmnj3zrof019dhojaj8wfptwn	FRAUD_FLAG	-23.56719287955252	-46.78624953196547	\N	\N	\N	\N	GPS	\N	\N	UNKNOWN	1.0.0	26.4	iPhone 17 Pro Max	f	f	11	2026-04-03 23:36:52.335	2026-04-03 23:36:52.326	{"lat": -23.56719287955252, "lng": -46.78624953196547, "reason": "MOCK_LOCATION", "severity": "HIGH"}	LEGAL	2031-04-03 23:36:52.334
cmnjjmv2m0082bddjbx4ohtrc	\N	alex@brspark.com	\N	\N	HEARTBEAT	-23.56719176861247	-46.78624942803273	5.071065847973615	790.6075881195069	-1	-1	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-03 23:37:20.59	2026-04-03 23:37:20.47	null	RAW_SHORT	2026-04-18 23:37:20.589
cmni13wjb03d7k84whihdrdup	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.37311268	-122.14451887	5	0	33.18	324.14	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 22:10:56.76	2026-04-02 22:10:52.828	null	RAW_SHORT	2026-04-17 22:10:56.759
cmni1485a03dpk84wnil70qyy	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.37732484	-122.14894979	5	0	33.48	317.81	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 22:11:11.806	2026-04-02 22:11:10.828	null	RAW_SHORT	2026-04-17 22:11:11.806
cmni14fwb03e0k84wqnqrxuyh	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.3787954	-122.15030297	5	0	33.74	329.41	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 22:11:21.852	2026-04-02 22:11:16.816	null	RAW_SHORT	2026-04-17 22:11:21.851
cmni15y2q03gck84w5rzavgrc	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.39203734	-122.16826622	5	0	33.12	284.41	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 22:12:32.066	2026-04-02 22:12:28.827	null	RAW_SHORT	2026-04-17 22:12:32.065
cmni7usgn024p708nzev6qzvk	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.39698455	-122.17921131	5	0	34.33	321.68	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-03 01:19:48.887	2026-04-03 01:19:45.567	null	RAW_SHORT	2026-04-18 01:19:48.884
cmni7wxrz027s708nxr9whly0	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.41487543	-122.2096481	5	0	34.35	318.87	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-03 01:21:29.087	2026-04-03 01:21:26.568	null	RAW_SHORT	2026-04-18 01:21:29.086
cmni7xkwc028p708ngtfwsnzl	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.41900025	-122.2186972	5	0	33.98	280.9	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-03 01:21:59.052	2026-04-03 01:21:55.718	null	RAW_SHORT	2026-04-18 01:21:59.051
cmni7yjo002a3708nxbdxa6zo	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.42738525	-122.23260102	5	0	35	315	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-03 01:22:44.112	2026-04-03 01:22:40.556	null	RAW_SHORT	2026-04-18 01:22:44.112
cmni7yz4t02ap708nlb2s5lx0	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.43117949	-122.23802512	5	0	33.51	312.89	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-03 01:23:04.158	2026-04-03 01:22:59.566	null	RAW_SHORT	2026-04-18 01:23:04.157
cmnjjk850000sbddjn78ynn5u	\N	alex@brspark.com	dev_or2xj4	\N	SESSION_OPEN	\N	\N	\N	\N	\N	\N	GPS	\N	\N	UNKNOWN	1.0.0	26.4	iPhone 17 Pro Max	f	f	11	2026-04-03 23:35:17.557	2026-04-03 23:35:17.44	{}	OPERATIONAL	2026-09-30 23:35:17.556
cmnjjm99q006pbddj81mjl5rr	\N	alex@brspark.com	dev_or2xj4	cmnj3zrof019dhojaj8wfptwn	OS_ACCEPT	\N	\N	\N	\N	\N	\N	GPS	\N	\N	UNKNOWN	1.0.0	26.4	iPhone 17 Pro Max	f	f	-18	2026-04-03 23:36:52.335	2026-04-03 23:36:52.295	{"previousState": "IDLE"}	LEGAL	2031-04-03 23:36:52.334
cmnjjm99r006qbddjqwjm1d4s	\N	alex@brspark.com	\N	\N	HEARTBEAT	-23.56719453129495	-46.7862439702355	7.928586564459389	790.6075881195069	-1	-1	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-03 23:36:52.335	2026-04-03 23:36:11.556	null	RAW_SHORT	2026-04-18 23:36:52.334
cmnjjmd2a0074bddjjmzoveyu	\N	alex@brspark.com	dev_or2xj4	cmnj3zrof019dhojaj8wfptwn	TRANSIT_START	-23.56719289080543	-46.78624951054749	\N	\N	\N	\N	GPS	\N	\N	UNKNOWN	1.0.0	26.4	iPhone 17 Pro Max	f	f	-15	2026-04-03 23:36:57.251	2026-04-03 23:36:55.878	{"lat": -23.56719289080543, "lng": -46.78624951054749, "previousState": "DISPATCHED"}	LEGAL	2031-04-03 23:36:57.25
cmnjjmd2a0075bddjf3c1cxtt	\N	alex@brspark.com	\N	\N	HEARTBEAT	-23.56719289080536	-46.78624951054763	7.471794984429464	791.3087784395942	-1	-1	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-03 23:36:57.251	2026-04-03 23:36:55.867	null	RAW_SHORT	2026-04-18 23:36:57.25
cmnjjp06l00edbddjxzueq0xa	\N	alex@brspark.com	dev_or2xj4	cmnj3yrf4017vhojacp14gc5a	OS_ACCEPT	\N	\N	\N	\N	\N	\N	GPS	\N	\N	UNKNOWN	1.0.0	26.4	iPhone 17 Pro Max	f	f	4	2026-04-03 23:39:00.525	2026-04-03 23:38:57.006	{"previousState": "IDLE"}	LEGAL	2031-04-03 23:39:00.52
cmnjjp06l00eebddjj56krwco	\N	alex@brspark.com	\N	\N	HEARTBEAT	-23.56714953171399	-46.7862484256267	7.041206509771272	791.960033968091	0.1623321558597467	-1	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-03 23:39:00.525	2026-04-03 23:38:43.915	null	RAW_SHORT	2026-04-18 23:39:00.52
cmnjjp06l00efbddjao32itvq	\N	alex@brspark.com	\N	\N	HEARTBEAT	-23.56714953171399	-46.7862484256267	7.041206509771272	791.960033968091	0.1623321558597467	-1	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-03 23:39:00.525	2026-04-03 23:38:53.915	null	RAW_SHORT	2026-04-18 23:39:00.52
cmnjjp06l00egbddj3yffsm37	\N	alex@brspark.com	\N	\N	HEARTBEAT	-23.56714955518998	-46.78624845044061	12.195014	791.6738686936574	-1	-1	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-03 23:39:00.525	2026-04-03 23:38:55.817	null	RAW_SHORT	2026-04-18 23:39:00.52
cmnjjp06l00ehbddjikeygfdz	\N	alex@brspark.com	dev_or2xj4	cmnj3yrf4017vhojacp14gc5a	FRAUD_FLAG	-23.56719453129495	-46.7862439702355	\N	\N	\N	\N	GPS	\N	\N	UNKNOWN	1.0.0	26.4	iPhone 17 Pro Max	t	f	6	2026-04-03 23:39:00.525	2026-04-03 23:38:57.056	{"lat": -23.56719453129495, "lng": -46.7862439702355, "reason": "MOCK_LOCATION", "severity": "HIGH"}	LEGAL	2031-04-03 23:39:00.52
cmnjjp06l00eibddjz0j4dzke	\N	alex@brspark.com	\N	\N	HEARTBEAT	-23.56719453129495	-46.7862439702355	7.928586564459389	791.701017813771	-1	-1	\N	\N	\N	\N	\N	\N	\N	t	f	\N	2026-04-03 23:39:00.525	2026-04-03 23:38:57.034	null	RAW_SHORT	2026-04-18 23:39:00.52
cmnjjp06m00ejbddjff47pzwj	\N	alex@brspark.com	dev_or2xj4	cmnj3yrf4017vhojacp14gc5a	TRANSIT_START	-23.56719453129495	-46.7862439702355	\N	\N	\N	\N	GPS	\N	\N	UNKNOWN	1.0.0	26.4	iPhone 17 Pro Max	f	f	13	2026-04-03 23:39:00.525	2026-04-03 23:38:58.754	{"lat": -23.56719453129495, "lng": -46.7862439702355, "previousState": "DISPATCHED"}	LEGAL	2031-04-03 23:39:00.52
cmnjjp06m00ekbddjef3lauu2	\N	alex@brspark.com	\N	\N	HEARTBEAT	-23.56719453129495	-46.7862439702355	7.928586564459389	791.701017813771	-1	-1	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-03 23:39:00.525	2026-04-03 23:38:58.753	null	RAW_SHORT	2026-04-18 23:39:00.52
cmni140ed03ddk84w519w0fla	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.37457281	-122.14588663	5	0	33.98	321.33	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 22:11:01.765	2026-04-02 22:10:58.821	null	RAW_SHORT	2026-04-17 22:11:01.764
cmni14ips03e7k84wkb16l5b8	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.38048092	-122.15123277	5	0	34.49	342.42	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 22:11:25.504	2026-04-02 22:11:22.828	null	RAW_SHORT	2026-04-17 22:11:25.504
cmni169q403gsk84ww9uu4skq	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.39286883	-122.17400749	5	0	32.29	293.55	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 22:12:47.164	2026-04-02 22:12:44.827	null	RAW_SHORT	2026-04-17 22:12:47.163
cmni16wve03hok84wy2e2vwmk	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.39971672	-122.18192127	5	0	35.22	321.68	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 22:13:17.163	2026-04-02 22:13:15.824	null	RAW_SHORT	2026-04-17 22:13:17.162
cmni17k4c03ikk84woaj0o0y2	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.40684142	-122.18921084	5	0	32.72	314.65	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 22:13:47.293	2026-04-02 22:13:45.82	null	RAW_SHORT	2026-04-17 22:13:47.292
cmni18iy503jwk84wtljaqrw9	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.41256089	-122.20514618	5	0	34.47	291.45	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 22:14:32.43	2026-04-02 22:14:31.834	null	RAW_SHORT	2026-04-17 22:14:32.429
cmni18unm03kck84wrtoit688	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.41511369	-122.2099019	5	0	34.21	320.98	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 22:14:47.602	2026-04-02 22:14:46.846	null	RAW_SHORT	2026-04-17 22:14:47.601
cmni19a0k03kxk84wb94k2v8z	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.41821562	-122.21438304	5	0	32.7	293.55	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 22:15:07.508	2026-04-02 22:15:02.832	null	RAW_SHORT	2026-04-17 22:15:07.507
cmni19lnd03ldk84wec1rmvea	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.41926445	-122.22021307	5	0	34.26	283.01	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 22:15:22.585	2026-04-02 22:15:18.831	null	RAW_SHORT	2026-04-17 22:15:22.584
cmni1a8uy03mek84wrnqdz501	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.42488967	-122.22949008	5	0	35.8	311.84	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 22:15:52.667	2026-04-02 22:15:48.824	null	RAW_SHORT	2026-04-17 22:15:52.666
cmni1akgx03muk84w4rwdultf	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.4282366	-122.23374641	5	0	34.4	311.48	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 22:16:07.713	2026-04-02 22:16:03.831	null	RAW_SHORT	2026-04-17 22:16:07.713
cmni1aw2503nak84wqcz4t2eh	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.43117949	-122.23802512	5	0	33.51	312.89	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 22:16:22.733	2026-04-02 22:16:18.835	null	RAW_SHORT	2026-04-17 22:16:22.732
cmni1b7o303nqk84wmkln4vc8	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.43441436	-122.24197802	5	0	33.17	316.05	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 22:16:37.779	2026-04-02 22:16:33.823	null	RAW_SHORT	2026-04-17 22:16:37.779
cmni1bja203o6k84wak3x6mdu	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.4378918	-122.24613695	5	0	33.5	316.41	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 22:16:52.827	2026-04-02 22:16:49.825	null	RAW_SHORT	2026-04-17 22:16:52.826
cmni1buvm03omk84wvrh8kp8p	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.44124096	-122.25037308	5	0	32.82	313.95	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 22:17:07.858	2026-04-02 22:17:05.823	null	RAW_SHORT	2026-04-17 22:17:07.858
cmni1c6ht03p2k84w30xjqfwv	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.44384262	-122.25528153	5	0	32.69	288.63	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 22:17:22.913	2026-04-02 22:17:21.827	null	RAW_SHORT	2026-04-17 22:17:22.912
cmni1ci4a03pik84wke15cplr	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.44407878	-122.26109077	5	0	32.65	264.38	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 22:17:37.979	2026-04-02 22:17:37.833	null	RAW_SHORT	2026-04-17 22:17:37.978
cmni1cxlx03q3k84wmhllxw1f	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.44395875	-122.2668851	5	0	32.2	279.84	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 22:17:58.053	2026-04-02 22:17:53.824	null	RAW_SHORT	2026-04-17 22:17:58.052
cmni1d98003qjk84w9ma6g6uy	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.44598499	-122.27225807	5	0	34.36	309.73	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 22:18:13.104	2026-04-02 22:18:09.831	null	RAW_SHORT	2026-04-17 22:18:13.104
cmni1dkte03qzk84wh2g05dku	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.44910327	-122.27674381	5	0	35.36	310.78	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 22:18:28.13	2026-04-02 22:18:24.837	null	RAW_SHORT	2026-04-17 22:18:28.129
cmni1dwig03rfk84wgpig2cpm	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.45213903	-122.28131706	5	0	34.62	309.38	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 22:18:43.288	2026-04-02 22:18:39.824	null	RAW_SHORT	2026-04-17 22:18:43.287
cmni1e81603rvk84wstell9xl	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.45508011	-122.28577665	5	0	34.46	309.73	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 22:18:58.218	2026-04-02 22:18:54.831	null	RAW_SHORT	2026-04-17 22:18:58.217
cmni1ejmp03sbk84wats7cqwl	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.45855399	-122.28964389	5	0	34.6	333.28	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 22:19:13.25	2026-04-02 22:19:09.834	null	RAW_SHORT	2026-04-17 22:19:13.249
cmni1ev8403srk84wd6jb1cqv	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.46299866	-122.29070546	5	0	33.43	358.59	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 22:19:28.276	2026-04-02 22:19:24.828	null	RAW_SHORT	2026-04-17 22:19:28.276
cmni1f6uq03t7k84wdecbnnhv	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.46768876	-122.29178052	5	0	33.44	338.2	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 22:19:43.347	2026-04-02 22:19:40.832	null	RAW_SHORT	2026-04-17 22:19:43.346
cmni1fifv03tnk84wz7eviw8i	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.47146019	-122.2948939	5	0	33.57	321.68	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 22:19:58.363	2026-04-02 22:19:55.828	null	RAW_SHORT	2026-04-17 22:19:58.362
cmni1fu1v03u3k84w8ay0ekkw	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.47511504	-122.29823928	5	0	33.49	333.63	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 22:20:13.412	2026-04-02 22:20:10.833	null	RAW_SHORT	2026-04-17 22:20:13.411
cmni1g5nj03ujk84w369sxkkm	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.47959504	-122.29920555	5	0	34.03	5.62	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 22:20:28.448	2026-04-02 22:20:25.827	null	RAW_SHORT	2026-04-17 22:20:28.447
cmni1gh9703v4k84woiadl8rt	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.48415014	-122.29845126	5	0	33.01	7.73	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 22:20:43.483	2026-04-02 22:20:40.828	null	RAW_SHORT	2026-04-17 22:20:43.483
cmni1gsu803vkk84wnpckmuz2	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.48888495	-122.29847339	5	0	33.55	347.7	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 22:20:58.497	2026-04-02 22:20:56.828	null	RAW_SHORT	2026-04-17 22:20:58.496
cmni1h4fw03w0k84ws1m9ujcf	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.49291363	-122.30150194	5	0	32.67	313.95	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 22:21:13.532	2026-04-02 22:21:12.849	null	RAW_SHORT	2026-04-17 22:21:13.531
cmni1hj3o03wlk84w6frpb757	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.49508765	-122.30676787	5	0	32.87	286.88	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 22:21:32.532	2026-04-02 22:21:28.832	null	RAW_SHORT	2026-04-17 22:21:32.531
cmni1hunp03x1k84wgmxx05l6	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.49664228	-122.31227193	5	0	32.79	296.72	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 22:21:47.51	2026-04-02 22:21:44.848	null	RAW_SHORT	2026-04-17 22:21:47.509
cmni1i67j03xhk84wbdacp9z9	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.49913263	-122.31702405	5	0	33.81	303.75	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 22:22:02.48	2026-04-02 22:21:59.83	null	RAW_SHORT	2026-04-17 22:22:02.479
cmni1ihs503xxk84wb8t715sh	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.50075222	-122.32244974	5	0	31.21	277.38	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 22:22:17.478	2026-04-02 22:22:15.833	null	RAW_SHORT	2026-04-17 22:22:17.477
cmni1itcl03ydk84wa9jqnyyg	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.50133564	-122.32819947	5	0	32.41	287.58	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 22:22:32.469	2026-04-02 22:22:31.832	null	RAW_SHORT	2026-04-17 22:22:32.468
cmni1j8rw03yyk84w5qnw6xx9	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.5038171	-122.33321034	5	0	33.55	307.27	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 22:22:52.461	2026-04-02 22:22:47.832	null	RAW_SHORT	2026-04-17 22:22:52.46
cmni1jkd203zek84wkyz7c0oi	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.50664554	-122.33782793	5	0	34.93	307.62	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 22:23:07.479	2026-04-02 22:23:02.841	null	RAW_SHORT	2026-04-17 22:23:07.478
cmni1jvx303zuk84wyuy5uy8a	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.50948943	-122.34244552	5	0	33.34	309.73	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 22:23:22.456	2026-04-02 22:23:17.828	null	RAW_SHORT	2026-04-17 22:23:22.455
cmni1k7j2040ak84ws04xgxyx	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.51292513	-122.3466607	5	0	33.47	317.46	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 22:23:37.502	2026-04-02 22:23:33.835	null	RAW_SHORT	2026-04-17 22:23:37.501
cmni1kj38040qk84wk9856gcm	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.51644813	-122.35068376	5	0	32.69	318.16	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 22:23:52.485	2026-04-02 22:23:49.831	null	RAW_SHORT	2026-04-17 22:23:52.483
cmni1kuoe0416k84wkt2a5asz	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.5202453	-122.35426233	5	0	33.74	332.23	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 22:24:07.502	2026-04-02 22:24:05.834	null	RAW_SHORT	2026-04-17 22:24:07.501
cmni1l6ap041mk84w814kn131	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.52454815	-122.35693297	5	0	33.35	324.84	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 22:24:22.561	2026-04-02 22:24:21.831	null	RAW_SHORT	2026-04-17 22:24:22.559
cmni1lhts0422k84wlmf5q2ui	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.52859497	-122.35974351	5	0	34.72	341.37	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 22:24:37.504	2026-04-02 22:24:36.829	null	RAW_SHORT	2026-04-17 22:24:37.503
cmni1qfcs049nk84w672yt7qp	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.58502861	-122.40717301	5	0	34.12	316.41	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 22:28:27.58	2026-04-02 22:28:23.836	null	RAW_SHORT	2026-04-17 22:28:27.58
cmni7vjgx025s708njkvdp7vf	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.40572269	-122.18797644	5	0	33.13	320.98	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-03 01:20:23.889	2026-04-03 01:20:21.563	null	RAW_SHORT	2026-04-18 01:20:23.888
cmni7w6nr026p708nz5cped27	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.41002813	-122.19717013	5	0	33.85	291.8	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-03 01:20:53.943	2026-04-03 01:20:50.558	null	RAW_SHORT	2026-04-18 01:20:53.943
cmni7wee00270708n6cjn6y90	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.41105102	-122.20042583	5	0	34.79	291.45	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-03 01:21:03.961	2026-04-03 01:20:59.566	null	RAW_SHORT	2026-04-18 01:21:03.96
cmni7wpz3027h708n25twbq2d	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.41316012	-122.20691443	5	0	34.19	296.02	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-03 01:21:18.975	2026-04-03 01:21:17.568	null	RAW_SHORT	2026-04-18 01:21:18.975
cmni7xd67028e708njuw9vinu	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.41841264	-122.21506373	5	0	32.38	287.93	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-03 01:21:49.039	2026-04-03 01:21:45.564	null	RAW_SHORT	2026-04-18 01:21:49.038
cmni80dcb02cp708nhy7uohwa	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.44411847	-122.25671014	5	0	32.43	279.49	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-03 01:24:09.227	2026-04-03 01:24:06.582	null	RAW_SHORT	2026-04-18 01:24:09.226
cmnjjkm3k002cbddj1qscleip	\N	alex@brspark.com	dev_or2xj4	cmnj0qdf70003j3y6z9zcptf7	OS_ACCEPT	\N	\N	\N	\N	\N	\N	GPS	\N	\N	UNKNOWN	1.0.0	26.4	iPhone 17 Pro Max	f	f	10	2026-04-03 23:35:35.649	2026-04-03 23:35:35.496	{"previousState": "IDLE"}	LEGAL	2031-04-03 23:35:35.648
cmnjjkm3k002dbddjduux02t0	\N	alex@brspark.com	\N	\N	HEARTBEAT	-23.56719453129495	-46.7862439702355	7.928586564459389	791.3087784395942	-1	-1	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-03 23:35:35.649	2026-04-03 23:35:23.956	null	RAW_SHORT	2026-04-18 23:35:35.648
cmnjjkm3k002ebddjl42gcs76	\N	alex@brspark.com	\N	\N	HEARTBEAT	-23.56719453129495	-46.7862439702355	7.928586564459389	791.3087784395942	-1	-1	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-03 23:35:35.649	2026-04-03 23:35:35.511	null	RAW_SHORT	2026-04-18 23:35:35.648
cmnjjooo500d2bddjqeypmgnb	\N	alex@brspark.com	dev_or2xj4	cmnj3zrof019dhojaj8wfptwn	SESSION_CLOSE	\N	\N	\N	\N	\N	\N	GPS	\N	\N	UNKNOWN	1.0.0	26.4	iPhone 17 Pro Max	f	f	-132	2026-04-03 23:38:45.606	2026-04-03 23:38:44.688	{"previousState": "IN_TRANSIT"}	OPERATIONAL	2026-09-30 23:38:45.605
cmni1lteu042ik84wn1ei0zth	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.53305079	-122.36164578	5	0	34.53	341.02	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 22:24:52.518	2026-04-02 22:24:51.831	null	RAW_SHORT	2026-04-17 22:24:52.517
cmni1m4ys042yk84w6u98yybm	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.53727196	-122.36378208	5	0	33.19	333.98	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 22:25:07.493	2026-04-02 22:25:06.851	null	RAW_SHORT	2026-04-17 22:25:07.492
cmni1mkga043jk84wbvn9ppm2	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.54148915	-122.36637376	5	0	32.23	331.17	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 22:25:27.562	2026-04-02 22:25:22.829	null	RAW_SHORT	2026-04-17 22:25:27.561
cmni1mvzk0444k84wmttom2kv	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.54528133	-122.36988486	5	0	33.45	320.62	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 22:25:42.513	2026-04-02 22:25:38.836	null	RAW_SHORT	2026-04-17 22:25:42.512
cmni1n7kb044kk84wy49ma1oj	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.54895177	-122.37367935	5	0	32.54	319.57	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 22:25:57.515	2026-04-02 22:25:54.832	null	RAW_SHORT	2026-04-17 22:25:57.514
cmni1nj5e0450k84wrv1v3osl	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.55254949	-122.37717024	5	0	35.34	327.3	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 22:26:12.53	2026-04-02 22:26:09.832	null	RAW_SHORT	2026-04-17 22:26:12.529
cmni1nuqd045ik84wjgp6l1ab	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.55656673	-122.37994851	5	0	35.45	332.23	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 22:26:27.541	2026-04-02 22:26:23.832	null	RAW_SHORT	2026-04-17 22:26:27.54
cmni1o6bc045yk84wr2cwk4zj	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.56043141	-122.38316263	5	0	35.63	321.33	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 22:26:42.553	2026-04-02 22:26:38.835	null	RAW_SHORT	2026-04-17 22:26:42.552
cmni1ohvd046ek84wf8u6db9s	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.56410897	-122.3868381	5	0	33.66	321.33	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 22:26:57.529	2026-04-02 22:26:53.833	null	RAW_SHORT	2026-04-17 22:26:57.528
cmni1otfi046uk84w1nakv0jd	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.56674169	-122.39169239	5	0	33.49	294.61	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 22:27:12.511	2026-04-02 22:27:09.828	null	RAW_SHORT	2026-04-17 22:27:12.51
cmni1p51f047ak84w102keszp	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.56998858	-122.39608401	5	0	33.78	323.09	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 22:27:27.556	2026-04-02 22:27:25.833	null	RAW_SHORT	2026-04-17 22:27:27.555
cmni1pgbo0480k84wum03px03	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.57361598	-122.39950986	5	0	33.29	325.2	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 22:27:42.18	2026-04-02 22:27:40.838	null	RAW_SHORT	2026-04-17 22:27:42.18
cmni1pkh6048bk84w2zl1r6nu	cmnhhqj5c000e3yrjmvwv50er	alex@brspark.com	dev_szkcjr	cmni1npwo045ck84w2mp3uaqv	OS_ACCEPT	\N	\N	\N	\N	\N	\N	GPS	\N	\N	UNKNOWN	1.0.0	26.3.1	Simulator iOS	f	f	4	2026-04-02 22:27:47.562	2026-04-02 22:27:45.312	{"previousState": "IDLE"}	LEGAL	2031-04-02 22:27:47.561
cmni1pkh6048ck84w80oa5qfz	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.57495771	-122.40041879	5	0	34.34	337.85	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 22:27:47.562	2026-04-02 22:27:45.832	null	RAW_SHORT	2026-04-17 22:27:47.561
cmni1ps6v048nk84wnooakhqa	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.57760761	-122.40156585	5	0	34	341.37	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 22:27:57.56	2026-04-02 22:27:54.829	null	RAW_SHORT	2026-04-17 22:27:57.559
cmni1pw1z048tk84w9npq4ydi	cmnhhqj5c000e3yrjmvwv50er	alex@brspark.com	dev_szkcjr	cmni1npwo045ck84w2mp3uaqv	TRANSIT_START	\N	\N	\N	\N	\N	\N	GPS	\N	\N	UNKNOWN	1.0.0	26.3.1	Simulator iOS	f	f	-108	2026-04-02 22:28:02.567	2026-04-02 22:27:58.245	{"previousState": "DISPATCHED"}	LEGAL	2031-04-02 22:28:02.566
cmni1pw1z048uk84wh5q5cvg9	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.5784743	-122.40192879	5	0	34.14	341.37	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 22:28:02.567	2026-04-02 22:27:57.845	null	RAW_SHORT	2026-04-17 22:28:02.566
cmni1pzwn0490k84wnf4rshs2	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.58030013	-122.40309329	5	0	32.41	329.41	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 22:28:07.56	2026-04-02 22:28:04.83	null	RAW_SHORT	2026-04-17 22:28:07.559
cmni1q3rm0496k84wwljmyy65	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.58207437	-122.404453	5	0	33.47	328.71	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 22:28:12.562	2026-04-02 22:28:11.848	null	RAW_SHORT	2026-04-17 22:28:12.561
cmni1qbio049hk84wpgbqaged	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.58362519	-122.40571196	5	0	34.04	325.9	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 22:28:22.609	2026-04-02 22:28:17.83	null	RAW_SHORT	2026-04-17 22:28:22.608
cmni1qj70049tk84w9qbdhexy	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.58628103	-122.40888284	5	0	34.43	310.08	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 22:28:32.557	2026-04-02 22:28:29.83	null	RAW_SHORT	2026-04-17 22:28:32.556
cmni1qn2f049zk84w5fs7u5t7	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.58751653	-122.41061705	5	0	34.23	315.7	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 22:28:37.576	2026-04-02 22:28:35.836	null	RAW_SHORT	2026-04-17 22:28:37.575
cmni1qqwt04a5k84wz832zqml	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.58894149	-122.4121014	5	0	34.06	322.03	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 22:28:42.557	2026-04-02 22:28:41.837	null	RAW_SHORT	2026-04-17 22:28:42.556
cmni1qymp04agk84wc1ny12ln	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.59039961	-122.4135301	5	0	34.34	322.03	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 22:28:52.562	2026-04-02 22:28:47.835	null	RAW_SHORT	2026-04-17 22:28:52.561
cmni1r2hy04amk84wqkrlaxov	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.59186703	-122.41497883	5	0	34.34	321.68	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 22:28:57.575	2026-04-02 22:28:53.838	null	RAW_SHORT	2026-04-17 22:28:57.574
cmni1r6fy04ask84wexcbwzi0	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.5933155	-122.41641054	5	0	34.1	322.03	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 22:29:02.686	2026-04-02 22:28:59.843	null	RAW_SHORT	2026-04-17 22:29:02.682
cmni1ra7s04ayk84we8vok68e	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.59477194	-122.41782784	5	0	33.66	322.03	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 22:29:07.576	2026-04-02 22:29:05.845	null	RAW_SHORT	2026-04-17 22:29:07.575
cmni1re2n04b4k84wukizukwp	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.5961884	-122.41924144	5	0	33.2	320.98	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 22:29:12.576	2026-04-02 22:29:11.844	null	RAW_SHORT	2026-04-17 22:29:12.575
cmni1rls904bfk84w2poiimkq	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.59753085	-122.42080467	5	0	33.88	315.7	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 22:29:22.569	2026-04-02 22:29:17.825	null	RAW_SHORT	2026-04-17 22:29:22.568
cmni1rpnd04blk84w7a3bt9uy	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.59881294	-122.42240561	5	0	33.64	315.7	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 22:29:27.577	2026-04-02 22:29:23.832	null	RAW_SHORT	2026-04-17 22:29:27.576
cmni1rtj704brk84w26owi8ih	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.60011457	-122.42399767	5	0	33.7	316.05	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 22:29:32.611	2026-04-02 22:29:29.832	null	RAW_SHORT	2026-04-17 22:29:32.61
cmni1rxco04bxk84wz4rfcrhd	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.60144184	-122.42557665	5	0	33.85	317.11	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 22:29:37.56	2026-04-02 22:29:35.831	null	RAW_SHORT	2026-04-17 22:29:37.559
cmni1s17i04c3k84w6ist4u5d	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.60292963	-122.42692212	5	0	34.03	331.52	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 22:29:42.558	2026-04-02 22:29:41.834	null	RAW_SHORT	2026-04-17 22:29:42.557
cmni1s8xt04cek84w6m7y5a5j	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.60490126	-122.42782443	5	0	33.81	347.7	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 22:29:52.578	2026-04-02 22:29:48.846	null	RAW_SHORT	2026-04-17 22:29:52.577
cmni1scsn04ckk84wz7lhfy41	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.60697453	-122.42798519	5	0	32.63	2.81	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 22:29:57.575	2026-04-02 22:29:55.836	null	RAW_SHORT	2026-04-17 22:29:57.574
cmni1skjz04cvk84wta3pr1wu	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.60901452	-122.42752478	5	0	33.23	14.06	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 22:30:07.631	2026-04-02 22:30:02.85	null	RAW_SHORT	2026-04-17 22:30:07.629
cmni1sodd04d1k84wbndfmtme	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.61097345	-122.42659053	5	0	33.43	24.61	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 22:30:12.577	2026-04-02 22:30:09.851	null	RAW_SHORT	2026-04-17 22:30:12.576
cmni1ss8a04d7k84wy0nrhisk	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.61255499	-122.42549493	5	0	32.91	29.88	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 22:30:17.579	2026-04-02 22:30:15.848	null	RAW_SHORT	2026-04-17 22:30:17.578
cmni1szyh04dik84wt7o9debm	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.6144335	-122.42438064	5	0	33.19	18.63	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 22:30:27.593	2026-04-02 22:30:22.869	null	RAW_SHORT	2026-04-17 22:30:27.592
cmni1t3u804dok84w1g2x310k	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.61622802	-122.4240856	5	0	33.35	1.76	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 22:30:32.625	2026-04-02 22:30:28.839	null	RAW_SHORT	2026-04-17 22:30:32.623
cmni1t7np04dzk84wnoyxj8ww	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.61830682	-122.42451894	5	0	33.98	344.88	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 22:30:37.573	2026-04-02 22:30:35.845	null	RAW_SHORT	2026-04-17 22:30:37.573
cmni1tbj104e5k84wty7u7ls4	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.61997167	-122.42551723	5	0	34.89	332.58	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 22:30:42.589	2026-04-02 22:30:41.84	null	RAW_SHORT	2026-04-17 22:30:42.588
cmni1tj8y04egk84w228zxqzn	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.62166536	-122.42661417	5	0	35.4	332.93	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 22:30:52.595	2026-04-02 22:30:47.835	null	RAW_SHORT	2026-04-17 22:30:52.594
cmni1ultv04g3k84wsmc98el0	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.6349348	-122.43884269	5	0	34.88	339.61	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 22:31:42.595	2026-04-02 22:31:41.837	null	RAW_SHORT	2026-04-17 22:31:42.594
cmni1uxes04gkk84wd57q59kz	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.63827763	-122.44069124	5	0	33.2	327.66	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 22:31:57.604	2026-04-02 22:31:53.852	null	RAW_SHORT	2026-04-17 22:31:57.603
cmni1vog504hok84w0gz1qr1f	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.64568224	-122.44954965	5	0	32.82	324.14	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 22:32:32.646	2026-04-02 22:32:28.836	null	RAW_SHORT	2026-04-17 22:32:32.645
cmni1wfhb04isk84wicys337h	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.65414599	-122.45638216	5	0	32.19	314.65	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 22:33:07.679	2026-04-02 22:33:03.841	null	RAW_SHORT	2026-04-17 22:33:07.679
cmni7vyxf026e708nq6pzszxp	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.4090174	-122.19399146	5	0	33.26	291.45	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-03 01:20:43.923	2026-04-03 01:20:41.561	null	RAW_SHORT	2026-04-18 01:20:43.922
cmnjjmd2a0076bddjsff2lolp	\N	alex@brspark.com	dev_or2xj4	cmnj3zrof019dhojaj8wfptwn	TRANSIT_START	-23.56719289080543	-46.78624951054749	\N	\N	\N	\N	GPS	\N	\N	UNKNOWN	1.0.0	26.4	iPhone 17 Pro Max	f	f	-15	2026-04-03 23:36:57.251	2026-04-03 23:36:55.878	{"lat": -23.56719289080543, "lng": -46.78624951054749, "previousState": "DISPATCHED"}	LEGAL	2031-04-03 23:36:57.25
cmnjjmd2b0077bddjfg0yjsm3	\N	alex@brspark.com	\N	\N	HEARTBEAT	-23.56719289080536	-46.78624951054763	7.471794984429464	791.3087784395942	-1	-1	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-03 23:36:57.251	2026-04-03 23:36:55.867	null	RAW_SHORT	2026-04-18 23:36:57.25
cmnjjoolm00cwbddjkecirs6m	\N	alex@brspark.com	dev_or2xj4	cmnj3zrof019dhojaj8wfptwn	SESSION_CLOSE	\N	\N	\N	\N	\N	\N	GPS	\N	\N	UNKNOWN	1.0.0	26.4	iPhone 17 Pro Max	f	f	-132	2026-04-03 23:38:45.514	2026-04-03 23:38:44.688	{"previousState": "IN_TRANSIT"}	OPERATIONAL	2026-09-30 23:38:45.514
cmnjjp06m00elbddjm85eadbl	\N	alex@brspark.com	dev_or2xj4	cmnj3yrf4017vhojacp14gc5a	OS_ACCEPT	\N	\N	\N	\N	\N	\N	GPS	\N	\N	UNKNOWN	1.0.0	26.4	iPhone 17 Pro Max	f	f	4	2026-04-03 23:39:00.526	2026-04-03 23:38:57.006	{"previousState": "IDLE"}	LEGAL	2031-04-03 23:39:00.524
cmnjjp06m00embddjyyuxy9mj	\N	alex@brspark.com	\N	\N	HEARTBEAT	-23.56714953171399	-46.7862484256267	7.041206509771272	791.960033968091	0.1623321558597467	-1	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-03 23:39:00.526	2026-04-03 23:38:43.915	null	RAW_SHORT	2026-04-18 23:39:00.524
cmnjjp06m00enbddj2turoyke	\N	alex@brspark.com	\N	\N	HEARTBEAT	-23.56714953171399	-46.7862484256267	7.041206509771272	791.960033968091	0.1623321558597467	-1	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-03 23:39:00.526	2026-04-03 23:38:53.915	null	RAW_SHORT	2026-04-18 23:39:00.524
cmnjjp06n00eobddj9j9f3rdh	\N	alex@brspark.com	\N	\N	HEARTBEAT	-23.56714955518998	-46.78624845044061	12.195014	791.6738686936574	-1	-1	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-03 23:39:00.526	2026-04-03 23:38:55.817	null	RAW_SHORT	2026-04-18 23:39:00.524
cmnjjp06n00epbddjsnc5rhv3	\N	alex@brspark.com	dev_or2xj4	cmnj3yrf4017vhojacp14gc5a	FRAUD_FLAG	-23.56719453129495	-46.7862439702355	\N	\N	\N	\N	GPS	\N	\N	UNKNOWN	1.0.0	26.4	iPhone 17 Pro Max	t	f	6	2026-04-03 23:39:00.526	2026-04-03 23:38:57.056	{"lat": -23.56719453129495, "lng": -46.7862439702355, "reason": "MOCK_LOCATION", "severity": "HIGH"}	LEGAL	2031-04-03 23:39:00.524
cmnjjp06n00eqbddjpq7qpyxn	\N	alex@brspark.com	\N	\N	HEARTBEAT	-23.56719453129495	-46.7862439702355	7.928586564459389	791.701017813771	-1	-1	\N	\N	\N	\N	\N	\N	\N	t	f	\N	2026-04-03 23:39:00.526	2026-04-03 23:38:57.034	null	RAW_SHORT	2026-04-18 23:39:00.524
cmnjjp06n00erbddjxblot7b8	\N	alex@brspark.com	dev_or2xj4	cmnj3yrf4017vhojacp14gc5a	TRANSIT_START	-23.56719453129495	-46.7862439702355	\N	\N	\N	\N	GPS	\N	\N	UNKNOWN	1.0.0	26.4	iPhone 17 Pro Max	f	f	13	2026-04-03 23:39:00.526	2026-04-03 23:38:58.754	{"lat": -23.56719453129495, "lng": -46.7862439702355, "previousState": "DISPATCHED"}	LEGAL	2031-04-03 23:39:00.524
cmnjjp06n00esbddjuz3vhv07	\N	alex@brspark.com	\N	\N	HEARTBEAT	-23.56719453129495	-46.7862439702355	7.928586564459389	791.701017813771	-1	-1	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-03 23:39:00.526	2026-04-03 23:38:58.753	null	RAW_SHORT	2026-04-18 23:39:00.524
cmni1tn6704emk84wsvse7kg5	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.62334694	-122.42769149	5	0	34.53	332.93	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 22:30:57.68	2026-04-02 22:30:53.836	null	RAW_SHORT	2026-04-17 22:30:57.679
cmni1ue4704frk84wuxl0ciiv	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.63173002	-122.43652912	5	0	33.71	317.46	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 22:31:32.599	2026-04-02 22:31:29.837	null	RAW_SHORT	2026-04-17 22:31:32.599
cmni1utkh04gek84w3btpzg1z	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.63666256	-122.43965423	5	0	33.48	338.91	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 22:31:52.625	2026-04-02 22:31:47.846	null	RAW_SHORT	2026-04-17 22:31:52.625
cmni7x5g20283708nvbv9yhqn	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.41694823	-122.2118667	5	0	33.17	312.54	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-03 01:21:39.026	2026-04-03 01:21:35.565	null	RAW_SHORT	2026-04-18 01:21:39.026
cmni7xwh60296708n2gwvt295	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.42160254	-122.22475346	5	0	34.06	310.78	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-03 01:22:14.058	2026-04-03 01:22:13.561	null	RAW_SHORT	2026-04-18 01:22:14.058
cmni7zig302bh708nus4b5aon	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.43723487	-122.24533942	5	0	33.73	316.05	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-03 01:23:29.187	2026-04-03 01:23:27.563	null	RAW_SHORT	2026-04-18 01:23:29.187
cmni80l2202d0708n91rmzqbo	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.44414135	-122.2603566	5	0	32.45	264.02	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-03 01:24:19.226	2026-04-03 01:24:16.561	null	RAW_SHORT	2026-04-18 01:24:19.224
cmnjjmv2n0083bddjozzwehlk	\N	alex@brspark.com	\N	\N	HEARTBEAT	-23.56719176861247	-46.78624942803273	5.071065847973615	790.6075881195069	-1	-1	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-03 23:37:20.591	2026-04-03 23:37:20.47	null	RAW_SHORT	2026-04-18 23:37:20.591
cmni1tr0004esk84wwdvajw4j	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.62499411	-122.42876044	5	0	34.39	331.52	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 22:31:02.64	2026-04-02 22:30:59.836	null	RAW_SHORT	2026-04-17 22:31:02.639
cmni1tutq04eyk84wjfu7st5o	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.62659895	-122.43005762	5	0	36.58	325.9	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 22:31:07.598	2026-04-02 22:31:05.85	null	RAW_SHORT	2026-04-17 22:31:07.597
cmni1tyog04f4k84w6oghdt0p	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.62794567	-122.43159863	5	0	33.88	315	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 22:31:12.592	2026-04-02 22:31:11.834	null	RAW_SHORT	2026-04-17 22:31:12.591
cmni1u6eb04ffk84ww3wkuedc	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.62919127	-122.43325339	5	0	33.92	313.59	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 22:31:22.595	2026-04-02 22:31:17.858	null	RAW_SHORT	2026-04-17 22:31:22.594
cmni1ua9704flk84wkresb208	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.63043476	-122.43489758	5	0	33.42	313.95	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 22:31:27.595	2026-04-02 22:31:23.831	null	RAW_SHORT	2026-04-17 22:31:27.594
cmni1uhz304fxk84wz3g33upj	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.63323021	-122.4378776	5	0	34.35	329.41	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 22:31:37.599	2026-04-02 22:31:35.834	null	RAW_SHORT	2026-04-17 22:31:37.598
cmni1v91d04h1k84wt7a3qt4v	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.64164233	-122.44364393	5	0	32.33	322.73	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 22:32:12.674	2026-04-02 22:32:07.837	null	RAW_SHORT	2026-04-17 22:32:12.673
cmni1vgpv04hdk84w89xlpz3p	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.64425086	-122.44768593	5	0	33.27	303.05	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 22:32:22.627	2026-04-02 22:32:21.835	null	RAW_SHORT	2026-04-17 22:32:22.626
cmni1wjco04iyk84wxrcue4dy	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.655592	-122.45823598	5	0	33.05	314.65	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 22:33:12.696	2026-04-02 22:33:10.85	null	RAW_SHORT	2026-04-17 22:33:12.695
cmni1wn7204j4k84wzp0hpneo	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.65685674	-122.45985453	5	0	33.73	314.3	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 22:33:17.678	2026-04-02 22:33:16.847	null	RAW_SHORT	2026-04-17 22:33:17.677
cmni7ybxt029s708nxm2xgw2p	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.42533181	-122.230081	5	0	35.95	314.3	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-03 01:22:34.097	2026-04-03 01:22:31.564	null	RAW_SHORT	2026-04-18 01:22:34.096
cmnjjrddc00labddj1xgxb2ql	\N	alex@brspark.com	dev_or2xj4	cmnj3yrf4017vhojacp14gc5a	SESSION_CLOSE	\N	\N	\N	\N	\N	\N	GPS	\N	\N	UNKNOWN	1.0.0	26.4	iPhone 17 Pro Max	f	f	-46	2026-04-03 23:40:50.928	2026-04-03 23:40:47.649	{"previousState": "IN_TRANSIT"}	OPERATIONAL	2026-09-30 23:40:50.927
cmni1v1ae04gqk84wlqi2bspb	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.63997584	-122.44214793	5	0	32.22	325.2	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 22:32:02.63	2026-04-02 22:32:00.837	null	RAW_SHORT	2026-04-17 22:32:02.629
cmni1vcus04h7k84w604gka37	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.64307505	-122.44550295	5	0	32.91	307.27	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 22:32:17.621	2026-04-02 22:32:14.937	null	RAW_SHORT	2026-04-17 22:32:17.62
cmni1vsb104huk84w27zxhsny	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.64750744	-122.45075656	5	0	32.66	334.34	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 22:32:37.645	2026-04-02 22:32:35.845	null	RAW_SHORT	2026-04-17 22:32:37.644
cmni1w01e04i5k84wp0i6iatk	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.64934857	-122.45186264	5	0	32.21	334.34	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 22:32:47.667	2026-04-02 22:32:42.836	null	RAW_SHORT	2026-04-17 22:32:47.666
cmni1w3w504ibk84w6co8wu87	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.65116761	-122.45299486	5	0	31.84	329.77	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 22:32:52.661	2026-04-02 22:32:49.835	null	RAW_SHORT	2026-04-17 22:32:52.66
cmni1w7ri04ihk84wqg18e233	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.65273415	-122.45456253	5	0	31.84	314.65	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 22:32:57.678	2026-04-02 22:32:56.836	null	RAW_SHORT	2026-04-17 22:32:57.677
cmni1wuwp04jfk84wmz69myh3	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.65831775	-122.46173392	5	0	33	313.95	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 22:33:27.673	2026-04-02 22:33:23.831	null	RAW_SHORT	2026-04-17 22:33:27.673
cmni1wyrq04jlk84w2f4xo99z	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.6595944	-122.46334517	5	0	33.46	314.65	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 22:33:32.678	2026-04-02 22:33:29.862	null	RAW_SHORT	2026-04-17 22:33:32.677
cmni1x2mm04jrk84w3qx9frkz	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.66129513	-122.46489055	5	0	33.28	333.28	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 22:33:37.678	2026-04-02 22:33:36.847	null	RAW_SHORT	2026-04-17 22:33:37.677
cmni1xacv04k2k84w768ltgew	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.66331739	-122.46552707	5	0	33.46	355.08	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 22:33:47.696	2026-04-02 22:33:43.863	null	RAW_SHORT	2026-04-17 22:33:47.695
cmni1xe7s04k8k84wug2tok1s	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.66513186	-122.46553863	5	0	33.59	360	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 22:33:52.696	2026-04-02 22:33:49.846	null	RAW_SHORT	2026-04-17 22:33:52.695
cmni1xi2q04kek84w540yl2nr	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.66695534	-122.46555179	5	0	33.64	359.65	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 22:33:57.698	2026-04-02 22:33:55.848	null	RAW_SHORT	2026-04-17 22:33:57.697
cmni1xlxg04kkk84wo8zr1831	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.66878205	-122.46570828	5	0	33.91	351.56	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 22:34:02.693	2026-04-02 22:34:01.844	null	RAW_SHORT	2026-04-17 22:34:02.692
cmni1xtoa04kvk84w5qu1pxqz	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.67058693	-122.46624196	5	0	34.11	343.12	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 22:34:12.73	2026-04-02 22:34:07.847	null	RAW_SHORT	2026-04-17 22:34:12.728
cmni1xxil04l1k84we8agdtxj	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.67225941	-122.46713488	5	0	33.45	332.93	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 22:34:17.71	2026-04-02 22:34:13.844	null	RAW_SHORT	2026-04-17 22:34:17.709
cmni1y1e004l7k84w93oxw0i1	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.67402812	-122.46851379	5	0	32.85	326.95	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 22:34:22.728	2026-04-02 22:34:20.835	null	RAW_SHORT	2026-04-17 22:34:22.727
cmni1y95b04lik84wdf922n0v	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.67577633	-122.46992933	5	0	32.26	327.3	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 22:34:32.783	2026-04-02 22:34:27.837	null	RAW_SHORT	2026-04-17 22:34:32.781
cmni1ycz404lok84w7n28bemq	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.67751495	-122.47117463	5	0	31.21	337.85	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 22:34:37.744	2026-04-02 22:34:34.85	null	RAW_SHORT	2026-04-17 22:34:37.743
cmni1ygu204luk84ws0h180dh	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.67947426	-122.47165114	5	0	32.72	358.59	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 22:34:42.746	2026-04-02 22:34:41.842	null	RAW_SHORT	2026-04-17 22:34:42.745
cmni1yoju04m5k84wuzz5gh20	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.68155054	-122.47154159	5	0	33.15	2.81	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 22:34:52.747	2026-04-02 22:34:48.851	null	RAW_SHORT	2026-04-17 22:34:52.746
cmni1ysf704mbk84wxja3fc4q	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.68362322	-122.47142784	5	0	32.51	3.16	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 22:34:57.763	2026-04-02 22:34:55.853	null	RAW_SHORT	2026-04-17 22:34:57.762
cmni1z05c04mmk84wgmai44wy	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.68566509	-122.47130429	5	0	32.81	1.76	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 22:35:07.777	2026-04-02 22:35:02.851	null	RAW_SHORT	2026-04-17 22:35:07.776
cmni1z3zs04msk84wmb49hoj1	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.6876731	-122.47090381	5	0	33	14.41	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 22:35:12.76	2026-04-02 22:35:09.849	null	RAW_SHORT	2026-04-17 22:35:12.76
cmni1z7up04myk84w3am9bq28	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.68971271	-122.47030274	5	0	33.13	10.9	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 22:35:17.761	2026-04-02 22:35:16.869	null	RAW_SHORT	2026-04-17 22:35:17.761
cmni1zfki04n9k84w8gq9f9u4	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.69179595	-122.47024616	5	0	32.06	359.3	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 22:35:27.763	2026-04-02 22:35:23.836	null	RAW_SHORT	2026-04-17 22:35:27.762
cmni1zjfc04nfk84wrad9defb	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.6937618	-122.47026427	5	0	30.32	359.65	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 22:35:32.76	2026-04-02 22:35:30.843	null	RAW_SHORT	2026-04-17 22:35:32.76
cmni1zr5k04nvk84w92ks8dtt	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.69577346	-122.47054154	5	0	32.28	347.7	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 22:35:42.776	2026-04-02 22:35:37.867	null	RAW_SHORT	2026-04-17 22:35:42.775
cmni1zv0h04o1k84wsbsjm4o1	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.69773847	-122.47121318	5	0	32.25	350.16	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 22:35:47.778	2026-04-02 22:35:44.847	null	RAW_SHORT	2026-04-17 22:35:47.777
cmni1zyve04o7k84wk3qp01m6	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.69970403	-122.47131284	5	0	30.73	358.24	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 22:35:52.778	2026-04-02 22:35:51.834	null	RAW_SHORT	2026-04-17 22:35:52.777
cmni206l304oik84wyjmmosjq	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.70172029	-122.47133397	5	0	32.93	0.35	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 22:36:02.775	2026-04-02 22:35:58.849	null	RAW_SHORT	2026-04-17 22:36:02.775
cmni20aku04ook84w85nh2bby	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.70374603	-122.47131519	5	0	31.51	0.7	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 22:36:07.951	2026-04-02 22:36:05.841	null	RAW_SHORT	2026-04-17 22:36:07.95
cmni20i6o04ozk84we9cb2je7	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.70569093	-122.47085796	5	0	32.33	16.88	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 22:36:17.808	2026-04-02 22:36:12.858	null	RAW_SHORT	2026-04-17 22:36:17.808
cmni20m1704p5k84wqm3o6gds	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.70741441	-122.4695213	5	0	32.68	37.97	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 22:36:22.795	2026-04-02 22:36:19.848	null	RAW_SHORT	2026-04-17 22:36:22.794
cmni20pxg04pbk84wyszr3knl	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.70903656	-122.46788255	5	0	33.51	38.32	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 22:36:27.844	2026-04-02 22:36:26.849	null	RAW_SHORT	2026-04-17 22:36:27.843
cmni20xmv04pmk84w0v0izkxl	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.71011779	-122.46571449	5	0	32.38	67.15	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 22:36:37.831	2026-04-02 22:36:33.838	null	RAW_SHORT	2026-04-17 22:36:37.83
cmni211hp04psk84wmzeo5qc0	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.71044166	-122.46319019	5	0	32.55	89.65	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 22:36:42.829	2026-04-02 22:36:40.837	null	RAW_SHORT	2026-04-17 22:36:42.828
cmni215dq04pyk84wn14pdpn1	cmnhhqj5c000e3yrjmvwv50er	alex@brspark.com	dev_szkcjr	cmni1npwo045ck84w2mp3uaqv	OS_ACCEPT	\N	\N	\N	\N	\N	\N	GPS	\N	\N	UNKNOWN	1.0.0	26.3.1	Simulator iOS	f	f	-2	2026-04-02 22:36:47.871	2026-04-02 22:36:47.345	{"previousState": "IN_TRANSIT"}	LEGAL	2031-04-02 22:36:47.87
cmni215dq04pzk84wclnas62x	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.71045038	-122.46097678	5	0	32.1	89.65	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 22:36:47.871	2026-04-02 22:36:46.856	null	RAW_SHORT	2026-04-17 22:36:47.87
cmni21d2u04qak84wnlqb5qms	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.71052364	-122.45740525	5	0	31.01	82.97	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 22:36:57.846	2026-04-02 22:36:56.838	null	RAW_SHORT	2026-04-17 22:36:57.846
cmni21kuf04qlk84w4xsobgje	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.71162795	-122.45419314	5	0	31.95	50.27	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 22:37:07.911	2026-04-02 22:37:06.841	null	RAW_SHORT	2026-04-17 22:37:07.911
cmni21sk304qwk84wj5q0t8pe	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.71380725	-122.45159173	5	0	34.36	42.89	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 22:37:17.907	2026-04-02 22:37:16.854	null	RAW_SHORT	2026-04-17 22:37:17.906
cmni220aq04r7k84wkksu91we	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.71585977	-122.44931077	5	0	32.96	37.62	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 22:37:27.937	2026-04-02 22:37:25.861	null	RAW_SHORT	2026-04-17 22:37:27.931
cmni227zi04rik84wuvh4yuxf	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.71869117	-122.44835883	5	0	33.04	5.62	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 22:37:37.903	2026-04-02 22:37:35.9	null	RAW_SHORT	2026-04-17 22:37:37.902
cmni22fo804rtk84w6sltdu6d	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.72141299	-122.44803948	5	0	34.01	5.27	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 22:37:47.865	2026-04-02 22:37:44.897	null	RAW_SHORT	2026-04-17 22:37:47.864
cmni241l804u4k84wpv3oop04	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.73150681	-122.42617839	5	0	34.34	99.49	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 22:39:02.924	2026-04-02 22:38:59.846	null	RAW_SHORT	2026-04-17 22:39:02.923
cmni276k004z7k84w56zquml9	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.75658588	-122.40323083	5	0	24.84	350.51	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 22:41:29.329	2026-04-02 22:41:24.849	null	RAW_SHORT	2026-04-17 22:41:29.328
cmni7z2zq02av708nkk33hmn3	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.43311575	-122.24044723	5	0	33.61	316.76	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-03 01:23:09.159	2026-04-03 01:23:08.556	null	RAW_SHORT	2026-04-18 01:23:09.158
cmni81nor02eo708n97jo760u	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.44889519	-122.27643795	5	0	35.85	311.48	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-03 01:25:09.291	2026-04-03 01:25:04.563	null	RAW_SHORT	2026-04-18 01:25:09.291
cmni81z9h02f5708ni8gulrqd	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.45253138	-122.2819136	5	0	34.38	309.38	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-03 01:25:24.293	2026-04-03 01:25:22.562	null	RAW_SHORT	2026-04-18 01:25:24.293
cmnjjrdgi00lcbddjcf6mio0m	\N	alex@brspark.com	dev_or2xj4	cmnj3yrf4017vhojacp14gc5a	SESSION_CLOSE	\N	\N	\N	\N	\N	\N	GPS	\N	\N	UNKNOWN	1.0.0	26.4	iPhone 17 Pro Max	f	f	-46	2026-04-03 23:40:51.042	2026-04-03 23:40:47.649	{"previousState": "IN_TRANSIT"}	OPERATIONAL	2026-09-30 23:40:51.041
cmni22nlu04s4k84wq5no5e5m	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.72410961	-122.44729576	5	0	34.32	19.34	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 22:37:58.145	2026-04-02 22:37:53.847	null	RAW_SHORT	2026-04-17 22:37:58.143
cmni7zaq102b6708n4ivmx8yp	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.43527279	-122.24300522	5	0	32.93	316.41	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-03 01:23:19.177	2026-04-03 01:23:19.077	null	RAW_SHORT	2026-04-18 01:23:19.176
cmni7zq7o02bs708ng39db4ta	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.43917407	-122.24771351	5	0	32.95	315	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-03 01:23:39.252	2026-04-03 01:23:36.568	null	RAW_SHORT	2026-04-18 01:23:39.252
cmni7zxw402c3708nt5eymerb	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.44124096	-122.25037308	5	0	32.82	313.95	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-03 01:23:49.204	2026-04-03 01:23:46.562	null	RAW_SHORT	2026-04-18 01:23:49.203
cmni80ssb02db708nhsopyejg	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.44383398	-122.26398513	5	0	31.86	265.43	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-03 01:24:29.244	2026-04-03 01:24:26.569	null	RAW_SHORT	2026-04-18 01:24:29.243
cmni8270c02fg708n6cm2ndq8	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.45428831	-122.28458122	5	0	34.39	309.73	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-03 01:25:34.333	2026-04-03 01:25:31.565	null	RAW_SHORT	2026-04-18 01:25:34.332
cmnjjrdgi00lbbddjo6rojtr3	\N	alex@brspark.com	dev_or2xj4	cmnj3yrf4017vhojacp14gc5a	SESSION_CLOSE	\N	\N	\N	\N	\N	\N	GPS	\N	\N	UNKNOWN	1.0.0	26.4	iPhone 17 Pro Max	f	f	-46	2026-04-03 23:40:51.042	2026-04-03 23:40:47.649	{"previousState": "IN_TRANSIT"}	OPERATIONAL	2026-09-30 23:40:51.041
cmni22slr04sak84w0ojj5fsb	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.72651765	-122.44565416	5	0	33.82	34.45	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 22:38:04.623	2026-04-02 22:38:02.852	null	RAW_SHORT	2026-04-17 22:38:04.621
cmni24h0q04uqk84wg4yskuf6	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.73190474	-122.4188029	5	0	33.33	90.7	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 22:39:22.923	2026-04-02 22:39:19.843	null	RAW_SHORT	2026-04-17 22:39:22.922
cmni810l102dr708ncor1zpkg	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.44407484	-122.26760192	5	0	32.31	283.36	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-03 01:24:39.349	2026-04-03 01:24:36.561	null	RAW_SHORT	2026-04-18 01:24:39.348
cmni82qb502g8708nblu26o8r	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.46090604	-122.29058057	5	0	34.36	348.75	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-03 01:25:59.345	2026-04-03 01:25:58.563	null	RAW_SHORT	2026-04-18 01:25:59.345
cmni835uk02gu708nszt3r0qc	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.46685325	-122.2913901	5	0	33.34	343.12	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-03 01:26:19.485	2026-04-03 01:26:18.562	null	RAW_SHORT	2026-04-18 01:26:19.484
cmnjjxgo600pjbddjipv3ltfw	\N	alex@brspark.com	dev_or2xj4	cmnj1lkhy01n1hw8y4bohk7qw	OS_ACCEPT	\N	\N	\N	\N	\N	\N	GPS	\N	\N	UNKNOWN	1.0.0	26.4	iPhone 17 Pro Max	f	f	-23	2026-04-03 23:45:35.142	2026-04-03 23:45:32.71	{"previousState": "IDLE"}	LEGAL	2031-04-03 23:45:35.141
cmnjjxgo600pmbddjkryo03yt	\N	alex@brspark.com	\N	\N	HEARTBEAT	-23.56719453129495	-46.7862439702355	7.928586564459389	790.9448802007472	-1	-1	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-03 23:45:35.142	2026-04-03 23:45:26.526	null	RAW_SHORT	2026-04-18 23:45:35.141
cmnjjxgo600pnbddj6p693o61	\N	alex@brspark.com	\N	\N	HEARTBEAT	-23.56719453129495	-46.7862439702355	7.928586564459389	790.9448802007472	-1	-1	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-03 23:45:35.142	2026-04-03 23:45:32.713	null	RAW_SHORT	2026-04-18 23:45:35.141
cmnjk2r5300w8bddjrgjbamz7	\N	alex@brspark.com	dev_or2xj4	cmnj3xzrq016shojah2dyzntn	OS_ACCEPT	\N	\N	\N	\N	\N	\N	GPS	\N	\N	UNKNOWN	1.0.0	26.4	iPhone 17 Pro Max	f	f	9	2026-04-03 23:49:41.992	2026-04-03 23:48:05.857	{"previousState": "DISPATCHED"}	LEGAL	2031-04-03 23:49:41.989
cmnjk2r5400w9bddji3t3u84a	\N	alex@brspark.com	\N	\N	HEARTBEAT	-23.56719453129495	-46.7862439702355	7.928586564459389	791.6763897836395	-1	-1	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-03 23:49:41.992	2026-04-03 23:48:05.374	null	RAW_SHORT	2026-04-18 23:49:41.989
cmni22zbg04slk84wb0cfstrq	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.72855831	-122.44296625	5	0	32.56	57.66	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 22:38:13.324	2026-04-02 22:38:12.865	null	RAW_SHORT	2026-04-17 22:38:13.322
cmni2546304vnk84wz8s8ztdq	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.7348374	-122.40873523	5	0	27.12	46.76	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 22:39:52.923	2026-04-02 22:39:50.849	null	RAW_SHORT	2026-04-17 22:39:52.922
cmni25bwg04vyk84w8pieymt8	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.73748596	-122.40752731	5	0	26.71	357.54	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 22:40:02.945	2026-04-02 22:40:02.835	null	RAW_SHORT	2026-04-17 22:40:02.944
cmni8188u02e2708nyqmu30ml	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.44525815	-122.27101285	5	0	33.97	302.34	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-03 01:24:49.279	2026-04-03 01:24:46.566	null	RAW_SHORT	2026-04-18 01:24:49.278
cmni81fy702ed708nb31ryy5r	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.44701194	-122.27374359	5	0	34.96	311.13	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-03 01:24:59.264	2026-04-03 01:24:55.569	null	RAW_SHORT	2026-04-18 01:24:59.263
cmni82mgc02g2708na1135t2b	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.45827194	-122.28946385	5	0	34.72	331.17	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-03 01:25:54.348	2026-04-03 01:25:49.568	null	RAW_SHORT	2026-04-18 01:25:54.348
cmnjjxgo600pkbddj4z8x8yly	\N	alex@brspark.com	dev_or2xj4	cmnj1lkhy01n1hw8y4bohk7qw	OS_ACCEPT	\N	\N	\N	\N	\N	\N	GPS	\N	\N	UNKNOWN	1.0.0	26.4	iPhone 17 Pro Max	f	f	-23	2026-04-03 23:45:35.142	2026-04-03 23:45:32.71	{"previousState": "IDLE"}	LEGAL	2031-04-03 23:45:35.141
cmnjjxgo600plbddjbtv19aiu	\N	alex@brspark.com	\N	\N	HEARTBEAT	-23.56719453129495	-46.7862439702355	7.928586564459389	790.9448802007472	-1	-1	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-03 23:45:35.142	2026-04-03 23:45:26.526	null	RAW_SHORT	2026-04-18 23:45:35.141
cmnjjxgo600pobddjpng4q3bj	\N	alex@brspark.com	\N	\N	HEARTBEAT	-23.56719453129495	-46.7862439702355	7.928586564459389	790.9448802007472	-1	-1	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-03 23:45:35.142	2026-04-03 23:45:32.713	null	RAW_SHORT	2026-04-18 23:45:35.141
cmni236pu04swk84wcdrcullj	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.72991563	-122.43968599	5	0	33.15	64.69	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 22:38:22.914	2026-04-02 22:38:22.85	null	RAW_SHORT	2026-04-17 22:38:22.913
cmni23eii04t7k84wu8al7icd	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.7309606	-122.43651914	5	0	33.93	69.96	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 22:38:33.018	2026-04-02 22:38:31.833	null	RAW_SHORT	2026-04-17 22:38:33.017
cmni23m5d04tik84w7lwnwryd	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.73184624	-122.43321198	5	0	33.48	71.72	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 22:38:42.913	2026-04-02 22:38:40.84	null	RAW_SHORT	2026-04-17 22:38:42.912
cmni23tvw04ttk84wjcogk489	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.73212414	-122.42955135	5	0	33.39	99.14	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 22:38:52.94	2026-04-02 22:38:50.843	null	RAW_SHORT	2026-04-17 22:38:52.939
cmni249ay04ufk84w8bbe9qge	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.73152823	-122.42250586	5	0	32.35	80.51	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 22:39:12.922	2026-04-02 22:39:09.844	null	RAW_SHORT	2026-04-17 22:39:12.921
cmni24oqn04v1k84w0w2gwh28	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.73208047	-122.4151556	5	0	31.8	74.88	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 22:39:32.927	2026-04-02 22:39:29.849	null	RAW_SHORT	2026-04-17 22:39:32.926
cmni24wgv04vck84wi44h5bwz	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.73335846	-122.41185347	5	0	32.12	61.52	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 22:39:42.943	2026-04-02 22:39:39.848	null	RAW_SHORT	2026-04-17 22:39:42.943
cmni25nh404wek84w7gcc5214	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.74031301	-122.40778103	5	0	24.04	7.03	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 22:40:17.945	2026-04-02 22:40:14.849	null	RAW_SHORT	2026-04-17 22:40:17.944
cmni25v6u04wpk84wy5uak9rw	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.74291726	-122.40638042	5	0	25.33	33.05	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 22:40:27.942	2026-04-02 22:40:27.848	null	RAW_SHORT	2026-04-17 22:40:27.941
cmni266rm04xak84w06qxxntl	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.7454038	-122.40480714	5	0	26.43	16.88	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 22:40:42.946	2026-04-02 22:40:39.848	null	RAW_SHORT	2026-04-17 22:40:42.945
cmni26n8204yfk84woblq1k8m	\N	alex@brspark.com	dev_szkcjr	cmni1npwo045ck84w2mp3uaqv	OS_ACCEPT	\N	\N	\N	\N	\N	\N	GPS	\N	\N	UNKNOWN	1.0.0	26.3.1	Simulator iOS	f	f	9	2026-04-02 22:41:04.274	2026-04-02 22:41:02.195	{"previousState": "IDLE"}	LEGAL	2031-04-02 22:41:04.273
cmni26n8204ygk84wlhcjmuf2	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.75088225	-122.40310192	5	0	29.3	12.3	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 22:41:04.274	2026-04-02 22:41:01.857	null	RAW_SHORT	2026-04-17 22:41:04.273
cmni26v0304yrk84werx7fun2	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.75380183	-122.40286605	5	0	28.81	355.78	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 22:41:14.355	2026-04-02 22:41:12.829	null	RAW_SHORT	2026-04-17 22:41:14.354
cmni27ea604zik84w2e8mycgy	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.75875152	-122.40553318	5	0	25.54	318.87	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 22:41:39.343	2026-04-02 22:41:37.845	null	RAW_SHORT	2026-04-17 22:41:39.342
cmni27pwv04zyk84w1lbjsfw8	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.76147723	-122.40613148	5	0	27.02	20.04	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 22:41:54.415	2026-04-02 22:41:49.844	null	RAW_SHORT	2026-04-17 22:41:54.414
cmni28u2l051sk84wi038v18o	\N	alex@brspark.com	dev_szkcjr	cmni1npwo045ck84w2mp3uaqv	OS_ACCEPT	\N	\N	\N	\N	\N	\N	GPS	\N	\N	UNKNOWN	1.0.0	26.3.1	Simulator iOS	f	f	6	2026-04-02 22:42:46.461	2026-04-02 22:42:42.543	{"previousState": "IDLE"}	LEGAL	2031-04-02 22:42:46.46
cmni28u2l051tk84w6m9rhfw1	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.3344584	-122.04077831	5	0	31.67	268.59	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 22:42:46.461	2026-04-02 22:42:42.126	null	RAW_SHORT	2026-04-17 22:42:46.46
cmni28u2l051uk84wwm17xlns	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.3344584	-122.04077831	5	0	31.67	268.59	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 22:42:46.461	2026-04-02 22:42:43.154	null	RAW_SHORT	2026-04-17 22:42:46.46
cmni28xxp0520k84wqcre85wj	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.33445832	-122.04420408	5	0	34.56	270.35	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 22:42:51.469	2026-04-02 22:42:51.124	null	RAW_SHORT	2026-04-17 22:42:51.469
cmni295o4052bk84w7vt5zxho	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.33420971	-122.04784191	5	0	30.78	256.64	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 22:43:01.493	2026-04-02 22:43:01.126	null	RAW_SHORT	2026-04-17 22:43:01.492
cmni29dem052mk84w6hc0tpfe	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.33344889	-122.05137547	5	0	33.73	255.59	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 22:43:11.519	2026-04-02 22:43:11.125	null	RAW_SHORT	2026-04-17 22:43:11.518
cmni29l59052xk84w47kue2zj	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.33268517	-122.05498531	5	0	33.08	254.88	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 22:43:21.549	2026-04-02 22:43:21.124	null	RAW_SHORT	2026-04-17 22:43:21.545
cmni29swm0538k84w8jhjz9kt	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.33230505	-122.05871525	5	0	33.93	274.22	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 22:43:31.606	2026-04-02 22:43:31.125	null	RAW_SHORT	2026-04-17 22:43:31.605
cmni2a0m8053jk84wt23z2lsm	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.33307736	-122.06203541	5	0	34.54	294.26	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 22:43:41.6	2026-04-02 22:43:40.136	null	RAW_SHORT	2026-04-17 22:43:41.599
cmni2a8br053uk84wdyhqveh3	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.33414928	-122.06526437	5	0	34.2	286.52	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 22:43:51.591	2026-04-02 22:43:49.135	null	RAW_SHORT	2026-04-17 22:43:51.591
cmni2ag200545k84w1yslceoe	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.33442613	-122.06864035	5	0	33.67	266.13	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 22:44:01.608	2026-04-02 22:43:58.133	null	RAW_SHORT	2026-04-17 22:44:01.608
cmni2ansv054gk84w188sdcky	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.33389384	-122.07197743	5	0	33.67	257.34	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 22:44:11.648	2026-04-02 22:44:07.144	null	RAW_SHORT	2026-04-17 22:44:11.647
cmni2aviu054rk84wd1oce5u5	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.33355228	-122.07558936	5	0	31.58	274.57	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 22:44:21.654	2026-04-02 22:44:17.138	null	RAW_SHORT	2026-04-17 22:44:21.654
cmni2b3970552k84wu6arbr1g	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.33442102	-122.07904631	5	0	32.75	299.18	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 22:44:31.676	2026-04-02 22:44:27.133	null	RAW_SHORT	2026-04-17 22:44:31.675
cmni2b7930558k84w8c5du1et	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.33617167	-122.08165962	5	0	33.81	314.3	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 22:44:36.855	2026-04-02 22:44:36.125	null	RAW_SHORT	2026-04-17 22:44:36.854
cmni2bev6055jk84wb2ayl3nt	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.33810893	-122.08454124	5	0	33.63	305.51	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 22:44:46.722	2026-04-02 22:44:46.138	null	RAW_SHORT	2026-04-17 22:44:46.722
cmni2bmkz055uk84wt217qkr1	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.33981846	-122.08762326	5	0	32.9	304.45	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 22:44:56.724	2026-04-02 22:44:56.133	null	RAW_SHORT	2026-04-17 22:44:56.723
cmni2buc80565k84wqcnbv2h3	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.34137909	-122.09077234	5	0	33.04	302.34	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 22:45:06.777	2026-04-02 22:45:06.125	null	RAW_SHORT	2026-04-17 22:45:06.776
cmni2c22f056gk84wx45fm51o	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.34332805	-122.09343444	5	0	31.35	317.11	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 22:45:16.791	2026-04-02 22:45:16.121	null	RAW_SHORT	2026-04-17 22:45:16.79
cmni2c9sm056rk84w1919l9zn	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.34520782	-122.0960117	5	0	31.12	302.7	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 22:45:26.806	2026-04-02 22:45:26.154	null	RAW_SHORT	2026-04-17 22:45:26.805
cmni2chnx0572k84wpa015754	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.3466164	-122.09929791	5	0	33.93	297.42	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 22:45:37.005	2026-04-02 22:45:36.127	null	RAW_SHORT	2026-04-17 22:45:37.004
cmni2cp9j057dk84wx4dhezfw	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.34794036	-122.10227399	5	0	33.1	304.8	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 22:45:46.855	2026-04-02 22:45:45.159	null	RAW_SHORT	2026-04-17 22:45:46.854
cmni2cx0l057ok84wep20g44a	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.35016915	-122.1047086	5	0	33.52	329.06	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 22:45:56.901	2026-04-02 22:45:55.137	null	RAW_SHORT	2026-04-17 22:45:56.901
cmni2d4qj057zk84wx3svxusq	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.35262907	-122.10682025	5	0	32.67	317.46	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 22:46:06.907	2026-04-02 22:46:05.136	null	RAW_SHORT	2026-04-17 22:46:06.906
cmni2dcho058ak84wlv1kz88x	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.354285	-122.10973833	5	0	31.86	295.31	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 22:46:16.956	2026-04-02 22:46:15.14	null	RAW_SHORT	2026-04-17 22:46:16.956
cmni2dk8e058lk84w2puaz2dl	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.35522226	-122.11317885	5	0	32.24	288.28	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 22:46:26.991	2026-04-02 22:46:25.136	null	RAW_SHORT	2026-04-17 22:46:26.99
cmni2dryf058wk84wr6exjhm9	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.35667204	-122.11636489	5	0	32.76	310.43	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 22:46:37	2026-04-02 22:46:35.135	null	RAW_SHORT	2026-04-17 22:46:36.999
cmni2dzow0597k84wjk2slzvq	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.3589945	-122.11866179	5	0	34.06	332.23	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 22:46:47.024	2026-04-02 22:46:45.131	null	RAW_SHORT	2026-04-17 22:46:47.024
cmni2emwr05a4k84wskhzqmxj	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.3647884	-122.12586327	5	0	33.5	280.55	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 22:47:17.116	2026-04-02 22:47:13.125	null	RAW_SHORT	2026-04-17 22:47:17.115
cmni81rjb02eu708nlh5greyy	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.45073833	-122.27919962	5	0	34.86	309.38	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-03 01:25:14.279	2026-04-03 01:25:13.565	null	RAW_SHORT	2026-04-18 01:25:14.278
cmnjjxk2400q7bddjfd6ir2by	\N	alex@brspark.com	dev_or2xj4	cmnj1lkhy01n1hw8y4bohk7qw	SESSION_CLOSE	\N	\N	\N	\N	\N	\N	GPS	\N	\N	UNKNOWN	1.0.0	26.4	iPhone 17 Pro Max	f	f	-1	2026-04-03 23:45:39.532	2026-04-03 23:45:35.327	{"previousState": "DISPATCHED"}	OPERATIONAL	2026-09-30 23:45:39.532
cmnjk2r4t00w4bddjhwlly5aj	\N	alex@brspark.com	dev_or2xj4	cmnj3xzrq016shojah2dyzntn	OS_ACCEPT	\N	\N	\N	\N	\N	\N	GPS	\N	\N	UNKNOWN	1.0.0	26.4	iPhone 17 Pro Max	f	f	9	2026-04-03 23:49:41.981	2026-04-03 23:48:05.857	{"previousState": "DISPATCHED"}	LEGAL	2031-04-03 23:49:41.981
cmnjk2r4t00w5bddjqqs99ouc	\N	alex@brspark.com	\N	\N	HEARTBEAT	-23.56719453129495	-46.7862439702355	7.928586564459389	791.6763897836395	-1	-1	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-03 23:49:41.981	2026-04-03 23:48:05.374	null	RAW_SHORT	2026-04-18 23:49:41.981
cmnjk32ko00xgbddjje4i6b06	cmnhhqj5c000e3yrjmvwv50er	alex@brspark.com	dev_or2xj4	cmnj3ycod0179hojan64s2qh5	OS_ACCEPT	\N	\N	\N	\N	\N	\N	GPS	\N	\N	UNKNOWN	1.0.0	26.4	iPhone 17 Pro Max	f	f	7	2026-04-03 23:49:56.808	2026-04-03 23:49:55.37	{"previousState": "IDLE"}	LEGAL	2031-04-03 23:49:56.808
cmni2e7fn059ik84wa506s3hj	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.36154377	-122.1202173	5	0	34.65	332.23	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 22:46:57.059	2026-04-02 22:46:54.134	null	RAW_SHORT	2026-04-17 22:46:57.058
cmni2ef6s059tk84wv5kpn1kh	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.36362588	-122.12248745	5	0	33.39	306.56	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 22:47:07.108	2026-04-02 22:47:03.137	null	RAW_SHORT	2026-04-17 22:47:07.108
cmni2eu1y05afk84wnk598tvz	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.364913	-122.12927755	5	0	33.43	271.41	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 22:47:26.374	2026-04-02 22:47:22.132	null	RAW_SHORT	2026-04-17 22:47:26.373
cmni2eymu05aqk84wdpiyo546	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.36565505	-122.13287858	5	0	33.39	290.74	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 22:47:32.31	2026-04-02 22:47:32.132	null	RAW_SHORT	2026-04-17 22:47:32.309
cmni2f6ky05b1k84wzlqo6hbe	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.36667454	-122.13633075	5	0	32.17	290.39	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 22:47:42.61	2026-04-02 22:47:42.133	null	RAW_SHORT	2026-04-17 22:47:42.609
cmni2fe6805bck84w9hlsb2oy	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.36813371	-122.13959391	5	0	34.03	308.67	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 22:47:52.448	2026-04-02 22:47:52.129	null	RAW_SHORT	2026-04-17 22:47:52.446
cmni2hr2f05ezk84wml02us4s	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.39063719	-122.16493601	5	0	33.54	306.56	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 22:49:42.472	2026-04-02 22:49:39.133	null	RAW_SHORT	2026-04-17 22:49:42.471
cmni2ieae05fwk84wnqihyw0b	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.39327728	-122.17497485	5	0	32.3	301.99	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 22:50:12.566	2026-04-02 22:50:08.135	null	RAW_SHORT	2026-04-17 22:50:12.565
cmni2j5e805gzk84wjw9ca9i7	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.40193507	-122.18412948	5	0	34.75	320.98	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 22:50:47.697	2026-04-02 22:50:45.138	null	RAW_SHORT	2026-04-17 22:50:47.696
cmni2jsr005hwk84wshg66ww4	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.40807192	-122.19127153	5	0	32.36	300.23	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 22:51:17.964	2026-04-02 22:51:13.126	null	RAW_SHORT	2026-04-17 22:51:17.963
cmni2lmeq05kik84wm348b1cv	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.41919475	-122.21983287	5	0	34.26	283.01	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 22:52:43.059	2026-04-02 22:52:38.136	null	RAW_SHORT	2026-04-17 22:52:43.058
cmni82eq102fr708nyc0cctoa	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.45607437	-122.28728422	5	0	34.52	311.48	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-03 01:25:44.329	2026-04-03 01:25:40.57	null	RAW_SHORT	2026-04-18 01:25:44.327
cmni82y8t02gj708nxwlllh4t	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.46390399	-122.29075357	5	0	33.23	357.89	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-03 01:26:09.63	2026-04-03 01:26:08.568	null	RAW_SHORT	2026-04-18 01:26:09.629
cmni839qj02h8708natdcchkx	\N	alex@brspark.com	dev_szkcjr	cmni0yc0l034gk84wpt1ucqfp	SESSION_CLOSE	\N	\N	\N	\N	\N	\N	GPS	\N	\N	UNKNOWN	1.0.0	26.3.1	Simulator iOS	f	f	-66	2026-04-03 01:26:24.523	2026-04-03 01:26:22.514	{"previousState": "DISPATCHED"}	OPERATIONAL	2026-09-30 01:26:24.522
cmnjjxs7600rabddju6bnx6ve	\N	alex@brspark.com	dev_or2xj4	cmnj0xh1v0001hw8ycw1mvicf	OS_ACCEPT	\N	\N	\N	\N	\N	\N	GPS	\N	\N	UNKNOWN	1.0.0	26.4	iPhone 17 Pro Max	f	f	10	2026-04-03 23:45:50.082	2026-04-03 23:45:45.315	{"previousState": "IDLE"}	LEGAL	2031-04-03 23:45:50.081
cmnjjxs7600rcbddj4idue8xd	\N	alex@brspark.com	\N	\N	HEARTBEAT	-23.56719453129495	-46.7862439702355	7.928586564459389	790.6080504131318	-1	-1	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-03 23:45:50.082	2026-04-03 23:45:38.715	null	RAW_SHORT	2026-04-18 23:45:50.081
cmnjjxs7600rdbddj5zsfy8mn	\N	alex@brspark.com	dev_or2xj4	cmnj0xh1v0001hw8ycw1mvicf	FRAUD_FLAG	-23.56719284123004	-46.78624960487538	\N	\N	\N	\N	GPS	\N	\N	UNKNOWN	1.0.0	26.4	iPhone 17 Pro Max	f	f	-53	2026-04-03 23:45:50.082	2026-04-03 23:45:45.478	{"lat": -23.56719284123004, "lng": -46.78624960487538, "reason": "MOCK_LOCATION", "severity": "HIGH"}	LEGAL	2031-04-03 23:45:50.081
cmnjjxs7600rebddjrnn3r8o2	\N	alex@brspark.com	\N	\N	HEARTBEAT	-23.56719284123004	-46.78624960487538	14.195014	790.57	-1	-1	\N	\N	\N	\N	\N	\N	\N	t	f	\N	2026-04-03 23:45:50.082	2026-04-03 23:45:45.318	null	RAW_SHORT	2026-04-18 23:45:50.081
cmnjk2r4500w2bddjxnv6cj2q	\N	alex@brspark.com	dev_or2xj4	cmnj3xzrq016shojah2dyzntn	OS_ACCEPT	\N	\N	\N	\N	\N	\N	GPS	\N	\N	UNKNOWN	1.0.0	26.4	iPhone 17 Pro Max	f	f	9	2026-04-03 23:49:41.958	2026-04-03 23:48:05.857	{"previousState": "DISPATCHED"}	LEGAL	2031-04-03 23:49:41.957
cmnjk2r4500w3bddjhpfraxba	\N	alex@brspark.com	\N	\N	HEARTBEAT	-23.56719453129495	-46.7862439702355	7.928586564459389	791.6763897836395	-1	-1	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-03 23:49:41.958	2026-04-03 23:48:05.374	null	RAW_SHORT	2026-04-18 23:49:41.957
cmnjk2r4y00w6bddj89grdm1c	\N	alex@brspark.com	dev_or2xj4	cmnj3xzrq016shojah2dyzntn	OS_ACCEPT	\N	\N	\N	\N	\N	\N	GPS	\N	\N	UNKNOWN	1.0.0	26.4	iPhone 17 Pro Max	f	f	9	2026-04-03 23:49:41.986	2026-04-03 23:48:05.857	{"previousState": "DISPATCHED"}	LEGAL	2031-04-03 23:49:41.985
cmnjk2r4y00w7bddjlx0bc22b	\N	alex@brspark.com	\N	\N	HEARTBEAT	-23.56719453129495	-46.7862439702355	7.928586564459389	791.6763897836395	-1	-1	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-03 23:49:41.986	2026-04-03 23:48:05.374	null	RAW_SHORT	2026-04-18 23:49:41.985
cmni2fxay05cck84wqpxfwy9y	\N	alex@brspark.com	dev_szkcjr	cmni1npwo045ck84w2mp3uaqv	OS_ACCEPT	\N	\N	\N	\N	\N	\N	GPS	\N	\N	UNKNOWN	1.0.0	26.3.1	Simulator iOS	f	f	1	2026-04-02 22:48:17.242	2026-04-02 22:48:14.208	{"previousState": "IDLE"}	LEGAL	2031-04-02 22:48:17.241
cmni2fxaz05cdk84w3ljulfzb	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.37336271	-122.14472699	5	0	33.53	325.2	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 22:48:17.242	2026-04-02 22:48:14.138	null	RAW_SHORT	2026-04-17 22:48:17.241
cmni2g52v05cok84w162krb9p	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.37550207	-122.14687494	5	0	34.21	317.81	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 22:48:27.319	2026-04-02 22:48:23.127	null	RAW_SHORT	2026-04-17 22:48:27.314
cmni2g8v405cuk84wllobwvh5	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.37755308	-122.14919429	5	0	33.76	319.57	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 22:48:32.224	2026-04-02 22:48:32.13	null	RAW_SHORT	2026-04-17 22:48:32.223
cmni2ggll05d5k84wq1awzp9q	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.37989138	-122.15096748	5	0	33.97	338.2	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 22:48:42.25	2026-04-02 22:48:41.139	null	RAW_SHORT	2026-04-17 22:48:42.249
cmni2gocb05dgk84w8988gdmo	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.3826398	-122.15178036	5	0	34.97	350.51	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 22:48:52.284	2026-04-02 22:48:50.139	null	RAW_SHORT	2026-04-17 22:48:52.283
cmni2gw3505drk84ww71tot65	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.3853594	-122.15250213	5	0	33.75	345.59	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 22:49:02.321	2026-04-02 22:48:59.139	null	RAW_SHORT	2026-04-17 22:49:02.32
cmni2h3ub05e2k84wfjjyahn8	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.38758433	-122.15481075	5	0	31.64	307.27	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 22:49:12.371	2026-04-02 22:49:09.14	null	RAW_SHORT	2026-04-17 22:49:12.371
cmni2hbl005edk84w6sn7gdr6	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.38863873	-122.158132	5	0	32.54	280.55	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 22:49:22.405	2026-04-02 22:49:19.14	null	RAW_SHORT	2026-04-17 22:49:22.404
cmni2hjcz05eok84wo6v7h5vt	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.38921159	-122.16173186	5	0	32.27	285.82	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 22:49:32.484	2026-04-02 22:49:29.137	null	RAW_SHORT	2026-04-17 22:49:32.482
cmni2hysn05fak84wv51u99zk	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.39195948	-122.16790371	5	0	33.32	287.58	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 22:49:52.488	2026-04-02 22:49:48.134	null	RAW_SHORT	2026-04-17 22:49:52.487
cmni2i6iw05flk84wyitnlyhl	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.39232727	-122.17156408	5	0	32.51	275.98	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 22:50:02.504	2026-04-02 22:49:58.134	null	RAW_SHORT	2026-04-17 22:50:02.503
cmni2im0w05g7k84wwp50dmay	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.39531442	-122.1776014	5	0	33.11	322.03	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 22:50:22.592	2026-04-02 22:50:18.14	null	RAW_SHORT	2026-04-17 22:50:22.591
cmni2ipvl05gdk84wf9kslmiy	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.39747477	-122.17969227	5	0	34.8	321.68	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 22:50:27.585	2026-04-02 22:50:27.221	null	RAW_SHORT	2026-04-17 22:50:27.585
cmni2ixmx05gok84wkwwao2y8	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.39971672	-122.18192127	5	0	35.22	321.68	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 22:50:37.641	2026-04-02 22:50:36.133	null	RAW_SHORT	2026-04-17 22:50:37.64
cmni2jd4c05hak84wrfw3y8oa	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.40408658	-122.18630827	5	0	34	321.33	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 22:50:57.709	2026-04-02 22:50:54.137	null	RAW_SHORT	2026-04-17 22:50:57.708
cmni2jkv405hlk84w7xwrtvwf	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.406187	-122.18845228	5	0	32.96	319.92	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 22:51:07.745	2026-04-02 22:51:03.134	null	RAW_SHORT	2026-04-17 22:51:07.743
cmni2k0dt05i7k84wv0eoz3f7	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.40924065	-122.19469587	5	0	33.01	291.09	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 22:51:27.858	2026-04-02 22:51:23.154	null	RAW_SHORT	2026-04-17 22:51:27.857
cmni2k47t05idk84wj6daitc4	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.41025751	-122.19788477	5	0	34.04	291.8	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 22:51:32.825	2026-04-02 22:51:32.137	null	RAW_SHORT	2026-04-17 22:51:32.825
cmni2kbyg05iok84wrw4r9zu1	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.41128521	-122.20114273	5	0	34.79	291.8	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 22:51:42.856	2026-04-02 22:51:41.137	null	RAW_SHORT	2026-04-17 22:51:42.855
cmni2kjon05izk84wwyarajsq	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.41233794	-122.20442475	5	0	34.65	291.8	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 22:51:52.872	2026-04-02 22:51:50.131	null	RAW_SHORT	2026-04-17 22:51:52.871
cmni2krfl05jak84w6s7a7ul4	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.41347243	-122.20759654	5	0	34.2	301.29	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 22:52:02.913	2026-04-02 22:51:59.138	null	RAW_SHORT	2026-04-17 22:52:02.912
cmni2kz6505jlk84wkkayy3w5	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.41535131	-122.21013769	5	0	34.26	321.33	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 22:52:12.941	2026-04-02 22:52:08.166	null	RAW_SHORT	2026-04-17 22:52:12.94
cmni2l6xa05jwk84wdo1mwtht	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.41751498	-122.21274345	5	0	33.08	305.51	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 22:52:22.99	2026-04-02 22:52:18.14	null	RAW_SHORT	2026-04-17 22:52:22.989
cmni2leny05k7k84wnrcv3y66	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.41862281	-122.2161253	5	0	32.23	281.95	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 22:52:33.022	2026-04-02 22:52:28.137	null	RAW_SHORT	2026-04-17 22:52:33.022
cmni2lq9j05kok84w7pcas3d3	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.42039831	-122.22300357	5	0	34.56	306.56	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 22:52:48.055	2026-04-02 22:52:47.134	null	RAW_SHORT	2026-04-17 22:52:48.054
cmni2ly0a05kzk84wn56jal2r	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.42221534	-122.22563264	5	0	34.15	310.78	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 22:52:58.09	2026-04-02 22:52:56.133	null	RAW_SHORT	2026-04-17 22:52:58.09
cmni2m4zv05lak84wg5uoyo4u	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.42404586	-122.22828543	5	0	35.16	310.78	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 22:53:07.147	2026-04-02 22:53:05.139	null	RAW_SHORT	2026-04-17 22:53:07.146
cmni2mdi105lqk84wkcqr887n	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.42602726	-122.23093034	5	0	35.64	316.05	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 22:53:18.169	2026-04-02 22:53:14.134	null	RAW_SHORT	2026-04-17 22:53:18.168
cmni2mhdf05lwk84wt8082dtx	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.42803355	-122.23345363	5	0	34.52	312.19	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 22:53:23.187	2026-04-02 22:53:23.139	null	RAW_SHORT	2026-04-17 22:53:23.187
cmni2mp4p05m7k84wm6hvrnnt	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.42981596	-122.23606668	5	0	32.93	310.43	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 22:53:33.242	2026-04-02 22:53:32.14	null	RAW_SHORT	2026-04-17 22:53:33.241
cmni2mwvr05mik84wjn30pe2c	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.43180499	-122.23884881	5	0	33.85	313.95	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 22:53:43.287	2026-04-02 22:53:42.146	null	RAW_SHORT	2026-04-17 22:53:43.287
cmni2n4l205mtk84wm67pesd0	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.43376254	-122.2412125	5	0	33.13	316.41	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 22:53:53.27	2026-04-02 22:53:51.138	null	RAW_SHORT	2026-04-17 22:53:53.269
cmni2ncb905n4k84w0a2ovm4s	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.43592675	-122.24376328	5	0	33.23	316.41	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 22:54:03.286	2026-04-02 22:54:01.158	null	RAW_SHORT	2026-04-17 22:54:03.285
cmni2nk1j05nfk84w2jrt6o5u	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.4378918	-122.24613695	5	0	33.5	316.41	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 22:54:13.303	2026-04-02 22:54:10.131	null	RAW_SHORT	2026-04-17 22:54:13.302
cmni2nrrs05nqk84wvupb4w3d	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.44000262	-122.24876996	5	0	32.88	314.3	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 22:54:23.32	2026-04-02 22:54:20.147	null	RAW_SHORT	2026-04-17 22:54:23.319
cmni2nzi705o1k84wjv7rdlxj	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.44207177	-122.25146784	5	0	32.88	312.89	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 22:54:33.343	2026-04-02 22:54:30.137	null	RAW_SHORT	2026-04-17 22:54:33.342
cmni2o78c05ock84w8ylah96b	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.44364246	-122.25458952	5	0	32.61	292.5	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 22:54:43.356	2026-04-02 22:54:40.145	null	RAW_SHORT	2026-04-17 22:54:43.355
cmni2oeyi05onk84w8m4fvbrl	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.44423451	-122.25815644	5	0	32.29	272.46	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 22:54:53.371	2026-04-02 22:54:50.141	null	RAW_SHORT	2026-04-17 22:54:53.37
cmni2omot05oyk84w932k6s4k	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.44401797	-122.26182293	5	0	32.35	264.02	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 22:55:03.389	2026-04-02 22:55:00.14	null	RAW_SHORT	2026-04-17 22:55:03.388
cmni2ouf005p9k84wqj7rwzqh	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.44381697	-122.26544651	5	0	32.14	272.46	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 22:55:13.405	2026-04-02 22:55:10.143	null	RAW_SHORT	2026-04-17 22:55:13.404
cmni2p25m05pkk84w3omfd8vh	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.4444387	-122.26900388	5	0	32.78	291.8	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 22:55:23.434	2026-04-02 22:55:20.142	null	RAW_SHORT	2026-04-17 22:55:23.434
cmni2p9vc05pvk84w9ofo977a	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.44578948	-122.27195431	5	0	34.08	307.62	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 22:55:33.433	2026-04-02 22:55:29.146	null	RAW_SHORT	2026-04-17 22:55:33.432
cmni2pdr005q1k84wireldazw	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.44763979	-122.27464045	5	0	35.01	311.13	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 22:55:38.46	2026-04-02 22:55:38.14	null	RAW_SHORT	2026-04-17 22:55:38.46
cmni8dbfl02pr708neecjq4vg	\N	alex@brspark.com	dev_szkcjr	cmni8cwga02p1708nrb9ddvxg	OS_ACCEPT	\N	\N	\N	\N	\N	\N	GPS	\N	\N	UNKNOWN	1.0.0	26.3.1	Simulator iOS	f	f	-3	2026-04-03 01:34:13.281	2026-04-03 01:34:10.182	{"previousState": "IDLE"}	LEGAL	2031-04-03 01:34:13.279
cmni8dbfl02ps708n197kkrvc	\N	alex@brspark.com	\N	\N	HEARTBEAT	-23.569983	-46.7851655	5	0	-1	-1	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-03 01:34:13.281	2026-04-03 01:34:10.064	null	RAW_SHORT	2026-04-18 01:34:13.279
cmnjjxs7600r7bddjqzhe6std	\N	alex@brspark.com	dev_or2xj4	cmnj0xh1v0001hw8ycw1mvicf	OS_ACCEPT	\N	\N	\N	\N	\N	\N	GPS	\N	\N	UNKNOWN	1.0.0	26.4	iPhone 17 Pro Max	f	f	10	2026-04-03 23:45:50.082	2026-04-03 23:45:45.315	{"previousState": "IDLE"}	LEGAL	2031-04-03 23:45:50.081
cmnjjxs7600r8bddj4drde4s7	\N	alex@brspark.com	\N	\N	HEARTBEAT	-23.56719453129495	-46.7862439702355	7.928586564459389	790.6080504131318	-1	-1	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-03 23:45:50.082	2026-04-03 23:45:38.715	null	RAW_SHORT	2026-04-18 23:45:50.081
cmnjjxs7600r9bddj24fdmd52	\N	alex@brspark.com	dev_or2xj4	cmnj0xh1v0001hw8ycw1mvicf	FRAUD_FLAG	-23.56719284123004	-46.78624960487538	\N	\N	\N	\N	GPS	\N	\N	UNKNOWN	1.0.0	26.4	iPhone 17 Pro Max	f	f	-53	2026-04-03 23:45:50.082	2026-04-03 23:45:45.478	{"lat": -23.56719284123004, "lng": -46.78624960487538, "reason": "MOCK_LOCATION", "severity": "HIGH"}	LEGAL	2031-04-03 23:45:50.081
cmnjjxs7600rbbddjyglpp1e6	\N	alex@brspark.com	\N	\N	HEARTBEAT	-23.56719284123004	-46.78624960487538	14.195014	790.57	-1	-1	\N	\N	\N	\N	\N	\N	\N	t	f	\N	2026-04-03 23:45:50.082	2026-04-03 23:45:45.318	null	RAW_SHORT	2026-04-18 23:45:50.081
cmnjk36ho00xrbddj6fcmhioh	\N	alex@brspark.com	\N	\N	HEARTBEAT	-23.56719453129495	-46.7862439702355	7.928586564459389	790.6080504131318	-1	-1	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-03 23:50:01.884	2026-04-03 23:49:55.39	null	RAW_SHORT	2026-04-18 23:50:01.88
cmnjk36ho00xsbddjq3lsiegj	\N	alex@brspark.com	\N	\N	HEARTBEAT	-23.56719453129495	-46.7862439702355	7.928586564459389	790.6080504131318	-1	-1	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-03 23:50:01.884	2026-04-03 23:49:57.863	null	RAW_SHORT	2026-04-18 23:50:01.88
cmni2plhh05qck84wpxnttbnq	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.44952769	-122.27735443	5	0	35.54	310.08	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 22:55:48.486	2026-04-02 22:55:47.134	null	RAW_SHORT	2026-04-17 22:55:48.485
cmni2pt7605qnk84woik91y3z	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.45133281	-122.28009883	5	0	34.86	309.73	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 22:55:58.482	2026-04-02 22:55:56.144	null	RAW_SHORT	2026-04-17 22:55:58.481
cmni2qk9905rqk84w7i6b41nr	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.4591201	-122.28995444	5	0	34.45	337.85	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 22:56:33.549	2026-04-02 22:56:32.154	null	RAW_SHORT	2026-04-17 22:56:33.548
cmni2qzqh05sck84w3xv5nieh	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.46449927	-122.29080537	5	0	33.1	355.43	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 22:56:53.609	2026-04-02 22:56:50.141	null	RAW_SHORT	2026-04-17 22:56:53.608
cmni2r7gn05snk84w19egzfuz	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.46741706	-122.29164222	5	0	33.44	339.61	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 22:57:03.624	2026-04-02 22:57:00.147	null	RAW_SHORT	2026-04-17 22:57:03.623
cmni2rj2805t4k84wo6vv82g7	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.47193243	-122.29536731	5	0	33.52	321.33	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 22:57:18.657	2026-04-02 22:57:18.142	null	RAW_SHORT	2026-04-17 22:57:18.656
cmni2se0605uck84w71aiwkr0	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.48204679	-122.298808	5	0	34.51	7.03	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 22:57:58.759	2026-04-02 22:57:54.141	null	RAW_SHORT	2026-04-17 22:57:58.758
cmni8durx02qn708n8d4vsuef	\N	alex@brspark.com	dev_szkcjr	cmni8cwga02p1708nrb9ddvxg	TRANSIT_START	\N	\N	\N	\N	\N	\N	GPS	\N	\N	UNKNOWN	1.0.0	26.3.1	Simulator iOS	f	f	9	2026-04-03 01:34:38.349	2026-04-03 01:34:37.048	{"previousState": "DISPATCHED"}	LEGAL	2031-04-03 01:34:38.349
cmni8durx02qo708nmk5rm5x7	\N	alex@brspark.com	\N	\N	HEARTBEAT	-23.569983	-46.7851655	5	0	-1	-1	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-03 01:34:38.349	2026-04-03 01:34:37.078	null	RAW_SHORT	2026-04-18 01:34:38.349
cmnjk36is00xtbddjsjwd44rc	\N	alex@brspark.com	\N	\N	HEARTBEAT	-23.56719453129495	-46.7862439702355	7.928586564459389	790.6080504131318	-1	-1	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-03 23:50:01.924	2026-04-03 23:49:55.39	null	RAW_SHORT	2026-04-18 23:50:01.924
cmnjk36is00xubddjtsr7xmpq	\N	alex@brspark.com	\N	\N	HEARTBEAT	-23.56719453129495	-46.7862439702355	7.928586564459389	790.6080504131318	-1	-1	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-03 23:50:01.924	2026-04-03 23:49:57.863	null	RAW_SHORT	2026-04-18 23:50:01.924
cmni2q0xl05qyk84wqtb8tvpg	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.45311074	-122.28279923	5	0	34.09	309.38	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 22:56:08.506	2026-04-02 22:56:05.143	null	RAW_SHORT	2026-04-17 22:56:08.505
cmni8prcr02r6708n6r03ylag	\N	alex@brspark.com	\N	\N	HEARTBEAT	-23.569983	-46.7851655	5	0	-1	-1	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-03 01:43:53.783	2026-04-03 01:43:50.695	null	RAW_SHORT	2026-04-18 01:43:53.778
cmnjk4uo0012lbddj68r4ofku	\N	alex@brspark.com	dev_or2xj4	cmnj3ycod0179hojan64s2qh5	OS_ACCEPT	\N	\N	\N	\N	\N	\N	GPS	\N	\N	UNKNOWN	1.0.0	26.4	iPhone 17 Pro Max	f	f	18	2026-04-03 23:51:19.872	2026-04-03 23:51:19.376	{"previousState": "IDLE"}	LEGAL	2031-04-03 23:51:19.871
cmnjk4uo0012mbddjpu17312q	\N	alex@brspark.com	\N	\N	HEARTBEAT	-23.56719276291074	-46.78624975392268	4.740314856161533	791.3092407332191	-1	-1	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-03 23:51:19.872	2026-04-03 23:51:15.953	null	RAW_SHORT	2026-04-18 23:51:19.871
cmnjk4ymh012sbddjdnssab03	\N	alex@brspark.com	\N	\N	HEARTBEAT	-23.56719276084832	-46.78624975784761	4.612869540326709	791.3092407332191	-1	-1	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-03 23:51:25.001	2026-04-03 23:51:21.96	null	RAW_SHORT	2026-04-18 23:51:25
cmni2q8nq05r9k84w01fmkd7u	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.45488322	-122.28547306	5	0	34.74	309.73	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 22:56:18.518	2026-04-02 22:56:14.141	null	RAW_SHORT	2026-04-17 22:56:18.517
cmni2qcja05rfk84wwrx4a9yq	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.45672979	-122.28811109	5	0	34.63	317.81	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 22:56:23.543	2026-04-02 22:56:23.146	null	RAW_SHORT	2026-04-17 22:56:23.542
cmni2qrzh05s1k84w3mc3un7c	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.4617959	-122.29070035	5	0	33.54	354.38	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 22:56:43.565	2026-04-02 22:56:41.146	null	RAW_SHORT	2026-04-17 22:56:43.564
cmni2rf7e05syk84wu822r6yu	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.46980661	-122.29324794	5	0	33.47	324.84	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 22:57:13.659	2026-04-02 22:57:09.144	null	RAW_SHORT	2026-04-17 22:57:13.658
cmni2rqt005tfk84wkx03l0rc	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.47407652	-122.29748533	5	0	33.71	324.84	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 22:57:28.692	2026-04-02 22:57:27.139	null	RAW_SHORT	2026-04-17 22:57:28.691
cmni2ryjq05tqk84wis116uxa	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.47654113	-122.29890078	5	0	33.88	343.83	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 22:57:38.727	2026-04-02 22:57:36.155	null	RAW_SHORT	2026-04-17 22:57:38.726
cmni2s69e05u1k84wlrgs171b	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.47928265	-122.29924209	5	0	33.95	3.52	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 22:57:48.723	2026-04-02 22:57:45.143	null	RAW_SHORT	2026-04-17 22:57:48.722
cmni2shvj05uik84www8s7hyc	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.48475481	-122.29834808	5	0	32.93	7.38	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 22:58:03.776	2026-04-02 22:58:03.143	null	RAW_SHORT	2026-04-17 22:58:03.775
cmni2splq05uyk84wy5azkicf	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.48769154	-122.29820324	5	0	33.23	353.32	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 22:58:13.79	2026-04-02 22:58:13.146	null	RAW_SHORT	2026-04-17 22:58:13.789
cmni2sxcf05v9k84wg3jh26m7	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.49056217	-122.29928702	5	0	32.99	333.98	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 22:58:23.823	2026-04-02 22:58:23.145	null	RAW_SHORT	2026-04-17 22:58:23.822
cmni2t53305vkk84wqrfx9cp9	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.49291363	-122.30150194	5	0	32.67	313.95	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 22:58:33.856	2026-04-02 22:58:33.162	null	RAW_SHORT	2026-04-17 22:58:33.855
cmni2tctt05vvk84wr8q1xu0i	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.49453457	-122.30464079	5	0	33.45	293.2	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 22:58:43.889	2026-04-02 22:58:43.144	null	RAW_SHORT	2026-04-17 22:58:43.888
cmni2tkkn05w6k84wouodrihu	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.49543424	-122.30818156	5	0	32.45	286.88	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 22:58:53.927	2026-04-02 22:58:53.146	null	RAW_SHORT	2026-04-17 22:58:53.926
cmni2tsbs05whk84w1f71kl77	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.4963855	-122.3116028	5	0	32.65	294.26	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 22:59:03.976	2026-04-02 22:59:03.146	null	RAW_SHORT	2026-04-17 22:59:03.975
cmni2u01z05wsk84w7qprlps8	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.49791545	-122.31482925	5	0	34.11	305.16	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 22:59:13.991	2026-04-02 22:59:13.161	null	RAW_SHORT	2026-04-17 22:59:13.99
cmni2u7sn05x3k84wdl9of0v9	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.49945868	-122.31765789	5	0	33.58	301.29	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 22:59:24.023	2026-04-02 22:59:22.14	null	RAW_SHORT	2026-04-17 22:59:24.022
cmni2ufiv05xek84wxphblpf5	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.50055478	-122.32105281	5	0	31.39	283.71	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 22:59:34.039	2026-04-02 22:59:32.144	null	RAW_SHORT	2026-04-17 22:59:34.039
cmni2unab05xpk84wtdtc6unz	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.50087108	-122.32460448	5	0	32.05	272.81	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 22:59:44.099	2026-04-02 22:59:42.144	null	RAW_SHORT	2026-04-17 22:59:44.098
cmni2uuzs05y0k84w4r5hbufz	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.50133564	-122.32819947	5	0	32.41	287.58	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 22:59:54.089	2026-04-02 22:59:52.141	null	RAW_SHORT	2026-04-17 22:59:54.088
cmni2v2r205ybk84wuuznhves	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.50272247	-122.33142131	5	0	33.04	307.27	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 23:00:04.142	2026-04-02 23:00:02.146	null	RAW_SHORT	2026-04-17 23:00:04.141
cmni2vai105ymk84wdlz6dtq0	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.50438925	-122.33410746	5	0	33.69	307.27	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 23:00:14.185	2026-04-02 23:00:11.146	null	RAW_SHORT	2026-04-17 23:00:14.184
cmni2vi8o05yxk84wfv75vtr6	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.50606869	-122.33688933	5	0	34.88	307.62	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 23:00:24.216	2026-04-02 23:00:20.142	null	RAW_SHORT	2026-04-17 23:00:24.215
cmni2vm3n05z3k84wcpaf0dlf	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.50780014	-122.33971445	5	0	35.12	307.97	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 23:00:29.22	2026-04-02 23:00:29.14	null	RAW_SHORT	2026-04-17 23:00:29.219
cmni2vtty05zek84we1a8m4dr	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.50948943	-122.34244552	5	0	33.34	309.73	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 23:00:39.239	2026-04-02 23:00:38.141	null	RAW_SHORT	2026-04-17 23:00:39.238
cmni2w1ka05zpk84wyg7vexs3	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.51158508	-122.3451284	5	0	33.63	317.11	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 23:00:49.258	2026-04-02 23:00:48.142	null	RAW_SHORT	2026-04-17 23:00:49.257
cmni2w9bf0600k84wsgq1whvt	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.51359988	-122.34743577	5	0	33.46	317.46	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 23:00:59.308	2026-04-02 23:00:57.141	null	RAW_SHORT	2026-04-17 23:00:59.307
cmni2wh0m060bk84wqnfbtpn9	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.51579153	-122.3499475	5	0	32.41	317.81	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 23:01:09.286	2026-04-02 23:01:07.145	null	RAW_SHORT	2026-04-17 23:01:09.286
cmni2woru060mk84w74yyifq6	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.51797837	-122.35239962	5	0	32.96	320.98	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 23:01:19.338	2026-04-02 23:01:17.144	null	RAW_SHORT	2026-04-17 23:01:19.337
cmni2wwhp060xk84wugshvaek	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.5202453	-122.35426233	5	0	33.74	332.23	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 23:01:29.341	2026-04-02 23:01:26.147	null	RAW_SHORT	2026-04-17 23:01:29.34
cmni2x47c0618k84wjsnoia10	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.52299544	-122.35580008	5	0	33.29	336.09	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 23:01:39.336	2026-04-02 23:01:36.144	null	RAW_SHORT	2026-04-17 23:01:39.335
cmni2xby6061jk84wztuxpu1y	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.52552611	-122.35781861	5	0	34.13	324.49	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 23:01:49.374	2026-04-02 23:01:46.14	null	RAW_SHORT	2026-04-17 23:01:49.374
cmni2xjoc061uk84wovyi3lp3	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.52800506	-122.35949985	5	0	34.9	341.02	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 23:01:59.389	2026-04-02 23:01:55.159	null	RAW_SHORT	2026-04-17 23:01:59.388
cmni2xnjq0620k84w1vrklqkd	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.53068496	-122.36063467	5	0	34.77	341.37	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 23:02:04.407	2026-04-02 23:02:04.14	null	RAW_SHORT	2026-04-17 23:02:04.406
cmni2xv9y062bk84wuldeww0p	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.53334395	-122.36177327	5	0	34.44	341.37	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 23:02:14.422	2026-04-02 23:02:13.14	null	RAW_SHORT	2026-04-17 23:02:14.421
cmni2y30d062mk84wb280ejb6	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.53591623	-122.36300097	5	0	33.5	336.45	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 23:02:24.445	2026-04-02 23:02:22.138	null	RAW_SHORT	2026-04-17 23:02:24.442
cmni2yaqg062xk84wmsma190g	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.53860477	-122.36458146	5	0	32.83	334.34	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 23:02:34.456	2026-04-02 23:02:32.146	null	RAW_SHORT	2026-04-17 23:02:34.456
cmni2yih10638k84wypec9xyk	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.54123564	-122.36620294	5	0	32.44	331.17	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 23:02:44.486	2026-04-02 23:02:42.143	null	RAW_SHORT	2026-04-17 23:02:44.485
cmni2yq7e063jk84wdxx1hnps	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.54365964	-122.36820328	5	0	32.86	320.98	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 23:02:54.506	2026-04-02 23:02:52.141	null	RAW_SHORT	2026-04-17 23:02:54.505
cmni2yxy6063uk84whj89jwpl	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.54598206	-122.37059682	5	0	33.29	320.62	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 23:03:04.542	2026-04-02 23:03:02.146	null	RAW_SHORT	2026-04-17 23:03:04.541
cmni2z5o6064ak84wg6sd8n1o	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.54827568	-122.3729751	5	0	32.68	320.27	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 23:03:14.551	2026-04-02 23:03:12.144	null	RAW_SHORT	2026-04-17 23:03:14.55
cmni2zdeu064lk84wm8xk7myq	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.55055158	-122.37533284	5	0	33.27	321.33	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 23:03:24.582	2026-04-02 23:03:22.146	null	RAW_SHORT	2026-04-17 23:03:24.581
cmni2zl4v064wk84wtb1bqvo9	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.5528237	-122.37738054	5	0	35.82	328.36	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 23:03:34.592	2026-04-02 23:03:31.147	null	RAW_SHORT	2026-04-17 23:03:34.591
cmni2zsvi0657k84wm5pwkolz	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.55541199	-122.37918458	5	0	36.43	332.23	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 23:03:44.622	2026-04-02 23:03:40.14	null	RAW_SHORT	2026-04-17 23:03:44.621
cmni2zwr1065dk84wn2m3l3yw	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.55792263	-122.38086842	5	0	33.86	330.82	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 23:03:49.645	2026-04-02 23:03:49.151	null	RAW_SHORT	2026-04-17 23:03:49.644
cmni304hn065ok84whkslixtk	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.56018092	-122.38291134	5	0	35.39	321.33	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 23:03:59.675	2026-04-02 23:03:58.141	null	RAW_SHORT	2026-04-17 23:03:59.674
cmni30rre066lk84wlq5yte0f	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.5662684	-122.39029697	5	0	32.91	292.85	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 23:04:29.835	2026-04-02 23:04:26.139	null	RAW_SHORT	2026-04-17 23:04:29.834
cmni30zg0066wk84wr8vvhlbx	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.56749438	-122.39332946	5	0	33.82	306.56	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 23:04:39.792	2026-04-02 23:04:35.139	null	RAW_SHORT	2026-04-17 23:04:39.792
cmni313bd0672k84wvbubst81	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.56950528	-122.39562543	5	0	33.97	323.09	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 23:04:44.809	2026-04-02 23:04:44.136	null	RAW_SHORT	2026-04-17 23:04:44.808
cmni31b1i067dk84wrlguuukd	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.57168001	-122.39767439	5	0	33.69	323.09	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 23:04:54.823	2026-04-02 23:04:53.145	null	RAW_SHORT	2026-04-17 23:04:54.822
cmni31zwg068nk84w8ugyw5d1	\N	alex@brspark.com	dev_szkcjr	cmni1npwo045ck84w2mp3uaqv	OS_ACCEPT	\N	\N	\N	\N	\N	\N	GPS	\N	\N	UNKNOWN	1.0.0	26.3.1	Simulator iOS	f	f	5	2026-04-02 23:05:27.04	2026-04-02 23:05:23.59	{"previousState": "IDLE"}	LEGAL	2031-04-02 23:05:27.039
cmni31zwg068ok84wuynlkujx	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.58005085	-122.40290788	5	0	32.41	329.41	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 23:05:27.04	2026-04-02 23:05:24.154	null	RAW_SHORT	2026-04-17 23:05:27.039
cmni327ui068zk84wzi1eest1	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.58259199	-122.40486589	5	0	33.67	328.71	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 23:05:37.337	2026-04-02 23:05:34.135	null	RAW_SHORT	2026-04-17 23:05:37.332
cmni32jm2069gk84w4e3jwqi0	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.58668202	-122.40947736	5	0	34.52	310.08	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 23:05:52.584	2026-04-02 23:05:52.149	null	RAW_SHORT	2026-04-17 23:05:52.583
cmni33xnw06bgk84wnb401jzz	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.6012209	-122.42531681	5	0	33.64	316.41	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 23:06:57.453	2026-04-02 23:06:55.145	null	RAW_SHORT	2026-04-17 23:06:57.451
cmni9mwti02r7708np32gdzoo	\N	alex@brspark.com	\N	\N	HEARTBEAT	-23.569983	-46.7851655	5	0	-1	-1	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-03 02:09:40.517	2026-04-03 02:09:36.989	null	RAW_SHORT	2026-04-18 02:09:40.51
cmni9mwti02r8708n36412vl3	\N	alex@brspark.com	\N	\N	HEARTBEAT	-23.569983	-46.7851655	5	0	-1	-1	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-03 02:09:40.517	2026-04-03 02:09:36.989	null	RAW_SHORT	2026-04-18 02:09:40.515
cmnjk4ymw012tbddjbesj1wak	\N	alex@brspark.com	\N	\N	HEARTBEAT	-23.56719276084832	-46.78624975784761	4.612869540326709	791.3092407332191	-1	-1	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-03 23:51:25.017	2026-04-03 23:51:21.96	null	RAW_SHORT	2026-04-18 23:51:25.016
cmnjk73q70198bddjg4f6wvi4	\N	alex@brspark.com	\N	\N	HEARTBEAT	-23.56719272778735	-46.78624982076507	5.978709476490201	791.3092407332191	-1	-1	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-03 23:53:04.927	2026-04-03 23:52:58.078	null	RAW_SHORT	2026-04-18 23:53:04.926
cmnjk73q70199bddj8zd7fnee	\N	alex@brspark.com	\N	\N	HEARTBEAT	-23.56719272778735	-46.78624982076507	5.978709476490201	791.3092407332191	-1	-1	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-03 23:53:04.927	2026-04-03 23:52:58.078	null	RAW_SHORT	2026-04-18 23:53:04.926
cmnjk73q7019abddjst37vmqr	\N	alex@brspark.com	\N	\N	HEARTBEAT	-23.56719272748756	-46.78624982133561	5.73460504996959	791.3092407332191	-1	-1	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-03 23:53:04.927	2026-04-03 23:53:04.083	null	RAW_SHORT	2026-04-18 23:53:04.926
cmni30c7u065zk84wqicci51i	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.56242844	-122.38515208	5	0	34.55	321.33	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 23:04:09.69	2026-04-02 23:04:07.143	null	RAW_SHORT	2026-04-17 23:04:09.689
cmni34d3u06c2k84wmzxtus81	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.60638205	-122.42801839	5	0	32.8	358.95	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 23:07:17.467	2026-04-02 23:07:14.169	null	RAW_SHORT	2026-04-17 23:07:17.466
cmni35jos06drk84wcdkvzrq1	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.6227911	-122.42733945	5	0	34.94	332.93	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 23:08:12.653	2026-04-02 23:08:12.138	null	RAW_SHORT	2026-04-17 23:08:12.651
cmni35rem06e2k84w1bzdd4m8	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.62525969	-122.42895322	5	0	34.47	330.47	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 23:08:22.654	2026-04-02 23:08:21.14	null	RAW_SHORT	2026-04-17 23:08:22.653
cmni9swah02rr708nkqgrbktk	cmnhhqj5c000e3yrjmvwv50er	alex@brspark.com	dev_szkcjr	\N	SESSION_OPEN	\N	\N	\N	\N	\N	\N	GPS	\N	\N	UNKNOWN	1.0.0	26.3.1	Simulator iOS	f	f	-152	2026-04-03 02:14:19.77	2026-04-03 02:14:16.036	{}	OPERATIONAL	2026-09-30 02:14:19.769
cmni9t05x02s2708nlpwvso8v	cmnhhqj5c000e3yrjmvwv50er	alex@brspark.com	dev_szkcjr	cmni8cwga02p1708nrb9ddvxg	OS_ACCEPT	\N	\N	\N	\N	\N	\N	GPS	\N	\N	UNKNOWN	1.0.0	26.3.1	Simulator iOS	f	f	4	2026-04-03 02:14:24.79	2026-04-03 02:14:22.949	{"previousState": "IDLE"}	LEGAL	2031-04-03 02:14:24.789
cmni9t05x02s3708nedzegl4t	\N	alex@brspark.com	\N	\N	HEARTBEAT	-23.569983	-46.7851655	5	0	-1	-1	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-03 02:14:24.79	2026-04-03 02:14:22.439	null	RAW_SHORT	2026-04-18 02:14:24.789
cmnjk73qe019bbddj5kep8lsx	\N	alex@brspark.com	\N	\N	HEARTBEAT	-23.56719272778735	-46.78624982076507	5.978709476490201	791.3092407332191	-1	-1	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-03 23:53:04.934	2026-04-03 23:52:58.078	null	RAW_SHORT	2026-04-18 23:53:04.933
cmnjk73qe019cbddjiikxrs29	\N	alex@brspark.com	\N	\N	HEARTBEAT	-23.56719272778735	-46.78624982076507	5.978709476490201	791.3092407332191	-1	-1	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-03 23:53:04.934	2026-04-03 23:52:58.078	null	RAW_SHORT	2026-04-18 23:53:04.933
cmnjk73qe019dbddjqho6mae1	\N	alex@brspark.com	\N	\N	HEARTBEAT	-23.56719272748756	-46.78624982133561	5.73460504996959	791.3092407332191	-1	-1	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-03 23:53:04.934	2026-04-03 23:53:04.083	null	RAW_SHORT	2026-04-18 23:53:04.933
cmni30jyb066ak84wkn3q3akj	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.56457886	-122.387311	5	0	33.15	320.27	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 23:04:19.715	2026-04-02 23:04:16.142	null	RAW_SHORT	2026-04-17 23:04:19.714
cmni32r0k069rk84wjd52oeh3	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.58870185	-122.41186269	5	0	34.32	322.03	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 23:06:02.181	2026-04-02 23:06:01.144	null	RAW_SHORT	2026-04-17 23:06:02.18
cmni9x6oh032y708nj9ubgx02	cmnhhqj5c000e3yrjmvwv50er	alex@brspark.com	dev_szkcjr	cmni8cwga02p1708nrb9ddvxg	OS_ACCEPT	\N	\N	\N	\N	\N	\N	GPS	\N	\N	UNKNOWN	1.0.0	26.3.1	Simulator iOS	f	f	-2	2026-04-03 02:17:39.857	2026-04-03 02:17:35.7	{"previousState": "DISPATCHED"}	LEGAL	2031-04-03 02:17:39.854
cmni9x6oh032z708n2ds2j7hw	\N	alex@brspark.com	\N	\N	HEARTBEAT	-23.569983	-46.7851655	5	0	-1	-1	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-03 02:17:39.857	2026-04-03 02:17:35.445	null	RAW_SHORT	2026-04-18 02:17:39.854
cmnjkm9pk000grohktjwggqyu	\N	alex@brspark.com	\N	\N	HEARTBEAT	-23.56719273188238	-46.78624981297197	2.504342540577132	791.3087784395942	-1	-1	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-04 00:04:52.52	2026-04-03 23:58:40.58	null	RAW_SHORT	2026-04-19 00:04:52.52
cmnjkm9pk000frohknw4hurjg	\N	alex@brspark.com	\N	\N	HEARTBEAT	-23.56719273188238	-46.78624981297197	2.504342540577132	791.3087784395942	-1	-1	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-04 00:04:52.52	2026-04-03 23:58:40.58	null	RAW_SHORT	2026-04-19 00:04:52.519
cmnjkma3c000lrohkuui9iktl	\N	alex@brspark.com	dev_or2xj4	cmnj3ycod0179hojan64s2qh5	FRAUD_FLAG	-23.56719453129495	-46.7862439702355	\N	\N	\N	\N	GPS	\N	\N	UNKNOWN	1.0.0	26.4	iPhone 17 Pro Max	f	f	-417	2026-04-04 00:04:53.017	2026-04-04 00:04:52.7	{"lat": -23.56719453129495, "lng": -46.7862439702355, "reason": "MOCK_LOCATION", "severity": "HIGH"}	LEGAL	2031-04-04 00:04:53.016
cmnjkma3d000orohkxrnhd40l	\N	alex@brspark.com	\N	\N	HEARTBEAT	-23.56719453129495	-46.7862439702355	7.928586564459389	791.3092407332191	-1	-1	\N	\N	\N	\N	\N	\N	\N	t	f	\N	2026-04-04 00:04:53.017	2026-04-04 00:04:51.786	null	RAW_SHORT	2026-04-19 00:04:53.016
cmnjkncef0059rohka5ecvhu9	\N	alex@brspark.com	\N	\N	HEARTBEAT	-23.56719453129495	-46.7862439702355	7.928586564459389	791.3092407332191	-1	-1	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-04 00:05:42.664	2026-04-04 00:05:39.834	null	RAW_SHORT	2026-04-19 00:05:42.663
cmnjkouy500a1rohkmuni2em8	cmnhhqj5c000e3yrjmvwv50er	alex@brspark.com	dev_or2xj4	cmnj1lkhy01n1hw8y4bohk7qw	OS_ACCEPT	\N	\N	\N	\N	\N	\N	GPS	\N	\N	UNKNOWN	1.0.0	26.4	iPhone 17 Pro Max	f	f	9	2026-04-04 00:06:53.358	2026-04-04 00:06:52.123	{"previousState": "DISPATCHED"}	LEGAL	2031-04-04 00:06:53.357
cmnjkouy500a2rohk9tk5qckk	\N	alex@brspark.com	\N	\N	HEARTBEAT	-23.56719278163695	-46.7862497182854	5.547875893260453	790.6080504131318	-1	-1	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-04 00:06:53.358	2026-04-04 00:06:50.828	null	RAW_SHORT	2026-04-19 00:06:53.357
cmni32fhw069ak84w7dzgpxcd	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.58480976	-122.40690337	5	0	34.05	317.81	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 23:05:47.251	2026-04-02 23:05:43.173	null	RAW_SHORT	2026-04-17 23:05:47.249
cmni32yse06a2k84w048iv5mg	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.59089234	-122.41402865	5	0	35.15	320.98	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 23:06:12.255	2026-04-02 23:06:10.142	null	RAW_SHORT	2026-04-17 23:06:12.254
cmni336ki06adk84wm6cqyiwd	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.59307729	-122.41618842	5	0	34.11	320.98	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 23:06:22.338	2026-04-02 23:06:19.158	null	RAW_SHORT	2026-04-17 23:06:22.337
cmni33eb406aok84ws2wvtlrz	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.59524887	-122.41829286	5	0	33.59	321.68	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 23:06:32.368	2026-04-02 23:06:28.141	null	RAW_SHORT	2026-04-17 23:06:32.368
cmni33i6i06auk84w4bxf6rf5	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.59731589	-122.42053569	5	0	33.64	315.7	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 23:06:37.386	2026-04-02 23:06:37.139	null	RAW_SHORT	2026-04-17 23:06:37.386
cmni33pwr06b5k84wno18yosw	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.59924335	-122.42293962	5	0	33.86	315.7	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 23:06:47.404	2026-04-02 23:06:46.154	null	RAW_SHORT	2026-04-17 23:06:47.403
cmni345dk06brk84wseoaeavh	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.6034719	-122.42725153	5	0	33.73	335.74	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 23:07:07.449	2026-04-02 23:07:04.14	null	RAW_SHORT	2026-04-17 23:07:07.448
cmni34kwx06cdk84wwuujghn7	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.60930046	-122.42741623	5	0	33.22	15.82	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 23:07:27.585	2026-04-02 23:07:24.155	null	RAW_SHORT	2026-04-17 23:07:27.584
cmni34sld06cok84wfbu668ym	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.61204076	-122.42587002	5	0	33.18	29.18	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 23:07:37.538	2026-04-02 23:07:34.21	null	RAW_SHORT	2026-04-17 23:07:37.537
cmni350cs06czk84w52268zp3	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.61473169	-122.42429095	5	0	33.57	15.12	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 23:07:47.596	2026-04-02 23:07:44.157	null	RAW_SHORT	2026-04-17 23:07:47.595
cmni3584806dak84w0g80eswf	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.61771095	-122.42432037	5	0	33.49	346.64	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 23:07:57.656	2026-04-02 23:07:54.14	null	RAW_SHORT	2026-04-17 23:07:57.654
cmni35fth06dlk84wjrm3mxvs	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.6202557	-122.42570557	5	0	34.87	332.23	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 23:08:07.637	2026-04-02 23:08:03.155	null	RAW_SHORT	2026-04-17 23:08:07.636
cmni35z5106edk84wz9dt8so5	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.62751237	-122.43105867	5	0	34.12	316.76	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 23:08:32.677	2026-04-02 23:08:30.143	null	RAW_SHORT	2026-04-17 23:08:32.676
cmni366w406eok84w1k0362p5	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.62940085	-122.43352924	5	0	33.65	313.59	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 23:08:42.724	2026-04-02 23:08:39.144	null	RAW_SHORT	2026-04-17 23:08:42.723
cmni36emk06ezk84wwlrqnb9a	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.63128427	-122.43601061	5	0	33.33	314.3	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 23:08:52.748	2026-04-02 23:08:48.195	null	RAW_SHORT	2026-04-17 23:08:52.746
cmni36ihq06f5k84wiytnth10	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.63349298	-122.43806368	5	0	34.47	331.52	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 23:08:57.759	2026-04-02 23:08:57.141	null	RAW_SHORT	2026-04-17 23:08:57.758
cmni36q7q06fgk84wok6228q8	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.63609125	-122.43938995	5	0	34.21	339.96	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 23:09:07.767	2026-04-02 23:09:06.141	null	RAW_SHORT	2026-04-17 23:09:07.766
cmni36xye06frk84wpc3v9rj5	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.63853126	-122.44089953	5	0	33.29	325.9	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 23:09:17.799	2026-04-02 23:09:15.143	null	RAW_SHORT	2026-04-17 23:09:17.798
cmni375pt06g2k84w1dpsv28p	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.64093544	-122.44298813	5	0	32.37	325.2	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 23:09:27.857	2026-04-02 23:09:25.141	null	RAW_SHORT	2026-04-17 23:09:27.856
cmni37dfh06gdk84ww3q3w7gt	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.64307505	-122.44550295	5	0	32.91	307.27	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 23:09:37.853	2026-04-02 23:09:35.248	null	RAW_SHORT	2026-04-17 23:09:37.853
cmni37l5t06gok84wtirllabj	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.64480118	-122.44856712	5	0	33.28	312.19	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 23:09:47.873	2026-04-02 23:09:45.143	null	RAW_SHORT	2026-04-17 23:09:47.872
cmni37swg06gzk84wa5a1ne4d	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.64724442	-122.45059714	5	0	32.66	334.34	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 23:09:57.905	2026-04-02 23:09:55.139	null	RAW_SHORT	2026-04-17 23:09:57.904
cmni37zw006hak84w7itutl87	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.64986665	-122.4521721	5	0	32.1	335.04	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 23:10:06.96	2026-04-02 23:10:05.142	null	RAW_SHORT	2026-04-17 23:10:06.959
cmni388dg06hqk84w5nh40byr	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.65232339	-122.45406641	5	0	31.79	318.52	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 23:10:17.956	2026-04-02 23:10:15.244	null	RAW_SHORT	2026-04-17 23:10:17.955
cmni38g3n06i1k84wzwjopomc	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.6543464	-122.45663554	5	0	32.34	314.65	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 23:10:27.971	2026-04-02 23:10:25.15	null	RAW_SHORT	2026-04-17 23:10:27.97
cmni38nuj06ick84wdmdozcxu	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.65643224	-122.45931348	5	0	33.68	314.65	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 23:10:38.011	2026-04-02 23:10:35.143	null	RAW_SHORT	2026-04-17 23:10:38.01
cmni38vlt06ink84wjd6jc49h	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.6585296	-122.46199854	5	0	33.24	314.3	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 23:10:48.065	2026-04-02 23:10:45.144	null	RAW_SHORT	2026-04-17 23:10:48.064
cmni393av06iyk84wo414f0qk	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.66051201	-122.46432619	5	0	33.43	324.84	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 23:10:58.039	2026-04-02 23:10:54.148	null	RAW_SHORT	2026-04-17 23:10:58.038
cmni39b1u06j9k84w5em04wy6	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.66331739	-122.46552707	5	0	33.46	355.08	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 23:11:08.083	2026-04-02 23:11:04.172	null	RAW_SHORT	2026-04-17 23:11:08.082
cmni39ptx06k4k84wn1d2vm1o	\N	alex@brspark.com	dev_szkcjr	cmni1npwo045ck84w2mp3uaqv	OS_ACCEPT	\N	\N	\N	\N	\N	\N	GPS	\N	\N	UNKNOWN	1.0.0	26.3.1	Simulator iOS	f	f	8	2026-04-02 23:11:27.238	2026-04-02 23:11:26.242	{"previousState": "IDLE"}	LEGAL	2031-04-02 23:11:27.236
cmni39ptx06k5k84wyvf1xfcn	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.66999366	-122.46600668	5	0	34.25	348.4	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 23:11:27.238	2026-04-02 23:11:26.769	null	RAW_SHORT	2026-04-17 23:11:27.236
cmni39xjl06kgk84w99yd5q12	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.67252508	-122.46730663	5	0	33.32	331.52	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 23:11:37.233	2026-04-02 23:11:35.14	null	RAW_SHORT	2026-04-17 23:11:37.232
cmni3a5be06krk84weh7b4qjl	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.67503877	-122.46932809	5	0	32.96	326.95	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 23:11:47.306	2026-04-02 23:11:45.166	null	RAW_SHORT	2026-04-17 23:11:47.304
cmni3ad0k06l2k84wqy4vh6jd	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.67751495	-122.47117463	5	0	31.21	337.85	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 23:11:57.284	2026-04-02 23:11:55.143	null	RAW_SHORT	2026-04-17 23:11:57.283
cmni3et4c0001gvhml373oazh	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.68035365	-122.47161149	5	0	32.91	2.46	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 23:15:24.78	2026-04-02 23:12:05.153	null	RAW_SHORT	2026-04-17 23:15:24.779
cmni3et4c0000gvhmkd1wrr0y	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.68035365	-122.47161149	5	0	32.91	2.46	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 23:15:24.78	2026-04-02 23:12:05.153	null	RAW_SHORT	2026-04-17 23:15:24.78
cmni3f1am000rgvhmge2f3sju	\N	alex@brspark.com	dev_szkcjr	cmni1npwo045ck84w2mp3uaqv	OS_ACCEPT	\N	\N	\N	\N	\N	\N	GPS	\N	\N	UNKNOWN	1.0.0	26.3.1	Simulator iOS	f	f	11	2026-04-02 23:15:35.373	2026-04-02 23:15:32.99	{"previousState": "IDLE"}	LEGAL	2031-04-02 23:15:35.372
cmni3f1an000sgvhmnpk8myz5	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.72855831	-122.44296625	5	0	32.56	57.66	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 23:15:35.373	2026-04-02 23:15:33.175	null	RAW_SHORT	2026-04-17 23:15:35.372
cmni3f8zg0013gvhmrjlrr5d3	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.72991563	-122.43968599	5	0	33.15	64.69	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 23:15:45.34	2026-04-02 23:15:43.157	null	RAW_SHORT	2026-04-17 23:15:45.339
cmni3fgj0001egvhmzm2541jr	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.7309606	-122.43651914	5	0	33.93	69.96	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 23:15:55.116	2026-04-02 23:15:52.143	null	RAW_SHORT	2026-04-17 23:15:55.115
cmni3fo80001pgvhmhwdxx1uc	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.73184624	-122.43321198	5	0	33.48	71.72	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 23:16:05.088	2026-04-02 23:16:01.15	null	RAW_SHORT	2026-04-17 23:16:05.087
cmni3fvya0020gvhmvqe95tm1	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.73212414	-122.42955135	5	0	33.39	99.14	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 23:16:15.106	2026-04-02 23:16:11.153	null	RAW_SHORT	2026-04-17 23:16:15.106
cmni3g3oz002bgvhmyqwcv8or	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.73150681	-122.42617839	5	0	34.34	99.49	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 23:16:25.139	2026-04-02 23:16:20.151	null	RAW_SHORT	2026-04-17 23:16:25.138
cmni9zv7903ab708njlofqpm0	cmnhhqj5c000e3yrjmvwv50er	alex@brspark.com	dev_szkcjr	cmni8cwga02p1708nrb9ddvxg	SESSION_CLOSE	\N	\N	\N	\N	\N	\N	GPS	\N	\N	UNKNOWN	1.0.0	26.3.1	Simulator iOS	f	f	-34	2026-04-03 02:19:44.95	2026-04-03 02:19:42.551	{"previousState": "DISPATCHED"}	OPERATIONAL	2026-09-30 02:19:44.948
cmni9zv7a03ac708nj0uqgjy1	\N	alex@brspark.com	\N	\N	HEARTBEAT	-23.569983	-46.7851655	5	0	-1	-1	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-03 02:19:44.95	2026-04-03 02:19:42.049	null	RAW_SHORT	2026-04-18 02:19:44.948
cmnjkm9px000hrohkxdbqgm62	\N	alex@brspark.com	\N	\N	HEARTBEAT	-23.56719273188238	-46.78624981297197	2.504342540577132	791.3087784395942	-1	-1	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-04 00:04:52.534	2026-04-03 23:58:40.58	null	RAW_SHORT	2026-04-19 00:04:52.533
cmni3gbfa002mgvhmyk0rgb34	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.73152823	-122.42250586	5	0	32.35	80.51	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 23:16:35.158	2026-04-02 23:16:30.155	null	RAW_SHORT	2026-04-17 23:16:35.157
cmnia086n03bh708niy5zv6ru	\N	alex@brspark.com	dev_szkcjr	cmni8bpkq02oz708nzfdg04oc	OS_ACCEPT	\N	\N	\N	\N	\N	\N	GPS	\N	\N	UNKNOWN	1.0.0	26.3.1	Simulator iOS	f	f	3	2026-04-03 02:20:01.775	2026-04-03 02:20:00.201	{"previousState": "IDLE"}	LEGAL	2031-04-03 02:20:01.768
cmnia086n03bi708n9wm0b3x4	\N	alex@brspark.com	\N	\N	HEARTBEAT	-23.569983	-46.7851655	5	0	-1	-1	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-03 02:20:01.775	2026-04-03 02:20:00.117	null	RAW_SHORT	2026-04-18 02:20:01.768
cmnjkm9q1000irohk4boauy7h	\N	alex@brspark.com	\N	\N	HEARTBEAT	-23.56719273188238	-46.78624981297197	2.504342540577132	791.3087784395942	-1	-1	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-04 00:04:52.538	2026-04-03 23:58:40.58	null	RAW_SHORT	2026-04-19 00:04:52.537
cmnjkma3c000mrohkasjbh52l	\N	alex@brspark.com	dev_or2xj4	cmnj3ycod0179hojan64s2qh5	FRAUD_FLAG	-23.56719453129495	-46.7862439702355	\N	\N	\N	\N	GPS	\N	\N	UNKNOWN	1.0.0	26.4	iPhone 17 Pro Max	f	f	-417	2026-04-04 00:04:53.017	2026-04-04 00:04:52.7	{"lat": -23.56719453129495, "lng": -46.7862439702355, "reason": "MOCK_LOCATION", "severity": "HIGH"}	LEGAL	2031-04-04 00:04:53.016
cmnjkma3c000nrohk2ip5i5ey	\N	alex@brspark.com	\N	\N	HEARTBEAT	-23.56719453129495	-46.7862439702355	7.928586564459389	791.3092407332191	-1	-1	\N	\N	\N	\N	\N	\N	\N	t	f	\N	2026-04-04 00:04:53.017	2026-04-04 00:04:51.786	null	RAW_SHORT	2026-04-19 00:04:53.016
cmnjkouy600a4rohk8hio6vy0	cmnhhqj5c000e3yrjmvwv50er	alex@brspark.com	dev_or2xj4	cmnj1lkhy01n1hw8y4bohk7qw	OS_ACCEPT	\N	\N	\N	\N	\N	\N	GPS	\N	\N	UNKNOWN	1.0.0	26.4	iPhone 17 Pro Max	f	f	9	2026-04-04 00:06:53.358	2026-04-04 00:06:52.123	{"previousState": "DISPATCHED"}	LEGAL	2031-04-04 00:06:53.357
cmnjkouy600a6rohkk4o5hm6l	\N	alex@brspark.com	\N	\N	HEARTBEAT	-23.56719278163695	-46.7862497182854	5.547875893260453	790.6080504131318	-1	-1	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-04 00:06:53.358	2026-04-04 00:06:50.828	null	RAW_SHORT	2026-04-19 00:06:53.357
cmni3gj4y002xgvhm55agduhz	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.73190474	-122.4188029	5	0	33.33	90.7	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 23:16:45.154	2026-04-02 23:16:40.148	null	RAW_SHORT	2026-04-17 23:16:45.154
cmni3hqk00000w72dzkn46xn5	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.73208047	-122.4151556	5	0	31.8	74.88	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 23:17:41.425	2026-04-02 23:16:50.159	null	RAW_SHORT	2026-04-17 23:17:41.423
cmni3hqk00001w72dck36l5vm	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.73335846	-122.41185347	5	0	32.12	61.52	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 23:17:41.425	2026-04-02 23:17:00.156	null	RAW_SHORT	2026-04-17 23:17:41.423
cmni3hqk00002w72dqs8u6lua	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.7348374	-122.40873523	5	0	27.12	46.76	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 23:17:41.425	2026-04-02 23:17:11.169	null	RAW_SHORT	2026-04-17 23:17:41.423
cmni3hqk00003w72dnm0t9ksr	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.73748596	-122.40752731	5	0	26.71	357.54	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 23:17:41.425	2026-04-02 23:17:23.144	null	RAW_SHORT	2026-04-17 23:17:41.423
cmni3hqk00004w72dvtud77mn	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.74031301	-122.40778103	5	0	24.04	7.03	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 23:17:41.425	2026-04-02 23:17:35.157	null	RAW_SHORT	2026-04-17 23:17:41.423
cmni3hygs000fw72djyxs049t	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.74291726	-122.40638042	5	0	25.33	33.05	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 23:17:51.676	2026-04-02 23:17:48.152	null	RAW_SHORT	2026-04-17 23:17:51.675
cmni3i5gd000qw72d93g84i9x	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.7454038	-122.40480714	5	0	26.43	16.88	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 23:18:00.732	2026-04-02 23:18:00.157	null	RAW_SHORT	2026-04-17 23:18:00.726
cmni3igr20016w72d5umyzdn5	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.74815646	-122.40393139	5	0	28.39	14.77	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 23:18:15.374	2026-04-02 23:18:11.186	null	RAW_SHORT	2026-04-17 23:18:15.373
cmni3iojd001hw72dgqw1jfbm	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.75088225	-122.40310192	5	0	29.3	12.3	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 23:18:25.466	2026-04-02 23:18:22.167	null	RAW_SHORT	2026-04-17 23:18:25.465
cmni3iw8f001sw72dtd971tcb	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.75380183	-122.40286605	5	0	28.81	355.78	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 23:18:35.439	2026-04-02 23:18:33.141	null	RAW_SHORT	2026-04-17 23:18:35.438
cmni3j3z70023w72d3njb8uh5	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.75658588	-122.40323083	5	0	24.84	350.51	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 23:18:45.475	2026-04-02 23:18:45.159	null	RAW_SHORT	2026-04-17 23:18:45.475
cmni3jfm3002jw72dhqs5p7c4	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.75875152	-122.40553318	5	0	25.54	318.87	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 23:19:00.555	2026-04-02 23:18:58.154	null	RAW_SHORT	2026-04-17 23:19:00.555
cmni3jnbs002uw72dypfse276	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.76147723	-122.40613148	5	0	27.02	20.04	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 23:19:10.553	2026-04-02 23:19:10.151	null	RAW_SHORT	2026-04-17 23:19:10.552
cmni3lpk10062w72dkomm8tja	\N	alex@brspark.com	dev_szkcjr	cmni0ykni034tk84w4shu4k67	OS_ACCEPT	\N	\N	\N	\N	\N	\N	GPS	\N	\N	UNKNOWN	1.0.0	26.3.1	Simulator iOS	f	f	-13	2026-04-02 23:20:46.753	2026-04-02 23:20:44.956	{"previousState": "IDLE"}	LEGAL	2031-04-02 23:20:46.751
cmni3lpk10063w72dwedrolg8	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.33238246	-122.05644652	5	0	33.59	255.59	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 23:20:46.753	2026-04-02 23:20:45.21	null	RAW_SHORT	2026-04-17 23:20:46.751
cmni3ltj10069w72de0d26alg	\N	alex@brspark.com	dev_szkcjr	cmni0ykni034tk84w4shu4k67	TRANSIT_START	\N	\N	\N	\N	\N	\N	GPS	\N	\N	UNKNOWN	1.0.0	26.3.1	Simulator iOS	f	f	5	2026-04-02 23:20:51.902	2026-04-02 23:20:50.989	{"previousState": "DISPATCHED"}	LEGAL	2031-04-02 23:20:51.9
cmni3ltj1006aw72d1zxzimvw	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.33228724	-122.05833354	5	0	33.78	271.76	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 23:20:51.902	2026-04-02 23:20:50.983	null	RAW_SHORT	2026-04-17 23:20:51.9
cmni3lxbb006gw72dv2hocbt5	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.33260198	-122.06059221	5	0	33.93	287.23	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 23:20:56.808	2026-04-02 23:20:56.219	null	RAW_SHORT	2026-04-17 23:20:56.807
cmni3m527006rw72d32v4eg29	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.33333498	-122.06274686	5	0	34.33	294.61	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 23:21:06.847	2026-04-02 23:21:02.294	null	RAW_SHORT	2026-04-17 23:21:06.847
cmni3m8x3006xw72dd3s6ntj0	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.33405917	-122.06489607	5	0	34.3	288.98	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 23:21:11.847	2026-04-02 23:21:08.219	null	RAW_SHORT	2026-04-17 23:21:11.846
cmni3mcs60073w72dkgshmblj	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.33442928	-122.06711736	5	0	33.75	275.27	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 23:21:16.854	2026-04-02 23:21:14.218	null	RAW_SHORT	2026-04-17 23:21:16.853
cmni3mgne0079w72d9yaagxhj	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.33435661	-122.06939204	5	0	33.72	261.91	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 23:21:21.867	2026-04-02 23:21:20.213	null	RAW_SHORT	2026-04-17 23:21:21.865
cmni3mkit007fw72d468ones6	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.33396475	-122.07160897	5	0	33.51	256.64	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 23:21:26.886	2026-04-02 23:21:26.23	null	RAW_SHORT	2026-04-17 23:21:26.885
cmni3msac007qw72djnp04p3d	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.33359159	-122.07381886	5	0	32.16	261.21	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 23:21:36.948	2026-04-02 23:21:32.223	null	RAW_SHORT	2026-04-17 23:21:36.947
cmni3mw82007ww72dclfvza04	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.33362663	-122.0763056	5	0	31.9	279.14	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 23:21:42.051	2026-04-02 23:21:39.209	null	RAW_SHORT	2026-04-17 23:21:42.05
cmni3n0760082w72d8zvlp4xd	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.3342805	-122.07872034	5	0	32.85	296.72	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 23:21:47.202	2026-04-02 23:21:46.213	null	RAW_SHORT	2026-04-17 23:21:47.2
cmni3n7r3008dw72dpf45xlpl	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.33552177	-122.08082252	5	0	33.84	313.59	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 23:21:56.991	2026-04-02 23:21:53.212	null	RAW_SHORT	2026-04-17 23:21:56.99
cmni3nbma008jw72dv67kmpsi	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.33680278	-122.08247812	5	0	33.57	313.24	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 23:22:02.002	2026-04-02 23:21:59.219	null	RAW_SHORT	2026-04-17 23:22:02.001
cmni3nfjf008pw72dcfhem8mh	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.33810893	-122.08454124	5	0	33.63	305.51	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 23:22:07.083	2026-04-02 23:22:06.226	null	RAW_SHORT	2026-04-17 23:22:07.083
cmni3nn8k0090w72d004i6fh4	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.33913576	-122.08640269	5	0	33.22	304.1	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 23:22:17.061	2026-04-02 23:22:12.218	null	RAW_SHORT	2026-04-17 23:22:17.06
cmni3nr3r0096w72du6qbztqf	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.34031484	-122.08856086	5	0	32.58	301.99	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 23:22:22.071	2026-04-02 23:22:19.212	null	RAW_SHORT	2026-04-17 23:22:22.071
cmni3nv54009cw72d39q6u27b	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.34137909	-122.09077234	5	0	33.04	302.34	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 23:22:27.304	2026-04-02 23:22:26.214	null	RAW_SHORT	2026-04-17 23:22:27.303
cmni3o2py009nw72dmistigru	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.342708	-122.092712	5	0	32.19	316.76	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 23:22:37.126	2026-04-02 23:22:33.21	null	RAW_SHORT	2026-04-17 23:22:37.125
cmni3o6pb009tw72d4blrhpso	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.34415677	-122.09439031	5	0	30.74	316.41	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 23:22:42.287	2026-04-02 23:22:40.218	null	RAW_SHORT	2026-04-17 23:22:42.286
cmni3oebr00a4w72dmk5gfiv8	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.34534964	-122.09631924	5	0	31.26	300.23	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 23:22:52.168	2026-04-02 23:22:47.215	null	RAW_SHORT	2026-04-17 23:22:52.167
cmni3oi7n00aaw72dfbpcfbt3	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.34633112	-122.09862728	5	0	34.15	298.12	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 23:22:57.203	2026-04-02 23:22:54.241	null	RAW_SHORT	2026-04-17 23:22:57.202
cmni3om5300agw72dkxv0dcej	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.34719244	-122.1006624	5	0	33.72	297.77	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 23:23:02.295	2026-04-02 23:23:00.225	null	RAW_SHORT	2026-04-17 23:23:02.293
cmni3oq7k00amw72dr8cci654	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.34831482	-122.10286198	5	0	33.08	310.78	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 23:23:07.567	2026-04-02 23:23:07.219	null	RAW_SHORT	2026-04-17 23:23:07.566
cmni3oxow00axw72dtzj9gg9q	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.34991623	-122.10451573	5	0	33.2	328.01	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 23:23:17.264	2026-04-02 23:23:14.22	null	RAW_SHORT	2026-04-17 23:23:17.262
cmni3p1jv00b3w72d2kcnluqw	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.35145376	-122.10569934	5	0	33.23	327.66	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 23:23:22.267	2026-04-02 23:23:20.235	null	RAW_SHORT	2026-04-17 23:23:22.266
cmni3p5fq00b9w72df1pzy6yg	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.35304318	-122.1073468	5	0	32.43	312.19	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 23:23:27.303	2026-04-02 23:23:27.226	null	RAW_SHORT	2026-04-17 23:23:27.302
cmni3pd5g00bkw72daldxbc3d	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.35416275	-122.10941512	5	0	31.82	297.07	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 23:23:37.3	2026-04-02 23:23:34.223	null	RAW_SHORT	2026-04-17 23:23:37.3
cmni3qbya00d0w72dyhyyfjq8	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.36303768	-122.12160442	5	0	34.35	315.35	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 23:24:22.402	2026-04-02 23:24:20.213	null	RAW_SHORT	2026-04-17 23:24:22.401
cmni3r6wp00eaw72dhokdcc7e	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.36657341	-122.13598643	5	0	32.22	290.39	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 23:25:02.521	2026-04-02 23:25:01.229	null	RAW_SHORT	2026-04-17 23:25:02.52
cmni3rlpb00exw72da4na3aa4	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.36994839	-122.1416339	5	0	34.01	324.14	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 23:25:21.695	2026-04-02 23:25:20.22	null	RAW_SHORT	2026-04-17 23:25:21.695
cmni3s5re00fvw72dzwj9wxco	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.37595557	-122.14739872	5	0	34.41	317.81	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 23:25:47.69	2026-04-02 23:25:45.221	null	RAW_SHORT	2026-04-17 23:25:47.689
cmnia0my103c3708noiwrhe3d	\N	alex@brspark.com	dev_szkcjr	cmni8bpkq02oz708nzfdg04oc	TRANSIT_START	-23.569983	-46.7851655	\N	\N	\N	\N	GPS	\N	\N	UNKNOWN	1.0.0	26.3.1	Simulator iOS	f	f	-3	2026-04-03 02:20:20.905	2026-04-03 02:20:20.168	{"lat": -23.569983, "lng": -46.7851655, "previousState": "DISPATCHED"}	LEGAL	2031-04-03 02:20:20.904
cmnia0my103c4708nq2u0uaat	\N	alex@brspark.com	\N	\N	HEARTBEAT	-23.569983	-46.7851655	5	0	-1	-1	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-03 02:20:20.905	2026-04-03 02:20:19.408	null	RAW_SHORT	2026-04-18 02:20:20.904
cmnjkma3m000prohkqu8cseh1	\N	alex@brspark.com	dev_or2xj4	cmnj3ycod0179hojan64s2qh5	FRAUD_FLAG	-23.56719453129495	-46.7862439702355	\N	\N	\N	\N	GPS	\N	\N	UNKNOWN	1.0.0	26.4	iPhone 17 Pro Max	f	f	-417	2026-04-04 00:04:53.027	2026-04-04 00:04:52.7	{"lat": -23.56719453129495, "lng": -46.7862439702355, "reason": "MOCK_LOCATION", "severity": "HIGH"}	LEGAL	2031-04-04 00:04:53.026
cmnjkma3m000qrohkk8ut78d1	\N	alex@brspark.com	\N	\N	HEARTBEAT	-23.56719453129495	-46.7862439702355	7.928586564459389	791.3092407332191	-1	-1	\N	\N	\N	\N	\N	\N	\N	t	f	\N	2026-04-04 00:04:53.027	2026-04-04 00:04:51.786	null	RAW_SHORT	2026-04-19 00:04:53.026
cmnjkmadl0013rohkvii38kxl	cmnhhqj5c000e3yrjmvwv50er	alex@brspark.com	dev_or2xj4	cmnj3ycod0179hojan64s2qh5	SESSION_OPEN	\N	\N	\N	\N	\N	\N	GPS	\N	\N	UNKNOWN	1.0.0	26.4	iPhone 17 Pro Max	f	f	13	2026-04-04 00:04:53.385	2026-04-04 00:04:53.2	{}	OPERATIONAL	2026-10-01 00:04:53.384
cmnjkojfy008erohk0a95vp68	\N	alex@brspark.com	\N	\N	HEARTBEAT	-23.56719279209403	-46.78624969838481	6.030699648198145	790.6075881195069	-1	-1	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-04 00:06:38.447	2026-04-04 00:06:37.611	null	RAW_SHORT	2026-04-19 00:06:38.446
cmnjkojfy008frohk09h66zzw	\N	alex@brspark.com	\N	\N	HEARTBEAT	-23.56719279209403	-46.78624969838481	6.030699648198145	790.6075881195069	-1	-1	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-04 00:06:38.447	2026-04-04 00:06:37.611	null	RAW_SHORT	2026-04-19 00:06:38.446
cmnjkouy600a3rohkarazz8il	cmnhhqj5c000e3yrjmvwv50er	alex@brspark.com	dev_or2xj4	cmnj1lkhy01n1hw8y4bohk7qw	OS_ACCEPT	\N	\N	\N	\N	\N	\N	GPS	\N	\N	UNKNOWN	1.0.0	26.4	iPhone 17 Pro Max	f	f	9	2026-04-04 00:06:53.358	2026-04-04 00:06:52.123	{"previousState": "DISPATCHED"}	LEGAL	2031-04-04 00:06:53.357
cmnjkouy600a5rohkv6evgnzp	\N	alex@brspark.com	\N	\N	HEARTBEAT	-23.56719278163695	-46.7862497182854	5.547875893260453	790.6080504131318	-1	-1	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-04 00:06:53.358	2026-04-04 00:06:50.828	null	RAW_SHORT	2026-04-19 00:06:53.357
cmni3ph0w00bqw72dl6zbqmd7	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.35486926	-122.11178469	5	0	32.5	287.58	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 23:23:42.32	2026-04-02 23:23:41.229	null	RAW_SHORT	2026-04-17 23:23:42.319
cmni3porh00c1w72dndziq8bx	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.35555758	-122.11420421	5	0	32.28	295.31	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 23:23:52.35	2026-04-02 23:23:48.222	null	RAW_SHORT	2026-04-17 23:23:52.349
cmni3pslu00c7w72d3b6f3ilr	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.35667204	-122.11636489	5	0	32.76	310.43	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 23:23:57.33	2026-04-02 23:23:55.22	null	RAW_SHORT	2026-04-17 23:23:57.33
cmni3q82w00cuw72dhaelo6ea	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.36154377	-122.1202173	5	0	34.65	332.23	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 23:24:17.384	2026-04-02 23:24:14.219	null	RAW_SHORT	2026-04-17 23:24:17.383
cmni3qfvv00d6w72dy5kquwm7	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.36424153	-122.12374717	5	0	32.83	296.72	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 23:24:27.499	2026-04-02 23:24:27.219	null	RAW_SHORT	2026-04-17 23:24:27.497
cmni3scqg00g1w72dzod3anry	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.37732484	-122.14894979	5	0	33.48	317.81	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 23:25:56.729	2026-04-02 23:25:51.218	null	RAW_SHORT	2026-04-17 23:25:56.728
cmni3skfp00gdw72d50ctwl90	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.38048092	-122.15123277	5	0	34.49	342.42	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 23:26:06.709	2026-04-02 23:26:03.219	null	RAW_SHORT	2026-04-17 23:26:06.708
cmnia7mjr03ll708n1pkuguaq	\N	alex@brspark.com	dev_szkcjr	cmni8bpkq02oz708nzfdg04oc	OS_ACCEPT	\N	\N	\N	\N	\N	\N	GPS	\N	\N	UNKNOWN	1.0.0	26.3.1	Simulator iOS	f	f	5	2026-04-03 02:25:46.98	2026-04-03 02:25:43.784	{"previousState": "IN_TRANSIT"}	LEGAL	2031-04-03 02:25:46.978
cmnia7mjr03lm708n2uxm72mx	\N	alex@brspark.com	\N	\N	HEARTBEAT	-23.569983	-46.7851655	5	0	-1	-1	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-03 02:25:46.98	2026-04-03 02:25:43.955	null	RAW_SHORT	2026-04-18 02:25:46.978
cmnjkn8pb004xrohknl549s6f	cmnhhqj5c000e3yrjmvwv50er	alex@brspark.com	dev_or2xj4	cmnj3ycod0179hojan64s2qh5	OS_ACCEPT	\N	\N	\N	\N	\N	\N	GPS	\N	\N	UNKNOWN	1.0.0	26.4	iPhone 17 Pro Max	f	f	17	2026-04-04 00:05:37.871	2026-04-04 00:05:37.737	{"previousState": "DISPATCHED"}	LEGAL	2031-04-04 00:05:37.87
cmnjkn8pb004yrohkg06c1f6a	\N	alex@brspark.com	\N	\N	HEARTBEAT	-23.56719453129495	-46.7862439702355	7.928586564459389	791.3092407332191	-1	-1	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-04 00:05:37.871	2026-04-04 00:05:33.829	null	RAW_SHORT	2026-04-19 00:05:37.87
cmnjkojfp008crohkwwy4xq1m	\N	alex@brspark.com	\N	\N	HEARTBEAT	-23.56719279209403	-46.78624969838481	6.030699648198145	790.6075881195069	-1	-1	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-04 00:06:38.437	2026-04-04 00:06:37.611	null	RAW_SHORT	2026-04-19 00:06:38.436
cmnjkojfp008drohk2oat668m	\N	alex@brspark.com	\N	\N	HEARTBEAT	-23.56719279209403	-46.78624969838481	6.030699648198145	790.6075881195069	-1	-1	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-04 00:06:38.437	2026-04-04 00:06:37.611	null	RAW_SHORT	2026-04-19 00:06:38.436
cmnjkq32m00b1rohkfg0iowt9	cmnhhqj5c000e3yrjmvwv50er	alex@brspark.com	dev_or2xj4	cmnj1lkhy01n1hw8y4bohk7qw	SESSION_OPEN	\N	\N	\N	\N	\N	\N	GPS	\N	\N	UNKNOWN	1.0.0	26.4	iPhone 17 Pro Max	f	f	5	2026-04-04 00:07:50.543	2026-04-04 00:07:47.808	{}	OPERATIONAL	2026-10-01 00:07:50.542
cmni3pwhd00cdw72dg9wjl791	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.35821377	-122.11808519	5	0	33.51	325.9	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 23:24:02.353	2026-04-02 23:24:02.28	null	RAW_SHORT	2026-04-17 23:24:02.352
cmni3q48d00cow72dxw1bnouq	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.35983897	-122.11918616	5	0	34.77	333.98	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 23:24:12.398	2026-04-02 23:24:08.214	null	RAW_SHORT	2026-04-17 23:24:12.397
cmni3qnk800dhw72dwyrdsiuz	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.36483488	-122.12623861	5	0	33.57	278.09	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 23:24:37.448	2026-04-02 23:24:34.219	null	RAW_SHORT	2026-04-17 23:24:37.447
cmni3qrfs00dnw72d6stqtns2	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.36489536	-122.12851823	5	0	33.32	270.35	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 23:24:42.472	2026-04-02 23:24:40.219	null	RAW_SHORT	2026-04-17 23:24:42.47
cmni3renb00elw72dgiipj9w4	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.36743034	-122.13834434	5	0	33.46	300.59	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 23:25:12.551	2026-04-02 23:25:08.217	null	RAW_SHORT	2026-04-17 23:25:12.55
cmni3rq9e00f8w72dr1fu8k2y	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.37142067	-122.14297886	5	0	33.47	324.14	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 23:25:27.602	2026-04-02 23:25:26.219	null	RAW_SHORT	2026-04-17 23:25:27.601
cmni3ry1500fjw72dctuvo7k3	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.37311268	-122.14451887	5	0	33.18	324.14	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 23:25:37.674	2026-04-02 23:25:33.223	null	RAW_SHORT	2026-04-17 23:25:37.673
cmni3sgkp00g7w72d21qfnw31	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.3787954	-122.15030297	5	0	33.74	329.41	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 23:26:01.705	2026-04-02 23:25:57.212	null	RAW_SHORT	2026-04-17 23:26:01.704
cmni3soah00gjw72dnj5zag7o	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.38232167	-122.15171758	5	0	35	350.16	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 23:26:11.705	2026-04-02 23:26:09.226	null	RAW_SHORT	2026-04-17 23:26:11.704
cmni3sw0j00gvw72dci2m56zt	\N	alex@brspark.com	dev_szkcjr	cmni0ykni034tk84w4shu4k67	OS_ACCEPT	\N	\N	\N	\N	\N	\N	GPS	\N	\N	UNKNOWN	1.0.0	26.3.1	Simulator iOS	f	f	7	2026-04-02 23:26:21.716	2026-04-02 23:26:17.206	{"previousState": "IN_TRANSIT"}	LEGAL	2031-04-02 23:26:21.715
cmni3sw0k00gww72db7s6q86l	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.3847595	-122.15231454	5	0	34.06	344.18	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 23:26:21.716	2026-04-02 23:26:17.45	null	RAW_SHORT	2026-04-17 23:26:21.715
cmnibabwj00l9za8gsmg0k9kn	\N	alex@brspark.com	dev_szkcjr	cmni8bpkq02oz708nzfdg04oc	OS_ACCEPT	\N	\N	\N	\N	\N	\N	GPS	\N	\N	UNKNOWN	1.0.0	26.3.1	Simulator iOS	f	f	7	2026-04-03 02:55:52.77	2026-04-03 02:55:51.353	{"previousState": "IDLE"}	LEGAL	2031-04-03 02:55:52.769
cmnibabwj00laza8gfrdm2i1k	\N	alex@brspark.com	\N	\N	HEARTBEAT	-23.569983	-46.7851655	5	0	-1	-1	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-03 02:55:52.77	2026-04-03 02:55:52.137	null	RAW_SHORT	2026-04-18 02:55:52.769
cmnjkn8pa004vrohk31wpdkc9	cmnhhqj5c000e3yrjmvwv50er	alex@brspark.com	dev_or2xj4	cmnj3ycod0179hojan64s2qh5	OS_ACCEPT	\N	\N	\N	\N	\N	\N	GPS	\N	\N	UNKNOWN	1.0.0	26.4	iPhone 17 Pro Max	f	f	17	2026-04-04 00:05:37.871	2026-04-04 00:05:37.737	{"previousState": "DISPATCHED"}	LEGAL	2031-04-04 00:05:37.87
cmnjkn8pb004wrohk2h3s2m29	\N	alex@brspark.com	\N	\N	HEARTBEAT	-23.56719453129495	-46.7862439702355	7.928586564459389	791.3092407332191	-1	-1	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-04 00:05:37.871	2026-04-04 00:05:33.829	null	RAW_SHORT	2026-04-19 00:05:37.87
cmnjkojfy008grohkgs4ar46j	\N	alex@brspark.com	\N	\N	HEARTBEAT	-23.56719279209403	-46.78624969838481	6.030699648198145	790.6075881195069	-1	-1	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-04 00:06:38.447	2026-04-04 00:06:37.611	null	RAW_SHORT	2026-04-19 00:06:38.446
cmnjkojfy008hrohkkfdxjikv	\N	alex@brspark.com	\N	\N	HEARTBEAT	-23.56719279209403	-46.78624969838481	6.030699648198145	790.6075881195069	-1	-1	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-04 00:06:38.447	2026-04-04 00:06:37.611	null	RAW_SHORT	2026-04-19 00:06:38.446
cmni3qvak00dtw72d7hijg00z	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.36513495	-122.13112023	5	0	33.14	285.82	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 23:24:47.468	2026-04-02 23:24:47.216	null	RAW_SHORT	2026-04-17 23:24:47.467
cmni3r31a00e4w72dd72i6wol	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.3658664	-122.13358057	5	0	33.38	290.74	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 23:24:57.502	2026-04-02 23:24:54.222	null	RAW_SHORT	2026-04-17 23:24:57.501
cmni3s1w000fpw72dyez1d8sp	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.37457281	-122.14588663	5	0	33.98	321.33	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 23:25:42.672	2026-04-02 23:25:39.216	null	RAW_SHORT	2026-04-17 23:25:42.671
cmni3ss5m00gpw72daldrlju3	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.38417047	-122.1521117	5	0	34.13	349.45	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 23:26:16.714	2026-04-02 23:26:15.271	null	RAW_SHORT	2026-04-17 23:26:16.713
cmnibg0ef00t0za8g2u7f45n8	\N	alex@brspark.com	dev_szkcjr	cmni8bpkq02oz708nzfdg04oc	OS_ACCEPT	\N	\N	\N	\N	\N	\N	GPS	\N	\N	UNKNOWN	1.0.0	26.3.1	Simulator iOS	f	f	8	2026-04-03 03:00:17.8	2026-04-03 03:00:14.502	{"previousState": "DISPATCHED"}	LEGAL	2031-04-03 03:00:17.799
cmnibg0db00syza8gbbta9fd6	\N	alex@brspark.com	dev_szkcjr	cmni8bpkq02oz708nzfdg04oc	OS_ACCEPT	\N	\N	\N	\N	\N	\N	GPS	\N	\N	UNKNOWN	1.0.0	26.3.1	Simulator iOS	f	f	8	2026-04-03 03:00:17.755	2026-04-03 03:00:14.502	{"previousState": "DISPATCHED"}	LEGAL	2031-04-03 03:00:17.75
cmnibg0db00szza8gbowbg26e	\N	alex@brspark.com	\N	\N	HEARTBEAT	-23.569983	-46.7851655	5	0	-1	-1	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-03 03:00:17.755	2026-04-03 03:00:14.249	null	RAW_SHORT	2026-04-18 03:00:17.75
cmnibg0ef00t1za8glxgz3xkw	\N	alex@brspark.com	\N	\N	HEARTBEAT	-23.569983	-46.7851655	5	0	-1	-1	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-03 03:00:17.8	2026-04-03 03:00:14.249	null	RAW_SHORT	2026-04-18 03:00:17.799
cmnibg8me00tpza8gdwaer6v7	\N	alex@brspark.com	dev_szkcjr	cmni8b8rv02ox708n5s952fjt	OS_ACCEPT	\N	\N	\N	\N	\N	\N	GPS	\N	\N	UNKNOWN	1.0.0	26.3.1	Simulator iOS	f	f	-2	2026-04-03 03:00:28.454	2026-04-03 03:00:24.868	{"previousState": "IDLE"}	LEGAL	2031-04-03 03:00:28.449
cmnibg8me00tqza8g498rsulk	\N	alex@brspark.com	\N	\N	HEARTBEAT	-23.569983	-46.7851655	5	0	-1	-1	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-03 03:00:28.454	2026-04-03 03:00:24.935	null	RAW_SHORT	2026-04-18 03:00:28.449
cmnibg8me00trza8g2dsk9z86	\N	alex@brspark.com	dev_szkcjr	cmni8b8rv02ox708n5s952fjt	TRANSIT_START	-23.569983	-46.7851655	\N	\N	\N	\N	GPS	\N	\N	UNKNOWN	1.0.0	26.3.1	Simulator iOS	f	f	0	2026-04-03 03:00:28.454	2026-04-03 03:00:26.852	{"lat": -23.569983, "lng": -46.7851655, "previousState": "DISPATCHED"}	LEGAL	2031-04-03 03:00:28.449
cmnibg8me00tsza8g6kqu85fp	\N	alex@brspark.com	\N	\N	HEARTBEAT	-23.569983	-46.7851655	5	0	-1	-1	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-03 03:00:28.454	2026-04-03 03:00:26.814	null	RAW_SHORT	2026-04-18 03:00:28.449
cmnjl18vf00ncrohkusnt0ozq	cmnhhqj5c000e3yrjmvwv50er	alex@brspark.com	dev_or2xj4	\N	SESSION_OPEN	\N	\N	\N	\N	\N	\N	GPS	\N	\N	UNKNOWN	1.0.0	26.4	iPhone 17 Pro Max	f	f	-10	2026-04-04 00:16:31.275	2026-04-04 00:16:26.785	{}	OPERATIONAL	2026-10-01 00:16:31.274
cmnjl18vs00ndrohkh2vl9mv5	cmnhhqj5c000e3yrjmvwv50er	alex@brspark.com	dev_or2xj4	\N	SESSION_OPEN	\N	\N	\N	\N	\N	\N	GPS	\N	\N	UNKNOWN	1.0.0	26.4	iPhone 17 Pro Max	f	f	-10	2026-04-04 00:16:31.289	2026-04-04 00:16:26.785	{}	OPERATIONAL	2026-10-01 00:16:31.288
cmni3riiq00erw72dish7pjr1	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.36854278	-122.1401674	5	0	34.22	312.89	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 23:25:17.571	2026-04-02 23:25:14.219	null	RAW_SHORT	2026-04-17 23:25:17.57
cmni4s0q10000kaef1ggv5ojv	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.38723661	-122.15426073	5	0	31.79	313.24	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 23:53:40.777	2026-04-02 23:26:27.212	null	RAW_SHORT	2026-04-17 23:53:40.77
cmni4s0q10001kaefl8lfh0rk	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.38852302	-122.15740629	5	0	32.12	283.36	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 23:53:40.777	2026-04-02 23:26:37.227	null	RAW_SHORT	2026-04-17 23:53:40.77
cmni4s0q10002kaefa4ttz1if	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.38907593	-122.16102912	5	0	32.47	282.66	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 23:53:40.777	2026-04-02 23:26:47.228	null	RAW_SHORT	2026-04-17 23:53:40.77
cmni4s0q10003kaefw7h3szai	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.39029043	-122.16432732	5	0	32.51	304.8	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 23:53:40.777	2026-04-02 23:26:57.22	null	RAW_SHORT	2026-04-17 23:53:40.77
cmni4s0q20004kaefh7ej831z	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.3917638	-122.16719669	5	0	33.76	292.85	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 23:53:40.777	2026-04-02 23:27:06.226	null	RAW_SHORT	2026-04-17 23:53:40.77
cmni4s0q20005kaef4e7ka3i5	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.39228038	-122.17082706	5	0	32.92	274.92	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 23:53:40.777	2026-04-02 23:27:16.226	null	RAW_SHORT	2026-04-17 23:53:40.77
cmni4s0q20006kaeftc5nekz2	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.39299238	-122.17434528	5	0	32.41	296.02	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 23:53:40.777	2026-04-02 23:27:26.217	null	RAW_SHORT	2026-04-17 23:53:40.77
cmni4s0q20007kaefhvvcqqoo	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.39485119	-122.17713419	5	0	32.6	320.62	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 23:53:40.777	2026-04-02 23:27:36.224	null	RAW_SHORT	2026-04-17 23:53:40.77
cmni4s0q20008kaefoqcryuvf	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.39723081	-122.17945213	5	0	34.62	322.03	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 23:53:40.777	2026-04-02 23:27:46.223	null	RAW_SHORT	2026-04-17 23:53:40.77
cmni4s0q20009kaef3ey1nam6	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.39946853	-122.181674	5	0	35.58	322.38	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 23:53:40.777	2026-04-02 23:27:55.244	null	RAW_SHORT	2026-04-17 23:53:40.77
cmni4s0q2000akaef9qzsjonf	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.40169564	-122.1838916	5	0	34.8	320.98	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 23:53:40.777	2026-04-02 23:28:04.22	null	RAW_SHORT	2026-04-17 23:53:40.77
cmni4s0q2000bkaefpc5fb8zg	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.40384703	-122.1860652	5	0	34.08	321.68	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 23:53:40.777	2026-04-02 23:28:13.22	null	RAW_SHORT	2026-04-17 23:53:40.77
cmni4s0q2000ckaefdhlnxiiq	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.40595558	-122.18821616	5	0	33.07	320.98	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 23:53:40.777	2026-04-02 23:28:22.218	null	RAW_SHORT	2026-04-17 23:53:40.77
cmni4s0q2000dkaefxa4kxa8a	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.40792864	-122.19096048	5	0	32.4	302.34	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 23:53:40.777	2026-04-02 23:28:32.217	null	RAW_SHORT	2026-04-17 23:53:40.77
cmni4s0q2000ekaefppcbkzm9	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.40913001	-122.19434853	5	0	33.41	291.8	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 23:53:40.777	2026-04-02 23:28:42.224	null	RAW_SHORT	2026-04-17 23:53:40.77
cmni4s0q2000fkaef6jwjk0ie	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.41013974	-122.1975256	5	0	33.93	291.8	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 23:53:40.777	2026-04-02 23:28:51.222	null	RAW_SHORT	2026-04-17 23:53:40.77
cmni4s0q2000gkaefqmal7bvw	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.4111682	-122.20078524	5	0	34.82	291.8	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 23:53:40.777	2026-04-02 23:29:00.224	null	RAW_SHORT	2026-04-17 23:53:40.77
cmni4s0q2000hkaefvkcw9fh0	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.41221975	-122.20406123	5	0	34.82	291.45	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 23:53:40.777	2026-04-02 23:29:09.223	null	RAW_SHORT	2026-04-17 23:53:40.77
cmni4s0q2000ikaefnxy63o7x	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.41331028	-122.20726311	5	0	34.17	298.48	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 23:53:40.777	2026-04-02 23:29:18.217	null	RAW_SHORT	2026-04-17 23:53:40.77
cmni4s0q2000jkaefxrb4bioq	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.41511369	-122.2099019	5	0	34.21	320.98	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 23:53:40.777	2026-04-02 23:29:27.241	null	RAW_SHORT	2026-04-17 23:53:40.77
cmni4s0q2000kkaefsukayjy2	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.41715007	-122.21215672	5	0	33.26	310.08	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 23:53:40.777	2026-04-02 23:29:36.22	null	RAW_SHORT	2026-04-17 23:53:40.77
cmni4s0q3000lkaef6wt8ioh2	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.41849109	-122.21541158	5	0	32.22	285.47	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 23:53:40.777	2026-04-02 23:29:46.234	null	RAW_SHORT	2026-04-17 23:53:40.77
cmni4s0q3000mkaef93roty6j	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.41905687	-122.21907137	5	0	33.98	280.9	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 23:53:40.777	2026-04-02 23:29:56.22	null	RAW_SHORT	2026-04-17 23:53:40.77
cmni4s0q3000nkaefll5746ps	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.42003034	-122.22234886	5	0	34.85	301.64	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 23:53:40.777	2026-04-02 23:30:05.231	null	RAW_SHORT	2026-04-17 23:53:40.77
cmni4s0q3000okaef2emy25w9	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.42180622	-122.225047	5	0	34.15	310.78	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 23:53:40.777	2026-04-02 23:30:14.219	null	RAW_SHORT	2026-04-17 23:53:40.77
cmni4s0q3000pkaefwbtpuxsk	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.42364424	-122.22769744	5	0	34.88	310.78	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 23:53:40.777	2026-04-02 23:30:23.226	null	RAW_SHORT	2026-04-17 23:53:40.77
cmni4s0q3000qkaefmmcjxz9f	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.42556261	-122.23036783	5	0	35.73	315.35	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 23:53:40.777	2026-04-02 23:30:32.227	null	RAW_SHORT	2026-04-17 23:53:40.77
cmni4s0q3000rkaefju50xe71	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.42760419	-122.23287838	5	0	34.9	314.65	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 23:53:40.777	2026-04-02 23:30:41.227	null	RAW_SHORT	2026-04-17 23:53:40.77
cmni4s0q3000skaefnbjlqzqb	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.42942843	-122.23549663	5	0	33.3	310.43	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 23:53:40.777	2026-04-02 23:30:50.234	null	RAW_SHORT	2026-04-17 23:53:40.77
cmni4s0q3000tkaefvemtywdr	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.4313864	-122.23829728	5	0	33.61	313.24	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 23:53:40.777	2026-04-02 23:31:00.234	null	RAW_SHORT	2026-04-17 23:53:40.77
cmni4s0q3000ukaefqxr40t7k	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.4333289	-122.24069492	5	0	33.29	316.41	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 23:53:40.777	2026-04-02 23:31:09.225	null	RAW_SHORT	2026-04-17 23:53:40.77
cmni4s0q3000vkaefmjr1jz27	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.4354937	-122.24325056	5	0	33.08	316.76	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 23:53:40.777	2026-04-02 23:31:19.682	null	RAW_SHORT	2026-04-17 23:53:40.77
cmni4s0q3000wkaefq5ea74gi	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.43745284	-122.24560906	5	0	33.53	316.41	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 23:53:40.777	2026-04-02 23:31:28.228	null	RAW_SHORT	2026-04-17 23:53:40.77
cmni4s0q3000xkaefht5ji0n3	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.43958193	-122.24823553	5	0	32.54	314.3	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 23:53:40.777	2026-04-02 23:31:38.23	null	RAW_SHORT	2026-04-17 23:53:40.77
cmni4s0q3000ykaefmqy4wq6w	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.4416554	-122.25091933	5	0	33.04	313.59	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 23:53:40.777	2026-04-02 23:31:48.225	null	RAW_SHORT	2026-04-17 23:53:40.77
cmni4s0q3000zkaef890erfam	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.44339993	-122.25391846	5	0	32.76	296.72	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 23:53:40.777	2026-04-02 23:31:58.225	null	RAW_SHORT	2026-04-17 23:53:40.77
cmni4s0q30010kaef71a0cqvv	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.44419763	-122.25743668	5	0	32.3	276.68	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 23:53:40.777	2026-04-02 23:32:08.232	null	RAW_SHORT	2026-04-17 23:53:40.77
cmni4s0q30011kaefuhbu8ovm	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.44407878	-122.26109077	5	0	32.65	264.38	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 23:53:40.777	2026-04-02 23:32:18.227	null	RAW_SHORT	2026-04-17 23:53:40.77
cmni4s0q30012kaef2pzx75ku	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.44380955	-122.26471217	5	0	32.07	268.59	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 23:53:40.777	2026-04-02 23:32:28.23	null	RAW_SHORT	2026-04-17 23:53:40.77
cmni4s0q30013kaef1cm60k39	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.44423405	-122.26830767	5	0	32.37	287.23	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 23:53:40.777	2026-04-02 23:32:38.232	null	RAW_SHORT	2026-04-17 23:53:40.77
cmni4s0q30014kaefsvej8773	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.44559578	-122.27164133	5	0	33.66	304.8	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 23:53:40.777	2026-04-02 23:32:48.233	null	RAW_SHORT	2026-04-17 23:53:40.77
cmni4s0q30015kaefxj7ckyqp	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.44742701	-122.27433854	5	0	35.12	311.48	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 23:53:40.777	2026-04-02 23:32:57.232	null	RAW_SHORT	2026-04-17 23:53:40.77
cmni4s0q30016kaefebcw79jc	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.44931173	-122.27705394	5	0	35.27	310.43	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 23:53:40.777	2026-04-02 23:33:06.23	null	RAW_SHORT	2026-04-17 23:53:40.77
cmni4s0q30017kaefa8ibn5m3	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.45113567	-122.27979667	5	0	34.86	309.73	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 23:53:40.777	2026-04-02 23:33:15.227	null	RAW_SHORT	2026-04-17 23:53:40.77
cmni4s0q30018kaefi9d9vr2t	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.45291645	-122.28250536	5	0	34.13	309.38	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 23:53:40.777	2026-04-02 23:33:24.227	null	RAW_SHORT	2026-04-17 23:53:40.77
cmni4s0q30019kaef677p9lf1	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.4546849	-122.28517332	5	0	34.25	309.38	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 23:53:40.777	2026-04-02 23:33:33.236	null	RAW_SHORT	2026-04-17 23:53:40.77
cmni4s0q3001akaeflkqg4cvd	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.45649921	-122.28784438	5	0	34.59	315.7	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 23:53:40.777	2026-04-02 23:33:42.23	null	RAW_SHORT	2026-04-17 23:53:40.77
cmni4s0q3001bkaefssyp21z9	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.45883663	-122.2898065	5	0	34.4	335.74	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 23:53:40.777	2026-04-02 23:33:51.234	null	RAW_SHORT	2026-04-17 23:53:40.77
cmni4s0q3001ckaef7hbmylq0	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.46150337	-122.29066665	5	0	33.68	353.32	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 23:53:40.777	2026-04-02 23:34:00.23	null	RAW_SHORT	2026-04-17 23:53:40.77
cmni4s0q3001dkaefj7v251xb	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.46449927	-122.29080537	5	0	33.1	355.43	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 23:53:40.777	2026-04-02 23:34:10.225	null	RAW_SHORT	2026-04-17 23:53:40.77
cmni4s0q3001ekaefcw19rxqr	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.46741706	-122.29164222	5	0	33.44	339.61	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 23:53:40.777	2026-04-02 23:34:20.233	null	RAW_SHORT	2026-04-17 23:53:40.77
cmni4s0q3001fkaef8rlipt0k	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.46980661	-122.29324794	5	0	33.47	324.84	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 23:53:40.777	2026-04-02 23:34:29.227	null	RAW_SHORT	2026-04-17 23:53:40.77
cmni4s0q3001gkaefumzbmhz4	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.47193243	-122.29536731	5	0	33.52	321.33	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 23:53:40.777	2026-04-02 23:34:38.225	null	RAW_SHORT	2026-04-17 23:53:40.77
cmni4s0q3001hkaefw3cx1kvu	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.47407652	-122.29748533	5	0	33.71	324.84	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 23:53:40.777	2026-04-02 23:34:47.229	null	RAW_SHORT	2026-04-17 23:53:40.77
cmni4s0q3001ikaefhyrp4iie	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.47654113	-122.29890078	5	0	33.88	343.83	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 23:53:40.777	2026-04-02 23:34:56.243	null	RAW_SHORT	2026-04-17 23:53:40.77
cmni4s0q3001jkaefco3bbs5s	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.47928265	-122.29924209	5	0	33.95	3.52	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 23:53:40.777	2026-04-02 23:35:05.227	null	RAW_SHORT	2026-04-17 23:53:40.77
cmni4s0q4001kkaef2z06nwjj	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.48204679	-122.298808	5	0	34.51	7.03	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 23:53:40.777	2026-04-02 23:35:14.224	null	RAW_SHORT	2026-04-17 23:53:40.77
cmni4s0q4001lkaefzv5xbe9j	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.48475481	-122.29834808	5	0	32.93	7.38	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 23:53:40.777	2026-04-02 23:35:23.23	null	RAW_SHORT	2026-04-17 23:53:40.77
cmni4s0q4001mkaefcbe2drvb	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.48769154	-122.29820324	5	0	33.23	353.32	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 23:53:40.777	2026-04-02 23:35:33.227	null	RAW_SHORT	2026-04-17 23:53:40.77
cmni4s0q4001nkaefobja48lc	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.49056217	-122.29928702	5	0	32.99	333.98	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 23:53:40.777	2026-04-02 23:35:43.233	null	RAW_SHORT	2026-04-17 23:53:40.77
cmni4s0q4001okaefvv49no0c	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.49291363	-122.30150194	5	0	32.67	313.95	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 23:53:40.777	2026-04-02 23:35:53.247	null	RAW_SHORT	2026-04-17 23:53:40.77
cmni4s0q4001pkaef70rpttj5	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.49453457	-122.30464079	5	0	33.45	293.2	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 23:53:40.777	2026-04-02 23:36:03.224	null	RAW_SHORT	2026-04-17 23:53:40.77
cmni4s0q4001qkaefplsx05o1	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.49543424	-122.30818156	5	0	32.45	286.88	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 23:53:40.777	2026-04-02 23:36:13.227	null	RAW_SHORT	2026-04-17 23:53:40.77
cmni4s0q4001rkaefhdj3a83k	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.4963855	-122.3116028	5	0	32.65	294.26	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 23:53:40.777	2026-04-02 23:36:23.225	null	RAW_SHORT	2026-04-17 23:53:40.77
cmni4s0q4001skaef0kthfr0y	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.49791545	-122.31482925	5	0	34.11	305.16	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 23:53:40.777	2026-04-02 23:36:33.247	null	RAW_SHORT	2026-04-17 23:53:40.77
cmni4s0q4001tkaefea36ww5b	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.49945868	-122.31765789	5	0	33.58	301.29	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 23:53:40.777	2026-04-02 23:36:42.224	null	RAW_SHORT	2026-04-17 23:53:40.77
cmni4s0q4001ukaefyo3ivmx9	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.50055478	-122.32105281	5	0	31.39	283.71	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 23:53:40.777	2026-04-02 23:36:52.227	null	RAW_SHORT	2026-04-17 23:53:40.77
cmni4s0q4001vkaef3t4sti0c	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.50087108	-122.32460448	5	0	32.05	272.81	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 23:53:40.777	2026-04-02 23:37:02.23	null	RAW_SHORT	2026-04-17 23:53:40.77
cmni4s0q4001wkaef0ogodz4d	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.50133564	-122.32819947	5	0	32.41	287.58	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 23:53:40.777	2026-04-02 23:37:12.232	null	RAW_SHORT	2026-04-17 23:53:40.77
cmni4s0q4001xkaefkfrl9o3y	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.50272247	-122.33142131	5	0	33.04	307.27	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 23:53:40.777	2026-04-02 23:37:22.235	null	RAW_SHORT	2026-04-17 23:53:40.77
cmni4s0q4001ykaefracd1w6a	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.50438925	-122.33410746	5	0	33.69	307.27	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 23:53:40.777	2026-04-02 23:37:31.232	null	RAW_SHORT	2026-04-17 23:53:40.77
cmni4s0q4001zkaef9qnxxow0	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.50606869	-122.33688933	5	0	34.88	307.62	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 23:53:40.777	2026-04-02 23:37:40.22	null	RAW_SHORT	2026-04-17 23:53:40.77
cmni4s0q40020kaef13qnsj0u	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.50780014	-122.33971445	5	0	35.12	307.97	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 23:53:40.777	2026-04-02 23:37:49.232	null	RAW_SHORT	2026-04-17 23:53:40.77
cmni4s0q40021kaefgd5n6lw4	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.50948943	-122.34244552	5	0	33.34	309.73	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 23:53:40.777	2026-04-02 23:37:58.224	null	RAW_SHORT	2026-04-17 23:53:40.77
cmni4s0q40022kaef1ie5r0gs	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.51158508	-122.3451284	5	0	33.63	317.11	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 23:53:40.777	2026-04-02 23:38:08.23	null	RAW_SHORT	2026-04-17 23:53:40.77
cmni4s0q40023kaefnbcx3i61	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.51359988	-122.34743577	5	0	33.46	317.46	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 23:53:40.777	2026-04-02 23:38:17.225	null	RAW_SHORT	2026-04-17 23:53:40.77
cmni4s0q40024kaef66oz6g5o	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.51579153	-122.3499475	5	0	32.41	317.81	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 23:53:40.777	2026-04-02 23:38:27.233	null	RAW_SHORT	2026-04-17 23:53:40.77
cmni4s0q40025kaefwlawhkf8	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.51797837	-122.35239962	5	0	32.96	320.98	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 23:53:40.777	2026-04-02 23:38:37.231	null	RAW_SHORT	2026-04-17 23:53:40.77
cmni4s0q50026kaefcszhqqte	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.5202453	-122.35426233	5	0	33.74	332.23	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 23:53:40.777	2026-04-02 23:38:46.232	null	RAW_SHORT	2026-04-17 23:53:40.77
cmni4s0q50027kaef4qbhht4f	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.52299544	-122.35580008	5	0	33.29	336.09	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 23:53:40.777	2026-04-02 23:38:56.224	null	RAW_SHORT	2026-04-17 23:53:40.77
cmni4s0q50028kaefun5v6yy0	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.52552611	-122.35781861	5	0	34.13	324.49	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 23:53:40.777	2026-04-02 23:39:06.223	null	RAW_SHORT	2026-04-17 23:53:40.77
cmni4s0q50029kaef0oern92g	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.52800506	-122.35949985	5	0	34.9	341.02	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 23:53:40.777	2026-04-02 23:39:15.247	null	RAW_SHORT	2026-04-17 23:53:40.77
cmni4s0q5002akaefqqeooe5b	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.53068496	-122.36063467	5	0	34.77	341.37	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 23:53:40.777	2026-04-02 23:39:24.224	null	RAW_SHORT	2026-04-17 23:53:40.77
cmni4s0q5002bkaef5qw4eww4	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.53334395	-122.36177327	5	0	34.44	341.37	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 23:53:40.777	2026-04-02 23:39:33.23	null	RAW_SHORT	2026-04-17 23:53:40.77
cmni4s0q5002ckaefnrm00a8l	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.53591623	-122.36300097	5	0	33.5	336.45	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 23:53:40.777	2026-04-02 23:39:42.227	null	RAW_SHORT	2026-04-17 23:53:40.77
cmni4s0q5002dkaefhxvhng6s	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.53860477	-122.36458146	5	0	32.83	334.34	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 23:53:40.777	2026-04-02 23:39:52.233	null	RAW_SHORT	2026-04-17 23:53:40.77
cmni4s0q5002ekaefw7oalibq	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.54123564	-122.36620294	5	0	32.44	331.17	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 23:53:40.777	2026-04-02 23:40:02.227	null	RAW_SHORT	2026-04-17 23:53:40.77
cmni4s0q5002fkaefc2evsa7v	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.54365964	-122.36820328	5	0	32.86	320.98	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 23:53:40.777	2026-04-02 23:40:12.233	null	RAW_SHORT	2026-04-17 23:53:40.77
cmni4s0q5002gkaef1ll95vhm	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.54598206	-122.37059682	5	0	33.29	320.62	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 23:53:40.777	2026-04-02 23:40:22.229	null	RAW_SHORT	2026-04-17 23:53:40.77
cmni4s0q5002hkaefltfzb6q5	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.54827568	-122.3729751	5	0	32.68	320.27	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 23:53:40.777	2026-04-02 23:40:32.229	null	RAW_SHORT	2026-04-17 23:53:40.77
cmni4s0q5002ikaef329t2w36	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.55055158	-122.37533284	5	0	33.27	321.33	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 23:53:40.777	2026-04-02 23:40:42.233	null	RAW_SHORT	2026-04-17 23:53:40.77
cmni4s0q5002jkaefarcin7cr	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.5528237	-122.37738054	5	0	35.82	328.36	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 23:53:40.777	2026-04-02 23:40:51.235	null	RAW_SHORT	2026-04-17 23:53:40.77
cmni4s0q5002kkaefmojr96g5	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.55541199	-122.37918458	5	0	36.43	332.23	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 23:53:40.777	2026-04-02 23:41:00.231	null	RAW_SHORT	2026-04-17 23:53:40.77
cmni4s0q5002lkaef505b2j9x	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.55792263	-122.38086842	5	0	33.86	330.82	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 23:53:40.777	2026-04-02 23:41:09.238	null	RAW_SHORT	2026-04-17 23:53:40.77
cmni4s0q5002mkaefompavnel	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.56018092	-122.38291134	5	0	35.39	321.33	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 23:53:40.777	2026-04-02 23:41:18.233	null	RAW_SHORT	2026-04-17 23:53:40.77
cmni4s0q5002nkaefshnf10bq	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.56242844	-122.38515208	5	0	34.55	321.33	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 23:53:40.777	2026-04-02 23:41:27.234	null	RAW_SHORT	2026-04-17 23:53:40.77
cmni4s0q5002okaefpt15i171	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.56457886	-122.387311	5	0	33.15	320.27	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 23:53:40.777	2026-04-02 23:41:36.232	null	RAW_SHORT	2026-04-17 23:53:40.77
cmni4s0q6002pkaefbdgt0lym	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.5662684	-122.39029697	5	0	32.91	292.85	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 23:53:40.777	2026-04-02 23:41:46.233	null	RAW_SHORT	2026-04-17 23:53:40.77
cmni4s0q6002qkaefks1vcvc5	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.56749438	-122.39332946	5	0	33.82	306.56	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 23:53:40.777	2026-04-02 23:41:55.234	null	RAW_SHORT	2026-04-17 23:53:40.77
cmni4s0q6002rkaef07z1ezra	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.56950528	-122.39562543	5	0	33.97	323.09	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 23:53:40.777	2026-04-02 23:42:04.224	null	RAW_SHORT	2026-04-17 23:53:40.77
cmni4s0rp002skaefu1mkn2dx	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.57168001	-122.39767439	5	0	33.69	323.09	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 23:53:40.837	2026-04-02 23:42:13.237	null	RAW_SHORT	2026-04-17 23:53:40.834
cmni4s0rp002tkaefz9ygmcut	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.57386932	-122.39972142	5	0	33.45	327.3	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 23:53:40.837	2026-04-02 23:42:22.231	null	RAW_SHORT	2026-04-17 23:53:40.834
cmni4s0rp002ukaefp8i2poi7	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.57643435	-122.40106956	5	0	34.61	341.72	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 23:53:40.837	2026-04-02 23:42:31.229	null	RAW_SHORT	2026-04-17 23:53:40.834
cmni4s0rp002vkaeftbzfmzad	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.57901078	-122.4022173	5	0	32.83	337.85	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 23:53:40.837	2026-04-02 23:42:40.234	null	RAW_SHORT	2026-04-17 23:53:40.834
cmni4s0rp002wkaefn29i6m4l	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.58156135	-122.40405955	5	0	32.87	328.01	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 23:53:40.837	2026-04-02 23:42:50.227	null	RAW_SHORT	2026-04-17 23:53:40.834
cmni4s0rp002xkaefv8ec8f5t	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.58387392	-122.40592478	5	0	33.91	324.84	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 23:53:40.837	2026-04-02 23:42:59.232	null	RAW_SHORT	2026-04-17 23:53:40.834
cmni4s0rp002ykaef88b19try	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.58587003	-122.40829367	5	0	34.37	311.84	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 23:53:40.837	2026-04-02 23:43:08.227	null	RAW_SHORT	2026-04-17 23:53:40.834
cmni4s0rp002zkaefkmwocic1	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.58774183	-122.41088075	5	0	34.22	317.46	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 23:53:40.837	2026-04-02 23:43:17.233	null	RAW_SHORT	2026-04-17 23:53:40.834
cmni4s0rp0030kaefe0g7r2hw	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.58991962	-122.41305694	5	0	34.09	322.03	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 23:53:40.837	2026-04-02 23:43:26.224	null	RAW_SHORT	2026-04-17 23:53:40.834
cmni4s0rp0031kaefybpb29cf	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.59211048	-122.41521352	5	0	34.35	321.68	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 23:53:40.837	2026-04-02 23:43:35.233	null	RAW_SHORT	2026-04-17 23:53:40.834
cmni4s0rp0032kaefarqnq081	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.59428449	-122.41735996	5	0	33.8	322.03	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 23:53:40.837	2026-04-02 23:43:44.244	null	RAW_SHORT	2026-04-17 23:53:40.834
cmni4s0rp0033kaefpefyk1n0	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.59641538	-122.41948988	5	0	33.23	319.92	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 23:53:40.837	2026-04-02 23:43:53.234	null	RAW_SHORT	2026-04-17 23:53:40.834
cmni4s0rp0034kaefhc4k437t	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.59838496	-122.42187504	5	0	33.65	315.7	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 23:53:40.837	2026-04-02 23:44:02.231	null	RAW_SHORT	2026-04-17 23:53:40.834
cmni4s0rp0035kaefq99u7vnp	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.60033635	-122.42425684	5	0	33.66	316.05	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 23:53:40.837	2026-04-02 23:44:11.225	null	RAW_SHORT	2026-04-17 23:53:40.834
cmni4s0rp0036kaef64rqsi0g	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.60240224	-122.4265399	5	0	33.79	325.9	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 23:53:40.837	2026-04-02 23:44:20.243	null	RAW_SHORT	2026-04-17 23:53:40.834
cmni4s0rp0037kaef2l3wul36	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.60520008	-122.42789551	5	0	33.24	348.75	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 23:53:40.837	2026-04-02 23:44:30.238	null	RAW_SHORT	2026-04-17 23:53:40.834
cmni4s0rp0038kaef78wr6iqg	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.60813618	-122.42777573	5	0	33.02	10.55	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 23:53:40.837	2026-04-02 23:44:40.244	null	RAW_SHORT	2026-04-17 23:53:40.834
cmni4s0rp0039kaefu16j83oq	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.61097345	-122.42659053	5	0	33.43	24.61	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 23:53:40.837	2026-04-02 23:44:50.241	null	RAW_SHORT	2026-04-17 23:53:40.834
cmni4s0rq003akaefl5c58jpo	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.61359414	-122.42477627	5	0	32.88	26.72	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 23:53:40.837	2026-04-02 23:45:00.235	null	RAW_SHORT	2026-04-17 23:53:40.834
cmni4s0rq003bkaef5uz14hkt	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.61652164	-122.42409633	5	0	33.36	358.24	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 23:53:40.837	2026-04-02 23:45:10.242	null	RAW_SHORT	2026-04-17 23:53:40.834
cmni4s0rq003ckaefggzv2aq6	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.61913529	-122.42497542	5	0	34.15	333.98	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 23:53:40.837	2026-04-02 23:45:19.231	null	RAW_SHORT	2026-04-17 23:53:40.834
cmni4s0rq003dkaefg3sti8qx	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.62166536	-122.42661417	5	0	35.4	332.93	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 23:53:40.837	2026-04-02 23:45:28.232	null	RAW_SHORT	2026-04-17 23:53:40.834
cmni4s0rq003ekaefihz4gqku	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.62416933	-122.4282281	5	0	34.23	332.93	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 23:53:40.837	2026-04-02 23:45:37.232	null	RAW_SHORT	2026-04-17 23:53:40.834
cmni4s0rq003fkaef4wikeh27	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.62659895	-122.43005762	5	0	36.58	325.9	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 23:53:40.837	2026-04-02 23:45:46.243	null	RAW_SHORT	2026-04-17 23:53:40.834
cmni4s0rq003gkaefmi96ivck	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.62856623	-122.43242609	5	0	34	313.59	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 23:53:40.837	2026-04-02 23:45:55.229	null	RAW_SHORT	2026-04-17 23:53:40.834
cmni4s0rq003hkaefjv79y6bi	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.63043476	-122.43489758	5	0	33.42	313.95	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 23:53:40.837	2026-04-02 23:46:04.223	null	RAW_SHORT	2026-04-17 23:53:40.834
cmni4s0rq003ikaefynnjv5em	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.63243678	-122.43724443	5	0	33.94	323.09	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 23:53:40.837	2026-04-02 23:46:13.226	null	RAW_SHORT	2026-04-17 23:53:40.834
cmni4s0rq003jkaefgrdj879w	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.6349348	-122.43884269	5	0	34.88	339.61	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 23:53:40.837	2026-04-02 23:46:22.229	null	RAW_SHORT	2026-04-17 23:53:40.834
cmni4s0rq003kkaefcb68xcx3	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.63749279	-122.44010434	5	0	33.36	335.39	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 23:53:40.837	2026-04-02 23:46:31.224	null	RAW_SHORT	2026-04-17 23:53:40.834
cmni4s0rq003lkaef3pyk6no4	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.63997584	-122.44214793	5	0	32.22	325.2	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 23:53:40.837	2026-04-02 23:46:41.236	null	RAW_SHORT	2026-04-17 23:53:40.834
cmni4s0rq003mkaef8ekxgnea	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.64230429	-122.44437793	5	0	32.66	316.41	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 23:53:40.837	2026-04-02 23:46:51.241	null	RAW_SHORT	2026-04-17 23:53:40.834
cmni4s0rq003nkaefdbs5bide	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.64408553	-122.44736776	5	0	33.27	303.05	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 23:53:40.837	2026-04-02 23:47:01.235	null	RAW_SHORT	2026-04-17 23:53:40.834
cmni4s0rq003okaef4th4z0r1	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.64618218	-122.44995475	5	0	32.66	327.66	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 23:53:40.837	2026-04-02 23:47:11.232	null	RAW_SHORT	2026-04-17 23:53:40.834
cmni4s0rq003pkaef9cyrjufx	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.64882156	-122.45154882	5	0	32.21	333.98	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 23:53:40.837	2026-04-02 23:47:21.231	null	RAW_SHORT	2026-04-17 23:53:40.834
cmni4s0rq003qkaefawzhyo43	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.65141777	-122.45317751	5	0	31.84	329.77	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 23:53:40.837	2026-04-02 23:47:31.224	null	RAW_SHORT	2026-04-17 23:53:40.834
cmni4s0rq003rkaefwhjij71t	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.65353831	-122.45560239	5	0	32.04	314.3	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 23:53:40.837	2026-04-02 23:47:41.242	null	RAW_SHORT	2026-04-17 23:53:40.834
cmni4s0rq003skaefbvh7kcdv	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.655592	-122.45823598	5	0	33.05	314.65	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 23:53:40.837	2026-04-02 23:47:51.252	null	RAW_SHORT	2026-04-17 23:53:40.834
cmni4s0rq003tkaefa65ma3bq	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.65749297	-122.4606685	5	0	32.91	314.3	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 23:53:40.837	2026-04-02 23:48:00.233	null	RAW_SHORT	2026-04-17 23:53:40.834
cmni4s0rq003ukaefhc9humu8	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.6595944	-122.46334517	5	0	33.46	314.65	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 23:53:40.837	2026-04-02 23:48:10.264	null	RAW_SHORT	2026-04-17 23:53:40.834
cmni4s0rq003vkaefkx8epwgf	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.66213336	-122.46529514	5	0	33.76	341.72	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 23:53:40.837	2026-04-02 23:48:20.254	null	RAW_SHORT	2026-04-17 23:53:40.834
cmni4s0rq003wkaefdaseksrg	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.66513186	-122.46553863	5	0	33.59	360	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 23:53:40.837	2026-04-02 23:48:30.239	null	RAW_SHORT	2026-04-17 23:53:40.834
cmni4s0rr003xkaef18e4ina3	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.66788041	-122.46556931	5	0	33.82	356.48	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 23:53:40.837	2026-04-02 23:48:39.253	null	RAW_SHORT	2026-04-17 23:53:40.834
cmni4s0rr003ykaef0fqdfpwc	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.67058693	-122.46624196	5	0	34.11	343.12	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 23:53:40.837	2026-04-02 23:48:48.246	null	RAW_SHORT	2026-04-17 23:53:40.834
cmni4s0rr003zkaefads8lync	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.67303763	-122.46769396	5	0	33	328.36	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 23:53:40.837	2026-04-02 23:48:57.245	null	RAW_SHORT	2026-04-17 23:53:40.834
cmni4s0rr0040kaefgnw2wdnm	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.67553774	-122.46973772	5	0	32.54	326.95	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 23:53:40.837	2026-04-02 23:49:07.235	null	RAW_SHORT	2026-04-17 23:53:40.834
cmni4s0rr0041kaeflbr28ki2	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.67803454	-122.47139918	5	0	30.8	341.72	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 23:53:40.837	2026-04-02 23:49:17.226	null	RAW_SHORT	2026-04-17 23:53:40.834
cmni4s0rr0042kaefmx43yolf	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.68095911	-122.47156765	5	0	33.3	3.16	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 23:53:40.837	2026-04-02 23:49:27.244	null	RAW_SHORT	2026-04-17 23:53:40.834
cmni4s0rr0043kaef23la1mwk	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.68390426	-122.47140219	5	0	32.09	3.87	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 23:53:40.837	2026-04-02 23:49:37.246	null	RAW_SHORT	2026-04-17 23:53:40.834
cmni4s0rr0044kaefdq4ig17v	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.68680738	-122.47116189	5	0	32	9.84	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 23:53:40.837	2026-04-02 23:49:47.25	null	RAW_SHORT	2026-04-17 23:53:40.834
cmni4s0rr0045kaefc71kw435	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.68971271	-122.47030274	5	0	33.13	10.9	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 23:53:40.837	2026-04-02 23:49:57.264	null	RAW_SHORT	2026-04-17 23:53:40.834
cmni4s0rr0046kaefjccyz16l	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.69265296	-122.47025966	5	0	31.27	359.65	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 23:53:40.837	2026-04-02 23:50:07.23	null	RAW_SHORT	2026-04-17 23:53:40.834
cmni4s0rr0047kaef1sgguskq	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.69548717	-122.47046216	5	0	32.28	347.7	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 23:53:40.837	2026-04-02 23:50:17.275	null	RAW_SHORT	2026-04-17 23:53:40.834
cmni4s0rr0048kaefkx0bhekn	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.69831024	-122.47127906	5	0	31.26	354.73	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 23:53:40.837	2026-04-02 23:50:27.223	null	RAW_SHORT	2026-04-17 23:53:40.834
cmni4s0rr0049kaefs16kgefs	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.70111839	-122.47133086	5	0	32.36	359.65	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 23:53:40.837	2026-04-02 23:50:37.229	null	RAW_SHORT	2026-04-17 23:53:40.834
cmni4s0rr004akaefrzl5k21f	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.70403219	-122.47131041	5	0	31.51	0.7	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 23:53:40.837	2026-04-02 23:50:47.223	null	RAW_SHORT	2026-04-17 23:53:40.834
cmni4s0rr004bkaef92htjni1	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.70669663	-122.47017626	5	0	32.3	30.23	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 23:53:40.837	2026-04-02 23:50:57.239	null	RAW_SHORT	2026-04-17 23:53:40.834
cmni4s0rr004ckaefytbrpl11	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.70903656	-122.46788255	5	0	33.51	38.32	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 23:53:40.837	2026-04-02 23:51:07.244	null	RAW_SHORT	2026-04-17 23:53:40.834
cmni4s0rr004dkaef01p9ictn	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.71035705	-122.46465828	5	0	32.36	79.1	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 23:53:40.837	2026-04-02 23:51:17.239	null	RAW_SHORT	2026-04-17 23:53:40.834
cmni4s0rr004ekaeffes96ur8	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.71045038	-122.46097678	5	0	32.1	89.65	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 23:53:40.837	2026-04-02 23:51:27.246	null	RAW_SHORT	2026-04-17 23:53:40.834
cmni4s0rr004fkaefeyr5ik2b	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.71052364	-122.45740525	5	0	31.01	82.97	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 23:53:40.837	2026-04-02 23:51:37.229	null	RAW_SHORT	2026-04-17 23:53:40.834
cmni4s0rr004gkaefxrto6lr3	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.71162795	-122.45419314	5	0	31.95	50.27	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 23:53:40.837	2026-04-02 23:51:47.237	null	RAW_SHORT	2026-04-17 23:53:40.834
cmni4s0rs004hkaefe0p6ty1n	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.71380725	-122.45159173	5	0	34.36	42.89	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 23:53:40.837	2026-04-02 23:51:57.248	null	RAW_SHORT	2026-04-17 23:53:40.834
cmni4s0rs004ikaefc2ehf4ki	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.71585977	-122.44931077	5	0	32.96	37.62	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 23:53:40.837	2026-04-02 23:52:06.258	null	RAW_SHORT	2026-04-17 23:53:40.834
cmni4s0rs004jkaef6xlfcput	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.71869117	-122.44835883	5	0	33.04	5.62	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 23:53:40.837	2026-04-02 23:52:16.287	null	RAW_SHORT	2026-04-17 23:53:40.834
cmni583w1008skaefwnf4s4gp	\N	alex@brspark.com	dev_szkcjr	cmni0ykni034tk84w4shu4k67	OS_ACCEPT	\N	\N	\N	\N	\N	\N	GPS	\N	\N	UNKNOWN	1.0.0	26.3.1	Simulator iOS	f	f	4	2026-04-03 00:06:11.377	2026-04-03 00:06:08.23	{"previousState": "IDLE"}	LEGAL	2031-04-03 00:06:11.376
cmni583w2008tkaef1qjlvxsh	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.40979918	-122.19646479	5	0	33.58	291.8	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-03 00:06:11.377	2026-04-03 00:06:08.348	null	RAW_SHORT	2026-04-18 00:06:11.376
cmni58bmw0094kaefvv6vyu2a	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.41082094	-122.19968311	5	0	34.81	291.8	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-03 00:06:21.417	2026-04-03 00:06:17.322	null	RAW_SHORT	2026-04-18 00:06:21.416
cmni58fi1009akaefgyisrtxu	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.41187169	-122.20296881	5	0	34.81	291.8	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-03 00:06:26.425	2026-04-03 00:06:26.317	null	RAW_SHORT	2026-04-18 00:06:26.424
cmni58n88009lkaef4grdcthp	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.41290506	-122.20622074	5	0	34.3	292.15	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-03 00:06:36.44	2026-04-03 00:06:35.321	null	RAW_SHORT	2026-04-18 00:06:36.44
cmni58uyh009wkaefrt833jke	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.41442675	-122.20911895	5	0	34.31	314.3	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-03 00:06:46.457	2026-04-03 00:06:44.314	null	RAW_SHORT	2026-04-18 00:06:46.456
cmni592p800a7kaeff0vj8uy0	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.41652076	-122.21132892	5	0	33.46	317.11	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-03 00:06:56.493	2026-04-03 00:06:53.324	null	RAW_SHORT	2026-04-18 00:06:56.492
cmni592rc00a8kaefd9b9tjyi	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.41652076	-122.21132892	5	0	33.46	317.11	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-03 00:06:56.567	2026-04-03 00:06:53.324	null	RAW_SHORT	2026-04-18 00:06:56.567
cmni5bbws00dtkaefjl5jf42f	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.4354937	-122.24325056	5	0	33.08	316.76	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-03 00:08:41.741	2026-04-03 00:08:39.771	null	RAW_SHORT	2026-04-18 00:08:41.74
cmni5dh8m00gvkaefrc1v0jbp	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.44742701	-122.27433854	5	0	35.12	311.48	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-03 00:10:21.958	2026-04-03 00:10:17.322	null	RAW_SHORT	2026-04-18 00:10:21.957
cmnibwcog01f5za8gkem2w7gf	\N	alex@brspark.com	dev_szkcjr	cmni8b8rv02ox708n5s952fjt	SESSION_CLOSE	\N	\N	\N	\N	\N	\N	GPS	\N	\N	UNKNOWN	1.0.0	26.3.1	Simulator iOS	f	f	-35	2026-04-03 03:13:00.209	2026-04-03 03:12:59.152	{"previousState": "IN_TRANSIT"}	OPERATIONAL	2026-09-30 03:13:00.208
cmnjl18vw00nfrohkima1v3qj	cmnhhqj5c000e3yrjmvwv50er	alex@brspark.com	dev_or2xj4	\N	SESSION_OPEN	\N	\N	\N	\N	\N	\N	GPS	\N	\N	UNKNOWN	1.0.0	26.4	iPhone 17 Pro Max	f	f	-10	2026-04-04 00:16:31.292	2026-04-04 00:16:26.785	{}	OPERATIONAL	2026-10-01 00:16:31.291
cmnjl18xo00ngrohkjttn6cxn	cmnhhqj5c000e3yrjmvwv50er	alex@brspark.com	dev_or2xj4	\N	SESSION_OPEN	\N	\N	\N	\N	\N	\N	GPS	\N	\N	UNKNOWN	1.0.0	26.4	iPhone 17 Pro Max	f	f	-10	2026-04-04 00:16:31.356	2026-04-04 00:16:26.785	{}	OPERATIONAL	2026-10-01 00:16:31.355
cmni59ag600aokaeftjd4stp1	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.41821562	-122.21438304	5	0	32.7	293.55	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-03 00:07:06.534	2026-04-03 00:07:03.32	null	RAW_SHORT	2026-04-18 00:07:06.533
cmni59i6w00azkaefu3vztuq5	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.41888362	-122.21793663	5	0	33.51	280.55	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-03 00:07:16.568	2026-04-03 00:07:13.316	null	RAW_SHORT	2026-04-18 00:07:16.567
cmni59px800bfkaefjg8jd6a1	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.41959201	-122.22131613	5	0	34.94	293.55	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-03 00:07:26.588	2026-04-03 00:07:22.317	null	RAW_SHORT	2026-04-18 00:07:26.587
cmni5cek100fckaef1v29jdpl	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.44419763	-122.25743668	5	0	32.3	276.68	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-03 00:09:31.826	2026-04-03 00:09:28.318	null	RAW_SHORT	2026-04-18 00:09:31.825
cmni5cmar00fnkaefwhrx5s37	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.44407878	-122.26109077	5	0	32.65	264.38	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-03 00:09:41.859	2026-04-03 00:09:38.322	null	RAW_SHORT	2026-04-18 00:09:41.858
cmni5d1rn00g9kaefvpg56aw5	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.44423405	-122.26830767	5	0	32.37	287.23	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-03 00:10:01.908	2026-04-03 00:09:58.322	null	RAW_SHORT	2026-04-18 00:10:01.907
cmni5dl4200h1kaefteb2r459	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.44931173	-122.27705394	5	0	35.27	310.43	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-03 00:10:26.978	2026-04-03 00:10:26.32	null	RAW_SHORT	2026-04-18 00:10:26.977
cmni5dsuo00hckaefc12u062r	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.45113567	-122.27979667	5	0	34.86	309.73	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-03 00:10:37.008	2026-04-03 00:10:35.32	null	RAW_SHORT	2026-04-18 00:10:37.008
cmnj0y4xc000khw8y2i0tgwo6	cmnhhqj5c000e3yrjmvwv50er	alex@brspark.com	dev_szkcjr	\N	SESSION_OPEN	\N	\N	\N	\N	\N	\N	GPS	\N	\N	UNKNOWN	1.0.0	26.3.1	Simulator iOS	f	f	-1	2026-04-03 14:54:13.872	2026-04-03 14:54:09.484	{}	OPERATIONAL	2026-09-30 14:54:13.871
cmnjl18vv00nerohkk27sqeda	cmnhhqj5c000e3yrjmvwv50er	alex@brspark.com	dev_or2xj4	\N	SESSION_OPEN	\N	\N	\N	\N	\N	\N	GPS	\N	\N	UNKNOWN	1.0.0	26.4	iPhone 17 Pro Max	f	f	-10	2026-04-04 00:16:31.292	2026-04-04 00:16:26.785	{}	OPERATIONAL	2026-10-01 00:16:31.291
cmnjl1kep00pkrohkogn0y50d	cmnhhqj5c000e3yrjmvwv50er	alex@brspark.com	dev_or2xj4	cmnj3xzrq016shojah2dyzntn	OS_ACCEPT	\N	\N	\N	\N	\N	\N	GPS	\N	\N	UNKNOWN	1.0.0	26.4	iPhone 17 Pro Max	f	f	-2	2026-04-04 00:16:46.226	2026-04-04 00:16:45.331	{"previousState": "IDLE"}	LEGAL	2031-04-04 00:16:46.224
cmnjl1keq00plrohkzrtcie6z	\N	alex@brspark.com	\N	\N	HEARTBEAT	-23.56719453129495	-46.7862439702355	7.928586564459389	791.3092407332191	-1	-1	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-04 00:16:46.226	2026-04-04 00:14:58.929	null	RAW_SHORT	2026-04-19 00:16:46.224
cmnjl1keq00pmrohkwag88hjd	\N	alex@brspark.com	\N	\N	HEARTBEAT	-23.56719453129495	-46.7862439702355	7.928586564459389	791.3092407332191	-1	-1	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-04 00:16:46.226	2026-04-04 00:15:07.929	null	RAW_SHORT	2026-04-19 00:16:46.224
cmnjl1keq00pnrohkfahchg85	cmnhhqj5c000e3yrjmvwv50er	alex@brspark.com	dev_or2xj4	cmnj3xzrq016shojah2dyzntn	FRAUD_FLAG	-23.56719284864866	-46.78624959075722	\N	\N	\N	\N	GPS	\N	\N	UNKNOWN	1.0.0	26.4	iPhone 17 Pro Max	f	f	4	2026-04-04 00:16:46.226	2026-04-04 00:16:45.386	{"lat": -23.56719284864866, "lng": -46.78624959075722, "reason": "MOCK_LOCATION", "severity": "HIGH"}	LEGAL	2031-04-04 00:16:46.224
cmnjl1keq00porohk7svpx1a4	\N	alex@brspark.com	\N	\N	HEARTBEAT	-23.56719284864866	-46.78624959075722	12.595014	791.2711903200874	-1	-1	\N	\N	\N	\N	\N	\N	\N	t	f	\N	2026-04-04 00:16:46.226	2026-04-04 00:16:44.862	null	RAW_SHORT	2026-04-19 00:16:46.224
cmni59tsd00blkaef3ezpmzva	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.42120016	-122.22417637	5	0	34.29	311.48	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-03 00:07:31.598	2026-04-03 00:07:31.319	null	RAW_SHORT	2026-04-18 00:07:31.597
cmni5bjn100e4kaef1pe72hk4	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.43745284	-122.24560906	5	0	33.53	316.41	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-03 00:08:51.757	2026-04-03 00:08:48.317	null	RAW_SHORT	2026-04-18 00:08:51.756
cmni5brdc00efkaefqd9tyb9w	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.43958193	-122.24823553	5	0	32.54	314.3	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-03 00:09:01.776	2026-04-03 00:08:58.322	null	RAW_SHORT	2026-04-18 00:09:01.775
cmni5c6tr00f1kaefb17zuzm4	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.44339993	-122.25391846	5	0	32.76	296.72	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-03 00:09:21.807	2026-04-03 00:09:18.317	null	RAW_SHORT	2026-04-18 00:09:21.807
cmni5d9ig00gkkaef9b9yavuo	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.44559578	-122.27164133	5	0	33.66	304.8	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-03 00:10:11.945	2026-04-03 00:10:08.322	null	RAW_SHORT	2026-04-18 00:10:11.944
cmni5e4gv00i1kaefetrq40av	\N	alex@brspark.com	dev_szkcjr	cmni0ykni034tk84w4shu4k67	OS_ACCEPT	\N	\N	\N	\N	\N	\N	GPS	\N	\N	UNKNOWN	1.0.0	26.3.1	Simulator iOS	f	f	7	2026-04-03 00:10:52.063	2026-04-03 00:10:47.564	{"previousState": "IDLE"}	LEGAL	2031-04-03 00:10:52.062
cmni5e4gv00i2kaefea8tfpbq	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.4535041	-122.28339124	5	0	33.99	309.38	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-03 00:10:52.063	2026-04-03 00:10:47.842	null	RAW_SHORT	2026-04-18 00:10:52.062
cmni5e8bs00i8kaefirtr7chk	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.45527792	-122.28607664	5	0	34.41	309.38	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-03 00:10:57.064	2026-04-03 00:10:56.319	null	RAW_SHORT	2026-04-18 00:10:57.063
cmnj0y4yy000lhw8ykaurifcp	cmnhhqj5c000e3yrjmvwv50er	alex@brspark.com	dev_szkcjr	\N	SESSION_OPEN	\N	\N	\N	\N	\N	\N	GPS	\N	\N	UNKNOWN	1.0.0	26.3.1	Simulator iOS	f	f	-1	2026-04-03 14:54:13.931	2026-04-03 14:54:09.484	{}	OPERATIONAL	2026-09-30 14:54:13.93
cmnjl1keq00pprohkolivlwmv	cmnhhqj5c000e3yrjmvwv50er	alex@brspark.com	dev_or2xj4	cmnj3xzrq016shojah2dyzntn	OS_ACCEPT	\N	\N	\N	\N	\N	\N	GPS	\N	\N	UNKNOWN	1.0.0	26.4	iPhone 17 Pro Max	f	f	-2	2026-04-04 00:16:46.226	2026-04-04 00:16:45.331	{"previousState": "IDLE"}	LEGAL	2031-04-04 00:16:46.225
cmnjl1keq00pqrohkoo511f83	\N	alex@brspark.com	\N	\N	HEARTBEAT	-23.56719453129495	-46.7862439702355	7.928586564459389	791.3092407332191	-1	-1	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-04 00:16:46.226	2026-04-04 00:14:58.929	null	RAW_SHORT	2026-04-19 00:16:46.225
cmnjl1keq00prrohk578jhax7	\N	alex@brspark.com	\N	\N	HEARTBEAT	-23.56719453129495	-46.7862439702355	7.928586564459389	791.3092407332191	-1	-1	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-04 00:16:46.226	2026-04-04 00:15:07.929	null	RAW_SHORT	2026-04-19 00:16:46.225
cmnjl1keq00psrohkobjwkajq	cmnhhqj5c000e3yrjmvwv50er	alex@brspark.com	dev_or2xj4	cmnj3xzrq016shojah2dyzntn	FRAUD_FLAG	-23.56719284864866	-46.78624959075722	\N	\N	\N	\N	GPS	\N	\N	UNKNOWN	1.0.0	26.4	iPhone 17 Pro Max	f	f	4	2026-04-04 00:16:46.226	2026-04-04 00:16:45.386	{"lat": -23.56719284864866, "lng": -46.78624959075722, "reason": "MOCK_LOCATION", "severity": "HIGH"}	LEGAL	2031-04-04 00:16:46.225
cmnjl1keq00purohkuw1qo3pc	\N	alex@brspark.com	\N	\N	HEARTBEAT	-23.56719284864866	-46.78624959075722	12.595014	791.2711903200874	-1	-1	\N	\N	\N	\N	\N	\N	\N	t	f	\N	2026-04-04 00:16:46.226	2026-04-04 00:16:44.862	null	RAW_SHORT	2026-04-19 00:16:46.225
cmni59xnv00brkaefrm0rb57p	\N	alex@brspark.com	dev_szkcjr	cmni1npwo045ck84w2mp3uaqv	OS_ACCEPT	\N	\N	\N	\N	\N	\N	GPS	\N	\N	UNKNOWN	1.0.0	26.3.1	Simulator iOS	f	f	0	2026-04-03 00:07:36.619	2026-04-03 00:07:34.947	{"previousState": "DISPATCHED"}	LEGAL	2031-04-03 00:07:36.618
cmni59xnv00bskaef4cwi6hud	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.42180622	-122.225047	5	0	34.15	310.78	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-03 00:07:36.619	2026-04-03 00:07:35.343	null	RAW_SHORT	2026-04-18 00:07:36.618
cmni5a5ed00c3kaef78ro2tqv	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.42364424	-122.22769744	5	0	34.88	310.78	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-03 00:07:46.645	2026-04-03 00:07:43.32	null	RAW_SHORT	2026-04-18 00:07:46.644
cmni5ad4m00cekaeffpj1jla5	\N	alex@brspark.com	dev_szkcjr	cmni1npwo045ck84w2mp3uaqv	OS_ACCEPT	\N	\N	\N	\N	\N	\N	GPS	\N	\N	UNKNOWN	1.0.0	26.3.1	Simulator iOS	f	f	1	2026-04-03 00:07:56.662	2026-04-03 00:07:52.378	{"previousState": "DISPATCHED"}	LEGAL	2031-04-03 00:07:56.662
cmni5ad4m00cfkaef3fsmbndo	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.42556261	-122.23036783	5	0	35.73	315.35	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-03 00:07:56.662	2026-04-03 00:07:52.403	null	RAW_SHORT	2026-04-18 00:07:56.662
cmni5agzu00clkaeffnwppbv6	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.42760419	-122.23287838	5	0	34.9	314.65	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-03 00:08:01.675	2026-04-03 00:08:01.319	null	RAW_SHORT	2026-04-18 00:08:01.674
cmni5aoq500cwkaef9r5op95i	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.42942843	-122.23549663	5	0	33.3	310.43	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-03 00:08:11.694	2026-04-03 00:08:10.327	null	RAW_SHORT	2026-04-18 00:08:11.693
cmni5bz3i00eqkaef7nv6t3pt	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.4416554	-122.25091933	5	0	33.04	313.59	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-03 00:09:11.79	2026-04-03 00:09:08.319	null	RAW_SHORT	2026-04-18 00:09:11.789
cmni5dwq500hqkaefatbx1ras	\N	alex@brspark.com	dev_szkcjr	cmni1npwo045ck84w2mp3uaqv	SESSION_CLOSE	\N	\N	\N	\N	\N	\N	GPS	\N	\N	UNKNOWN	1.0.0	26.3.1	Simulator iOS	f	f	-60	2026-04-03 00:10:42.029	2026-04-03 00:10:39.298	{"previousState": "DISPATCHED"}	OPERATIONAL	2026-09-30 00:10:42.029
cmnj0y4yz000mhw8y98ywd98r	cmnhhqj5c000e3yrjmvwv50er	alex@brspark.com	dev_szkcjr	\N	SESSION_OPEN	\N	\N	\N	\N	\N	\N	GPS	\N	\N	UNKNOWN	1.0.0	26.3.1	Simulator iOS	f	f	-1	2026-04-03 14:54:13.932	2026-04-03 14:54:09.484	{}	OPERATIONAL	2026-09-30 14:54:13.931
cmnj0y8s00012hw8yhxmwff8a	cmnhhqj5c000e3yrjmvwv50er	alex@brspark.com	dev_szkcjr	cmnj0qdf70003j3y6z9zcptf7	OS_ACCEPT	\N	\N	\N	\N	\N	\N	GPS	\N	\N	UNKNOWN	1.0.0	26.3.1	Simulator iOS	f	f	-1	2026-04-03 14:54:18.864	2026-04-03 14:54:15.651	{"previousState": "IDLE"}	LEGAL	2031-04-03 14:54:18.863
cmnj0y8s00013hw8yk3pcjsr4	\N	alex@brspark.com	\N	\N	HEARTBEAT	-23.569983	-46.7851655	5	0	-1	-1	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-03 14:54:18.864	2026-04-03 14:54:15.341	null	RAW_SHORT	2026-04-18 14:54:18.863
cmnjl1keq00ptrohk6hof397w	cmnhhqj5c000e3yrjmvwv50er	alex@brspark.com	dev_or2xj4	cmnj3xzrq016shojah2dyzntn	OS_ACCEPT	\N	\N	\N	\N	\N	\N	GPS	\N	\N	UNKNOWN	1.0.0	26.4	iPhone 17 Pro Max	f	f	-2	2026-04-04 00:16:46.227	2026-04-04 00:16:45.331	{"previousState": "IDLE"}	LEGAL	2031-04-04 00:16:46.226
cmnjl1keq00pvrohk83reloig	\N	alex@brspark.com	\N	\N	HEARTBEAT	-23.56719453129495	-46.7862439702355	7.928586564459389	791.3092407332191	-1	-1	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-04 00:16:46.227	2026-04-04 00:14:58.929	null	RAW_SHORT	2026-04-19 00:16:46.226
cmnjl1keq00pwrohky26yggf2	\N	alex@brspark.com	\N	\N	HEARTBEAT	-23.56719453129495	-46.7862439702355	7.928586564459389	791.3092407332191	-1	-1	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-04 00:16:46.227	2026-04-04 00:15:07.929	null	RAW_SHORT	2026-04-19 00:16:46.226
cmnjl1keq00pxrohkanydk522	cmnhhqj5c000e3yrjmvwv50er	alex@brspark.com	dev_or2xj4	cmnj3xzrq016shojah2dyzntn	FRAUD_FLAG	-23.56719284864866	-46.78624959075722	\N	\N	\N	\N	GPS	\N	\N	UNKNOWN	1.0.0	26.4	iPhone 17 Pro Max	f	f	4	2026-04-04 00:16:46.227	2026-04-04 00:16:45.386	{"lat": -23.56719284864866, "lng": -46.78624959075722, "reason": "MOCK_LOCATION", "severity": "HIGH"}	LEGAL	2031-04-04 00:16:46.226
cmnjl1keq00pyrohka3f0zsdj	\N	alex@brspark.com	\N	\N	HEARTBEAT	-23.56719284864866	-46.78624959075722	12.595014	791.2711903200874	-1	-1	\N	\N	\N	\N	\N	\N	\N	t	f	\N	2026-04-04 00:16:46.227	2026-04-04 00:16:44.862	null	RAW_SHORT	2026-04-19 00:16:46.226
cmni5awgu00d7kaef8amp12dd	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.4313864	-122.23829728	5	0	33.61	313.24	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-03 00:08:21.727	2026-04-03 00:08:20.319	null	RAW_SHORT	2026-04-18 00:08:21.726
cmni5b47300dikaefj09mydwe	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.4333289	-122.24069492	5	0	33.29	316.41	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-03 00:08:31.744	2026-04-03 00:08:29.32	null	RAW_SHORT	2026-04-18 00:08:31.743
cmni5cu1500fykaefmljc640g	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.44380955	-122.26471217	5	0	32.07	268.59	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-03 00:09:51.881	2026-04-03 00:09:48.321	null	RAW_SHORT	2026-04-18 00:09:51.88
cmni5eg2w00iokaefzrzpm9lz	\N	alex@brspark.com	dev_szkcjr	cmni0ykni034tk84w4shu4k67	GEOFENCE_ENTER	-14.841123	-51.31804	\N	\N	\N	\N	GPS	\N	\N	UNKNOWN	1.0.0	26.3.1	Simulator iOS	f	f	12	2026-04-03 00:11:07.112	2026-04-03 00:11:03.997	{"lat": -14.841123, "lng": -51.31804, "previousState": "DISPATCHED"}	LEGAL	2031-04-03 00:11:07.111
cmni5eg2w00ipkaefm0z2hphv	\N	alex@brspark.com	dev_szkcjr	cmni0ykni034tk84w4shu4k67	FRAUD_FLAG	37.45672979	-122.28811109	\N	\N	\N	\N	GPS	\N	\N	UNKNOWN	1.0.0	26.3.1	Simulator iOS	t	f	7	2026-04-03 00:11:07.112	2026-04-03 00:11:04.047	{"lat": 37.45672979, "lng": -122.28811109, "reason": "MOCK_LOCATION", "severity": "HIGH"}	LEGAL	2031-04-03 00:11:07.111
cmni5eg2w00iqkaefk9rrd2yh	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.45672979	-122.28811109	5	0	34.63	317.81	\N	\N	\N	\N	\N	\N	\N	t	f	\N	2026-04-03 00:11:07.112	2026-04-03 00:11:03.994	null	RAW_SHORT	2026-04-18 00:11:07.111
cmni5eg2w00irkaef6s7h3cii	\N	alex@brspark.com	dev_szkcjr	cmni0ykni034tk84w4shu4k67	FRAUD_FLAG	37.45721393	-122.28861267	\N	\N	\N	\N	GPS	\N	\N	UNKNOWN	1.0.0	26.3.1	Simulator iOS	t	f	-4	2026-04-03 00:11:07.112	2026-04-03 00:11:05.363	{"lat": 37.45721393, "lng": -122.28861267, "reason": "MOCK_LOCATION", "severity": "HIGH"}	LEGAL	2031-04-03 00:11:07.111
cmni5eg2w00iskaefs22dz1tk	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.45721393	-122.28861267	5	0	34.81	322.38	\N	\N	\N	\N	\N	\N	\N	t	f	\N	2026-04-03 00:11:07.112	2026-04-03 00:11:05.341	null	RAW_SHORT	2026-04-18 00:11:07.111
cmni5eh2z00izkaefu9x2j521	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.45773575	-122.28906747	5	0	34.8	326.6	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-03 00:11:08.411	2026-04-03 00:11:07.321	null	RAW_SHORT	2026-04-18 00:11:08.41
cmni5eh2y00iykaefj5vicm7j	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.45773575	-122.28906747	5	0	34.8	326.6	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-03 00:11:08.41	2026-04-03 00:11:07.321	null	RAW_SHORT	2026-04-18 00:11:08.41
cmni5hcja00n5kaefrvtwykxe	\N	alex@brspark.com	dev_szkcjr	cmni5h43y00mpkaef20ijrtel	OS_ACCEPT	\N	\N	\N	\N	\N	\N	GPS	\N	\N	UNKNOWN	1.0.0	26.3.1	Simulator iOS	f	f	4	2026-04-03 00:13:22.487	2026-04-03 00:13:21.064	{"previousState": "IDLE"}	LEGAL	2031-04-03 00:13:22.486
cmni5hcja00n6kaefnftxw5fa	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.49413538	-122.3036213	5	0	33.62	299.88	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-03 00:13:22.487	2026-04-03 00:13:21.358	null	RAW_SHORT	2026-04-18 00:13:22.486
cmni5hk9s00nhkaefb6pjhdsn	\N	alex@brspark.com	dev_szkcjr	cmni5h43y00mpkaef20ijrtel	TRANSIT_START	\N	\N	\N	\N	\N	\N	GPS	\N	\N	UNKNOWN	1.0.0	26.3.1	Simulator iOS	f	f	6	2026-04-03 00:13:32.513	2026-04-03 00:13:28.447	{"previousState": "DISPATCHED"}	LEGAL	2031-04-03 00:13:32.512
cmni5hk9s00nikaeful9ix766	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.4950032	-122.30641809	5	0	32.95	286.88	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-03 00:13:32.513	2026-04-03 00:13:28.448	null	RAW_SHORT	2026-04-18 00:13:32.512
cmni5ho5300nokaefd5egppdi	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.49560338	-122.30887726	5	0	32.15	287.23	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-03 00:13:37.527	2026-04-03 00:13:35.317	null	RAW_SHORT	2026-04-18 00:13:37.526
cmni5hs0e00nukaefkabky4q7	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.49627109	-122.3112651	5	0	32.48	293.2	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-03 00:13:42.542	2026-04-03 00:13:42.335	null	RAW_SHORT	2026-04-18 00:13:42.542
cmni5hzr300o5kaef6w8tm2wy	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.49722931	-122.31356593	5	0	33.5	301.99	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-03 00:13:52.576	2026-04-03 00:13:49.318	null	RAW_SHORT	2026-04-18 00:13:52.575
cmni5i3mf00obkaefowqdxsrm	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.49826623	-122.31545236	5	0	33.87	305.16	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-03 00:13:57.592	2026-04-03 00:13:55.32	null	RAW_SHORT	2026-04-18 00:13:57.591
cmni5i6mt00oikaefuyy712uh	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.49929918	-122.31733326	5	0	33.72	303.05	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-03 00:14:01.494	2026-04-03 00:14:01.324	null	RAW_SHORT	2026-04-18 00:14:01.493
cmni5i6mr00ohkaefj16ma4hf	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.49929918	-122.31733326	5	0	33.72	303.05	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-03 00:14:01.491	2026-04-03 00:14:01.324	null	RAW_SHORT	2026-04-18 00:14:01.49
cmni5ibd800p1kaefzlvto3yw	\N	alex@brspark.com	dev_szkcjr	cmni5glfq00lykaefxv4igyw0	OS_ACCEPT	\N	\N	\N	\N	\N	\N	GPS	\N	\N	UNKNOWN	1.0.0	26.3.1	Simulator iOS	f	f	3	2026-04-03 00:14:07.628	2026-04-03 00:14:05.98	{"previousState": "IDLE"}	LEGAL	2031-04-03 00:14:07.627
cmni5ibd800p2kaefgy9qyuqt	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.4998836	-122.31865844	5	0	33.04	295.31	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-03 00:14:07.628	2026-04-03 00:14:05.323	null	RAW_SHORT	2026-04-18 00:14:07.627
cmni5if8200p8kaef490gog1o	\N	alex@brspark.com	dev_szkcjr	cmni5glfq00lykaefxv4igyw0	TRANSIT_START	\N	\N	\N	\N	\N	\N	GPS	\N	\N	UNKNOWN	1.0.0	26.3.1	Simulator iOS	f	f	6	2026-04-03 00:14:12.627	2026-04-03 00:14:11.681	{"previousState": "DISPATCHED"}	LEGAL	2031-04-03 00:14:12.626
cmni5if8200p9kaef9vghkgmf	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.50048014	-122.32070412	5	0	31.63	285.82	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-03 00:14:12.627	2026-04-03 00:14:11.687	null	RAW_SHORT	2026-04-18 00:14:12.626
cmni5imz000pkkaefh69ro9q6	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.50080075	-122.32315935	5	0	31.66	274.22	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-03 00:14:22.668	2026-04-03 00:14:18.322	null	RAW_SHORT	2026-04-18 00:14:22.667
cmni5iqu700pqkaefhqcbztyo	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.5009279	-122.32568004	5	0	32.26	274.92	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-03 00:14:27.679	2026-04-03 00:14:25.323	null	RAW_SHORT	2026-04-18 00:14:27.678
cmni5iupo00pwkaefuo9adzg4	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.50133564	-122.32819947	5	0	32.41	287.58	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-03 00:14:32.701	2026-04-03 00:14:32.319	null	RAW_SHORT	2026-04-18 00:14:32.7
cmni5j2g900q7kaef9rrovpfj	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.50221411	-122.33052126	5	0	32.45	301.99	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-03 00:14:42.729	2026-04-03 00:14:39.321	null	RAW_SHORT	2026-04-18 00:14:42.728
cmni5j6bj00qdkaef8qpmwuq8	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.50345136	-122.33261204	5	0	33.51	307.62	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-03 00:14:47.743	2026-04-03 00:14:46.323	null	RAW_SHORT	2026-04-18 00:14:47.742
cmni5ja6i00qjkaef45ckz5ze	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.50457248	-122.33441357	5	0	33.61	307.27	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-03 00:14:52.746	2026-04-03 00:14:52.319	null	RAW_SHORT	2026-04-18 00:14:52.745
cmni5jhws00qukaefz1if7z30	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.5056856	-122.33626303	5	0	34.89	307.62	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-03 00:15:02.765	2026-04-03 00:14:58.319	null	RAW_SHORT	2026-04-18 00:15:02.764
cmni5jls600r0kaef8mt21f0h	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.50683681	-122.33813589	5	0	35.11	307.62	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-03 00:15:07.782	2026-04-03 00:15:04.32	null	RAW_SHORT	2026-04-18 00:15:07.781
cmni5jpmz00r6kaef80wr1ys1	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.50799594	-122.34003061	5	0	35.12	307.97	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-03 00:15:12.779	2026-04-03 00:15:10.318	null	RAW_SHORT	2026-04-18 00:15:12.778
cmni5jtig00rckaefxwqqwesa	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.50910181	-122.34185368	5	0	33.63	307.97	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-03 00:15:17.8	2026-04-03 00:15:16.343	null	RAW_SHORT	2026-04-18 00:15:17.8
cmni5jxd500rikaeflbwqg37i	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.51028467	-122.34356124	5	0	33.28	313.24	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-03 00:15:22.794	2026-04-03 00:15:22.323	null	RAW_SHORT	2026-04-18 00:15:22.793
cmni5k53i00rtkaef3wxrof6q	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.51158508	-122.3451284	5	0	33.63	317.11	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-03 00:15:32.815	2026-04-03 00:15:28.316	null	RAW_SHORT	2026-04-18 00:15:32.814
cmni5k8yv00rzkaefkz8b8pfb	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.51292513	-122.3466607	5	0	33.47	317.46	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-03 00:15:37.832	2026-04-03 00:15:34.319	null	RAW_SHORT	2026-04-18 00:15:37.831
cmni5kctn00s5kaefa58d4g8e	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.51425798	-122.34819157	5	0	33.15	317.81	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-03 00:15:42.827	2026-04-03 00:15:40.321	null	RAW_SHORT	2026-04-18 00:15:42.826
cmni5kgoy00sbkaefqa228q8f	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.51579153	-122.3499475	5	0	32.41	317.81	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-03 00:15:47.843	2026-04-03 00:15:47.325	null	RAW_SHORT	2026-04-18 00:15:47.842
cmni5kofx00smkaefrthycava	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.51731826	-122.35168456	5	0	32.5	317.46	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-03 00:15:57.885	2026-04-03 00:15:54.318	null	RAW_SHORT	2026-04-18 00:15:57.884
cmni5kr4y00sskaef2zp19uf6	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.51893207	-122.35329246	5	0	33.41	325.55	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-03 00:16:01.379	2026-04-03 00:16:01.318	null	RAW_SHORT	2026-04-18 00:16:01.378
cmni5kw6000t3kaef24fcom7c	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.52051884	-122.3544345	5	0	33.71	333.63	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-03 00:16:07.896	2026-04-03 00:16:07.322	null	RAW_SHORT	2026-04-18 00:16:07.895
cmni5l3wh00tekaef68ej9lcz	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.52244224	-122.3554969	5	0	33.28	336.8	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-03 00:16:17.922	2026-04-03 00:16:14.32	null	RAW_SHORT	2026-04-18 00:16:17.921
cmni5l7rf00tkkaef7qn9byot	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.52429661	-122.3567153	5	0	33.42	325.9	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-03 00:16:22.923	2026-04-03 00:16:21.322	null	RAW_SHORT	2026-04-18 00:16:22.923
cmni5ln8o00u7kaef2ltdwfie	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.52919302	-122.36000251	5	0	34.55	341.02	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-03 00:16:42.984	2026-04-03 00:16:39.324	null	RAW_SHORT	2026-04-18 00:16:42.982
cmni5lr3l00udkaefpkomvx5k	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.53097875	-122.3607594	5	0	34.66	341.37	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-03 00:16:47.985	2026-04-03 00:16:45.319	null	RAW_SHORT	2026-04-18 00:16:47.984
cmni5lyte00upkaefo00tmfyv	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.53449935	-122.36228381	5	0	34.14	340.66	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-03 00:16:57.984	2026-04-03 00:16:57.327	null	RAW_SHORT	2026-04-18 00:16:57.982
cmni5m6ju00v0kaefxguj9whd	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.53618827	-122.36315075	5	0	33.1	335.74	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-03 00:17:08.01	2026-04-03 00:17:03.324	null	RAW_SHORT	2026-04-18 00:17:08.009
cmni5n1hs00wakaefr1rkjef3	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.54645044	-122.37107526	5	0	33.21	320.62	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-03 00:17:48.112	2026-04-03 00:17:44.319	null	RAW_SHORT	2026-04-18 00:17:48.112
cmni5nd4r00wrkaefyz3xj5wr	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.54963058	-122.37438493	5	0	32.66	320.62	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-03 00:18:03.195	2026-04-03 00:17:58.318	null	RAW_SHORT	2026-04-18 00:18:03.194
cmni5ngz800wxkaef9g3xe6gr	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.55126157	-122.37602762	5	0	33.99	322.73	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-03 00:18:08.181	2026-04-03 00:18:05.318	null	RAW_SHORT	2026-04-18 00:18:08.18
cmni5nkuf00x3kaefu6ccjw5u	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.5528237	-122.37738054	5	0	35.82	328.36	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-03 00:18:13.192	2026-04-03 00:18:11.322	null	RAW_SHORT	2026-04-18 00:18:13.19
cmni5o0bo00xqkaef2vtk8b22	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.55792263	-122.38086842	5	0	33.86	330.82	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-03 00:18:33.253	2026-04-03 00:18:29.327	null	RAW_SHORT	2026-04-18 00:18:33.252
cmni5o82800y2kaef8p6k5urv	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.56093739	-122.38366881	5	0	35.76	321.33	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-03 00:18:43.28	2026-04-03 00:18:41.322	null	RAW_SHORT	2026-04-18 00:18:43.28
cmni5obxo00y8kaef4l2x49jm	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.56242844	-122.38515208	5	0	34.55	321.33	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-03 00:18:48.3	2026-04-03 00:18:47.324	null	RAW_SHORT	2026-04-18 00:18:48.299
cmni5ojod00yjkaefkw3du1c8	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.56386862	-122.38659938	5	0	33.82	321.33	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-03 00:18:58.333	2026-04-03 00:18:53.332	null	RAW_SHORT	2026-04-18 00:18:58.332
cmni5onjh00ypkaefk14ybkoj	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.56541169	-122.38835698	5	0	32.7	308.67	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-03 00:19:03.341	2026-04-03 00:19:00.321	null	RAW_SHORT	2026-04-18 00:19:03.34
cmni5pq6k010dkaefp90dg3rv	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.57583563	-122.40081651	5	0	34.64	341.02	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-03 00:19:53.421	2026-04-03 00:19:49.359	null	RAW_SHORT	2026-04-18 00:19:53.42
cmni5pu1v010jkaefu03kr7h2	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.57760761	-122.40156585	5	0	34	341.37	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-03 00:19:58.435	2026-04-03 00:19:55.318	null	RAW_SHORT	2026-04-18 00:19:58.434
cmni5q9kh0116kaefmng1e8y6	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.58286516	-122.40506723	5	0	34	328.36	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-03 00:20:18.545	2026-04-03 00:20:15.323	null	RAW_SHORT	2026-04-18 00:20:18.544
cmni5qde4011ckaefx291yb09	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.5843441	-122.40639618	5	0	34.16	320.62	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-03 00:20:23.5	2026-04-03 00:20:21.318	null	RAW_SHORT	2026-04-18 00:20:23.499
cmni5qsux011zkaefdgbuxkae	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.58821704	-122.41138618	5	0	34.26	321.68	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-03 00:20:43.545	2026-04-03 00:20:39.369	null	RAW_SHORT	2026-04-18 00:20:43.545
cmnj0z4e3003hhw8yylte0dug	\N	alex@brspark.com	\N	\N	HEARTBEAT	-23.569983	-46.7851655	5	0	-1	-1	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-03 14:54:59.835	2026-04-03 14:54:58.52	null	RAW_SHORT	2026-04-18 14:54:59.834
cmnj0z4e3003ihw8y623391vy	\N	alex@brspark.com	\N	\N	HEARTBEAT	-23.569983	-46.7851655	5	0	-1	-1	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-03 14:54:59.835	2026-04-03 14:54:59.734	null	RAW_SHORT	2026-04-18 14:54:59.834
cmnjl1kez00pzrohkchmehp8q	cmnhhqj5c000e3yrjmvwv50er	alex@brspark.com	dev_or2xj4	cmnj3xzrq016shojah2dyzntn	OS_ACCEPT	\N	\N	\N	\N	\N	\N	GPS	\N	\N	UNKNOWN	1.0.0	26.4	iPhone 17 Pro Max	f	f	-2	2026-04-04 00:16:46.236	2026-04-04 00:16:45.331	{"previousState": "IDLE"}	LEGAL	2031-04-04 00:16:46.235
cmnjl1kez00q0rohkvh752tp1	\N	alex@brspark.com	\N	\N	HEARTBEAT	-23.56719453129495	-46.7862439702355	7.928586564459389	791.3092407332191	-1	-1	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-04 00:16:46.236	2026-04-04 00:14:58.929	null	RAW_SHORT	2026-04-19 00:16:46.235
cmnjl1kez00q1rohkoetj8nxj	\N	alex@brspark.com	\N	\N	HEARTBEAT	-23.56719453129495	-46.7862439702355	7.928586564459389	791.3092407332191	-1	-1	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-04 00:16:46.236	2026-04-04 00:15:07.929	null	RAW_SHORT	2026-04-19 00:16:46.235
cmnjl1kez00q2rohkgjj12z1a	cmnhhqj5c000e3yrjmvwv50er	alex@brspark.com	dev_or2xj4	cmnj3xzrq016shojah2dyzntn	FRAUD_FLAG	-23.56719284864866	-46.78624959075722	\N	\N	\N	\N	GPS	\N	\N	UNKNOWN	1.0.0	26.4	iPhone 17 Pro Max	f	f	4	2026-04-04 00:16:46.236	2026-04-04 00:16:45.386	{"lat": -23.56719284864866, "lng": -46.78624959075722, "reason": "MOCK_LOCATION", "severity": "HIGH"}	LEGAL	2031-04-04 00:16:46.235
cmnjl1kf000q3rohkmkpdq8wp	\N	alex@brspark.com	\N	\N	HEARTBEAT	-23.56719284864866	-46.78624959075722	12.595014	791.2711903200874	-1	-1	\N	\N	\N	\N	\N	\N	\N	t	f	\N	2026-04-04 00:16:46.236	2026-04-04 00:16:44.862	null	RAW_SHORT	2026-04-19 00:16:46.235
cmni5lbn500tqkaefzixp0zxv	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.52578192	-122.35804173	5	0	34.33	324.49	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-03 00:16:27.954	2026-04-03 00:16:27.323	null	RAW_SHORT	2026-04-18 00:16:27.952
cmni5ljdc00u1kaefrojaj2dx	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.52740806	-122.35922299	5	0	35.09	337.15	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-03 00:16:37.968	2026-04-03 00:16:33.325	null	RAW_SHORT	2026-04-18 00:16:37.967
cmni5luyv00ujkaeffb8exq8x	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.53275508	-122.36151762	5	0	34.63	341.02	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-03 00:16:52.998	2026-04-03 00:16:51.322	null	RAW_SHORT	2026-04-18 00:16:52.996
cmni5mafb00v6kaef2ufwr6mt	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.53806531	-122.36427066	5	0	32.65	334.34	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-03 00:17:13.031	2026-04-03 00:17:10.325	null	RAW_SHORT	2026-04-18 00:17:13.03
cmni5mead00vckaefghb2sgfy	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.5399271	-122.36539895	5	0	32.55	334.34	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-03 00:17:18.038	2026-04-03 00:17:17.315	null	RAW_SHORT	2026-04-18 00:17:18.037
cmni5mm0v00vnkaef1apcu1ep	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.5417466	-122.36656428	5	0	32.1	329.77	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-03 00:17:28.063	2026-04-03 00:17:24.321	null	RAW_SHORT	2026-04-18 00:17:28.063
cmni5mpvu00vtkaef8fr82sfj	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.54342918	-122.36797295	5	0	32.52	322.03	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-03 00:17:33.066	2026-04-03 00:17:31.322	null	RAW_SHORT	2026-04-18 00:17:33.066
cmni5mxmg00w4kaefiyvs90tn	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.54504379	-122.36964053	5	0	33.45	320.62	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-03 00:17:43.096	2026-04-03 00:17:38.32	null	RAW_SHORT	2026-04-18 00:17:43.095
cmni5n5l900wgkaef8rbtsam3	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.54804732	-122.37274258	5	0	32.77	320.62	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-03 00:17:53.421	2026-04-03 00:17:51.322	null	RAW_SHORT	2026-04-18 00:17:53.42
cmni5nopg00x9kaefnlqblx03	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.55453235	-122.378596	5	0	36.85	331.88	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-03 00:18:18.197	2026-04-03 00:18:17.322	null	RAW_SHORT	2026-04-18 00:18:18.196
cmni5nwgf00xkkaef739znagw	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.55628002	-122.37975413	5	0	36.18	332.58	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-03 00:18:28.239	2026-04-03 00:18:23.319	null	RAW_SHORT	2026-04-18 00:18:28.233
cmni5o46w00xwkaefp0ouen8e	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.55944553	-122.38217432	5	0	34.46	322.03	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-03 00:18:38.264	2026-04-03 00:18:35.323	null	RAW_SHORT	2026-04-18 00:18:38.263
cmni5ore700yvkaefple4puu0	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.56638596	-122.39064549	5	0	33.39	292.5	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-03 00:19:08.334	2026-04-03 00:19:07.326	null	RAW_SHORT	2026-04-18 00:19:08.333
cmni5ov9f00z1kaef49qbgyeh	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.56715751	-122.39270291	5	0	33.67	301.29	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-03 00:19:13.347	2026-04-03 00:19:13.322	null	RAW_SHORT	2026-04-18 00:19:13.345
cmni5p2zm00zckaefvyi1yffl	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.56831057	-122.39444945	5	0	33.67	317.11	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-03 00:19:23.363	2026-04-03 00:19:19.325	null	RAW_SHORT	2026-04-18 00:19:23.362
cmni5p6uh00zkkaefofgls8fb	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.56974295	-122.39585292	5	0	33.78	323.09	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-03 00:19:28.361	2026-04-03 00:19:25.324	null	RAW_SHORT	2026-04-18 00:19:28.36
cmni5papl00zqkaef2f6t13gn	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.57119583	-122.39721472	5	0	33.46	322.73	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-03 00:19:33.37	2026-04-03 00:19:31.322	null	RAW_SHORT	2026-04-18 00:19:33.369
cmni5pel000zwkaefy2nl903t	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.57264351	-122.39858927	5	0	33.47	322.73	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-03 00:19:38.389	2026-04-03 00:19:37.335	null	RAW_SHORT	2026-04-18 00:19:38.388
cmni5pig40102kaeffvghu4ou	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.57412937	-122.3999204	5	0	33.73	329.77	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-03 00:19:43.397	2026-04-03 00:19:43.321	null	RAW_SHORT	2026-04-18 00:19:43.396
cmni5pxwn010pkaef075gq0sa	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.57954328	-122.4025353	5	0	32.56	332.23	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-03 00:20:03.431	2026-04-03 00:20:02.325	null	RAW_SHORT	2026-04-18 00:20:03.43
cmni5q5n60110kaefofejbvzz	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.58130801	-122.40386115	5	0	32.87	328.01	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-03 00:20:13.458	2026-04-03 00:20:09.323	null	RAW_SHORT	2026-04-18 00:20:13.457
cmni5qh8s011ikaefjlovp562	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.58565977	-122.40800533	5	0	34.22	312.54	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-03 00:20:28.492	2026-04-03 00:20:27.324	null	RAW_SHORT	2026-04-18 00:20:28.491
cmni5ql3w011okaef9qk388tv	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.58688411	-122.40977861	5	0	34.47	310.43	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-03 00:20:33.5	2026-04-03 00:20:33.335	null	RAW_SHORT	2026-04-18 00:20:33.499
cmni5qwrl0125kaefunzlun3a	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.58966933	-122.41282032	5	0	34.52	321.68	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-03 00:20:48.61	2026-04-03 00:20:45.322	null	RAW_SHORT	2026-04-18 00:20:48.609
cmni5r0l2012bkaefbz9diwjs	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.59114107	-122.41426435	5	0	34.85	321.68	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-03 00:20:53.558	2026-04-03 00:20:51.32	null	RAW_SHORT	2026-04-18 00:20:53.558
cmni5r4g8012hkaefxwamyfn3	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.59260107	-122.41569757	5	0	34.28	321.68	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-03 00:20:58.569	2026-04-03 00:20:57.321	null	RAW_SHORT	2026-04-18 00:20:58.568
cmni5r8ba012skaefrzjziko5	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.59404896	-122.41713675	5	0	33.93	321.68	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-03 00:21:03.575	2026-04-03 00:21:03.323	null	RAW_SHORT	2026-04-18 00:21:03.574
cmni5rg1s0133kaefdqhca8n5	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.59548533	-122.41852169	5	0	33.44	322.03	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-03 00:21:13.6	2026-04-03 00:21:09.324	null	RAW_SHORT	2026-04-18 00:21:13.599
cmni5rjx50139kaefu2cbsl7z	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.59687739	-122.42000453	5	0	33.69	317.11	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-03 00:21:18.618	2026-04-03 00:21:15.325	null	RAW_SHORT	2026-04-18 00:21:18.617
cmni5rnrx013fkaef5k0wmiv2	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.5981662	-122.42160673	5	0	33.65	315.7	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-03 00:21:23.613	2026-04-03 00:21:21.326	null	RAW_SHORT	2026-04-18 00:21:23.612
cmni5rrn2013lkaefe9r715zt	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.59945848	-122.42321044	5	0	33.36	315.35	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-03 00:21:28.623	2026-04-03 00:21:27.35	null	RAW_SHORT	2026-04-18 00:21:28.622
cmni5rvi5013rkaef0n5q5tfq	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.6007723	-122.42479018	5	0	33.75	316.05	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-03 00:21:33.629	2026-04-03 00:21:33.322	null	RAW_SHORT	2026-04-18 00:21:33.629
cmni5s3920142kaefp2odasgx	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.60215158	-122.42632113	5	0	34.06	323.44	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-03 00:21:43.671	2026-04-03 00:21:39.322	null	RAW_SHORT	2026-04-18 00:21:43.67
cmni5s74e0148kaefmyymouav	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.60374389	-122.42740357	5	0	33.45	336.45	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-03 00:21:48.686	2026-04-03 00:21:45.325	null	RAW_SHORT	2026-04-18 00:21:48.685
cmni5sazl014ekaef8av0csny	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.60578463	-122.42799969	5	0	32.59	352.27	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-03 00:21:53.697	2026-04-03 00:21:52.337	null	RAW_SHORT	2026-04-18 00:21:53.696
cmni5siqg014pkaefur3vaacr	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.60784989	-122.42783465	5	0	33	8.79	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-03 00:22:03.736	2026-04-03 00:21:59.339	null	RAW_SHORT	2026-04-18 00:22:03.735
cmni5smlx014vkaefs0p813lj	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.60985778	-122.42716444	5	0	33.54	19.34	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-03 00:22:08.757	2026-04-03 00:22:06.321	null	RAW_SHORT	2026-04-18 00:22:08.756
cmni5sqgz0151kaeffujqhd6e	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.61151375	-122.42623941	5	0	33.59	27.42	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-03 00:22:13.763	2026-04-03 00:22:12.334	null	RAW_SHORT	2026-04-18 00:22:13.762
cmni5sy6o015ckaefi9crkc4j	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.61332877	-122.42494558	5	0	32.84	28.12	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-03 00:22:23.76	2026-04-03 00:22:19.339	null	RAW_SHORT	2026-04-18 00:22:23.76
cmni5t21u015ikaef943vom2z	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.61532676	-122.42415123	5	0	33.57	10.9	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-03 00:22:28.771	2026-04-03 00:22:26.336	null	RAW_SHORT	2026-04-18 00:22:28.77
cmni5t5x1015okaef845euu9d	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.61741624	-122.42423697	5	0	33.57	349.45	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-03 00:22:33.781	2026-04-03 00:22:33.321	null	RAW_SHORT	2026-04-18 00:22:33.781
cmni5tdn4015zkaef85uoak6f	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.61913529	-122.42497542	5	0	34.15	333.98	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-03 00:22:43.793	2026-04-03 00:22:39.326	null	RAW_SHORT	2026-04-18 00:22:43.792
cmni5thim0165kaef9miwczey	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.62081393	-122.42606959	5	0	35.34	332.58	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-03 00:22:48.814	2026-04-03 00:22:45.323	null	RAW_SHORT	2026-04-18 00:22:48.813
cmni5tldo016bkaeffmmd0du1	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.62251265	-122.42715597	5	0	35.19	332.93	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-03 00:22:53.82	2026-04-03 00:22:51.32	null	RAW_SHORT	2026-04-18 00:22:53.82
cmni5tp92016hkaef6cdlp9x0	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.62416933	-122.4282281	5	0	34.23	332.93	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-03 00:22:58.838	2026-04-03 00:22:57.324	null	RAW_SHORT	2026-04-18 00:22:58.837
cmni5uo35017xkaef27m8l6lw	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.63406015	-122.43840734	5	0	34.61	335.39	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-03 00:23:43.986	2026-04-03 00:23:40.034	null	RAW_SHORT	2026-04-18 00:23:43.985
cmni5x51z01blkaefi2399v5k	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.66051201	-122.46432619	5	0	33.43	324.84	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-03 00:25:39.287	2026-04-03 00:25:34.328	null	RAW_SHORT	2026-04-18 00:25:39.287
cmni5x8w401brkaefvg4khs5z	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.66242417	-122.46538013	5	0	33.48	345.59	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-03 00:25:44.26	2026-04-03 00:25:41.335	null	RAW_SHORT	2026-04-18 00:25:44.259
cmni5xcr901bxkaefeplvkviv	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.66423047	-122.46553746	5	0	33.9	359.65	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-03 00:25:49.269	2026-04-03 00:25:47.337	null	RAW_SHORT	2026-04-18 00:25:49.268
cmnj1k2am01l0hw8yq56sstlc	\N	alex@brspark.com	dev_szkcjr	cmnj0xh1v0001hw8ycw1mvicf	OS_ACCEPT	\N	\N	\N	\N	\N	\N	GPS	\N	\N	UNKNOWN	1.0.0	26.3.1	Simulator iOS	f	f	-3	2026-04-03 15:11:16.894	2026-04-03 15:11:12.951	{"previousState": "IDLE"}	LEGAL	2031-04-03 15:11:16.891
cmnj1k2am01l1hw8yzohuvm4d	\N	alex@brspark.com	\N	\N	HEARTBEAT	-23.569983	-46.7851655	5	0	-1	-1	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-03 15:11:16.894	2026-04-03 15:11:12.714	null	RAW_SHORT	2026-04-18 15:11:16.891
cmnjl9ep900usrohk03uvsez9	\N	qualquecoisa@gmail.com	\N	\N	HEARTBEAT	-23.56719453129495	-46.7862439702355	7.928586564459389	788.3225873024778	-1	-1	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-04 00:22:52.077	2026-04-04 00:22:47.236	null	RAW_SHORT	2026-04-19 00:22:52.076
cmni5tt54016nkaefa1pf6vsm	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.62579706	-122.42936184	5	0	34.46	328.71	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-03 00:23:03.88	2026-04-03 00:23:03.316	null	RAW_SHORT	2026-04-18 00:23:03.879
cmni5u0v9016ykaefmhmkzyzl	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.62728518	-122.43078483	5	0	34.2	319.22	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-03 00:23:13.893	2026-04-03 00:23:09.338	null	RAW_SHORT	2026-04-18 00:23:13.893
cmni5ugc9017mkaefnouptmp6	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.63243678	-122.43724443	5	0	33.94	323.09	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-03 00:23:33.945	2026-04-03 00:23:33.32	null	RAW_SHORT	2026-04-18 00:23:33.944
cmni5vizv0197kaeft7mkhlh2	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.64375562	-122.44674171	5	0	33.34	303.75	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-03 00:24:24.043	2026-04-03 00:24:19.388	null	RAW_SHORT	2026-04-18 00:24:24.042
cmnj1lzx801o6hw8y1g64eemc	\N	alex@brspark.com	dev_szkcjr	cmnj1lkhy01n1hw8y4bohk7qw	OS_ACCEPT	\N	\N	\N	\N	\N	\N	GPS	\N	\N	UNKNOWN	1.0.0	26.3.1	Simulator iOS	f	f	0	2026-04-03 15:12:47.132	2026-04-03 15:12:42.602	{"previousState": "DISPATCHED"}	LEGAL	2031-04-03 15:12:47.131
cmnj1lzx901o7hw8yuiz8fs2a	\N	alex@brspark.com	\N	\N	HEARTBEAT	-23.569983	-46.7851655	5	0	-1	-1	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-03 15:12:47.132	2026-04-03 15:12:42.206	null	RAW_SHORT	2026-04-18 15:12:47.131
cmnjl9ep200uprohkgpi6t7ks	\N	qualquecoisa@gmail.com	\N	\N	HEARTBEAT	-23.56719453129495	-46.7862439702355	7.928586564459389	788.3225873024778	-1	-1	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-04 00:22:52.07	2026-04-04 00:22:47.236	null	RAW_SHORT	2026-04-19 00:22:52.069
cmni5u4r70174kaefbhizony3	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.62856623	-122.43242609	5	0	34	313.59	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-03 00:23:18.931	2026-04-03 00:23:15.321	null	RAW_SHORT	2026-04-18 00:23:18.93
cmni5u8m4017akaefgxnhoboy	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.62981274	-122.43408294	5	0	33.45	313.59	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-03 00:23:23.933	2026-04-03 00:23:21.337	null	RAW_SHORT	2026-04-18 00:23:23.931
cmni5uch5017gkaefin5z5yq1	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.63107828	-122.43573275	5	0	33.5	313.59	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-03 00:23:28.937	2026-04-03 00:23:27.326	null	RAW_SHORT	2026-04-18 00:23:28.936
cmni5urxt0183kaefrbycoxqk	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.63580421	-122.43925726	5	0	34.43	339.61	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-03 00:23:48.978	2026-04-03 00:23:45.322	null	RAW_SHORT	2026-04-18 00:23:48.977
cmni5uvt60189kaefz104srw0	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.63749279	-122.44010434	5	0	33.36	335.39	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-03 00:23:53.995	2026-04-03 00:23:51.317	null	RAW_SHORT	2026-04-18 00:23:53.994
cmni5uzoo018fkaefo4avbbr6	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.63925764	-122.44152758	5	0	32.71	325.2	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-03 00:23:59.016	2026-04-03 00:23:58.32	null	RAW_SHORT	2026-04-18 00:23:59.012
cmni5v7es018qkaeftz53v6sc	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.64093544	-122.44298813	5	0	32.37	325.2	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-03 00:24:09.029	2026-04-03 00:24:05.321	null	RAW_SHORT	2026-04-18 00:24:09.027
cmni5vba0018wkaef663cqw82	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.64250521	-122.44464263	5	0	32.99	313.59	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-03 00:24:14.04	2026-04-03 00:24:12.329	null	RAW_SHORT	2026-04-18 00:24:14.04
cmni5vmvh019dkaefslu1nl1y	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.6450036	-122.44884951	5	0	33.28	312.19	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-03 00:24:29.07	2026-04-03 00:24:26.322	null	RAW_SHORT	2026-04-18 00:24:29.069
cmni5vqqp019jkaefv0u53xle	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.64671535	-122.45027846	5	0	32.56	334.34	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-03 00:24:34.081	2026-04-03 00:24:33.336	null	RAW_SHORT	2026-04-18 00:24:34.08
cmni5vygw019ukaef8gsxn7cv	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.64856629	-122.45139107	5	0	32.31	334.34	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-03 00:24:44.096	2026-04-03 00:24:40.324	null	RAW_SHORT	2026-04-18 00:24:44.095
cmni5w2cg01a0kaefutqk31fg	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.65039124	-122.45248835	5	0	31.85	333.98	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-03 00:24:49.12	2026-04-03 00:24:47.387	null	RAW_SHORT	2026-04-18 00:24:49.12
cmni5wa2s01abkaef3sx138ci	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.65210789	-122.45382878	5	0	31.73	319.92	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-03 00:24:59.141	2026-04-03 00:24:54.327	null	RAW_SHORT	2026-04-18 00:24:59.14
cmni5wdyk01ahkaeff1exfzi0	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.65353831	-122.45560239	5	0	32.04	314.3	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-03 00:25:04.173	2026-04-03 00:25:01.337	null	RAW_SHORT	2026-04-18 00:25:04.172
cmni5whtq01ankaefm5d3bssf	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.65496855	-122.45743258	5	0	32.76	314.3	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-03 00:25:09.182	2026-04-03 00:25:08.332	null	RAW_SHORT	2026-04-18 00:25:09.182
cmni5wpjk01aykaefthf1kqqz	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.65643224	-122.45931348	5	0	33.68	314.65	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-03 00:25:19.185	2026-04-03 00:25:15.323	null	RAW_SHORT	2026-04-18 00:25:19.184
cmni5wtgc01b4kaefwpkpcahw	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.65770105	-122.46093303	5	0	32.74	314.3	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-03 00:25:24.252	2026-04-03 00:25:21.319	null	RAW_SHORT	2026-04-18 00:25:24.25
cmni5wxa601bakaeffna1gu48	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.65916931	-122.46280446	5	0	33.48	314.3	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-03 00:25:29.214	2026-04-03 00:25:28.334	null	RAW_SHORT	2026-04-18 00:25:29.213
cmni5xgn401c3kaef6xcdemt8	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.66604012	-122.46554886	5	0	33.68	359.65	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-03 00:25:54.304	2026-04-03 00:25:53.349	null	RAW_SHORT	2026-04-18 00:25:54.303
cmni5xm3101cekaeflx5ij2pz	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.66788041	-122.46556931	5	0	33.82	356.48	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-03 00:26:01.358	2026-04-03 00:25:59.339	null	RAW_SHORT	2026-04-18 00:26:01.357
cmni5xs7r01cpkaef3i51bekm	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.66968902	-122.46592722	5	0	34.25	348.4	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-03 00:26:09.303	2026-04-03 00:26:05.321	null	RAW_SHORT	2026-04-18 00:26:09.302
cmni5xw3v01cvkaefzey3myl8	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.67144121	-122.46664932	5	0	33.87	338.2	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-03 00:26:14.347	2026-04-03 00:26:11.337	null	RAW_SHORT	2026-04-18 00:26:14.346
cmni5xzxu01d1kaef1vthym2h	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.67328875	-122.46789755	5	0	32.98	326.95	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-03 00:26:19.314	2026-04-03 00:26:18.322	null	RAW_SHORT	2026-04-18 00:26:19.313
cmni5y7ol01dckaefaiwxpojx	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.67503877	-122.46932809	5	0	32.96	326.95	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-03 00:26:29.35	2026-04-03 00:26:25.347	null	RAW_SHORT	2026-04-18 00:26:29.348
cmni5yblk01dikaefw82bbt8g	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.67674604	-122.4707137	5	0	31.71	328.71	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-03 00:26:34.424	2026-04-03 00:26:32.322	null	RAW_SHORT	2026-04-18 00:26:34.423
cmni5yfge01dokaeftflfue6i	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.67860355	-122.47155592	5	0	31.9	348.05	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-03 00:26:39.423	2026-04-03 00:26:39.336	null	RAW_SHORT	2026-04-18 00:26:39.422
cmni5yn4y01dzkaef2r0opo8p	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.68066068	-122.47159028	5	0	33.3	2.46	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-03 00:26:49.378	2026-04-03 00:26:46.366	null	RAW_SHORT	2026-04-18 00:26:49.377
cmni5yr0f01e5kaefu1devpm1	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.68273658	-122.47147906	5	0	32.74	2.46	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-03 00:26:54.399	2026-04-03 00:26:53.34	null	RAW_SHORT	2026-04-18 00:26:54.398
cmni5yyql01egkaefx3gq26ky	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.6847816	-122.47134126	5	0	32.08	3.16	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-03 00:27:04.413	2026-04-03 00:27:00.329	null	RAW_SHORT	2026-04-18 00:27:04.412
cmni5z2m301emkaef0r3xw2v9	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.68680738	-122.47116189	5	0	32	9.84	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-03 00:27:09.436	2026-04-03 00:27:07.348	null	RAW_SHORT	2026-04-18 00:27:09.435
cmni5z6gu01eskaef02i6sggo	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.68883655	-122.4705065	5	0	33.55	15.47	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-03 00:27:14.43	2026-04-03 00:27:14.333	null	RAW_SHORT	2026-04-18 00:27:14.429
cmni5ze7i01f3kaefxk8cscps	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.69090609	-122.47024692	5	0	32.95	0.7	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-03 00:27:24.463	2026-04-03 00:27:21.584	null	RAW_SHORT	2026-04-18 00:27:24.462
cmni5zi2f01f9kaef3kgu450d	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.69293317	-122.47025832	5	0	31.33	359.65	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-03 00:27:29.463	2026-04-03 00:27:28.325	null	RAW_SHORT	2026-04-18 00:27:29.462
cmni5zptg01fkkaefzrzegh31	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.69491402	-122.47033308	5	0	32.09	354.02	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-03 00:27:39.509	2026-04-03 00:27:35.336	null	RAW_SHORT	2026-04-18 00:27:39.507
cmni5zto401fqkaefoy8l8k4f	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.69688264	-122.47097195	5	0	32.45	343.83	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-03 00:27:44.5	2026-04-03 00:27:42.338	null	RAW_SHORT	2026-04-18 00:27:44.499
cmni5zxjc01fwkaefkdo33mtr	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.69887099	-122.4712903	5	0	30.62	359.3	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-03 00:27:49.512	2026-04-03 00:27:49.39	null	RAW_SHORT	2026-04-18 00:27:49.512
cmni605a201g7kaeffengqpah	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.70082904	-122.47133464	5	0	32.2	359.3	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-03 00:27:59.546	2026-04-03 00:27:56.33	null	RAW_SHORT	2026-04-18 00:27:59.545
cmni6090801gdkaeffcqd1twc	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.70288244	-122.47131335	5	0	31.85	0.7	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-03 00:28:04.377	2026-04-03 00:28:03.424	null	RAW_SHORT	2026-04-18 00:28:04.376
cmni6091j01gekaefjer60wd3	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.70288244	-122.47131335	5	0	31.85	0.7	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-03 00:28:04.423	2026-04-03 00:28:03.424	null	RAW_SHORT	2026-04-18 00:28:04.422
cmni6f7dt000u708nzm1hxrgb	\N	alex@brspark.com	dev_szkcjr	cmni5g3d100lckaef6qeeg4y5	OS_ACCEPT	\N	\N	\N	\N	\N	\N	GPS	\N	\N	UNKNOWN	1.0.0	26.3.1	Simulator iOS	f	f	-2	2026-04-03 00:39:42.114	2026-04-03 00:39:39.563	{"previousState": "IDLE"}	LEGAL	2031-04-03 00:39:42.111
cmni6f7du000v708n3ha8hz69	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.36637342	-122.13530514	5	0	32.12	290.39	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-03 00:39:42.114	2026-04-03 00:39:40.084	null	RAW_SHORT	2026-04-18 00:39:42.111
cmni6fefu001e708nlj3sm1er	\N	alex@brspark.com	dev_szkcjr	cmni5g3d100lckaef6qeeg4y5	SESSION_CLOSE	\N	\N	\N	\N	\N	\N	GPS	\N	\N	UNKNOWN	1.0.0	26.3.1	Simulator iOS	f	f	-21	2026-04-03 00:39:51.258	2026-04-03 00:39:48.78	{"previousState": "DISPATCHED"}	OPERATIONAL	2026-09-30 00:39:51.257
cmni6fiyx001p708ns9wm72ml	\N	alex@brspark.com	dev_szkcjr	cmni0yc0l034gk84wpt1ucqfp	OS_ACCEPT	\N	\N	\N	\N	\N	\N	GPS	\N	\N	UNKNOWN	1.0.0	26.3.1	Simulator iOS	f	f	2	2026-04-03 00:39:57.129	2026-04-03 00:39:52.846	{"previousState": "IDLE"}	LEGAL	2031-04-03 00:39:57.128
cmni6fiyx001q708n7gcd3v0u	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.36813371	-122.13959391	5	0	34.03	308.67	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-03 00:39:57.129	2026-04-03 00:39:52.412	null	RAW_SHORT	2026-04-18 00:39:57.128
cmni6fmyq001w708nvjh2ut6s	\N	alex@brspark.com	dev_szkcjr	cmni0yc0l034gk84wpt1ucqfp	TRANSIT_START	\N	\N	\N	\N	\N	\N	GPS	\N	\N	UNKNOWN	1.0.0	26.3.1	Simulator iOS	f	f	1	2026-04-03 00:40:02.307	2026-04-03 00:39:57.479	{"previousState": "DISPATCHED"}	LEGAL	2031-04-03 00:40:02.305
cmni6fmyr001x708nflufyfjp	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.36921459	-122.14094005	5	0	34.04	320.27	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-03 00:40:02.307	2026-04-03 00:39:57.484	null	RAW_SHORT	2026-04-18 00:40:02.305
cmni6fqq20023708nzhwnuxsn	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.37068524	-122.14231367	5	0	33.45	323.79	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-03 00:40:07.179	2026-04-03 00:40:03.419	null	RAW_SHORT	2026-04-18 00:40:07.178
cmni6ful00029708n4rfcs55j	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.37215601	-122.14364204	5	0	33.14	324.49	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-03 00:40:12.181	2026-04-03 00:40:09.441	null	RAW_SHORT	2026-04-18 00:40:12.18
cmni6g664002q708nsbceme4e	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.37527039	-122.14662055	5	0	34.1	318.16	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-03 00:40:27.196	2026-04-03 00:40:22.417	null	RAW_SHORT	2026-04-18 00:40:27.195
cmni6gdwa0032708ntijsmmt1	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.3780272	-122.14968145	5	0	34.04	322.73	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-03 00:40:37.21	2026-04-03 00:40:34.42	null	RAW_SHORT	2026-04-18 00:40:37.209
cmni6h8ug004c708n6b7yyxma	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.38803876	-122.15572505	5	0	31.75	298.12	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-03 00:41:17.321	2026-04-03 00:41:12.411	null	RAW_SHORT	2026-04-18 00:41:17.32
cmni6hgku004o708ni8fwybqc	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.38901726	-122.16067063	5	0	32.51	280.9	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-03 00:41:27.342	2026-04-03 00:41:26.419	null	RAW_SHORT	2026-04-18 00:41:27.342
cmni6hoce004z708nuzokmc5d	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.38966543	-122.16308369	5	0	32.49	297.07	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-03 00:41:37.406	2026-04-03 00:41:33.424	null	RAW_SHORT	2026-04-18 00:41:37.406
cmni6i7o8005s708npg8zfpuw	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.39242056	-122.17227965	5	0	32.3	281.25	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-03 00:42:02.456	2026-04-03 00:42:00.639	null	RAW_SHORT	2026-04-18 00:42:02.455
cmni6ijab0069708nwwtwmxvy	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.39440066	-122.17665986	5	0	32.57	317.11	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-03 00:42:17.508	2026-04-03 00:42:14.417	null	RAW_SHORT	2026-04-18 00:42:17.507
cmni6in5n006f708ne5y4602q	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.39602298	-122.17827723	5	0	33.26	322.03	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-03 00:42:22.524	2026-04-03 00:42:21.419	null	RAW_SHORT	2026-04-18 00:42:22.523
cmni6ir37006l708nd89n8gz5	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.39747477	-122.17969227	5	0	34.8	321.68	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-03 00:42:27.62	2026-04-03 00:42:27.506	null	RAW_SHORT	2026-04-18 00:42:27.619
cmni6iysv006w708nd6dti8z6	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.39896494	-122.18117586	5	0	35.4	322.03	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-03 00:42:37.615	2026-04-03 00:42:33.417	null	RAW_SHORT	2026-04-18 00:42:37.614
cmni6j6la0078708njcanatbs	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.40193507	-122.18412948	5	0	34.75	320.98	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-03 00:42:47.71	2026-04-03 00:42:45.424	null	RAW_SHORT	2026-04-18 00:42:47.707
cmni6jm0u007v708nzj28en2b	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.40641352	-122.18869619	5	0	32.9	318.16	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-03 00:43:07.71	2026-04-03 00:43:04.412	null	RAW_SHORT	2026-04-18 00:43:07.708
cmni6jxl4008c708nwyb1m6cr	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.4086895	-122.19295621	5	0	33.01	292.15	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-03 00:43:22.696	2026-04-03 00:43:18.506	null	RAW_SHORT	2026-04-18 00:43:22.695
cmni6k5ci008o708ncy55576j	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.41013974	-122.1975256	5	0	33.93	291.8	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-03 00:43:32.755	2026-04-03 00:43:31.417	null	RAW_SHORT	2026-04-18 00:43:32.754
cmni6k976008u708niuu2ki2v	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.41082094	-122.19968311	5	0	34.81	291.8	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-03 00:43:37.746	2026-04-03 00:43:37.424	null	RAW_SHORT	2026-04-18 00:43:37.745
cmni6kkt2009b708nfslzvx9c	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.41221975	-122.20406123	5	0	34.82	291.45	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-03 00:43:52.79	2026-04-03 00:43:49.421	null	RAW_SHORT	2026-04-18 00:43:52.789
cmni6l80700aa708nowvhb5hz	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.41782917	-122.21338064	5	0	32.82	299.88	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-03 00:44:22.855	2026-04-03 00:44:20.421	null	RAW_SHORT	2026-04-18 00:44:22.854
cmni6lbvu00ag708nfz8n7il8	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.41856183	-122.21577393	5	0	32.1	283.36	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-03 00:44:27.883	2026-04-03 00:44:27.423	null	RAW_SHORT	2026-04-18 00:44:27.882
cmnj1u9sq01zehw8yamnnlwih	\N	alex@brspark.com	dev_szkcjr	cmnj1u3d401z3hw8yw2e5hqnc	OS_ACCEPT	\N	\N	\N	\N	\N	\N	GPS	\N	\N	UNKNOWN	1.0.0	26.3.1	Simulator iOS	f	f	4	2026-04-03 15:19:13.175	2026-04-03 15:19:13.086	{"previousState": "DISPATCHED"}	LEGAL	2031-04-03 15:19:13.174
cmnjl9ep300urrohkw8u0rcyz	\N	qualquecoisa@gmail.com	\N	\N	HEARTBEAT	-23.56719453129495	-46.7862439702355	7.928586564459389	788.3225873024778	-1	-1	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-04 00:22:52.071	2026-04-04 00:22:47.236	null	RAW_SHORT	2026-04-19 00:22:52.071
cmni6fygh002f708nqxda4gbg	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.37385134	-122.14517802	5	0	33.55	323.79	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-03 00:40:17.201	2026-04-03 00:40:16.416	null	RAW_SHORT	2026-04-18 00:40:17.2
cmni6ga1c002w708n6ulfoxif	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.37664016	-122.14817958	5	0	34.08	317.81	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-03 00:40:32.209	2026-04-03 00:40:28.406	null	RAW_SHORT	2026-04-18 00:40:32.208
cmni6ghrr0038708n1avz8tva	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.37961188	-122.15082139	5	0	33.85	336.09	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-03 00:40:42.231	2026-04-03 00:40:40.419	null	RAW_SHORT	2026-04-18 00:40:42.23
cmni6glmz003e708njiogzcmv	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.38139635	-122.15151398	5	0	35.01	349.1	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-03 00:40:47.243	2026-04-03 00:40:46.414	null	RAW_SHORT	2026-04-18 00:40:47.242
cmni6gtdq003p708n1pvbvp8b	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.38325235	-122.15190458	5	0	34.39	350.51	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-03 00:40:57.278	2026-04-03 00:40:52.423	null	RAW_SHORT	2026-04-18 00:40:57.277
cmni6gx91003v708ncuewfls2	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.38505698	-122.15241395	5	0	33.77	344.53	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-03 00:41:02.294	2026-04-03 00:40:58.417	null	RAW_SHORT	2026-04-18 00:41:02.293
cmni6h14k0041708nnvsaj20r	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.38681491	-122.15376042	5	0	31.96	318.16	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-03 00:41:07.317	2026-04-03 00:41:05.423	null	RAW_SHORT	2026-04-18 00:41:07.315
cmni6hcq9004i708nxzxzu35h	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.38863873	-122.158132	5	0	32.54	280.55	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-03 00:41:22.353	2026-04-03 00:41:19.426	null	RAW_SHORT	2026-04-18 00:41:22.351
cmni6hs6x0055708nmy62kzl6	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.39081987	-122.1652427	5	0	33.66	306.21	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-03 00:41:42.393	2026-04-03 00:41:40.412	null	RAW_SHORT	2026-04-18 00:41:42.392
cmni6hw22005b708nnij3qdom	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.3917638	-122.16719669	5	0	33.76	292.85	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-03 00:41:47.402	2026-04-03 00:41:46.421	null	RAW_SHORT	2026-04-18 00:41:47.397
cmni6i3sj005m708njy04hpbi	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.39221512	-122.16972115	5	0	32.6	274.57	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-03 00:41:57.428	2026-04-03 00:41:53.411	null	RAW_SHORT	2026-04-18 00:41:57.427
cmni6ibj8005y708nqbxdiwr2	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.39312741	-122.17466882	5	0	32.3	298.83	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-03 00:42:07.461	2026-04-03 00:42:07.424	null	RAW_SHORT	2026-04-18 00:42:07.46
cmni6j2np0072708niwmpde0f	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.40046241	-122.18266432	5	0	34.92	321.33	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-03 00:42:42.613	2026-04-03 00:42:39.422	null	RAW_SHORT	2026-04-18 00:42:42.611
cmni6jadd007e708n84jxzb4w	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.40336963	-122.1855891	5	0	34.12	321.33	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-03 00:42:52.61	2026-04-03 00:42:51.419	null	RAW_SHORT	2026-04-18 00:42:52.609
cmni6je8w007k708nlznvspay	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.40479565	-122.1870328	5	0	33.53	320.98	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-03 00:42:57.633	2026-04-03 00:42:57.437	null	RAW_SHORT	2026-04-18 00:42:57.631
cmni6jpuc0081708nxlez3tbe	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.40776758	-122.19065295	5	0	32.48	304.45	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-03 00:43:12.66	2026-04-03 00:43:11.417	null	RAW_SHORT	2026-04-18 00:43:12.659
cmni6k1gg008i708nstgag6fs	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.40945674	-122.19540213	5	0	33.35	291.45	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-03 00:43:27.713	2026-04-03 00:43:25.427	null	RAW_SHORT	2026-04-18 00:43:27.712
cmni6kgxq0095708nuq2mln8c	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.41152166	-122.20187338	5	0	34.93	292.15	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-03 00:43:47.775	2026-04-03 00:43:43.417	null	RAW_SHORT	2026-04-18 00:43:47.774
cmni6koo3009h708np33q8y6h	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.41290506	-122.20622074	5	0	34.3	292.15	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-03 00:43:57.796	2026-04-03 00:43:55.423	null	RAW_SHORT	2026-04-18 00:43:57.795
cmni6ksje009n708ng6v1jlne	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.41381696	-122.20823265	5	0	34.2	306.56	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-03 00:44:02.811	2026-04-03 00:44:01.424	null	RAW_SHORT	2026-04-18 00:44:02.81
cmni6kweq009t708nydnx0cwj	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.41511369	-122.2099019	5	0	34.21	320.98	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-03 00:44:07.827	2026-04-03 00:44:07.436	null	RAW_SHORT	2026-04-18 00:44:07.826
cmni6l44y00a4708nx0ee50hf	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.41652076	-122.21132892	5	0	33.46	317.11	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-03 00:44:17.843	2026-04-03 00:44:13.427	null	RAW_SHORT	2026-04-18 00:44:17.841
cmni6ljmg00aw708n6kl6dz0h	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.41894149	-122.21831725	5	0	33.84	280.55	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-03 00:44:37.912	2026-04-03 00:44:34.417	null	RAW_SHORT	2026-04-18 00:44:37.911
cmni6lni300b2708nua95l4lz	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.41935866	-122.22058933	5	0	34.5	285.82	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-03 00:44:42.939	2026-04-03 00:44:40.421	null	RAW_SHORT	2026-04-18 00:44:42.938
cmni6lrd700b8708n1lxjh5a2	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.42020951	-122.22268498	5	0	34.62	304.1	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-03 00:44:47.948	2026-04-03 00:44:46.411	null	RAW_SHORT	2026-04-18 00:44:47.947
cmni6lv8s00be708ndjuf681b	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.42140481	-122.22446999	5	0	34.11	311.13	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-03 00:44:52.973	2026-04-03 00:44:52.416	null	RAW_SHORT	2026-04-18 00:44:52.972
cmni6m2z800bp708nhjrnqxff	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.42261989	-122.22622172	5	0	34.07	310.78	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-03 00:45:02.997	2026-04-03 00:44:58.42	null	RAW_SHORT	2026-04-18 00:45:02.996
cmni6m6uk00bv708nz1x82b71	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.42384553	-122.22799483	5	0	35.16	310.78	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-03 00:45:08.012	2026-04-03 00:45:04.423	null	RAW_SHORT	2026-04-18 00:45:08.011
cmni6mapv00c1708n1snsuwkq	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.42510651	-122.22979057	5	0	35.88	312.89	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-03 00:45:13.027	2026-04-03 00:45:10.419	null	RAW_SHORT	2026-04-18 00:45:13.026
cmni6melb00c7708nar7hfpp3	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.42648156	-122.23149125	5	0	35.28	315.7	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-03 00:45:18.047	2026-04-03 00:45:16.419	null	RAW_SHORT	2026-04-18 00:45:18.045
cmni6migm00cd708nhpnhiuah	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.42782208	-122.23316965	5	0	34.57	313.24	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-03 00:45:23.062	2026-04-03 00:45:22.418	null	RAW_SHORT	2026-04-18 00:45:23.061
cmni6mq7t00co708n8vsoxbwk	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.42904315	-122.23491979	5	0	33.79	310.43	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-03 00:45:33.113	2026-04-03 00:45:28.422	null	RAW_SHORT	2026-04-18 00:45:33.112
cmni6mu2m00cu708n3z20ti3b	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.43039276	-122.23690446	5	0	32.63	310.78	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-03 00:45:38.111	2026-04-03 00:45:35.419	null	RAW_SHORT	2026-04-18 00:45:38.11
cmni6mxy200d0708nki9iykz5	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.43180499	-122.23884881	5	0	33.85	313.95	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-03 00:45:43.13	2026-04-03 00:45:42.425	null	RAW_SHORT	2026-04-18 00:45:43.129
cmni6n5oo00db708nws725p8x	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.43311575	-122.24044723	5	0	33.61	316.76	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-03 00:45:53.161	2026-04-03 00:45:48.416	null	RAW_SHORT	2026-04-18 00:45:53.16
cmni6n9k200dh708nqdnw7wep	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.43463237	-122.24223434	5	0	33.13	316.41	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-03 00:45:58.178	2026-04-03 00:45:55.418	null	RAW_SHORT	2026-04-18 00:45:58.177
cmni6ndfd00dn708n1yxx7lbm	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.43614275	-122.24402287	5	0	33.25	316.76	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-03 00:46:03.194	2026-04-03 00:46:02.488	null	RAW_SHORT	2026-04-18 00:46:03.193
cmni6nl6400dy708n7dyb40t8	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.43745284	-122.24560906	5	0	33.53	316.41	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-03 00:46:13.228	2026-04-03 00:46:08.417	null	RAW_SHORT	2026-04-18 00:46:13.227
cmni6np1r00e4708npw784e94	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.43875183	-122.24718427	5	0	33.22	315.7	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-03 00:46:18.255	2026-04-03 00:46:14.418	null	RAW_SHORT	2026-04-18 00:46:18.254
cmni6nswb00ea708niozauxm7	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.44020462	-122.24902871	5	0	32.84	314.3	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-03 00:46:23.243	2026-04-03 00:46:21.424	null	RAW_SHORT	2026-04-18 00:46:23.242
cmni6o0nr00el708nlbw7rb1a	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.4416554	-122.25091933	5	0	33.04	313.59	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-03 00:46:33.303	2026-04-03 00:46:28.42	null	RAW_SHORT	2026-04-18 00:46:33.301
cmni6o4i700er708nl1sjcl50	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.44296361	-122.25294834	5	0	32.96	301.99	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-03 00:46:38.287	2026-04-03 00:46:35.419	null	RAW_SHORT	2026-04-18 00:46:38.287
cmni6o8dr00ex708nd4lwexho	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.44384262	-122.25528153	5	0	32.69	288.63	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-03 00:46:43.312	2026-04-03 00:46:42.418	null	RAW_SHORT	2026-04-18 00:46:43.311
cmni6og4d00f8708nsu7iexgd	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.44422018	-122.2577904	5	0	32.25	274.22	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-03 00:46:53.342	2026-04-03 00:46:49.421	null	RAW_SHORT	2026-04-18 00:46:53.341
cmni6orqf00fp708n9yzzunut	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.4439248	-122.26291149	5	0	32.18	264.38	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-03 00:47:08.391	2026-04-03 00:47:03.418	null	RAW_SHORT	2026-04-18 00:47:08.391
cmni6ovlu00fv708nyuk4x8ie	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.44381697	-122.26544651	5	0	32.14	272.46	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-03 00:47:13.411	2026-04-03 00:47:10.422	null	RAW_SHORT	2026-04-18 00:47:13.41
cmni6p78b00gc708nd6uemcx8	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.44494848	-122.27035697	5	0	33.59	298.48	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-03 00:47:28.475	2026-04-03 00:47:24.417	null	RAW_SHORT	2026-04-18 00:47:28.474
cmni6peyg00go708nuexbyaq9	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.44721944	-122.27404475	5	0	35.05	311.48	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-03 00:47:38.489	2026-04-03 00:47:36.418	null	RAW_SHORT	2026-04-18 00:47:38.488
cmni6pufv00hb708n3nz6fxug	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.45094125	-122.27950028	5	0	34.77	309.73	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-03 00:47:58.555	2026-04-03 00:47:54.419	null	RAW_SHORT	2026-04-18 00:47:58.554
cmnj1x67e023ghw8y17u9yk4b	\N	alex@brspark.com	dev_szkcjr	cmnj1lkhy01n1hw8y4bohk7qw	OS_ACCEPT	\N	\N	\N	\N	\N	\N	GPS	\N	\N	UNKNOWN	1.0.0	26.3.1	Simulator iOS	f	f	5	2026-04-03 15:21:28.489	2026-04-03 15:21:27.835	{"previousState": "DISPATCHED"}	LEGAL	2031-04-03 15:21:28.488
cmnj1x67e023hhw8y8q833ohb	\N	alex@brspark.com	\N	\N	HEARTBEAT	-23.569983	-46.7851655	5	0	-1	-1	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-03 15:21:28.489	2026-04-03 15:21:27.581	null	RAW_SHORT	2026-04-18 15:21:28.488
cmnjl9ep200uorohkgz94epw3	\N	qualquecoisa@gmail.com	\N	\N	HEARTBEAT	-23.56719453129495	-46.7862439702355	7.928586564459389	788.3225873024778	-1	-1	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-04 00:22:52.07	2026-04-04 00:22:47.236	null	RAW_SHORT	2026-04-19 00:22:52.069
cmni6ojzq00fe708n4f149o0b	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.44414135	-122.2603566	5	0	32.45	264.02	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-03 00:46:58.359	2026-04-03 00:46:56.417	null	RAW_SHORT	2026-04-18 00:46:58.358
cmni6q27000hn708npj7ndmdc	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.45331094	-122.28309729	5	0	34.04	309.38	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-03 00:48:08.605	2026-04-03 00:48:06.417	null	RAW_SHORT	2026-04-18 00:48:08.604
cmnj1zn42026uhw8ytlzhwbdh	\N	alex@brspark.com	dev_szkcjr	cmnj1u3d401z3hw8yw2e5hqnc	OS_ACCEPT	\N	\N	\N	\N	\N	\N	GPS	\N	\N	UNKNOWN	1.0.0	26.3.1	Simulator iOS	f	f	-9	2026-04-03 15:23:23.714	2026-04-03 15:23:20.803	{"previousState": "DISPATCHED"}	LEGAL	2031-04-03 15:23:23.712
cmnj1zn42026vhw8ys6c46kk2	\N	alex@brspark.com	\N	\N	HEARTBEAT	-23.569983	-46.7851655	5	0	-1	-1	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-03 15:23:23.714	2026-04-03 15:23:20.024	null	RAW_SHORT	2026-04-18 15:23:23.712
cmnjl9ep200unrohklzbsl80f	\N	qualquecoisa@gmail.com	\N	\N	HEARTBEAT	-23.56719453129495	-46.7862439702355	7.928586564459389	788.3225873024778	-1	-1	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-04 00:22:52.07	2026-04-04 00:22:47.236	null	RAW_SHORT	2026-04-19 00:22:52.069
cmni6ozha00g1708n1r8q8new	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.44414998	-122.26795069	5	0	32.37	284.77	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-03 00:47:18.43	2026-04-03 00:47:17.421	null	RAW_SHORT	2026-04-18 00:47:18.429
cmni6pits00gu708n43lrw73h	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.44847416	-122.27582658	5	0	35.25	311.13	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-03 00:47:43.505	2026-04-03 00:47:42.422	null	RAW_SHORT	2026-04-18 00:47:43.504
cmnj2021g0280hw8yh6x7a25m	\N	alex@brspark.com	dev_szkcjr	cmnj1u3d401z3hw8yw2e5hqnc	OS_ACCEPT	\N	\N	\N	\N	\N	\N	GPS	\N	\N	UNKNOWN	1.0.0	26.3.1	Simulator iOS	f	f	7	2026-04-03 15:23:43.06	2026-04-03 15:23:40.736	{"previousState": "IDLE"}	LEGAL	2031-04-03 15:23:43.059
cmnj2021g0281hw8yxomhgh7x	\N	alex@brspark.com	\N	\N	HEARTBEAT	-23.569983	-46.7851655	5	0	-1	-1	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-03 15:23:43.06	2026-04-03 15:23:40.102	null	RAW_SHORT	2026-04-18 15:23:43.059
cmnjl9ep200uqrohkmwm5a3sm	\N	qualquecoisa@gmail.com	\N	\N	HEARTBEAT	-23.56719453129495	-46.7862439702355	7.928586564459389	788.3225873024778	-1	-1	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-04 00:22:52.07	2026-04-04 00:22:47.236	null	RAW_SHORT	2026-04-19 00:22:52.069
cmnjl9epz00utrohkzaj0wsx5	\N	qualquecoisa@gmail.com	\N	\N	HEARTBEAT	-23.56719453129495	-46.7862439702355	7.928586564459389	788.3225873024778	-1	-1	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-04 00:22:52.103	2026-04-04 00:22:47.236	null	RAW_SHORT	2026-04-19 00:22:52.103
cmnjl9eq000uurohkazcyo8od	\N	qualquecoisa@gmail.com	\N	\N	HEARTBEAT	-23.56719453129495	-46.7862439702355	7.928586564459389	788.3225873024778	-1	-1	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-04 00:22:52.105	2026-04-04 00:22:47.236	null	RAW_SHORT	2026-04-19 00:22:52.104
cmni6pb3d00gi708nz8fjxoxr	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.44598499	-122.27225807	5	0	34.36	309.73	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-03 00:47:33.481	2026-04-03 00:47:30.422	null	RAW_SHORT	2026-04-18 00:47:33.481
cmni6pmp500h0708ne4qkgkzw	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.44973334	-122.27765291	5	0	35.51	309.73	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-03 00:47:48.521	2026-04-03 00:47:48.421	null	RAW_SHORT	2026-04-18 00:47:48.52
cmni6q62200ht708n0auhomua	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.45448608	-122.28487643	5	0	34.38	309.73	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-03 00:48:13.61	2026-04-03 00:48:12.426	null	RAW_SHORT	2026-04-18 00:48:13.609
cmni6q9xb00hz708nzovhb4vo	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.45567627	-122.28668651	5	0	34.39	309.38	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-03 00:48:18.624	2026-04-03 00:48:18.42	null	RAW_SHORT	2026-04-18 00:48:18.623
cmnj20dnj028whw8yx83681sc	\N	alex@brspark.com	dev_szkcjr	cmnj1lkhy01n1hw8y4bohk7qw	OS_ACCEPT	\N	\N	\N	\N	\N	\N	GPS	\N	\N	UNKNOWN	1.0.0	26.3.1	Simulator iOS	f	f	5	2026-04-03 15:23:58.111	2026-04-03 15:23:57.052	{"previousState": "DISPATCHED"}	LEGAL	2031-04-03 15:23:58.111
cmnj20dnj028xhw8y8qcy3yw1	\N	alex@brspark.com	\N	\N	HEARTBEAT	-23.569983	-46.7851655	5	0	-1	-1	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-03 15:23:58.111	2026-04-03 15:23:56.152	null	RAW_SHORT	2026-04-18 15:23:58.111
cmnjlh0zz00vgrohkvi7hoyke	cmnjl5fzm00ugrohkuk34ncb6	qualquecoisa@gmail.com	dev_or2xj4	\N	SESSION_OPEN	\N	\N	\N	\N	\N	\N	GPS	\N	\N	UNKNOWN	1.0.0	26.4	iPhone 17 Pro Max	f	f	2	2026-04-04 00:28:47.565	2026-04-04 00:28:44.727	{}	OPERATIONAL	2026-10-01 00:28:47.564
cmnjlh0zz00vhrohksgleajl7	cmnjl5fzm00ugrohkuk34ncb6	qualquecoisa@gmail.com	dev_or2xj4	\N	SESSION_OPEN	\N	\N	\N	\N	\N	\N	GPS	\N	\N	UNKNOWN	1.0.0	26.4	iPhone 17 Pro Max	f	f	-2	2026-04-04 00:28:47.565	2026-04-04 00:28:44.844	{}	OPERATIONAL	2026-10-01 00:28:47.564
cmni6pybb00hh708nw0da8uw4	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.45213903	-122.28131706	5	0	34.62	309.38	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-03 00:48:03.575	2026-04-03 00:48:00.421	null	RAW_SHORT	2026-04-18 00:48:03.574
cmni6qho300ia708n2fq839li	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.45696847	-122.28836834	5	0	34.72	320.27	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-03 00:48:28.659	2026-04-03 00:48:24.421	null	RAW_SHORT	2026-04-18 00:48:28.659
cmni6qlje00ig708n9u92dbb3	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.45855399	-122.28964389	5	0	34.6	333.28	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-03 00:48:33.674	2026-04-03 00:48:30.421	null	RAW_SHORT	2026-04-18 00:48:33.673
cmni6qpey00im708nodu9ttl8	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.4603017	-122.29043087	5	0	34.21	346.64	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-03 00:48:38.698	2026-04-03 00:48:36.42	null	RAW_SHORT	2026-04-18 00:48:38.697
cmni6qta500is708no6q4vwht	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.46211156	-122.29069557	5	0	33.76	358.24	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-03 00:48:43.71	2026-04-03 00:48:42.428	null	RAW_SHORT	2026-04-18 00:48:43.708
cmni6r10s00j3708nmsyfv46d	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.46419317	-122.29077419	5	0	33.23	356.84	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-03 00:48:53.74	2026-04-03 00:48:49.424	null	RAW_SHORT	2026-04-18 00:48:53.739
cmni6r4vn00j9708nbj2skdi2	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.46598459	-122.29109271	5	0	33.28	348.05	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-03 00:48:58.74	2026-04-03 00:48:55.438	null	RAW_SHORT	2026-04-18 00:48:58.739
cmni6r8qz00jf708nb7of9ot7	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.46797307	-122.29193961	5	0	33.71	336.09	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-03 00:49:03.756	2026-04-03 00:49:02.428	null	RAW_SHORT	2026-04-18 00:49:03.755
cmni6rclt00jl708niqo5s4l6	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.46956224	-122.2930368	5	0	33.52	326.6	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-03 00:49:08.753	2026-04-03 00:49:08.422	null	RAW_SHORT	2026-04-18 00:49:08.753
cmni6rkcq00jw708nyhr54o55	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.47121917	-122.29465652	5	0	33.37	321.33	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-03 00:49:18.794	2026-04-03 00:49:15.419	null	RAW_SHORT	2026-04-18 00:49:18.793
cmni6ro7h00k2708ntcbltu4t	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.47263575	-122.29607826	5	0	33.62	321.33	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-03 00:49:23.789	2026-04-03 00:49:21.424	null	RAW_SHORT	2026-04-18 00:49:23.789
cmni6rs2z00k8708nmj0kafit	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.47407652	-122.29748533	5	0	33.71	324.84	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-03 00:49:28.811	2026-04-03 00:49:27.422	null	RAW_SHORT	2026-04-18 00:49:28.81
cmni6rztp00ko708nxc5r00zi	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.47596509	-122.29866961	5	0	33.64	339.61	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-03 00:49:38.845	2026-04-03 00:49:34.418	null	RAW_SHORT	2026-04-18 00:49:38.845
cmni6s3p600ku708nc2ciznyi	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.47775391	-122.29919189	5	0	34.28	352.27	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-03 00:49:43.866	2026-04-03 00:49:40.435	null	RAW_SHORT	2026-04-18 00:49:43.864
cmni6s7je00l0708n2o67g99m	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.47959504	-122.29920555	5	0	34.03	5.62	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-03 00:49:48.842	2026-04-03 00:49:46.417	null	RAW_SHORT	2026-04-18 00:49:48.842
cmni6sbes00l6708nbia4zmjr	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.48143034	-122.2989116	5	0	34.47	7.38	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-03 00:49:53.861	2026-04-03 00:49:52.424	null	RAW_SHORT	2026-04-18 00:49:53.86
cmni6sfa700lc708ns3467lgh	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.48327373	-122.29860566	5	0	34.03	7.03	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-03 00:49:58.879	2026-04-03 00:49:58.423	null	RAW_SHORT	2026-04-18 00:49:58.878
cmni6sn2n00ln708n2a804ilv	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.48532885	-122.29825278	5	0	32.86	7.03	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-03 00:50:08.975	2026-04-03 00:50:05.419	null	RAW_SHORT	2026-04-18 00:50:08.974
cmni6sqvq00lt708npv3stc27	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.48739461	-122.29817064	5	0	33.13	355.78	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-03 00:50:13.91	2026-04-03 00:50:12.426	null	RAW_SHORT	2026-04-18 00:50:13.909
cmni6sur600lz708nwq9b1qjo	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.48917912	-122.29858571	5	0	33.68	344.88	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-03 00:50:18.93	2026-04-03 00:50:18.419	null	RAW_SHORT	2026-04-18 00:50:18.928
cmni6t2i300ma708nek5vfh3z	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.49107368	-122.29964744	5	0	32.82	329.41	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-03 00:50:28.971	2026-04-03 00:50:25.427	null	RAW_SHORT	2026-04-18 00:50:28.97
cmni6t6d900mg708n8wcsizi0	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.49270362	-122.30124361	5	0	32.65	316.05	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-03 00:50:33.982	2026-04-03 00:50:32.422	null	RAW_SHORT	2026-04-18 00:50:33.981
cmni6te5l00mr708npe4tvcg9	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.49398501	-122.30329282	5	0	33.46	300.94	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-03 00:50:44.073	2026-04-03 00:50:39.424	null	RAW_SHORT	2026-04-18 00:50:44.072
cmni6thzm00mx708ncn8lriv5	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.49483455	-122.30570278	5	0	33.2	287.23	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-03 00:50:49.042	2026-04-03 00:50:46.419	null	RAW_SHORT	2026-04-18 00:50:49.04
cmni6tluk00n3708nevqojpk2	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.49543424	-122.30818156	5	0	32.45	286.88	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-03 00:50:54.045	2026-04-03 00:50:53.424	null	RAW_SHORT	2026-04-18 00:50:54.044
cmni6ttlb00ne708nq8f2dyrx	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.49605031	-122.31058583	5	0	31.95	291.09	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-03 00:51:04.08	2026-04-03 00:51:00.422	null	RAW_SHORT	2026-04-18 00:51:04.079
cmni6txgm00nk708na6fqs5s0	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.4969214	-122.3129258	5	0	33.06	299.18	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-03 00:51:09.094	2026-04-03 00:51:07.425	null	RAW_SHORT	2026-04-18 00:51:09.093
cmni6u1c100nq708nl3z2pkgq	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.49791545	-122.31482925	5	0	34.11	305.16	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-03 00:51:14.113	2026-04-03 00:51:13.439	null	RAW_SHORT	2026-04-18 00:51:14.112
cmni6u94100o1708npm4vfwa2	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.49896071	-122.3167052	5	0	33.94	304.45	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-03 00:51:24.194	2026-04-03 00:51:19.421	null	RAW_SHORT	2026-04-18 00:51:24.192
cmni6ucy600o7708nbevgmibw	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.4998836	-122.31865844	5	0	33.04	295.31	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-03 00:51:29.166	2026-04-03 00:51:25.422	null	RAW_SHORT	2026-04-18 00:51:29.165
cmni6ugtt00od708n345ejw61	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.50055478	-122.32105281	5	0	31.39	283.71	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-03 00:51:34.193	2026-04-03 00:51:32.422	null	RAW_SHORT	2026-04-18 00:51:34.192
cmni6uojo00oo708nz2wsl5pq	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.50081869	-122.32352505	5	0	31.73	273.52	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-03 00:51:44.197	2026-04-03 00:51:39.425	null	RAW_SHORT	2026-04-18 00:51:44.196
cmni6usik00ou708n8pk2h6nx	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.5009559	-122.32605421	5	0	32.35	276.33	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-03 00:51:49.339	2026-04-03 00:51:46.413	null	RAW_SHORT	2026-04-18 00:51:49.337
cmni6uw9r00p0708n4x0b53ax	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.50142772	-122.32853953	5	0	32.37	289.69	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-03 00:51:54.207	2026-04-03 00:51:53.422	null	RAW_SHORT	2026-04-18 00:51:54.206
cmni6v40h00pb708n17o1fcz1	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.50237035	-122.33083005	5	0	32.72	304.1	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-03 00:52:04.242	2026-04-03 00:52:00.418	null	RAW_SHORT	2026-04-18 00:52:04.241
cmni6v7vl00ph708n54uboz0h	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.5036348	-122.33291144	5	0	33.55	307.27	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-03 00:52:09.249	2026-04-03 00:52:07.427	null	RAW_SHORT	2026-04-18 00:52:09.248
cmni6vbqg00pn708nwder7mh6	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.50475667	-122.33470618	5	0	33.4	307.97	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-03 00:52:14.248	2026-04-03 00:52:13.426	null	RAW_SHORT	2026-04-18 00:52:14.247
cmni6vjgn00py708nrg5y5tpi	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.50587968	-122.33657258	5	0	34.8	307.27	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-03 00:52:24.263	2026-04-03 00:52:19.436	null	RAW_SHORT	2026-04-18 00:52:24.262
cmni6vnby00q4708nhmxh52ud	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.50702897	-122.33844744	5	0	35.11	307.62	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-03 00:52:29.279	2026-04-03 00:52:25.425	null	RAW_SHORT	2026-04-18 00:52:29.278
cmni6vr7f00qa708nbwwtyycz	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.50818584	-122.3403467	5	0	34.51	307.27	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-03 00:52:34.299	2026-04-03 00:52:31.43	null	RAW_SHORT	2026-04-18 00:52:34.298
cmni6vv2400qg708njfk2123g	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.50929124	-122.34215325	5	0	33.5	308.32	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-03 00:52:39.292	2026-04-03 00:52:37.425	null	RAW_SHORT	2026-04-18 00:52:39.291
cmni6w2rz00qr708nmi1fbpx2	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.51070418	-122.34409282	5	0	33.16	315.35	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-03 00:52:49.296	2026-04-03 00:52:44.426	null	RAW_SHORT	2026-04-18 00:52:49.295
cmni6w6na00qx708nsp58tgwq	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.51203087	-122.34564414	5	0	33.88	317.81	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-03 00:52:54.31	2026-04-03 00:52:50.422	null	RAW_SHORT	2026-04-18 00:52:54.309
cmni6wajh00r5708nebkmb0ru	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.51337465	-122.34718055	5	0	33.46	317.46	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-03 00:52:59.358	2026-04-03 00:52:56.423	null	RAW_SHORT	2026-04-18 00:52:59.357
cmni6wede00rb708nmm3lnj1s	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.51492464	-122.34894896	5	0	32.84	317.46	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-03 00:53:04.322	2026-04-03 00:53:03.421	null	RAW_SHORT	2026-04-18 00:53:04.321
cmni6wtuf00ry708ng0iizoma	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.51944944	-122.35370946	5	0	33.6	328.71	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-03 00:53:24.375	2026-04-03 00:53:23.43	null	RAW_SHORT	2026-04-18 00:53:24.374
cmni6x1l500s9708n4ro4lbr7	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.52106262	-122.35474966	5	0	33.36	336.09	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-03 00:53:34.41	2026-04-03 00:53:29.418	null	RAW_SHORT	2026-04-18 00:53:34.409
cmni6x5g800sf708ndvafdcli	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.52299544	-122.35580008	5	0	33.29	336.09	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-03 00:53:39.417	2026-04-03 00:53:36.42	null	RAW_SHORT	2026-04-18 00:53:39.416
cmni6xorw00t8708nscsjk5z7	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.52978642	-122.36025682	5	0	34.72	341.37	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-03 00:54:04.46	2026-04-03 00:54:01.441	null	RAW_SHORT	2026-04-18 00:54:04.46
cmni6z31k00vg708niud5dbny	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.54714002	-122.3717904	5	0	33.12	320.62	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-03 00:55:09.609	2026-04-03 00:55:07.472	null	RAW_SHORT	2026-04-18 00:55:09.608
cmni72k1t00zg708nd61o9gzg	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.586483	-122.40918282	5	0	34.43	310.08	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-03 00:57:51.617	2026-04-03 00:57:51.456	null	RAW_SHORT	2026-04-18 00:57:51.616
cmnj2351b02czhw8y4z9jy6ra	\N	alex@brspark.com	dev_szkcjr	cmnj1u3d401z3hw8yw2e5hqnc	OS_ACCEPT	\N	\N	\N	\N	\N	\N	GPS	\N	\N	UNKNOWN	1.0.0	26.3.1	Simulator iOS	f	f	6	2026-04-03 15:26:06.91	2026-04-03 15:26:03.152	{"previousState": "IDLE"}	LEGAL	2031-04-03 15:26:06.909
cmnj2351b02d0hw8yzxd1jk9s	\N	alex@brspark.com	\N	\N	HEARTBEAT	-23.569983	-46.7851655	5	0	-1	-1	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-03 15:26:06.91	2026-04-03 15:26:02.727	null	RAW_SHORT	2026-04-18 15:26:06.909
cmnj23l6n02e7hw8yttyqsy42	\N	alex@brspark.com	dev_szkcjr	cmnj1lkhy01n1hw8y4bohk7qw	OS_ACCEPT	\N	\N	\N	\N	\N	\N	GPS	\N	\N	UNKNOWN	1.0.0	26.3.1	Simulator iOS	f	f	-13	2026-04-03 15:26:27.839	2026-04-03 15:26:27.685	{"previousState": "DISPATCHED"}	LEGAL	2031-04-03 15:26:27.839
cmnj23l6n02e8hw8ytk1mrqfc	\N	alex@brspark.com	\N	\N	HEARTBEAT	-23.569983	-46.7851655	5	0	-1	-1	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-03 15:26:27.839	2026-04-03 15:26:26.825	null	RAW_SHORT	2026-04-18 15:26:27.839
cmnjlhkxb00vorohkzgql4s84	cmnjl5fzm00ugrohkuk34ncb6	qualquecoisa@gmail.com	dev_or2xj4	\N	SESSION_OPEN	\N	\N	\N	\N	\N	\N	GPS	\N	\N	UNKNOWN	1.0.0	26.4	iPhone 17 Pro Max	f	f	0	2026-04-04 00:29:13.391	2026-04-04 00:29:11.596	{}	OPERATIONAL	2026-10-01 00:29:13.391
cmni6wm4200rm708n38py39u6	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.51644813	-122.35068376	5	0	32.69	318.16	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-03 00:53:14.354	2026-04-03 00:53:10.421	null	RAW_SHORT	2026-04-18 00:53:14.353
cmni6wpz100rs708nze4g0jgh	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.51797837	-122.35239962	5	0	32.96	320.98	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-03 00:53:19.357	2026-04-03 00:53:17.423	null	RAW_SHORT	2026-04-18 00:53:19.357
cmni6x9aw00sl708nl6gdvlgn	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.52479646	-122.35715652	5	0	33.74	324.14	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-03 00:53:44.409	2026-04-03 00:53:43.424	null	RAW_SHORT	2026-04-18 00:53:44.408
cmni6xd6y00sr708n7et0zghi	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.52628731	-122.3584874	5	0	34.76	326.6	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-03 00:53:49.45	2026-04-03 00:53:49.425	null	RAW_SHORT	2026-04-18 00:53:49.449
cmni6xkwt00t2708nyb4iqk6k	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.52800506	-122.35949985	5	0	34.9	341.02	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-03 00:53:59.454	2026-04-03 00:53:55.44	null	RAW_SHORT	2026-04-18 00:53:59.453
cmni6xwi200tk708ncuyjoe05	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.53334395	-122.36177327	5	0	34.44	341.37	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-03 00:54:14.475	2026-04-03 00:54:13.428	null	RAW_SHORT	2026-04-18 00:54:14.474
cmni6yrg000uz708nq3i2ni0x	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.54412052	-122.36868826	5	0	33.3	320.27	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-03 00:54:54.576	2026-04-03 00:54:54.426	null	RAW_SHORT	2026-04-18 00:54:54.575
cmni6yz6v00va708nt4arbw2o	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.54574565	-122.37035517	5	0	33.09	320.62	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-03 00:55:04.616	2026-04-03 00:55:01.424	null	RAW_SHORT	2026-04-18 00:55:04.615
cmni70f1e00w8708nkoucmko4	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.55366378	-122.37799477	5	0	36.39	330.82	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-03 00:56:11.808	2026-04-03 00:55:34.421	null	RAW_SHORT	2026-04-18 00:56:11.806
cmni728gh00yy708nsjhxhnm8	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.58233106	-122.4046654	5	0	33.67	328.71	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-03 00:57:36.593	2026-04-03 00:57:33.436	null	RAW_SHORT	2026-04-18 00:57:36.593
cmnj239ka02dlhw8y4xnq7o1x	\N	alex@brspark.com	dev_szkcjr	cmnj1u3d401z3hw8yw2e5hqnc	OS_ACCEPT	\N	\N	\N	\N	\N	\N	GPS	\N	\N	UNKNOWN	1.0.0	26.3.1	Simulator iOS	f	f	1	2026-04-03 15:26:12.779	2026-04-03 15:26:10.119	{"previousState": "DISPATCHED"}	LEGAL	2031-04-03 15:26:12.778
cmnj239ka02dmhw8ylt05j1z9	\N	alex@brspark.com	\N	\N	HEARTBEAT	-23.569983	-46.7851655	5	0	-1	-1	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-03 15:26:12.779	2026-04-03 15:26:09.756	null	RAW_SHORT	2026-04-18 15:26:12.778
cmnj26f0z02izhw8ycxpfvwzm	\N	alex@brspark.com	dev_szkcjr	cmnj1u3d401z3hw8yw2e5hqnc	OS_ACCEPT	\N	\N	\N	\N	\N	\N	GPS	\N	\N	UNKNOWN	1.0.0	26.3.1	Simulator iOS	f	f	7	2026-04-03 15:28:39.827	2026-04-03 15:28:36.102	{"previousState": "IDLE"}	LEGAL	2031-04-03 15:28:39.826
cmnj26f0z02j0hw8yf1cgheuo	\N	alex@brspark.com	\N	\N	HEARTBEAT	-23.569983	-46.7851655	5	0	-1	-1	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-03 15:28:39.827	2026-04-03 15:28:35.351	null	RAW_SHORT	2026-04-18 15:28:39.826
cmnjlhv3v00vzrohk2rbvknh9	cmnhhqj5c000e3yrjmvwv50er	alex@brspark.com	dev_or2xj4	\N	SESSION_OPEN	\N	\N	\N	\N	\N	\N	GPS	\N	\N	UNKNOWN	1.0.0	26.4	iPhone 17 Pro Max	f	f	-15	2026-04-04 00:29:26.587	2026-04-04 00:29:24.264	{}	OPERATIONAL	2026-10-01 00:29:26.587
cmnjlijye00yarohkf4bw5z25	cmnhhqj5c000e3yrjmvwv50er	alex@brspark.com	dev_or2xj4	cmnj3xzrq016shojah2dyzntn	TRANSIT_START	-23.56713016945786	-46.78618701739954	\N	\N	\N	\N	GPS	\N	\N	UNKNOWN	1.0.0	26.4	iPhone 17 Pro Max	f	f	0	2026-04-04 00:29:58.79	2026-04-04 00:29:58.092	{"lat": -23.56713016945786, "lng": -46.78618701739954, "previousState": "DISPATCHED"}	LEGAL	2031-04-04 00:29:58.789
cmnjlijye00ybrohkxa3fwp77	\N	alex@brspark.com	\N	\N	HEARTBEAT	-23.56713016945786	-46.78618701739955	7.566294477092445	788.3229854615049	-1	-1	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-04 00:29:58.79	2026-04-04 00:29:58.073	null	RAW_SHORT	2026-04-19 00:29:58.789
cmni6xsn500te708nw2nbeoee	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.53157805	-122.36101546	5	0	34.59	341.37	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-03 00:54:09.474	2026-04-03 00:54:07.427	null	RAW_SHORT	2026-04-18 00:54:09.473
cmni6y0de00tq708n0kuspr1y	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.5350767	-122.36255572	5	0	34.01	338.91	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-03 00:54:19.491	2026-04-03 00:54:19.425	null	RAW_SHORT	2026-04-18 00:54:19.49
cmnj2ak5m02p5hw8y4irk6xrf	\N	alex@brspark.com	dev_szkcjr	cmnj1u3d401z3hw8yw2e5hqnc	OS_ACCEPT	\N	\N	\N	\N	\N	\N	GPS	\N	\N	UNKNOWN	1.0.0	26.3.1	Simulator iOS	f	f	4	2026-04-03 15:31:53.099	2026-04-03 15:31:48.236	{"previousState": "IDLE"}	LEGAL	2031-04-03 15:31:53.098
cmnj2ak5m02p6hw8yzdj0z3o7	\N	alex@brspark.com	\N	\N	HEARTBEAT	-23.569983	-46.7851655	5	0	-1	-1	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-03 15:31:53.099	2026-04-03 15:31:48.322	null	RAW_SHORT	2026-04-18 15:31:53.098
cmnjliee700xtrohkz3srm6pe	cmnhhqj5c000e3yrjmvwv50er	alex@brspark.com	dev_or2xj4	cmnj3xzrq016shojah2dyzntn	OS_ACCEPT	\N	\N	\N	\N	\N	\N	GPS	\N	\N	UNKNOWN	1.0.0	26.4	iPhone 17 Pro Max	f	f	6	2026-04-04 00:29:51.583	2026-04-04 00:29:51.343	{"previousState": "IDLE"}	LEGAL	2031-04-04 00:29:51.582
cmnjliee700xurohk2lh5kp8r	\N	alex@brspark.com	\N	\N	HEARTBEAT	-23.56719453129495	-46.7862439702355	7.928586564459389	788.3229854615049	-1	-1	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-04 00:29:51.583	2026-04-04 00:29:50.762	null	RAW_SHORT	2026-04-19 00:29:51.582
cmni6y84600u1708n1c9s551q	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.53700269	-122.36361964	5	0	33.04	334.34	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-03 00:54:29.526	2026-04-03 00:54:26.445	null	RAW_SHORT	2026-04-18 00:54:29.525
cmni6yc4v00uc708nvvo6el3l	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.53886398	-122.36474189	5	0	32.8	334.69	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-03 00:54:34.736	2026-04-03 00:54:33.423	null	RAW_SHORT	2026-04-18 00:54:34.735
cmni6yjpq00un708n7be2574s	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.54071957	-122.36586045	5	0	32.39	333.98	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-03 00:54:44.558	2026-04-03 00:54:40.426	null	RAW_SHORT	2026-04-18 00:54:44.557
cmni6ynl200ut708nqs7657gv	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.54248605	-122.36713492	5	0	31.9	326.95	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-03 00:54:49.575	2026-04-03 00:54:47.441	null	RAW_SHORT	2026-04-18 00:54:49.574
cmni6z77y00vm708nfx5l6bke	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.54872751	-122.37343644	5	0	32.67	320.62	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-03 00:55:15.022	2026-04-03 00:55:14.421	null	RAW_SHORT	2026-04-18 00:55:15.014
cmni6zihi00vx708n8vm0ltft	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.55031944	-122.37509639	5	0	33.06	320.62	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-03 00:55:29.622	2026-04-03 00:55:21.421	null	RAW_SHORT	2026-04-18 00:55:29.621
cmni70mhy00wj708na4kdlb3k	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.5648001	-122.38755181	5	0	33.01	318.52	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-03 00:56:21.478	2026-04-03 00:56:17.428	null	RAW_SHORT	2026-04-18 00:56:21.476
cmni70qd300wp708nluk62yuo	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.56603212	-122.38961644	5	0	32.98	296.72	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-03 00:56:26.488	2026-04-03 00:56:24.42	null	RAW_SHORT	2026-04-18 00:56:26.487
cmni70u8600wv708nu3j2p9h7	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.5668706	-122.39203496	5	0	33.66	296.37	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-03 00:56:31.494	2026-04-03 00:56:31.425	null	RAW_SHORT	2026-04-18 00:56:31.493
cmni711yy00x6708ne07trg2h	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.56787978	-122.39391678	5	0	33.87	311.84	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-03 00:56:41.531	2026-04-03 00:56:37.425	null	RAW_SHORT	2026-04-18 00:56:41.53
cmni715tt00xc708npxsktmkz	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.56925705	-122.39539937	5	0	33.5	323.09	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-03 00:56:46.529	2026-04-03 00:56:43.424	null	RAW_SHORT	2026-04-18 00:56:46.528
cmni719ot00xi708nrmuuok58	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.57070804	-122.39676126	5	0	33.52	322.73	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-03 00:56:51.534	2026-04-03 00:56:49.426	null	RAW_SHORT	2026-04-18 00:56:51.533
cmni71djh00xo708nt7r9g6h9	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.57216692	-122.39813942	5	0	33.46	322.73	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-03 00:56:56.526	2026-04-03 00:56:55.422	null	RAW_SHORT	2026-04-18 00:56:56.525
cmni71heb00xu708nsvlg8f90	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.57361598	-122.39950986	5	0	33.29	325.2	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-03 00:57:01.523	2026-04-03 00:57:01.426	null	RAW_SHORT	2026-04-18 00:57:01.523
cmni71p4m00y5708n9okjtdkw	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.57525716	-122.40055701	5	0	34.68	340.31	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-03 00:57:11.542	2026-04-03 00:57:07.422	null	RAW_SHORT	2026-04-18 00:57:11.542
cmni71t0200yb708ngtme4v1j	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.57701769	-122.40131859	5	0	34.32	341.37	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-03 00:57:16.562	2026-04-03 00:57:13.424	null	RAW_SHORT	2026-04-18 00:57:16.561
cmni71wv200yh708nkgqwty9k	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.57874084	-122.40206793	5	0	33.16	339.26	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-03 00:57:21.566	2026-04-03 00:57:19.437	null	RAW_SHORT	2026-04-18 00:57:21.565
cmni720qh00yn708nbhhyqfq7	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.58054794	-122.40328649	5	0	32.66	328.36	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-03 00:57:26.586	2026-04-03 00:57:26.426	null	RAW_SHORT	2026-04-18 00:57:26.585
cmni72cbc00z4708nlwgbtso8	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.58387392	-122.40592478	5	0	33.91	324.84	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-03 00:57:41.592	2026-04-03 00:57:39.424	null	RAW_SHORT	2026-04-18 00:57:41.591
cmni72g6l00za708ns462sdlr	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.58524046	-122.40743897	5	0	34.16	315.35	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-03 00:57:46.605	2026-04-03 00:57:45.423	null	RAW_SHORT	2026-04-18 00:57:46.605
cmni72rs300zr708nsbog0qi7	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.58774183	-122.41088075	5	0	34.22	317.46	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-03 00:58:01.636	2026-04-03 00:57:57.427	null	RAW_SHORT	2026-04-18 00:58:01.635
cmni72vn500zx708nlp412trp	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.58918792	-122.41234263	5	0	34.18	322.03	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-03 00:58:06.641	2026-04-03 00:58:03.424	null	RAW_SHORT	2026-04-18 00:58:06.64
cmni72zi60103708nxrs7dgz5	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.59064415	-122.41377627	5	0	35.15	320.98	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-03 00:58:11.647	2026-04-03 00:58:09.423	null	RAW_SHORT	2026-04-18 00:58:11.646
cmni733dx0109708nepooxiat	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.59211048	-122.41521352	5	0	34.35	321.68	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-03 00:58:16.678	2026-04-03 00:58:15.426	null	RAW_SHORT	2026-04-18 00:58:16.677
cmni7378k010f708nmjep6m5g	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.59355783	-122.41664699	5	0	34.59	321.68	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-03 00:58:21.669	2026-04-03 00:58:21.426	null	RAW_SHORT	2026-04-18 00:58:21.668
cmni73ezd010q708nmx6zslip	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.59501364	-122.41806387	5	0	33.77	322.03	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-03 00:58:31.705	2026-04-03 00:58:27.426	null	RAW_SHORT	2026-04-18 00:58:31.704
cmni73iu1010w708n5dgd8wuy	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.59641538	-122.41948988	5	0	33.23	319.92	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-03 00:58:36.697	2026-04-03 00:58:33.427	null	RAW_SHORT	2026-04-18 00:58:36.696
cmni73mpf0112708nb3dpyb3r	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.59774048	-122.42107188	5	0	33.88	315.35	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-03 00:58:41.716	2026-04-03 00:58:39.424	null	RAW_SHORT	2026-04-18 00:58:41.715
cmni73qlt0118708ng3rncnib	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.59901855	-122.42267333	5	0	33.71	315.35	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-03 00:58:46.769	2026-04-03 00:58:45.429	null	RAW_SHORT	2026-04-18 00:58:46.768
cmni73uft011e708nn2zt43qh	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.60033635	-122.42425684	5	0	33.66	316.05	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-03 00:58:51.737	2026-04-03 00:58:51.426	null	RAW_SHORT	2026-04-18 00:58:51.737
cmni7425y011p708n6rksk0d6	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.60166698	-122.42583381	5	0	34.11	318.87	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-03 00:59:01.751	2026-04-03 00:58:57.423	null	RAW_SHORT	2026-04-18 00:59:01.75
cmni7460w011v708nfwxvc3w9	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.60319764	-122.4270926	5	0	33.98	333.63	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-03 00:59:06.753	2026-04-03 00:59:03.421	null	RAW_SHORT	2026-04-18 00:59:06.752
cmni749vw0121708nz4dexxm1	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.60520008	-122.42789551	5	0	33.24	348.75	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-03 00:59:11.757	2026-04-03 00:59:10.434	null	RAW_SHORT	2026-04-18 00:59:11.756
cmni74hm9012c708nw29thvvc	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.60726366	-122.4279598	5	0	32.56	3.52	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-03 00:59:21.777	2026-04-03 00:59:17.427	null	RAW_SHORT	2026-04-18 00:59:21.776
cmni74lhl012i708nboaskzx3	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.60930046	-122.42741623	5	0	33.22	15.82	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-03 00:59:26.793	2026-04-03 00:59:24.438	null	RAW_SHORT	2026-04-18 00:59:26.792
cmni74pcx012o708ne9yf0b52	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.61124377	-122.42641702	5	0	33.45	26.37	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-03 00:59:31.81	2026-04-03 00:59:31.442	null	RAW_SHORT	2026-04-18 00:59:31.809
cmni74x350134708nut5o5jmy	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.61306712	-122.42512118	5	0	32.76	29.53	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-03 00:59:41.826	2026-04-03 00:59:38.443	null	RAW_SHORT	2026-04-18 00:59:41.825
cmni750ya013a708nb5uulbbe	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.61502727	-122.42422365	5	0	33.57	10.9	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-03 00:59:46.834	2026-04-03 00:59:45.437	null	RAW_SHORT	2026-04-18 00:59:46.834
cmni758oo013l708nj6of7w7w	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.6171207	-122.42417176	5	0	33.32	351.91	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-03 00:59:56.856	2026-04-03 00:59:52.425	null	RAW_SHORT	2026-04-18 00:59:56.855
cmni75cjo013r708n1jxk2n2b	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.61887059	-122.42481583	5	0	33.87	337.15	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-03 01:00:01.861	2026-04-03 00:59:58.425	null	RAW_SHORT	2026-04-18 01:00:01.86
cmni75geu013x708ngylxi69q	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.62053444	-122.42588653	5	0	35.26	332.58	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-03 01:00:06.871	2026-04-03 01:00:04.429	null	RAW_SHORT	2026-04-18 01:00:06.87
cmni75k9x0143708nvn725f9n	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.62223282	-122.42696981	5	0	35.23	332.58	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-03 01:00:11.877	2026-04-03 01:00:10.425	null	RAW_SHORT	2026-04-18 01:00:11.877
cmni75o4v0149708nxhcdul9u	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.62390061	-122.42805007	5	0	34.22	332.93	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-03 01:00:16.879	2026-04-03 01:00:16.422	null	RAW_SHORT	2026-04-18 01:00:16.878
cmni75vve014k708n25x70nxl	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.62552984	-122.42915698	5	0	34.46	328.71	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-03 01:00:26.906	2026-04-03 01:00:22.426	null	RAW_SHORT	2026-04-18 01:00:26.905
cmni77igu016z708nyo6u80pt	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.64341758	-122.44610972	5	0	33.23	304.45	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-03 01:01:42.847	2026-04-03 01:01:37.425	null	RAW_SHORT	2026-04-18 01:01:42.846
cmni77plm017b708nu95xotxs	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.64593185	-122.44975467	5	0	32.66	327.66	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-03 01:01:52.091	2026-04-03 01:01:50.435	null	RAW_SHORT	2026-04-18 01:01:52.09
cmni78s8v018w708n8pisie4p	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.65707161	-122.46013281	5	0	33.49	314.65	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-03 01:02:42.175	2026-04-03 01:02:38.423	null	RAW_SHORT	2026-04-18 01:02:42.175
cmni78zz60198708nb0ayztyp	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.6598153	-122.46360669	5	0	33.4	315.7	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-03 01:02:52.194	2026-04-03 01:02:51.44	null	RAW_SHORT	2026-04-18 01:02:52.193
cmni7aadr01b5708npf1vpwi0	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.67602054	-122.47012957	5	0	32.22	326.95	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-03 01:03:52.336	2026-04-03 01:03:49.432	null	RAW_SHORT	2026-04-18 01:03:52.335
cmnj2badw02qlhw8y6hbor4mj	\N	alex@brspark.com	dev_szkcjr	cmnj1u3d401z3hw8yw2e5hqnc	OS_ACCEPT	\N	\N	\N	\N	\N	\N	GPS	\N	\N	UNKNOWN	1.0.0	26.3.1	Simulator iOS	f	f	5	2026-04-03 15:32:27.093	2026-04-03 15:32:24.069	{"previousState": "IDLE"}	LEGAL	2031-04-03 15:32:27.091
cmnj2badw02qmhw8y9ortqeqi	\N	alex@brspark.com	\N	\N	HEARTBEAT	-23.569983	-46.7851655	5	0	-1	-1	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-03 15:32:27.093	2026-04-03 15:32:24.506	null	RAW_SHORT	2026-04-18 15:32:27.091
cmnjljwf2011urohkvyky4f3l	cmnhhqj5c000e3yrjmvwv50er	alex@brspark.com	dev_or2xj4	cmnj3xzrq016shojah2dyzntn	SESSION_CLOSE	\N	\N	\N	\N	\N	\N	GPS	\N	\N	UNKNOWN	1.0.0	26.4	iPhone 17 Pro Max	f	f	-39	2026-04-04 00:31:01.598	2026-04-04 00:31:01.254	{"previousState": "IN_TRANSIT"}	OPERATIONAL	2026-10-01 00:31:01.597
cmnjljwf2011vrohk3h9krcjx	\N	alex@brspark.com	\N	\N	HEARTBEAT	-23.56714282825717	-46.786178765571	2.175314176564542	790.3258958710358	0.02581261513937865	-1	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-04 00:31:01.598	2026-04-04 00:31:00.999	null	RAW_SHORT	2026-04-19 00:31:01.597
cmni75zqz014q708nl60n51l3	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.62706302	-122.43053069	5	0	34.53	321.33	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-03 01:00:31.931	2026-04-03 01:00:28.429	null	RAW_SHORT	2026-04-18 01:00:31.93
cmni763m4014w708nxj9mrgsp	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.62836385	-122.4321489	5	0	33.99	313.24	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-03 01:00:36.941	2026-04-03 01:00:34.426	null	RAW_SHORT	2026-04-18 01:00:36.94
cmni76my1015p708n3gcnmk7b	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.63377168	-122.43824188	5	0	34.43	333.28	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-03 01:01:01.993	2026-04-03 01:00:58.48	null	RAW_SHORT	2026-04-18 01:01:01.993
cmni76uo70161708npt2ig51t	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.63721702	-122.43994642	5	0	33.36	335.39	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-03 01:01:12.008	2026-04-03 01:01:10.428	null	RAW_SHORT	2026-04-18 01:01:12.007
cmni77a58016o708nkxmcat9f	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.64209642	-122.44410611	5	0	32.66	320.27	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-03 01:01:32.06	2026-04-03 01:01:30.444	null	RAW_SHORT	2026-04-18 01:01:32.06
cmni77xc0017m708niqosp6uu	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.64777453	-122.45090651	5	0	32.72	334.69	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-03 01:02:02.112	2026-04-03 01:01:57.428	null	RAW_SHORT	2026-04-18 01:02:02.112
cmni79fg0019v708nvebfvu2z	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.66543696	-122.46553922	5	0	33.59	360	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-03 01:03:12.24	2026-04-03 01:03:11.423	null	RAW_SHORT	2026-04-18 01:03:12.24
cmni7a6im01az708naavwlvbt	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.67428347	-122.46872091	5	0	32.85	326.6	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-03 01:03:47.326	2026-04-03 01:03:42.429	null	RAW_SHORT	2026-04-18 01:03:47.325
cmnj2dbw602s1hw8y0o2nvk4t	\N	alex@brspark.com	dev_szkcjr	cmnj1u3d401z3hw8yw2e5hqnc	OS_ACCEPT	\N	\N	\N	\N	\N	\N	GPS	\N	\N	UNKNOWN	1.0.0	26.3.1	Simulator iOS	f	f	6	2026-04-03 15:34:02.355	2026-04-03 15:33:58.052	{"previousState": "IDLE"}	LEGAL	2031-04-03 15:34:02.353
cmnj2dbw602s2hw8yo50v1f2i	\N	alex@brspark.com	\N	\N	HEARTBEAT	-23.569983	-46.7851655	5	0	-1	-1	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-03 15:34:02.355	2026-04-03 15:33:58.182	null	RAW_SHORT	2026-04-18 15:34:02.353
cmnjlpwnc01ehrohkuvqgt7x9	cmnhhqj5c000e3yrjmvwv50er	alex@brspark.com	dev_or2xj4	cmnjkskbz00m2rohksun8q8vw	OS_ACCEPT	\N	\N	\N	\N	\N	\N	GPS	\N	\N	UNKNOWN	1.0.0	26.4	iPhone 17 Pro Max	f	f	5	2026-04-04 00:35:41.833	2026-04-04 00:35:40.61	{"previousState": "IDLE"}	LEGAL	2031-04-04 00:35:41.83
cmnjlpwnd01eirohk9ajkvrv7	\N	alex@brspark.com	\N	\N	HEARTBEAT	-23.56713790975786	-46.7861819757015	2	788.4141334205879	-1	-1	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-04 00:35:41.833	2026-04-04 00:35:39.327	null	RAW_SHORT	2026-04-19 00:35:41.83
cmnjlpwnd01ejrohkdw6r7k44	\N	alex@brspark.com	\N	\N	HEARTBEAT	-23.56713790975786	-46.7861819757015	2	788.4141334205879	-1	-1	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-04 00:35:41.833	2026-04-04 00:35:40.614	null	RAW_SHORT	2026-04-19 00:35:41.83
cmni767h30152708nteae6846	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.62961128	-122.43380726	5	0	33.56	313.24	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-03 01:00:41.943	2026-04-03 01:00:40.437	null	RAW_SHORT	2026-04-18 01:00:41.943
cmni76j2o015j708nyd85q7ax	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.63219119	-122.43702466	5	0	33.85	320.27	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-03 01:00:56.976	2026-04-03 01:00:52.422	null	RAW_SHORT	2026-04-18 01:00:56.976
cmni76qt5015v708nhvrsgtft	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.63551579	-122.43911745	5	0	34.78	339.61	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-03 01:01:07.002	2026-04-03 01:01:04.422	null	RAW_SHORT	2026-04-18 01:01:07.001
cmni7769t016i708nequ9feid	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.64045755	-122.44257364	5	0	32.26	325.2	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-03 01:01:27.042	2026-04-03 01:01:23.428	null	RAW_SHORT	2026-04-18 01:01:27.041
cmni77lv50175708nk2i3kggp	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.64442776	-122.44799045	5	0	33.18	305.86	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-03 01:01:47.249	2026-04-03 01:01:43.427	null	RAW_SHORT	2026-04-18 01:01:47.248
cmni79ys801ao708n79npvxxu	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.67252508	-122.46730663	5	0	33.32	331.52	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-03 01:03:37.305	2026-04-03 01:03:35.432	null	RAW_SHORT	2026-04-18 01:03:37.304
cmni7alzk01bm708nn0ad8fgj	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.67977287	-122.47164527	5	0	32.79	1.41	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-03 01:04:07.377	2026-04-03 01:04:03.433	null	RAW_SHORT	2026-04-18 01:04:07.376
cmni7apud01bs708n31ruf3co	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.681853	-122.47152482	5	0	33	2.46	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-03 01:04:12.374	2026-04-03 01:04:10.445	null	RAW_SHORT	2026-04-18 01:04:12.373
cmni7b52u01cf708n391nop4c	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.6879624	-122.47079987	5	0	33.26	15.82	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-03 01:04:32.119	2026-04-03 01:04:31.448	null	RAW_SHORT	2026-04-18 01:04:32.118
cmnj2f1uu02ubhw8ymo4b0nie	\N	alex@brspark.com	dev_szkcjr	cmnj1u3d401z3hw8yw2e5hqnc	OS_ACCEPT	\N	\N	\N	\N	\N	\N	GPS	\N	\N	UNKNOWN	1.0.0	26.3.1	Simulator iOS	f	f	-6	2026-04-03 15:35:22.662	2026-04-03 15:35:21.103	{"previousState": "DISPATCHED"}	LEGAL	2031-04-03 15:35:22.662
cmnj2f1uu02uchw8yv3gradyy	\N	alex@brspark.com	\N	\N	HEARTBEAT	-23.569983	-46.7851655	5	0	-1	-1	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-03 15:35:22.662	2026-04-03 15:35:20.56	null	RAW_SHORT	2026-04-18 15:35:22.662
cmnjlpz3y01ekrohk7sly7w9u	cmnhhqj5c000e3yrjmvwv50er	alex@brspark.com	dev_or2xj4	cmnjkskbz00m2rohksun8q8vw	TRANSIT_START	-23.56713791222812	-46.78618197134462	\N	\N	\N	\N	GPS	\N	\N	UNKNOWN	1.0.0	26.4	iPhone 17 Pro Max	f	f	5	2026-04-04 00:35:45.022	2026-04-04 00:35:43.642	{"lat": -23.56713791222812, "lng": -46.78618197134462, "previousState": "DISPATCHED"}	LEGAL	2031-04-04 00:35:45.021
cmnjlpz3y01elrohkoa413jwi	\N	alex@brspark.com	\N	\N	HEARTBEAT	-23.56713791222812	-46.78618197134462	2.000256262803074	788.4137352615608	-1	-1	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-04 00:35:45.022	2026-04-04 00:35:43.618	null	RAW_SHORT	2026-04-19 00:35:45.021
cmnjlrsr401eorohkly1jovz0	cmnhhqj5c000e3yrjmvwv50er	alex@brspark.com	dev_or2xj4	cmnj0xh1v0001hw8ycw1mvicf	OS_ACCEPT	\N	\N	\N	\N	\N	\N	GPS	\N	\N	UNKNOWN	1.0.0	26.4	iPhone 17 Pro Max	f	f	-32	2026-04-04 00:37:10.096	2026-04-04 00:37:07.995	{"previousState": "DISPATCHED"}	LEGAL	2031-04-04 00:37:10.095
cmnjlrsr401eprohk3myv40vv	\N	alex@brspark.com	\N	\N	HEARTBEAT	-23.56714797556366	-46.78616963261482	2	790.5579862785339	-1	-1	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-04 00:37:10.096	2026-04-04 00:37:08.007	null	RAW_SHORT	2026-04-19 00:37:10.095
cmni76bc90158708ngwy0a5jd	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.63086526	-122.43544978	5	0	33.47	313.59	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-03 01:00:46.953	2026-04-03 01:00:46.426	null	RAW_SHORT	2026-04-18 01:00:46.952
cmni78180017s708nqhy5724x	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.64960837	-122.4520198	5	0	32.15	334.69	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-03 01:02:07.152	2026-04-03 01:02:04.441	null	RAW_SHORT	2026-04-18 01:02:07.151
cmni78526017y708n2nrt44f9	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.65141777	-122.45317751	5	0	31.84	329.77	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-03 01:02:12.127	2026-04-03 01:02:11.419	null	RAW_SHORT	2026-04-18 01:02:12.126
cmnj2f9ip02ushw8y4rq3av5e	\N	alex@brspark.com	dev_szkcjr	cmnj1lkhy01n1hw8y4bohk7qw	OS_ACCEPT	\N	\N	\N	\N	\N	\N	GPS	\N	\N	UNKNOWN	1.0.0	26.3.1	Simulator iOS	f	f	1	2026-04-03 15:35:32.593	2026-04-03 15:35:29.786	{"previousState": "DISPATCHED"}	LEGAL	2031-04-03 15:35:32.592
cmnj2f9iq02uthw8yeie01htg	\N	alex@brspark.com	\N	\N	HEARTBEAT	-23.569983	-46.7851655	5	0	-1	-1	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-03 15:35:32.593	2026-04-03 15:35:29.821	null	RAW_SHORT	2026-04-18 15:35:32.592
cmnjlrl2a01emrohkaa3zrkkt	cmnhhqj5c000e3yrjmvwv50er	alex@brspark.com	dev_or2xj4	cmnj0xh1v0001hw8ycw1mvicf	OS_ACCEPT	\N	\N	\N	\N	\N	\N	GPS	\N	\N	UNKNOWN	1.0.0	26.4	iPhone 17 Pro Max	f	f	-12	2026-04-04 00:37:00.13	2026-04-04 00:36:57.761	{"previousState": "IN_TRANSIT"}	LEGAL	2031-04-04 00:37:00.129
cmnjlrl2a01enrohke5g5pbkz	\N	alex@brspark.com	\N	\N	HEARTBEAT	-23.56714815320553	-46.78616946155719	2	790.4911705227569	0.07605777847559103	-1	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-04 00:37:00.13	2026-04-04 00:36:56.999	null	RAW_SHORT	2026-04-19 00:37:00.129
cmnjlrwmk01eqrohkweefurud	cmnhhqj5c000e3yrjmvwv50er	alex@brspark.com	dev_or2xj4	cmnj3ycod0179hojan64s2qh5	OS_ACCEPT	\N	\N	\N	\N	\N	\N	GPS	\N	\N	UNKNOWN	1.0.0	26.4	iPhone 17 Pro Max	f	f	7	2026-04-04 00:37:15.116	2026-04-04 00:37:12.289	{"previousState": "DISPATCHED"}	LEGAL	2031-04-04 00:37:15.115
cmnjlrwmk01errohktoqi5sh2	\N	alex@brspark.com	\N	\N	HEARTBEAT	-23.56714797801392	-46.78616962828255	2.00005049319832	790.5575881195068	-1	-1	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-04 00:37:15.116	2026-04-04 00:37:08.023	null	RAW_SHORT	2026-04-19 00:37:15.115
cmnjlrwmk01esrohk5xaslzmj	\N	alex@brspark.com	\N	\N	HEARTBEAT	-23.56714797801392	-46.78616962828255	2.095014	790.52	-1	-1	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-04 00:37:15.116	2026-04-04 00:37:12.31	null	RAW_SHORT	2026-04-19 00:37:15.115
cmnjls0h901etrohk3eh3kg7o	cmnhhqj5c000e3yrjmvwv50er	alex@brspark.com	dev_or2xj4	cmnjkskbz00m2rohksun8q8vw	OS_ACCEPT	\N	\N	\N	\N	\N	\N	GPS	\N	\N	UNKNOWN	1.0.0	26.4	iPhone 17 Pro Max	f	f	-36	2026-04-04 00:37:20.109	2026-04-04 00:37:17.921	{"previousState": "DISPATCHED"}	LEGAL	2031-04-04 00:37:20.108
cmnjls0h901eurohkszcuwoj1	\N	alex@brspark.com	\N	\N	HEARTBEAT	-23.56714797801309	-46.78616962828337	2.000500695653537	790.5575881195068	-1	-1	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-04 00:37:20.109	2026-04-04 00:37:12.328	null	RAW_SHORT	2026-04-19 00:37:20.108
cmnjls0h901evrohkla42rfs2	\N	alex@brspark.com	\N	\N	HEARTBEAT	-23.56714797801309	-46.78616962828337	2.095014	790.52	-1	-1	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-04 00:37:20.109	2026-04-04 00:37:16.801	null	RAW_SHORT	2026-04-19 00:37:20.108
cmnjls0h901ewrohk1mfrcuxz	\N	alex@brspark.com	\N	\N	HEARTBEAT	-23.56714797801166	-46.78616962828475	2.001269812946094	790.5579862785339	-1	-1	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-04 00:37:20.109	2026-04-04 00:37:17.933	null	RAW_SHORT	2026-04-19 00:37:20.108
cmnjlsz7o01exrohk0l89z01m	cmnhhqj5c000e3yrjmvwv50er	alex@brspark.com	dev_or2xj4	cmnj0xh1v0001hw8ycw1mvicf	OS_ACCEPT	\N	\N	\N	\N	\N	\N	GPS	\N	\N	UNKNOWN	1.0.0	26.4	iPhone 17 Pro Max	f	f	8	2026-04-04 00:38:05.124	2026-04-04 00:38:04.494	{"previousState": "DISPATCHED"}	LEGAL	2031-04-04 00:38:05.123
cmnjlsz7o01eyrohkqbbqfwkp	\N	alex@brspark.com	\N	\N	HEARTBEAT	-23.56716109207914	-46.78615411967298	2.000420341095792	790.5579862785339	0.01684269989471983	-1	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-04 00:38:05.124	2026-04-04 00:38:02.833	null	RAW_SHORT	2026-04-19 00:38:05.123
cmnjlsz7o01ezrohkhkkjrdo2	\N	alex@brspark.com	\N	\N	HEARTBEAT	-23.56716109207914	-46.78615411967298	2.095014	790.52	0	-1	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-04 00:38:05.124	2026-04-04 00:38:04.514	null	RAW_SHORT	2026-04-19 00:38:05.123
cmni76yjc0167708nb3w4msgz	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.63877547	-122.44111519	5	0	33.2	325.2	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-03 01:01:17.016	2026-04-03 01:01:16.43	null	RAW_SHORT	2026-04-18 01:01:17.015
cmni78csh0189708n1z8mvj7u	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.65294135	-122.45482078	5	0	32.04	314.3	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-03 01:02:22.145	2026-04-03 01:02:18.43	null	RAW_SHORT	2026-04-18 01:02:22.145
cmni78oe6018q708n8tpg2skv	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.6558023	-122.45850161	5	0	33.15	314.65	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-03 01:02:37.182	2026-04-03 01:02:32.433	null	RAW_SHORT	2026-04-18 01:02:37.181
cmnj2iyod02zphw8yhxu5zcti	\N	alex@brspark.com	dev_szkcjr	cmnj1lkhy01n1hw8y4bohk7qw	OS_ACCEPT	\N	\N	\N	\N	\N	\N	GPS	\N	\N	UNKNOWN	1.0.0	26.3.1	Simulator iOS	f	f	-7	2026-04-03 15:38:25.165	2026-04-03 15:38:20.188	{"previousState": "DISPATCHED"}	LEGAL	2031-04-03 15:38:25.16
cmnj2iyoe02zqhw8y8rjeqsq1	\N	alex@brspark.com	\N	\N	HEARTBEAT	-23.569983	-46.7851655	5	0	-1	-1	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-03 15:38:25.165	2026-04-03 15:38:20.818	null	RAW_SHORT	2026-04-18 15:38:25.16
cmnjm9nd701frrohkxwoy6ut0	\N	alex@brspark.com	\N	\N	HEARTBEAT	-23.56719453129495	-46.7862439702355	7.928586564459389	791.0626493816346	-1	-1	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-04 00:51:02.923	2026-04-04 00:51:02.342	null	RAW_SHORT	2026-04-19 00:51:02.923
cmni78goh018f708nkyb2k0t2	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.6543464	-122.45663554	5	0	32.34	314.65	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-03 01:02:27.185	2026-04-03 01:02:25.443	null	RAW_SHORT	2026-04-18 01:02:27.184
cmni78w490192708ndmr8xmo2	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.6585296	-122.46199854	5	0	33.24	314.3	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-03 01:02:47.193	2026-04-03 01:02:45.432	null	RAW_SHORT	2026-04-18 01:02:47.192
cmni797pw019j708n8aoyjp8g	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.6615618	-122.46503681	5	0	33.47	337.5	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-03 01:03:02.229	2026-04-03 01:02:58.451	null	RAW_SHORT	2026-04-18 01:03:02.227
cmni79bkx019p708n9qqa17eb	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.66361863	-122.46554249	5	0	33.44	357.54	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-03 01:03:07.234	2026-04-03 01:03:05.454	null	RAW_SHORT	2026-04-18 01:03:07.233
cmni79n6b01a6708ntymbqczc	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.66725462	-122.46555909	5	0	33.5	359.3	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-03 01:03:22.26	2026-04-03 01:03:17.438	null	RAW_SHORT	2026-04-18 01:03:22.259
cmni79r1n01ac708nmvvgvtjp	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.66908757	-122.46577484	5	0	34.09	350.51	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-03 01:03:27.275	2026-04-03 01:03:23.428	null	RAW_SHORT	2026-04-18 01:03:27.274
cmni79ux101ai708nnzaakhp6	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.67087158	-122.46637096	5	0	34.06	341.37	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-03 01:03:32.294	2026-04-03 01:03:29.448	null	RAW_SHORT	2026-04-18 01:03:32.293
cmni7ae8z01bb708n4ow3bteg	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.67777332	-122.47128946	5	0	30.8	341.72	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-03 01:03:57.348	2026-04-03 01:03:56.432	null	RAW_SHORT	2026-04-18 01:03:57.346
cmni7axkq01c3708nix4dtuaq	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.68390426	-122.47140219	5	0	32.09	3.87	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-03 01:04:22.394	2026-04-03 01:04:17.443	null	RAW_SHORT	2026-04-18 01:04:22.393
cmni7b1g301c9708ntobi5a4y	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.68594949	-122.47128904	5	0	32.36	2.46	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-03 01:04:27.411	2026-04-03 01:04:24.457	null	RAW_SHORT	2026-04-18 01:04:27.41
cmni7bd1z01cv708ng7vthpcx	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.69001467	-122.47029335	5	0	32.87	4.92	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-03 01:04:42.456	2026-04-03 01:04:38.445	null	RAW_SHORT	2026-04-18 01:04:42.455
cmni7bgwz01d1708n9ye4jhwj	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.69207683	-122.47025102	5	0	32.04	359.65	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-03 01:04:47.459	2026-04-03 01:04:45.427	null	RAW_SHORT	2026-04-18 01:04:47.459
cmni7bkrt01d7708nkehuqztc	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.69404565	-122.47027106	5	0	30.9	359.3	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-03 01:04:52.458	2026-04-03 01:04:52.434	null	RAW_SHORT	2026-04-18 01:04:52.457
cmni7bsin01di708nciufn9o7	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.69605048	-122.47064958	5	0	32.11	344.88	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-03 01:05:02.496	2026-04-03 01:04:59.442	null	RAW_SHORT	2026-04-18 01:05:02.495
cmni7bwdo01do708ndq324st7	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.69802752	-122.47124554	5	0	31.26	354.73	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-03 01:05:07.501	2026-04-03 01:05:06.428	null	RAW_SHORT	2026-04-18 01:05:07.5
cmni7c43v01dz708nqkwcgf3f	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.69997602	-122.47131947	5	0	31.02	359.3	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-03 01:05:17.515	2026-04-03 01:05:13.424	null	RAW_SHORT	2026-04-18 01:05:17.515
cmni7c7z001e5708n17kqrhhq	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.70201202	-122.47133229	5	0	32.84	0.35	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-03 01:05:22.525	2026-04-03 01:05:20.431	null	RAW_SHORT	2026-04-18 01:05:22.524
cmni7cbuf01eb708n65ma6ttn	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.70403219	-122.47131041	5	0	31.51	0.7	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-03 01:05:27.543	2026-04-03 01:05:27.43	null	RAW_SHORT	2026-04-18 01:05:27.542
cmni7cjkg01em708nr9ar1z6k	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.70595483	-122.47074489	5	0	31.7	17.93	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-03 01:05:37.552	2026-04-03 01:05:34.446	null	RAW_SHORT	2026-04-18 01:05:37.551
cmni7cnfg01es708n210rxr66	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.70763792	-122.46929683	5	0	32.74	39.02	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-03 01:05:42.556	2026-04-03 01:05:41.443	null	RAW_SHORT	2026-04-18 01:05:42.555
cmni7cv5s01f3708nxlu8dp95	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.70921334	-122.46760008	5	0	32.41	46.05	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-03 01:05:52.576	2026-04-03 01:05:48.443	null	RAW_SHORT	2026-04-18 01:05:52.575
cmni7cz1201f9708nhnuvybi8	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.71021564	-122.46536446	5	0	32.36	71.72	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-03 01:05:57.591	2026-04-03 01:05:55.434	null	RAW_SHORT	2026-04-18 01:05:57.59
cmni7d2w201ff708n4ykr1ul9	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.71044221	-122.46282013	5	0	32.5	89.65	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-03 01:06:02.594	2026-04-03 01:06:02.442	null	RAW_SHORT	2026-04-18 01:06:02.593
cmni7dam901fq708nhukcozq3	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.7104565	-122.46024571	5	0	32.03	88.95	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-03 01:06:12.609	2026-04-03 01:06:09.438	null	RAW_SHORT	2026-04-18 01:06:12.609
cmni7dehc01fw708ncpmngt44	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.71049518	-122.45774841	5	0	31.01	86.13	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-03 01:06:17.617	2026-04-03 01:06:16.434	null	RAW_SHORT	2026-04-18 01:06:17.616
cmni7dm7a01g7708nsu1u14zg	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.71100501	-122.45539586	5	0	31.18	67.5	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-03 01:06:27.623	2026-04-03 01:06:23.43	null	RAW_SHORT	2026-04-18 01:06:27.622
cmni7dq2r01gd708nzc5gszd9	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.71224348	-122.45340591	5	0	32.72	43.95	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-03 01:06:32.643	2026-04-03 01:06:30.431	null	RAW_SHORT	2026-04-18 01:06:32.642
cmni7dtxq01gj708ndng57dcy	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.71358303	-122.45185375	5	0	34.19	43.24	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-03 01:06:37.647	2026-04-03 01:06:36.445	null	RAW_SHORT	2026-04-18 01:06:37.646
cmni7dxsz01gp708n9sz8v1h1	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.71493088	-122.4502591	5	0	33.71	43.24	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-03 01:06:42.66	2026-04-03 01:06:42.441	null	RAW_SHORT	2026-04-18 01:06:42.659
cmni7e5ja01h0708n1c533wih	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.71666011	-122.44883987	5	0	32.77	23.55	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-03 01:06:52.678	2026-04-03 01:06:49.446	null	RAW_SHORT	2026-04-18 01:06:52.677
cmni7e9e301h6708ncz3kt2w5	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.71869117	-122.44835883	5	0	33.04	5.62	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-03 01:06:57.675	2026-04-03 01:06:56.484	null	RAW_SHORT	2026-04-18 01:06:57.675
cmni7ed9e01hc708nycwb9k99	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.72050506	-122.44815373	5	0	33.54	5.62	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-03 01:07:02.691	2026-04-03 01:07:02.441	null	RAW_SHORT	2026-04-18 01:07:02.69
cmni7ekzn01hn708nfhkytvoy	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.72232096	-122.44788668	5	0	33.91	8.44	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-03 01:07:12.708	2026-04-03 01:07:08.439	null	RAW_SHORT	2026-04-18 01:07:12.707
cmni7eouv01ht708n57b3yj5t	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.72410961	-122.44729576	5	0	34.32	19.34	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-03 01:07:17.719	2026-04-03 01:07:14.439	null	RAW_SHORT	2026-04-18 01:07:17.719
cmni7espy01hz708ndi0sjh4j	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.72576768	-122.44632572	5	0	33.8	27.07	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-03 01:07:22.727	2026-04-03 01:07:20.438	null	RAW_SHORT	2026-04-18 01:07:22.726
cmni7ewkv01i5708n9fhg5na9	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.72722512	-122.44493977	5	0	33.64	40.43	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-03 01:07:27.728	2026-04-03 01:07:26.44	null	RAW_SHORT	2026-04-18 01:07:27.727
cmni7f4bf01ig708nrbk4lo5o	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.72855831	-122.44296625	5	0	32.56	57.66	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-03 01:07:37.755	2026-04-03 01:07:33.465	null	RAW_SHORT	2026-04-18 01:07:37.754
cmni7f86f01im708nwof3iegy	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.72953195	-122.44070582	5	0	32.64	63.28	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-03 01:07:42.759	2026-04-03 01:07:40.468	null	RAW_SHORT	2026-04-18 01:07:42.758
cmni7fc1q01is708ny3wjw2qs	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.73040585	-122.43830156	5	0	33.88	67.5	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-03 01:07:47.775	2026-04-03 01:07:47.485	null	RAW_SHORT	2026-04-18 01:07:47.774
cmni7fjrv01j3708nt9s2njgw	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.73106542	-122.43616509	5	0	33.96	70.31	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-03 01:07:57.787	2026-04-03 01:07:53.472	null	RAW_SHORT	2026-04-18 01:07:57.786
cmni7fnnm01j9708naiucs0qs	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.73165395	-122.43393827	5	0	34.16	71.72	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-03 01:08:02.819	2026-04-03 01:07:59.439	null	RAW_SHORT	2026-04-18 01:08:02.817
cmni7fri501jf708nqs2g8x8j	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.73218428	-122.43140694	5	0	32.33	80.86	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-03 01:08:07.805	2026-04-03 01:08:06.427	null	RAW_SHORT	2026-04-18 01:08:07.804
cmni7fz8g01jq708n5v9v301k	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.73199824	-122.42881265	5	0	33.75	104.06	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-03 01:08:17.825	2026-04-03 01:08:13.443	null	RAW_SHORT	2026-04-18 01:08:17.824
cmni7g33d01jw708nn3njx0h0	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.73156653	-122.42656337	5	0	33.55	101.95	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-03 01:08:22.826	2026-04-03 01:08:19.433	null	RAW_SHORT	2026-04-18 01:08:22.825
cmni7hl7j01m9708ns714tzi2	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.7396505	-122.40785538	5	0	25.51	0.7	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-03 01:09:32.96	2026-04-03 01:09:32.452	null	RAW_SHORT	2026-04-18 01:09:32.959
cmnj2lca4032thw8ywnlry9rq	\N	alex@brspark.com	dev_szkcjr	cmnj1lkhy01n1hw8y4bohk7qw	OS_ACCEPT	\N	\N	\N	\N	\N	\N	GPS	\N	\N	UNKNOWN	1.0.0	26.3.1	Simulator iOS	f	f	-8	2026-04-03 15:40:16.107	2026-04-03 15:40:15.254	{"previousState": "DISPATCHED"}	LEGAL	2031-04-03 15:40:15.96
cmnjm9ncn01fqrohkfsfrspwa	\N	alex@brspark.com	\N	\N	HEARTBEAT	-23.56719453129495	-46.7862439702355	7.928586564459389	791.0626493816346	-1	-1	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-04 00:51:02.902	2026-04-04 00:51:02.342	null	RAW_SHORT	2026-04-19 00:51:02.901
cmni7g6yc01k2708nohony83h	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.73140472	-122.423954	5	0	32.38	87.89	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-03 01:08:27.828	2026-04-03 01:08:26.436	null	RAW_SHORT	2026-04-18 01:08:27.827
cmni7geox01kd708nf777cxqr	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.73169331	-122.42141856	5	0	32.82	79.1	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-03 01:08:37.858	2026-04-03 01:08:33.438	null	RAW_SHORT	2026-04-18 01:08:37.857
cmnj33hss001jhojamrxbteqa	\N	alex@brspark.com	dev_szkcjr	cmnj1u3d401z3hw8yw2e5hqnc	OS_ACCEPT	\N	\N	\N	\N	\N	\N	GPS	\N	\N	UNKNOWN	1.0.0	26.3.1	Simulator iOS	f	f	-4	2026-04-03 15:54:23.069	2026-04-03 15:54:19.786	{"previousState": "IDLE"}	LEGAL	2031-04-03 15:54:23.067
cmnj33hss001khoja450cqoi3	\N	alex@brspark.com	\N	\N	HEARTBEAT	-23.569983	-46.7851655	5	0	-1	-1	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-03 15:54:23.069	2026-04-03 15:54:19.917	null	RAW_SHORT	2026-04-18 15:54:23.067
cmnj37vcf007mhoja38sgovfv	\N	alex@brspark.com	dev_szkcjr	cmnj1u3d401z3hw8yw2e5hqnc	OS_ACCEPT	\N	\N	\N	\N	\N	\N	GPS	\N	\N	UNKNOWN	1.0.0	26.3.1	Simulator iOS	f	f	33	2026-04-03 15:57:47.248	2026-04-03 15:57:42.628	{"previousState": "IDLE"}	LEGAL	2031-04-03 15:57:47.247
cmnj37vcf007nhojafwzqu2gp	\N	alex@brspark.com	\N	\N	HEARTBEAT	-23.569983	-46.7851655	5	0	-1	-1	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-03 15:57:47.248	2026-04-03 15:57:42.435	null	RAW_SHORT	2026-04-18 15:57:47.247
cmnjm9ncn01fprohkgnpt98gi	\N	alex@brspark.com	\N	\N	HEARTBEAT	-23.56719453129495	-46.7862439702355	7.928586564459389	791.0626493816346	-1	-1	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-04 00:51:02.902	2026-04-04 00:51:02.342	null	RAW_SHORT	2026-04-19 00:51:02.902
cmni7gijv01kj708nydpfzs2w	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.73190474	-122.4188029	5	0	33.33	90.7	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-03 01:08:42.86	2026-04-03 01:08:40.434	null	RAW_SHORT	2026-04-18 01:08:42.859
cmni7hhc601ly708nz2vqw6vr	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.73771805	-122.40756445	5	0	26.72	351.56	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-03 01:09:27.942	2026-04-03 01:09:24.436	null	RAW_SHORT	2026-04-18 01:09:27.942
cmni7i0nq01mv708nnv58ok0g	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.74310845	-122.40622653	5	0	25.27	33.05	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-03 01:09:52.983	2026-04-03 01:09:49.443	null	RAW_SHORT	2026-04-18 01:09:52.982
cmni7jire01p2708n0z220ufo	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.75912761	-122.40587398	5	0	26.31	328.01	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-03 01:11:03.098	2026-04-03 01:11:00.432	null	RAW_SHORT	2026-04-18 01:11:03.097
cmnj36m1l005mhojad0qlljq9	\N	alex@brspark.com	dev_szkcjr	cmnj1u3d401z3hw8yw2e5hqnc	OS_ACCEPT	\N	\N	\N	\N	\N	\N	GPS	\N	\N	UNKNOWN	1.0.0	26.3.1	Simulator iOS	f	f	-5	2026-04-03 15:56:48.538	2026-04-03 15:56:46.286	{"previousState": "DISPATCHED"}	LEGAL	2031-04-03 15:56:48.537
cmnj36m1l005nhojawexcyps8	\N	alex@brspark.com	\N	\N	HEARTBEAT	-23.569983	-46.7851655	5	0	-1	-1	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-03 15:56:48.538	2026-04-03 15:56:46.222	null	RAW_SHORT	2026-04-18 15:56:48.537
cmnjm9vb401gerohkff243214	cmnhhqj5c000e3yrjmvwv50er	alex@brspark.com	dev_or2xj4	\N	SESSION_OPEN	\N	\N	\N	\N	\N	\N	GPS	\N	\N	UNKNOWN	1.0.0	26.4	iPhone 17 Pro Max	f	f	6	2026-04-04 00:51:13.216	2026-04-04 00:51:09.392	{}	OPERATIONAL	2026-10-01 00:51:13.216
cmnjm9vb401gfrohkw94yvuqv	cmnhhqj5c000e3yrjmvwv50er	alex@brspark.com	dev_or2xj4	\N	SESSION_OPEN	\N	\N	\N	\N	\N	\N	GPS	\N	\N	UNKNOWN	1.0.0	26.4	iPhone 17 Pro Max	f	f	11	2026-04-04 00:51:13.216	2026-04-04 00:51:10.175	{}	OPERATIONAL	2026-10-01 00:51:13.216
cmni7gmfr01kp708nr01s8eom	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.73191141	-122.41621021	5	0	32.02	84.02	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-03 01:08:47.896	2026-04-03 01:08:47.435	null	RAW_SHORT	2026-04-18 01:08:47.895
cmni7h5qp01lh708nvty0iylf	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.73438914	-122.40947586	5	0	28.51	60.12	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-03 01:09:12.913	2026-04-03 01:09:08.435	null	RAW_SHORT	2026-04-18 01:09:12.912
cmnj39dka009mhojapfzd177d	\N	alex@brspark.com	dev_szkcjr	cmnj1u3d401z3hw8yw2e5hqnc	OS_ACCEPT	\N	\N	\N	\N	\N	\N	GPS	\N	\N	UNKNOWN	1.0.0	26.3.1	Simulator iOS	f	f	-2	2026-04-03 15:58:57.515	2026-04-03 15:58:53.257	{"previousState": "DISPATCHED"}	LEGAL	2031-04-03 15:58:57.514
cmnj39dka009nhojak2p19ahc	\N	alex@brspark.com	\N	\N	HEARTBEAT	-23.569983	-46.7851655	5	0	-1	-1	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-03 15:58:57.515	2026-04-03 15:58:52.736	null	RAW_SHORT	2026-04-18 15:58:57.514
cmnjm9vay01gcrohk8gss3cef	cmnhhqj5c000e3yrjmvwv50er	alex@brspark.com	dev_or2xj4	\N	SESSION_OPEN	\N	\N	\N	\N	\N	\N	GPS	\N	\N	UNKNOWN	1.0.0	26.4	iPhone 17 Pro Max	f	f	6	2026-04-04 00:51:13.21	2026-04-04 00:51:09.392	{}	OPERATIONAL	2026-10-01 00:51:13.209
cmnjm9vay01gdrohk9ejgh5rf	cmnhhqj5c000e3yrjmvwv50er	alex@brspark.com	dev_or2xj4	\N	SESSION_OPEN	\N	\N	\N	\N	\N	\N	GPS	\N	\N	UNKNOWN	1.0.0	26.4	iPhone 17 Pro Max	f	f	11	2026-04-04 00:51:13.21	2026-04-04 00:51:10.175	{}	OPERATIONAL	2026-10-01 00:51:13.209
cmni7gu5s01l0708ng1fy786v	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.7325035	-122.41380528	5	0	32.01	65.74	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-03 01:08:57.905	2026-04-03 01:08:54.429	null	RAW_SHORT	2026-04-18 01:08:57.904
cmni7gy0s01l6708nc77a47to	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.73348762	-122.41154526	5	0	31.51	61.52	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-03 01:09:02.909	2026-04-03 01:09:01.438	null	RAW_SHORT	2026-04-18 01:09:02.908
cmni7h9mb01ln708n7cck8opr	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.73581968	-122.40786016	5	0	26.89	27.42	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-03 01:09:17.939	2026-04-03 01:09:16.439	null	RAW_SHORT	2026-04-18 01:09:17.938
cmni7hsxf01mk708ngnwh74qe	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.74154292	-122.40736102	5	0	24.11	20.39	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-03 01:09:42.964	2026-04-03 01:09:41.455	null	RAW_SHORT	2026-04-18 01:09:42.963
cmni7i4il01n1708ncfu9itqa	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.74472411	-122.40508676	5	0	25.72	21.8	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-03 01:09:57.982	2026-04-03 01:09:57.446	null	RAW_SHORT	2026-04-18 01:09:57.981
cmni7ic9e01nc708nlizbi3cx	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.74665044	-122.40442819	5	0	29.21	13.71	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-03 01:10:08.018	2026-04-03 01:10:05.44	null	RAW_SHORT	2026-04-18 01:10:08.017
cmni7ig4201ni708n73o65u2g	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.74840121	-122.40385688	5	0	28.11	14.41	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-03 01:10:13.01	2026-04-03 01:10:12.446	null	RAW_SHORT	2026-04-18 01:10:13.01
cmni7inup01nt708nrhjbzudr	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.75036492	-122.40324249	5	0	28.81	13.71	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-03 01:10:23.041	2026-04-03 01:10:20.477	null	RAW_SHORT	2026-04-18 01:10:23.04
cmni7irpa01nz708n2gk764p0	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.75220952	-122.40282465	5	0	30.01	4.92	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-03 01:10:28.031	2026-04-03 01:10:27.443	null	RAW_SHORT	2026-04-18 01:10:28.03
cmni7izft01oa708nzmbgjgqp	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.7540561	-122.40290746	5	0	28.24	353.32	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-03 01:10:38.057	2026-04-03 01:10:34.434	null	RAW_SHORT	2026-04-18 01:10:38.056
cmni7j3an01og708nr6r3swol	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.75593629	-122.40310762	5	0	24.48	354.73	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-03 01:10:43.056	2026-04-03 01:10:42.436	null	RAW_SHORT	2026-04-18 01:10:43.055
cmni7jb1301or708nxyip7h8v	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.75768006	-122.40408897	5	0	24.81	319.92	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-03 01:10:53.079	2026-04-03 01:10:51.458	null	RAW_SHORT	2026-04-18 01:10:53.078
cmni7jqhh01pd708nqlmhztxe	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.76100843	-122.4063059	5	0	27.37	7.73	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-03 01:11:13.109	2026-04-03 01:11:08.459	null	RAW_SHORT	2026-04-18 01:11:13.108
cmni7jucv01pj708nj6s9somq	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.76276406	-122.40536177	5	0	25.67	24.26	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-03 01:11:18.128	2026-04-03 01:11:16.507	null	RAW_SHORT	2026-04-18 01:11:18.127
cmni7pmzk01x7708nretbwkwx	\N	alex@brspark.com	dev_szkcjr	cmni0yc0l034gk84wpt1ucqfp	OS_ACCEPT	\N	\N	\N	\N	\N	\N	GPS	\N	\N	UNKNOWN	1.0.0	26.3.1	Simulator iOS	f	f	-8	2026-04-03 01:15:48.512	2026-04-03 01:15:47.715	{"previousState": "IN_TRANSIT"}	LEGAL	2031-04-03 01:15:48.511
cmni7pyl401xn708natohaw4a	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.35728082	-122.11715581	5	0	32.38	315.35	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-03 01:16:03.545	2026-04-03 01:15:58.583	null	RAW_SHORT	2026-04-18 01:16:03.544
cmni7q2jv01xt708nqwjl5xgd	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.35955814	-122.11901575	5	0	34.59	333.98	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-03 01:16:08.683	2026-04-03 01:16:07.554	null	RAW_SHORT	2026-04-18 01:16:08.681
cmni7qa6s01y4708n448zrvzx	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.36207862	-122.12062282	5	0	34.69	327.3	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-03 01:16:18.58	2026-04-03 01:16:16.563	null	RAW_SHORT	2026-04-18 01:16:18.579
cmni7qhx101yf708n8fwq151l	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.36396061	-122.12310285	5	0	32.94	301.29	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-03 01:16:28.598	2026-04-03 01:16:25.564	null	RAW_SHORT	2026-04-18 01:16:28.597
cmni7qpnb01yq708nq24pvw0t	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.36486694	-122.12661646	5	0	33.59	275.27	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-03 01:16:38.615	2026-04-03 01:16:35.551	null	RAW_SHORT	2026-04-18 01:16:38.614
cmni7qxds01z1708nreurygq6	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.36495642	-122.13002966	5	0	33.15	277.03	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-03 01:16:48.64	2026-04-03 01:16:44.553	null	RAW_SHORT	2026-04-18 01:16:48.636
cmni7r54i01zc708ntujaqlmf	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.3658664	-122.13358057	5	0	33.38	290.74	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-03 01:16:58.675	2026-04-03 01:16:54.561	null	RAW_SHORT	2026-04-18 01:16:58.674
cmni7rcu001zn708nphd6jqch	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.3668918	-122.13700784	5	0	32.41	292.15	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-03 01:17:08.664	2026-04-03 01:17:04.557	null	RAW_SHORT	2026-04-18 01:17:08.663
cmni7rgpa01zt708nva92lhhs	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.36833646	-122.13988803	5	0	34.3	310.78	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-03 01:17:13.678	2026-04-03 01:17:13.604	null	RAW_SHORT	2026-04-18 01:17:13.677
cmni7rof40204708np7v6s323	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.37043777	-122.14209172	5	0	33.88	324.14	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-03 01:17:23.68	2026-04-03 01:17:22.56	null	RAW_SHORT	2026-04-18 01:17:23.679
cmni7rw5f020f708ni6atrkbb	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.37263743	-122.14409064	5	0	33.07	323.44	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-03 01:17:33.695	2026-04-03 01:17:31.566	null	RAW_SHORT	2026-04-18 01:17:33.694
cmni7s3vv020q708nkz9x5qey	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.37481249	-122.14611939	5	0	34.05	320.27	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-03 01:17:43.723	2026-04-03 01:17:40.558	null	RAW_SHORT	2026-04-18 01:17:43.723
cmni7sblt0211708nmhr35vhg	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.37686895	-122.14843858	5	0	34.17	317.81	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-03 01:17:53.729	2026-04-03 01:17:49.554	null	RAW_SHORT	2026-04-18 01:17:53.728
cmni7sfh20217708n661pqp96	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.37906991	-122.15049139	5	0	33.75	331.17	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-03 01:17:58.742	2026-04-03 01:17:58.562	null	RAW_SHORT	2026-04-18 01:17:58.741
cmni7sn75021i708ncbklpp8q	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.38170908	-122.15158724	5	0	35.16	349.8	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-03 01:18:08.754	2026-04-03 01:18:07.562	null	RAW_SHORT	2026-04-18 01:18:08.753
cmni7suxl021t708n3yizkv9i	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.38447544	-122.1522008	5	0	34.65	347.7	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-03 01:18:18.777	2026-04-03 01:18:16.554	null	RAW_SHORT	2026-04-18 01:18:18.776
cmni7t2nz0224708nzysewg5q	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.38703695	-122.15399578	5	0	31.83	315.35	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-03 01:18:28.799	2026-04-03 01:18:26.552	null	RAW_SHORT	2026-04-18 01:18:28.798
cmni7tae8022f708ntq8rvznj	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.38845823	-122.15706146	5	0	31.89	286.17	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-03 01:18:38.817	2026-04-03 01:18:36.557	null	RAW_SHORT	2026-04-18 01:18:38.816
cmni7ti3q022q708nltmhko0y	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.38901726	-122.16067063	5	0	32.51	280.9	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-03 01:18:48.806	2026-04-03 01:18:46.557	null	RAW_SHORT	2026-04-18 01:18:48.806
cmni7tpuh0231708ns1llz3er	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.39012296	-122.1640311	5	0	32.15	303.75	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-03 01:18:58.842	2026-04-03 01:18:56.554	null	RAW_SHORT	2026-04-18 01:18:58.839
cmni7txnt023c708npv5rpvyw	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.39163715	-122.16684775	5	0	33.81	295.66	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-03 01:19:08.969	2026-04-03 01:19:05.565	null	RAW_SHORT	2026-04-18 01:19:08.967
cmni7u5an023n708nrh43ni9t	\N	alex@brspark.com	\N	\N	HEARTBEAT	37.39225456	-122.17045658	5	0	32.61	274.57	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-03 01:19:18.864	2026-04-03 01:19:15.565	null	RAW_SHORT	2026-04-18 01:19:18.863
cmnj39wkg00ashojau5nj1d02	\N	alex@brspark.com	dev_szkcjr	cmnj1u3d401z3hw8yw2e5hqnc	OS_ACCEPT	\N	\N	\N	\N	\N	\N	GPS	\N	\N	UNKNOWN	1.0.0	26.3.1	Simulator iOS	f	f	4	2026-04-03 15:59:22.144	2026-04-03 15:59:17.902	{"previousState": "IDLE"}	LEGAL	2031-04-03 15:59:22.142
cmnj39wkg00athojaksz1hfwj	\N	alex@brspark.com	\N	\N	HEARTBEAT	-23.569983	-46.7851655	5	0	-1	-1	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-03 15:59:22.144	2026-04-03 15:59:17.835	null	RAW_SHORT	2026-04-18 15:59:22.142
cmnjmq1x801h3rohk30kwvef1	cmnjmhnpx01gqrohk7zart6bt	ze@ze.com	dev_or2xj4	\N	SESSION_OPEN	\N	\N	\N	\N	\N	\N	GPS	\N	\N	UNKNOWN	1.0.0	26.4	iPhone 17 Pro Max	f	f	-31	2026-04-04 01:03:48.284	2026-04-04 01:03:43.61	{}	OPERATIONAL	2026-10-01 01:03:48.283
\.


--
-- Data for Name: Tenant; Type: TABLE DATA; Schema: public; Owner: alex
--

COPY public."Tenant" (id, name, slug, email, phone, "taxId", "defaultLang", status, "createdAt", "updatedAt", "avatarUrl", "localeId", "ownerName", "sectorCode") FROM stdin;
cmnhhqj5c000e3yrjmvwv50er	Alex	alex	alex@brspark.com	\N	\N	pt-BR	TRIAL	2026-04-02 13:08:40.176	2026-04-02 13:08:40.176	\N	\N	Alex	\N
cmnjl5fzm00ugrohkuk34ncb6	nick	qualquecoisa	qualquecoisa@gmail.com	\N	\N	pt-BR	TRIAL	2026-04-04 00:19:47.122	2026-04-04 00:19:47.122	\N	\N	nick	\N
cmnjmhnpx01gqrohk7zart6bt	Zé da Silva	ze	ze@ze.com	\N	\N	pt-BR	TRIAL	2026-04-04 00:57:16.627	2026-04-04 00:57:16.627	\N	\N	Zé da Silva	\N
\.


--
-- Data for Name: TranslationOverride; Type: TABLE DATA; Schema: public; Owner: alex
--

COPY public."TranslationOverride" (id, "tenantId", key, language, value, "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: User; Type: TABLE DATA; Schema: public; Owner: alex
--

COPY public."User" (id, "tenantId", email, name, password, role, "isActive", "lastLogin", "createdAt", "updatedAt", "avatarUrl") FROM stdin;
cmnjl5g0000uirohkljbrswtz	cmnjl5fzm00ugrohkuk34ncb6	qualquecoisa@gmail.com	nick	$2a$10$AbCRxh5GfpApRowZAZKu3.sLPVA9TWRkQ/M1eT7.NmWQDis.vyYC6	ADMIN	t	\N	2026-04-04 00:19:47.136	2026-04-04 00:19:47.136	\N
cmnhhqj5w000g3yrj2m7fnu6n	cmnhhqj5c000e3yrjmvwv50er	alex@brspark.com	Alex	$2a$10$eKNvxvkUGs4RfuO28hMEculRY80pNedDbiaZ6i5yLEciMgGLHmSyq	ADMIN	t	2026-04-04 00:29:23.667	2026-04-02 13:08:40.196	2026-04-04 00:29:23.668	http://192.168.15.73:3001/uploads/storage/avatars/cmnhhqj5w000g3yrj2m7fnu6n_1775260598952.jpg
cmnjmhnub01gsrohkw88ub2kd	cmnjmhnpx01gqrohk7zart6bt	ze@ze.com	Zé da Silva	$2a$10$uz7gl4ZjLF4Xd78DI.0jIeH06V6H0SPs/pjpYRpWJt9kOy0pwfrFC	ADMIN	t	2026-04-04 01:03:43.013	2026-04-04 00:57:16.782	2026-04-04 01:03:43.014	\N
\.


--
-- Data for Name: UserModuleData; Type: TABLE DATA; Schema: public; Owner: alex
--

COPY public."UserModuleData" (id, "ownerEmail", module, data, "updatedAt", "createdAt") FROM stdin;
cmnhgha6o0000edbotlvxyl8r	alex@brspark.com	stock_items	[{"id": "local_stock_1774732811358", "sku": "Qwewqe", "name": "Wqewq", "unit": "un", "category": "Suprimentos", "minStock": 2, "costPrice": 0, "locationId": null, "owner_email": "alex@brspark.com", "subLocation": null, "currentStock": 1, "asset_location_id": null}]	2026-04-04 01:01:03.138	2026-04-02 12:33:29.04
cmnhgha6q0001edboo6v4fuzq	alex@brspark.com	costs_expenses	[{"id": "exp-mn67vmfh-dy607", "date": "2026-03-25", "type": "EXPENSE", "amount": 532, "status": "PENDING", "assetId": "brsp-215880", "category": "OUTROS", "ownerEmail": "alex@brspark.com", "description": "Pneu"}, {"id": "exp-mn67xbkl-2bu76", "date": "2026-03-25", "type": "EXPENSE", "amount": 523.87, "status": "PENDING", "assetId": "brsp-585500", "category": "OUTROS", "ownerEmail": "alex@brspark.com", "description": "Pneu"}, {"id": "exp-mn684uwl-189lr", "date": "2026-03-25", "type": "EXPENSE", "amount": 582, "status": "PENDING", "assetId": "brsp-585500", "category": "OUTROS", "ownerEmail": "alex@brspark.com", "description": "Pmeu"}, {"id": "exp-mn68cwe3-e1zb0", "date": "2026-03-25", "type": "EXPENSE", "amount": 235, "status": "PENDING", "assetId": "brsp-215880", "category": "OUTROS", "ownerEmail": "alex@brspark.com", "description": "Pneu"}, {"id": "exp-mn6hn1bs-ka6kt", "date": "2026-03-25", "type": "EXPENSE", "amount": 152, "status": "PENDING", "assetId": "brsp-190135", "category": "OUTROS", "ownerEmail": "alex@brspark.com", "description": "Luz"}, {"id": "exp-mn6hp6c6-u9q2w", "date": "2026-03-25", "type": "EXPENSE", "amount": 500, "status": "PENDING", "assetId": "brsp-628386", "category": "OUTROS", "ownerEmail": "alex@brspark.com", "description": "Pmeu"}, {"id": "exp-mn7gcdd2-74nic", "date": "2026-03-26", "type": "REVENUE", "amount": 100, "status": "PENDING", "assetId": "brsp-756993", "category": "OUTROS", "ownerEmail": "alex@brspark.com", "description": "Testw"}, {"id": "exp-mn8wkyku-t309v", "date": "2026-03-27", "type": "REVENUE", "amount": 100, "status": "PENDING", "assetId": "brsp-134786", "category": "OUTROS", "ownerEmail": "alex@brspark.com", "description": "Teste"}, {"id": "exp-mn8wuoci-3bvk6", "date": "2026-03-27", "type": "EXPENSE", "amount": 25, "status": "PENDING", "assetId": "brsp-134786", "category": "OUTROS", "ownerEmail": "alex@brspark.com", "description": "Teste22"}]	2026-04-04 01:01:03.14	2026-04-02 12:33:29.043
cmnhgha7b0003edboqnmkfzho	alex@brspark.com	costs_recurring	[{"id": "rec-mn69xf9l-h54zj", "type": "REVENUE", "amount": 2500, "status": "ACTIVE", "assetId": "brsp-215880", "frequency": "MONTHLY", "ownerEmail": "alex@brspark.com", "description": "Tedte", "nextDueDate": "2026-03-25", "alertDaysBefore": 1, "totalInstallments": 2, "remainingInstallments": 2}, {"id": "ins_cost_ins_1774477825766_cwk5h", "type": "EXPENSE", "amount": 0, "status": "ACTIVE", "assetId": "brsp-190135", "category": "SEGURO", "frequency": "YEARLY", "ownerEmail": "alex@brspark.com", "description": "Seguro Residencial — Teste", "nextDueDate": "209383", "alertDaysBefore": 10}, {"id": "ins_cost_ins_1774477826163_pyzx0", "type": "EXPENSE", "amount": 0, "status": "ACTIVE", "assetId": "brsp-190135", "category": "SEGURO", "frequency": "YEARLY", "ownerEmail": "alex@brspark.com", "description": "Seguro Residencial — Teste", "nextDueDate": "209383", "alertDaysBefore": 10}, {"id": "rec-mn8wim0o-uh9wo", "type": "REVENUE", "amount": 1000, "status": "ACTIVE", "assetId": "brsp-756993", "frequency": "MONTHLY", "ownerEmail": "alex@brspark.com", "description": "Aluguel", "nextDueDate": "2026-03-28", "alertDaysBefore": 1, "totalInstallments": 12, "remainingInstallments": 12}, {"id": "rec-mn8wlgmp-owx71", "type": "REVENUE", "amount": 300, "status": "ACTIVE", "assetId": "brsp-134786", "frequency": "MONTHLY", "ownerEmail": "alex@brspark.com", "description": "Aluguel", "nextDueDate": "2026-03-27", "alertDaysBefore": 1, "totalInstallments": 12, "remainingInstallments": 12}, {"id": "rec-mn8wma7d-j64lj", "type": "REVENUE", "amount": 50, "status": "ACTIVE", "assetId": "brsp-756993", "frequency": "MONTHLY", "ownerEmail": "alex@brspark.com", "description": "Teste", "nextDueDate": "2026-03-27", "alertDaysBefore": 1, "totalInstallments": 12, "remainingInstallments": 12}, {"id": "rec-mn8wmvf1-vx666", "type": "EXPENSE", "amount": 300, "status": "ACTIVE", "assetId": "brsp-756993", "frequency": "MONTHLY", "ownerEmail": "alex@brspark.com", "description": "Teste rec", "nextDueDate": "2026-03-27", "alertDaysBefore": 1, "totalInstallments": 12, "remainingInstallments": 12}, {"id": "rec-mn8wn9yc-roy0r", "type": "EXPENSE", "amount": 50, "status": "ACTIVE", "assetId": "brsp-756993", "frequency": "MONTHLY", "ownerEmail": "alex@brspark.com", "description": "2", "nextDueDate": "2026-03-27", "alertDaysBefore": 1, "totalInstallments": 12, "remainingInstallments": 12}, {"id": "rec-mn8wnmsw-3nbph", "type": "REVENUE", "amount": 100, "status": "ACTIVE", "assetId": "brsp-756993", "frequency": "MONTHLY", "ownerEmail": "alex@brspark.com", "description": "3", "nextDueDate": "2026-03-27", "alertDaysBefore": 1, "totalInstallments": 12, "remainingInstallments": 12}, {"id": "rec-mn8wo9xg-olj46", "type": "REVENUE", "amount": 100, "status": "ACTIVE", "assetId": "brsp-134786", "frequency": "MONTHLY", "ownerEmail": "alex@brspark.com", "description": "1", "nextDueDate": "2026-03-27", "alertDaysBefore": 1, "totalInstallments": 12, "remainingInstallments": 12}, {"id": "rec-mn8wolzq-k0t6i", "type": "EXPENSE", "amount": 200, "status": "ACTIVE", "assetId": "brsp-134786", "frequency": "MONTHLY", "ownerEmail": "alex@brspark.com", "description": "2", "nextDueDate": "2026-03-27", "alertDaysBefore": 1, "totalInstallments": 12, "remainingInstallments": 12}, {"id": "rec-mn8wwasg-y98d3", "type": "EXPENSE", "amount": 50, "status": "ACTIVE", "assetId": "brsp-134786", "frequency": "MONTHLY", "ownerEmail": "alex@brspark.com", "description": "Netflix", "nextDueDate": "2026-03-27", "alertDaysBefore": 1}, {"id": "ins_cost_ins_1774648334205_drxzi", "type": "EXPENSE", "amount": 0, "status": "ACTIVE", "assetId": "brsp-134786", "category": "SEGURO", "frequency": "YEARLY", "ownerEmail": "alex@brspark.com", "description": "Seguro Residencial — Teste", "nextDueDate": "2026-04-27", "alertDaysBefore": 1}, {"id": "ins_cost_ins_1774648335970_y32ey", "type": "EXPENSE", "amount": 0, "status": "ACTIVE", "assetId": "brsp-134786", "category": "SEGURO", "frequency": "YEARLY", "ownerEmail": "alex@brspark.com", "description": "Seguro Residencial — Teste", "nextDueDate": "2026-04-27", "alertDaysBefore": 1}, {"id": "ins_cost_ins_1774648337353_bjq8z", "type": "EXPENSE", "amount": 0, "status": "ACTIVE", "assetId": "brsp-134786", "category": "SEGURO", "frequency": "YEARLY", "ownerEmail": "alex@brspark.com", "description": "Seguro Residencial — Teste", "nextDueDate": "2026-04-27", "alertDaysBefore": 1}, {"id": "ins_cost_ins_1774648337620_kuvjy", "type": "EXPENSE", "amount": 0, "status": "ACTIVE", "assetId": "brsp-134786", "category": "SEGURO", "frequency": "YEARLY", "ownerEmail": "alex@brspark.com", "description": "Seguro Residencial — Teste", "nextDueDate": "2026-04-27", "alertDaysBefore": 1}, {"id": "ins_cost_ins_1774648337870_l14de", "type": "EXPENSE", "amount": 0, "status": "ACTIVE", "assetId": "brsp-134786", "category": "SEGURO", "frequency": "YEARLY", "ownerEmail": "alex@brspark.com", "description": "Seguro Residencial — Teste", "nextDueDate": "2026-04-27", "alertDaysBefore": 1}, {"id": "ins_cost_ins_1774648441070_05axk", "type": "EXPENSE", "amount": 0, "status": "ACTIVE", "assetId": "brsp-134786", "category": "SEGURO", "frequency": "YEARLY", "ownerEmail": "alex@brspark.com", "description": "Seguro Residencial — Teste", "nextDueDate": "2026-04-27", "alertDaysBefore": 1}]	2026-04-04 01:01:03.144	2026-04-02 12:33:29.046
cmnjlgpdg00vdrohkctjryg9z	qualquecoisa@gmail.com	costs_recurring	[{"id": "rec-mnjlcrs4-0cbok", "type": "EXPENSE", "amount": 100, "status": "ACTIVE", "assetId": "brsp-920512", "frequency": "MONTHLY", "ownerEmail": "qualquecoisa@gmail.com", "description": "Internet", "nextDueDate": "2026-04-04", "alertDaysBefore": 1}]	2026-04-04 00:29:08.397	2026-04-04 00:28:32.5
cmnhgha7b0004edboe1zksx0k	alex@brspark.com	insurance_policies	[{"id": "ins_1774477825766_cwk5h", "type": "RESIDENTIAL", "status": "ACTIVE", "assetId": "brsp-190135", "endDate": "209383", "insurer": "Teste", "createdAt": "2026-03-25T22:30:25.766Z", "startDate": "2026-03-25", "brokerName": "", "deductible": 0, "ownerEmail": "alex@brspark.com", "brokerPhone": "", "documentUri": "file:///var/mobile/Containers/Data/Application/B49F90C2-F617-4081-910B-D71CE9F435F3/Library/Caches/ExponentExperienceData/@anonymous/BrsparkMobile-be63636c-8058-4d28-bef6-7ebf19f8191b/DocumentPicker/F0257E79-A544-48D8-AEC0-14D3CE2AB092.pages", "policyNumber": "123", "premiumValue": 0, "coverageAmount": 0, "alertDaysBefore": 10, "coverageDetails": ""}, {"id": "ins_1774477826163_pyzx0", "type": "RESIDENTIAL", "status": "ACTIVE", "assetId": "brsp-190135", "endDate": "209383", "insurer": "Teste", "createdAt": "2026-03-25T22:30:26.163Z", "startDate": "2026-03-25", "brokerName": "", "deductible": 0, "ownerEmail": "alex@brspark.com", "brokerPhone": "", "documentUri": "file:///var/mobile/Containers/Data/Application/B49F90C2-F617-4081-910B-D71CE9F435F3/Library/Caches/ExponentExperienceData/@anonymous/BrsparkMobile-be63636c-8058-4d28-bef6-7ebf19f8191b/DocumentPicker/F0257E79-A544-48D8-AEC0-14D3CE2AB092.pages", "policyNumber": "123", "premiumValue": 0, "coverageAmount": 0, "alertDaysBefore": 10, "coverageDetails": ""}, {"id": "ins_1774648334205_drxzi", "type": "RESIDENTIAL", "status": "ACTIVE", "assetId": "brsp-134786", "endDate": "2026-04-27", "insurer": "Teste", "createdAt": "2026-03-27T21:52:14.205Z", "startDate": "2026-03-27", "brokerName": "", "deductible": 0, "ownerEmail": "alex@brspark.com", "brokerPhone": "", "documentUri": "http://192.168.15.73:3001/uploads/storage/docs/alex_brspark_com/ins_1774648334205_drxzi.insurance_355", "policyNumber": "355", "premiumValue": 0, "coverageAmount": 0, "alertDaysBefore": 1, "coverageDetails": ""}, {"id": "ins_1774648335970_y32ey", "type": "RESIDENTIAL", "status": "ACTIVE", "assetId": "brsp-134786", "endDate": "2026-04-27", "insurer": "Teste", "createdAt": "2026-03-27T21:52:15.970Z", "startDate": "2026-03-27", "brokerName": "", "deductible": 0, "ownerEmail": "alex@brspark.com", "brokerPhone": "", "documentUri": "http://192.168.15.73:3001/uploads/storage/docs/alex_brspark_com/ins_1774648335970_y32ey.insurance_355", "policyNumber": "355", "premiumValue": 0, "coverageAmount": 0, "alertDaysBefore": 1, "coverageDetails": ""}, {"id": "ins_1774648337353_bjq8z", "type": "RESIDENTIAL", "status": "ACTIVE", "assetId": "brsp-134786", "endDate": "2026-04-27", "insurer": "Teste", "createdAt": "2026-03-27T21:52:17.353Z", "startDate": "2026-03-27", "brokerName": "", "deductible": 0, "ownerEmail": "alex@brspark.com", "brokerPhone": "", "documentUri": "http://192.168.15.73:3001/uploads/storage/docs/alex_brspark_com/ins_1774648337353_bjq8z.insurance_355", "policyNumber": "355", "premiumValue": 0, "coverageAmount": 0, "alertDaysBefore": 1, "coverageDetails": ""}, {"id": "ins_1774648337620_kuvjy", "type": "RESIDENTIAL", "status": "ACTIVE", "assetId": "brsp-134786", "endDate": "2026-04-27", "insurer": "Teste", "createdAt": "2026-03-27T21:52:17.620Z", "startDate": "2026-03-27", "brokerName": "", "deductible": 0, "ownerEmail": "alex@brspark.com", "brokerPhone": "", "documentUri": "http://192.168.15.73:3001/uploads/storage/docs/alex_brspark_com/ins_1774648337620_kuvjy.insurance_355", "policyNumber": "355", "premiumValue": 0, "coverageAmount": 0, "alertDaysBefore": 1, "coverageDetails": ""}, {"id": "ins_1774648337870_l14de", "type": "RESIDENTIAL", "status": "ACTIVE", "assetId": "brsp-134786", "endDate": "2026-04-27", "insurer": "Teste", "createdAt": "2026-03-27T21:52:17.870Z", "startDate": "2026-03-27", "brokerName": "", "deductible": 0, "ownerEmail": "alex@brspark.com", "brokerPhone": "", "documentUri": "http://192.168.15.73:3001/uploads/storage/docs/alex_brspark_com/ins_1774648337870_l14de.insurance_355", "policyNumber": "355", "premiumValue": 0, "coverageAmount": 0, "alertDaysBefore": 1, "coverageDetails": ""}]	2026-04-04 01:01:03.145	2026-04-02 12:33:29.047
cmnhgha7b0002edbo0e4apd4k	alex@brspark.com	asset_docs	[{"id": "qdce4o", "uri": "https://pub-5fc6db4a467f3070a46bf138e5b79edb.r2.dev/docs/alex_brspark_com/qdce4o.pdf", "type": "pdf", "title": "NF-e - Nota Fiscal Eletrônica de Serviços - São Paulo.pdf", "assetId": "brsp-190135", "version": 1, "category": "general", "createdAt": "2026-03-25T23:39:27.408Z", "description": ""}, {"id": "5b8tw4", "uri": "https://pub-5fc6db4a467f3070a46bf138e5b79edb.r2.dev/docs/alex_brspark_com/5b8tw4.pdf", "type": "pdf", "title": "Currículo Thais 2025.pdf", "assetId": "brsp-190135", "version": 1, "category": "general", "createdAt": "2026-03-25T23:39:33.198Z", "description": ""}, {"id": "nmft9b", "uri": "", "type": "folder", "title": "Teste", "assetId": "brsp-756993", "version": 1, "category": "general", "createdAt": "2026-03-26T18:13:09.048Z"}, {"id": "4oc4kl", "uri": "/BrSpark/docs/alex_brspark_com/4oc4kl.pdf", "type": "pdf", "title": "NF-e - Nota Fiscal Eletrônica de Serviços - São Paulo.pdf", "assetId": "brsp-756993", "version": 1, "category": "general", "parentId": "nmft9b", "createdAt": "2026-03-26T18:13:15.140Z", "description": ""}, {"id": "wf9ejb", "uri": "", "type": "folder", "title": "123", "assetId": "brsp-756993", "version": 1, "category": "general", "createdAt": "2026-03-26T18:16:09.617Z"}, {"id": "krsucl", "uri": "", "type": "folder", "title": "1", "assetId": "brsp-756993", "version": 1, "category": "general", "parentId": "nmft9b", "createdAt": "2026-03-26T18:20:06.259Z"}]	2026-04-04 01:01:03.154	2026-04-02 12:33:29.044
\.


--
-- Data for Name: _prisma_migrations; Type: TABLE DATA; Schema: public; Owner: alex
--

COPY public._prisma_migrations (id, checksum, finished_at, migration_name, logs, rolled_back_at, started_at, applied_steps_count) FROM stdin;
bde75b4c-c3db-4c87-ad8f-4ddea978e83b	73224fe465c7de5be1d4f58cef71fe703fb824623c5ac8e5cb2f2f6321e13618	2026-04-02 09:29:07.113358-03	20260323143455_init	\N	\N	2026-04-02 09:29:06.610775-03	1
84bbcd60-be5b-45e6-900e-32306a1742e6	b00868e21b0ca2a3323cd88c3837296362a8462505fcd8fd176873fdd031d0e0	2026-04-02 09:29:07.13236-03	20260324001407_add_locale_profiles	\N	\N	2026-04-02 09:29:07.113955-03	1
f83613b8-779c-4e16-a62d-948470bdec9f	4aee8126753b087ae1d49fcb712baf2e1c6e24482a4c62352b79d536d572e4fe	2026-04-02 09:29:07.146501-03	20260324005528_add_translation_overrides	\N	\N	2026-04-02 09:29:07.133527-03	1
fa379f63-5407-4f05-a7dd-6d66af351e5b	9d60239b46e3f387ba472534b063e7b1ec3b3261abed0fc6518319807e150d9f	2026-04-02 09:29:07.148304-03	20260324173511_add_expense_revenue_metatag_types	\N	\N	2026-04-02 09:29:07.147179-03	1
e2963595-78f5-4441-9e46-2309eb8f2573	589531bd1df68a2b7555da033cb015bbcbd21f47a34108adc3062f3239503fdd	2026-04-02 09:29:07.154377-03	20260325225008_add_user_module_data	\N	\N	2026-04-02 09:29:07.148785-03	1
e5bde5ae-a5c2-4076-a92e-aa28036b3f05	69261f245187956b568acf26c08edaaa8f37d68a4f7837d767ad498780c8045e	2026-04-02 09:29:07.155548-03	20260325230353_add_media_category	\N	\N	2026-04-02 09:29:07.154849-03	1
40d54862-aae6-4c63-b3be-94f7b4bdaecf	78071a54b17cd3c1f7831a52989a8e4b26c043c6761ea11357637c77c6134b4e	2026-04-02 09:29:07.165256-03	20260326005347_init_asset_shares	\N	\N	2026-04-02 09:29:07.155935-03	1
753e0335-6db2-46bd-8091-20c9c2899850	dad8b317482d5cf9c3cae44bb195dd16d21ea33da651aa95bff6efc0876ae2f0	2026-04-02 09:29:08.614109-03	20260402122908_data_collection_foundation	\N	\N	2026-04-02 09:29:08.594042-03	1
\.


--
-- Name: Admin Admin_pkey; Type: CONSTRAINT; Schema: public; Owner: alex
--

ALTER TABLE ONLY public."Admin"
    ADD CONSTRAINT "Admin_pkey" PRIMARY KEY (id);


--
-- Name: AssetShare AssetShare_pkey; Type: CONSTRAINT; Schema: public; Owner: alex
--

ALTER TABLE ONLY public."AssetShare"
    ADD CONSTRAINT "AssetShare_pkey" PRIMARY KEY (id);


--
-- Name: Asset Asset_pkey; Type: CONSTRAINT; Schema: public; Owner: alex
--

ALTER TABLE ONLY public."Asset"
    ADD CONSTRAINT "Asset_pkey" PRIMARY KEY (id);


--
-- Name: AuditLog AuditLog_pkey; Type: CONSTRAINT; Schema: public; Owner: alex
--

ALTER TABLE ONLY public."AuditLog"
    ADD CONSTRAINT "AuditLog_pkey" PRIMARY KEY (id);


--
-- Name: ChatContact ChatContact_pkey; Type: CONSTRAINT; Schema: public; Owner: alex
--

ALTER TABLE ONLY public."ChatContact"
    ADD CONSTRAINT "ChatContact_pkey" PRIMARY KEY (id);


--
-- Name: ChatMessage ChatMessage_pkey; Type: CONSTRAINT; Schema: public; Owner: alex
--

ALTER TABLE ONLY public."ChatMessage"
    ADD CONSTRAINT "ChatMessage_pkey" PRIMARY KEY (id);


--
-- Name: ChatRoomMember ChatRoomMember_pkey; Type: CONSTRAINT; Schema: public; Owner: alex
--

ALTER TABLE ONLY public."ChatRoomMember"
    ADD CONSTRAINT "ChatRoomMember_pkey" PRIMARY KEY (id);


--
-- Name: ChatRoom ChatRoom_pkey; Type: CONSTRAINT; Schema: public; Owner: alex
--

ALTER TABLE ONLY public."ChatRoom"
    ADD CONSTRAINT "ChatRoom_pkey" PRIMARY KEY (id);


--
-- Name: ChecklistExecution ChecklistExecution_pkey; Type: CONSTRAINT; Schema: public; Owner: alex
--

ALTER TABLE ONLY public."ChecklistExecution"
    ADD CONSTRAINT "ChecklistExecution_pkey" PRIMARY KEY (id);


--
-- Name: ChecklistTemplate ChecklistTemplate_pkey; Type: CONSTRAINT; Schema: public; Owner: alex
--

ALTER TABLE ONLY public."ChecklistTemplate"
    ADD CONSTRAINT "ChecklistTemplate_pkey" PRIMARY KEY (id);


--
-- Name: CollectionPolicy CollectionPolicy_pkey; Type: CONSTRAINT; Schema: public; Owner: alex
--

ALTER TABLE ONLY public."CollectionPolicy"
    ADD CONSTRAINT "CollectionPolicy_pkey" PRIMARY KEY (id);


--
-- Name: ComplianceAcceptance ComplianceAcceptance_pkey; Type: CONSTRAINT; Schema: public; Owner: alex
--

ALTER TABLE ONLY public."ComplianceAcceptance"
    ADD CONSTRAINT "ComplianceAcceptance_pkey" PRIMARY KEY (id);


--
-- Name: ComplianceDoc ComplianceDoc_pkey; Type: CONSTRAINT; Schema: public; Owner: alex
--

ALTER TABLE ONLY public."ComplianceDoc"
    ADD CONSTRAINT "ComplianceDoc_pkey" PRIMARY KEY (id);


--
-- Name: ConsentRecord ConsentRecord_pkey; Type: CONSTRAINT; Schema: public; Owner: alex
--

ALTER TABLE ONLY public."ConsentRecord"
    ADD CONSTRAINT "ConsentRecord_pkey" PRIMARY KEY (id);


--
-- Name: ExecutionMetric ExecutionMetric_pkey; Type: CONSTRAINT; Schema: public; Owner: alex
--

ALTER TABLE ONLY public."ExecutionMetric"
    ADD CONSTRAINT "ExecutionMetric_pkey" PRIMARY KEY (id);


--
-- Name: FeatureFlag FeatureFlag_pkey; Type: CONSTRAINT; Schema: public; Owner: alex
--

ALTER TABLE ONLY public."FeatureFlag"
    ADD CONSTRAINT "FeatureFlag_pkey" PRIMARY KEY (id);


--
-- Name: Integration Integration_pkey; Type: CONSTRAINT; Schema: public; Owner: alex
--

ALTER TABLE ONLY public."Integration"
    ADD CONSTRAINT "Integration_pkey" PRIMARY KEY (id);


--
-- Name: Invoice Invoice_pkey; Type: CONSTRAINT; Schema: public; Owner: alex
--

ALTER TABLE ONLY public."Invoice"
    ADD CONSTRAINT "Invoice_pkey" PRIMARY KEY (id);


--
-- Name: LocaleProfile LocaleProfile_pkey; Type: CONSTRAINT; Schema: public; Owner: alex
--

ALTER TABLE ONLY public."LocaleProfile"
    ADD CONSTRAINT "LocaleProfile_pkey" PRIMARY KEY (id);


--
-- Name: Location Location_pkey; Type: CONSTRAINT; Schema: public; Owner: alex
--

ALTER TABLE ONLY public."Location"
    ADD CONSTRAINT "Location_pkey" PRIMARY KEY (id);


--
-- Name: Metatag Metatag_pkey; Type: CONSTRAINT; Schema: public; Owner: alex
--

ALTER TABLE ONLY public."Metatag"
    ADD CONSTRAINT "Metatag_pkey" PRIMARY KEY (id);


--
-- Name: NotificationLog NotificationLog_pkey; Type: CONSTRAINT; Schema: public; Owner: alex
--

ALTER TABLE ONLY public."NotificationLog"
    ADD CONSTRAINT "NotificationLog_pkey" PRIMARY KEY (id);


--
-- Name: NotificationTemplate NotificationTemplate_pkey; Type: CONSTRAINT; Schema: public; Owner: alex
--

ALTER TABLE ONLY public."NotificationTemplate"
    ADD CONSTRAINT "NotificationTemplate_pkey" PRIMARY KEY (id);


--
-- Name: Plan Plan_pkey; Type: CONSTRAINT; Schema: public; Owner: alex
--

ALTER TABLE ONLY public."Plan"
    ADD CONSTRAINT "Plan_pkey" PRIMARY KEY (id);


--
-- Name: PushToken PushToken_pkey; Type: CONSTRAINT; Schema: public; Owner: alex
--

ALTER TABLE ONLY public."PushToken"
    ADD CONSTRAINT "PushToken_pkey" PRIMARY KEY (id);


--
-- Name: ServiceProvider ServiceProvider_pkey; Type: CONSTRAINT; Schema: public; Owner: alex
--

ALTER TABLE ONLY public."ServiceProvider"
    ADD CONSTRAINT "ServiceProvider_pkey" PRIMARY KEY (id);


--
-- Name: StockItem StockItem_pkey; Type: CONSTRAINT; Schema: public; Owner: alex
--

ALTER TABLE ONLY public."StockItem"
    ADD CONSTRAINT "StockItem_pkey" PRIMARY KEY (id);


--
-- Name: StockMovement StockMovement_pkey; Type: CONSTRAINT; Schema: public; Owner: alex
--

ALTER TABLE ONLY public."StockMovement"
    ADD CONSTRAINT "StockMovement_pkey" PRIMARY KEY (id);


--
-- Name: Subscription Subscription_pkey; Type: CONSTRAINT; Schema: public; Owner: alex
--

ALTER TABLE ONLY public."Subscription"
    ADD CONSTRAINT "Subscription_pkey" PRIMARY KEY (id);


--
-- Name: TechnicianProfile TechnicianProfile_pkey; Type: CONSTRAINT; Schema: public; Owner: alex
--

ALTER TABLE ONLY public."TechnicianProfile"
    ADD CONSTRAINT "TechnicianProfile_pkey" PRIMARY KEY (id);


--
-- Name: TelemetryEvent TelemetryEvent_pkey; Type: CONSTRAINT; Schema: public; Owner: alex
--

ALTER TABLE ONLY public."TelemetryEvent"
    ADD CONSTRAINT "TelemetryEvent_pkey" PRIMARY KEY (id);


--
-- Name: Tenant Tenant_pkey; Type: CONSTRAINT; Schema: public; Owner: alex
--

ALTER TABLE ONLY public."Tenant"
    ADD CONSTRAINT "Tenant_pkey" PRIMARY KEY (id);


--
-- Name: TranslationOverride TranslationOverride_pkey; Type: CONSTRAINT; Schema: public; Owner: alex
--

ALTER TABLE ONLY public."TranslationOverride"
    ADD CONSTRAINT "TranslationOverride_pkey" PRIMARY KEY (id);


--
-- Name: UserModuleData UserModuleData_pkey; Type: CONSTRAINT; Schema: public; Owner: alex
--

ALTER TABLE ONLY public."UserModuleData"
    ADD CONSTRAINT "UserModuleData_pkey" PRIMARY KEY (id);


--
-- Name: User User_pkey; Type: CONSTRAINT; Schema: public; Owner: alex
--

ALTER TABLE ONLY public."User"
    ADD CONSTRAINT "User_pkey" PRIMARY KEY (id);


--
-- Name: _prisma_migrations _prisma_migrations_pkey; Type: CONSTRAINT; Schema: public; Owner: alex
--

ALTER TABLE ONLY public._prisma_migrations
    ADD CONSTRAINT _prisma_migrations_pkey PRIMARY KEY (id);


--
-- Name: Admin_email_key; Type: INDEX; Schema: public; Owner: alex
--

CREATE UNIQUE INDEX "Admin_email_key" ON public."Admin" USING btree (email);


--
-- Name: AssetShare_assetId_sharedWithEmail_key; Type: INDEX; Schema: public; Owner: alex
--

CREATE UNIQUE INDEX "AssetShare_assetId_sharedWithEmail_key" ON public."AssetShare" USING btree ("assetId", "sharedWithEmail");


--
-- Name: ChatContact_requesterId_addresseeId_key; Type: INDEX; Schema: public; Owner: alex
--

CREATE UNIQUE INDEX "ChatContact_requesterId_addresseeId_key" ON public."ChatContact" USING btree ("requesterId", "addresseeId");


--
-- Name: ChatRoomMember_roomId_userId_key; Type: INDEX; Schema: public; Owner: alex
--

CREATE UNIQUE INDEX "ChatRoomMember_roomId_userId_key" ON public."ChatRoomMember" USING btree ("roomId", "userId");


--
-- Name: ChecklistExecution_ownerEmail_idx; Type: INDEX; Schema: public; Owner: alex
--

CREATE INDEX "ChecklistExecution_ownerEmail_idx" ON public."ChecklistExecution" USING btree ("ownerEmail");


--
-- Name: ChecklistExecution_ownerEmail_status_idx; Type: INDEX; Schema: public; Owner: alex
--

CREATE INDEX "ChecklistExecution_ownerEmail_status_idx" ON public."ChecklistExecution" USING btree ("ownerEmail", status);


--
-- Name: ChecklistExecution_status_idx; Type: INDEX; Schema: public; Owner: alex
--

CREATE INDEX "ChecklistExecution_status_idx" ON public."ChecklistExecution" USING btree (status);


--
-- Name: CollectionPolicy_tenantId_idx; Type: INDEX; Schema: public; Owner: alex
--

CREATE INDEX "CollectionPolicy_tenantId_idx" ON public."CollectionPolicy" USING btree ("tenantId");


--
-- Name: CollectionPolicy_tenantId_sectorCode_key; Type: INDEX; Schema: public; Owner: alex
--

CREATE UNIQUE INDEX "CollectionPolicy_tenantId_sectorCode_key" ON public."CollectionPolicy" USING btree ("tenantId", "sectorCode");


--
-- Name: ConsentRecord_ownerEmail_idx; Type: INDEX; Schema: public; Owner: alex
--

CREATE INDEX "ConsentRecord_ownerEmail_idx" ON public."ConsentRecord" USING btree ("ownerEmail");


--
-- Name: ConsentRecord_ownerEmail_policyId_consentType_key; Type: INDEX; Schema: public; Owner: alex
--

CREATE UNIQUE INDEX "ConsentRecord_ownerEmail_policyId_consentType_key" ON public."ConsentRecord" USING btree ("ownerEmail", "policyId", "consentType");


--
-- Name: ConsentRecord_tenantId_idx; Type: INDEX; Schema: public; Owner: alex
--

CREATE INDEX "ConsentRecord_tenantId_idx" ON public."ConsentRecord" USING btree ("tenantId");


--
-- Name: ExecutionMetric_executionId_idx; Type: INDEX; Schema: public; Owner: alex
--

CREATE INDEX "ExecutionMetric_executionId_idx" ON public."ExecutionMetric" USING btree ("executionId");


--
-- Name: ExecutionMetric_executionId_key; Type: INDEX; Schema: public; Owner: alex
--

CREATE UNIQUE INDEX "ExecutionMetric_executionId_key" ON public."ExecutionMetric" USING btree ("executionId");


--
-- Name: ExecutionMetric_tenantId_ownerEmail_idx; Type: INDEX; Schema: public; Owner: alex
--

CREATE INDEX "ExecutionMetric_tenantId_ownerEmail_idx" ON public."ExecutionMetric" USING btree ("tenantId", "ownerEmail");


--
-- Name: FeatureFlag_key_tenantId_key; Type: INDEX; Schema: public; Owner: alex
--

CREATE UNIQUE INDEX "FeatureFlag_key_tenantId_key" ON public."FeatureFlag" USING btree (key, "tenantId");


--
-- Name: LocaleProfile_countryCode_key; Type: INDEX; Schema: public; Owner: alex
--

CREATE UNIQUE INDEX "LocaleProfile_countryCode_key" ON public."LocaleProfile" USING btree ("countryCode");


--
-- Name: Metatag_key_key; Type: INDEX; Schema: public; Owner: alex
--

CREATE UNIQUE INDEX "Metatag_key_key" ON public."Metatag" USING btree (key);


--
-- Name: NotificationTemplate_key_key; Type: INDEX; Schema: public; Owner: alex
--

CREATE UNIQUE INDEX "NotificationTemplate_key_key" ON public."NotificationTemplate" USING btree (key);


--
-- Name: Plan_name_key; Type: INDEX; Schema: public; Owner: alex
--

CREATE UNIQUE INDEX "Plan_name_key" ON public."Plan" USING btree (name);


--
-- Name: PushToken_token_key; Type: INDEX; Schema: public; Owner: alex
--

CREATE UNIQUE INDEX "PushToken_token_key" ON public."PushToken" USING btree (token);


--
-- Name: StockItem_assetId_sku_key; Type: INDEX; Schema: public; Owner: alex
--

CREATE UNIQUE INDEX "StockItem_assetId_sku_key" ON public."StockItem" USING btree ("assetId", sku);


--
-- Name: Subscription_tenantId_key; Type: INDEX; Schema: public; Owner: alex
--

CREATE UNIQUE INDEX "Subscription_tenantId_key" ON public."Subscription" USING btree ("tenantId");


--
-- Name: TechnicianProfile_userId_key; Type: INDEX; Schema: public; Owner: alex
--

CREATE UNIQUE INDEX "TechnicianProfile_userId_key" ON public."TechnicianProfile" USING btree ("userId");


--
-- Name: TelemetryEvent_executionId_idx; Type: INDEX; Schema: public; Owner: alex
--

CREATE INDEX "TelemetryEvent_executionId_idx" ON public."TelemetryEvent" USING btree ("executionId");


--
-- Name: TelemetryEvent_expiresAt_idx; Type: INDEX; Schema: public; Owner: alex
--

CREATE INDEX "TelemetryEvent_expiresAt_idx" ON public."TelemetryEvent" USING btree ("expiresAt");


--
-- Name: TelemetryEvent_ownerEmail_serverTimestamp_idx; Type: INDEX; Schema: public; Owner: alex
--

CREATE INDEX "TelemetryEvent_ownerEmail_serverTimestamp_idx" ON public."TelemetryEvent" USING btree ("ownerEmail", "serverTimestamp");


--
-- Name: TelemetryEvent_tenantId_eventType_serverTimestamp_idx; Type: INDEX; Schema: public; Owner: alex
--

CREATE INDEX "TelemetryEvent_tenantId_eventType_serverTimestamp_idx" ON public."TelemetryEvent" USING btree ("tenantId", "eventType", "serverTimestamp");


--
-- Name: Tenant_email_key; Type: INDEX; Schema: public; Owner: alex
--

CREATE UNIQUE INDEX "Tenant_email_key" ON public."Tenant" USING btree (email);


--
-- Name: Tenant_slug_key; Type: INDEX; Schema: public; Owner: alex
--

CREATE UNIQUE INDEX "Tenant_slug_key" ON public."Tenant" USING btree (slug);


--
-- Name: TranslationOverride_tenantId_key_language_key; Type: INDEX; Schema: public; Owner: alex
--

CREATE UNIQUE INDEX "TranslationOverride_tenantId_key_language_key" ON public."TranslationOverride" USING btree ("tenantId", key, language);


--
-- Name: UserModuleData_ownerEmail_idx; Type: INDEX; Schema: public; Owner: alex
--

CREATE INDEX "UserModuleData_ownerEmail_idx" ON public."UserModuleData" USING btree ("ownerEmail");


--
-- Name: UserModuleData_ownerEmail_module_key; Type: INDEX; Schema: public; Owner: alex
--

CREATE UNIQUE INDEX "UserModuleData_ownerEmail_module_key" ON public."UserModuleData" USING btree ("ownerEmail", module);


--
-- Name: User_email_tenantId_key; Type: INDEX; Schema: public; Owner: alex
--

CREATE UNIQUE INDEX "User_email_tenantId_key" ON public."User" USING btree (email, "tenantId");


--
-- Name: Asset Asset_locationId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: alex
--

ALTER TABLE ONLY public."Asset"
    ADD CONSTRAINT "Asset_locationId_fkey" FOREIGN KEY ("locationId") REFERENCES public."Location"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: Asset Asset_parentId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: alex
--

ALTER TABLE ONLY public."Asset"
    ADD CONSTRAINT "Asset_parentId_fkey" FOREIGN KEY ("parentId") REFERENCES public."Asset"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: Asset Asset_tenantId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: alex
--

ALTER TABLE ONLY public."Asset"
    ADD CONSTRAINT "Asset_tenantId_fkey" FOREIGN KEY ("tenantId") REFERENCES public."Tenant"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: AuditLog AuditLog_adminId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: alex
--

ALTER TABLE ONLY public."AuditLog"
    ADD CONSTRAINT "AuditLog_adminId_fkey" FOREIGN KEY ("adminId") REFERENCES public."Admin"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: AuditLog AuditLog_tenantId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: alex
--

ALTER TABLE ONLY public."AuditLog"
    ADD CONSTRAINT "AuditLog_tenantId_fkey" FOREIGN KEY ("tenantId") REFERENCES public."Tenant"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: AuditLog AuditLog_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: alex
--

ALTER TABLE ONLY public."AuditLog"
    ADD CONSTRAINT "AuditLog_userId_fkey" FOREIGN KEY ("userId") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: ChatMessage ChatMessage_roomId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: alex
--

ALTER TABLE ONLY public."ChatMessage"
    ADD CONSTRAINT "ChatMessage_roomId_fkey" FOREIGN KEY ("roomId") REFERENCES public."ChatRoom"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: ChatRoomMember ChatRoomMember_roomId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: alex
--

ALTER TABLE ONLY public."ChatRoomMember"
    ADD CONSTRAINT "ChatRoomMember_roomId_fkey" FOREIGN KEY ("roomId") REFERENCES public."ChatRoom"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: ChecklistExecution ChecklistExecution_templateId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: alex
--

ALTER TABLE ONLY public."ChecklistExecution"
    ADD CONSTRAINT "ChecklistExecution_templateId_fkey" FOREIGN KEY ("templateId") REFERENCES public."ChecklistTemplate"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: CollectionPolicy CollectionPolicy_tenantId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: alex
--

ALTER TABLE ONLY public."CollectionPolicy"
    ADD CONSTRAINT "CollectionPolicy_tenantId_fkey" FOREIGN KEY ("tenantId") REFERENCES public."Tenant"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: ComplianceAcceptance ComplianceAcceptance_docId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: alex
--

ALTER TABLE ONLY public."ComplianceAcceptance"
    ADD CONSTRAINT "ComplianceAcceptance_docId_fkey" FOREIGN KEY ("docId") REFERENCES public."ComplianceDoc"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: ComplianceDoc ComplianceDoc_tenantId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: alex
--

ALTER TABLE ONLY public."ComplianceDoc"
    ADD CONSTRAINT "ComplianceDoc_tenantId_fkey" FOREIGN KEY ("tenantId") REFERENCES public."Tenant"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: ConsentRecord ConsentRecord_docId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: alex
--

ALTER TABLE ONLY public."ConsentRecord"
    ADD CONSTRAINT "ConsentRecord_docId_fkey" FOREIGN KEY ("docId") REFERENCES public."ComplianceDoc"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: ConsentRecord ConsentRecord_policyId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: alex
--

ALTER TABLE ONLY public."ConsentRecord"
    ADD CONSTRAINT "ConsentRecord_policyId_fkey" FOREIGN KEY ("policyId") REFERENCES public."CollectionPolicy"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: FeatureFlag FeatureFlag_tenantId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: alex
--

ALTER TABLE ONLY public."FeatureFlag"
    ADD CONSTRAINT "FeatureFlag_tenantId_fkey" FOREIGN KEY ("tenantId") REFERENCES public."Tenant"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: Invoice Invoice_subscriptionId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: alex
--

ALTER TABLE ONLY public."Invoice"
    ADD CONSTRAINT "Invoice_subscriptionId_fkey" FOREIGN KEY ("subscriptionId") REFERENCES public."Subscription"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: Location Location_parentId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: alex
--

ALTER TABLE ONLY public."Location"
    ADD CONSTRAINT "Location_parentId_fkey" FOREIGN KEY ("parentId") REFERENCES public."Location"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: Location Location_tenantId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: alex
--

ALTER TABLE ONLY public."Location"
    ADD CONSTRAINT "Location_tenantId_fkey" FOREIGN KEY ("tenantId") REFERENCES public."Tenant"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: NotificationLog NotificationLog_templateId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: alex
--

ALTER TABLE ONLY public."NotificationLog"
    ADD CONSTRAINT "NotificationLog_templateId_fkey" FOREIGN KEY ("templateId") REFERENCES public."NotificationTemplate"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: PushToken PushToken_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: alex
--

ALTER TABLE ONLY public."PushToken"
    ADD CONSTRAINT "PushToken_userId_fkey" FOREIGN KEY ("userId") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: StockItem StockItem_assetId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: alex
--

ALTER TABLE ONLY public."StockItem"
    ADD CONSTRAINT "StockItem_assetId_fkey" FOREIGN KEY ("assetId") REFERENCES public."Asset"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: StockMovement StockMovement_itemId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: alex
--

ALTER TABLE ONLY public."StockMovement"
    ADD CONSTRAINT "StockMovement_itemId_fkey" FOREIGN KEY ("itemId") REFERENCES public."StockItem"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: Subscription Subscription_planId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: alex
--

ALTER TABLE ONLY public."Subscription"
    ADD CONSTRAINT "Subscription_planId_fkey" FOREIGN KEY ("planId") REFERENCES public."Plan"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: Subscription Subscription_tenantId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: alex
--

ALTER TABLE ONLY public."Subscription"
    ADD CONSTRAINT "Subscription_tenantId_fkey" FOREIGN KEY ("tenantId") REFERENCES public."Tenant"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: TechnicianProfile TechnicianProfile_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: alex
--

ALTER TABLE ONLY public."TechnicianProfile"
    ADD CONSTRAINT "TechnicianProfile_userId_fkey" FOREIGN KEY ("userId") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: Tenant Tenant_localeId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: alex
--

ALTER TABLE ONLY public."Tenant"
    ADD CONSTRAINT "Tenant_localeId_fkey" FOREIGN KEY ("localeId") REFERENCES public."LocaleProfile"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: TranslationOverride TranslationOverride_tenantId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: alex
--

ALTER TABLE ONLY public."TranslationOverride"
    ADD CONSTRAINT "TranslationOverride_tenantId_fkey" FOREIGN KEY ("tenantId") REFERENCES public."Tenant"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: User User_tenantId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: alex
--

ALTER TABLE ONLY public."User"
    ADD CONSTRAINT "User_tenantId_fkey" FOREIGN KEY ("tenantId") REFERENCES public."Tenant"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- PostgreSQL database dump complete
--

\unrestrict opCaI35CyroqLAd0Kv6DeazeDa6HzygdvGYYMVNg0JhW1SP6RNGBHfdnFoj56HH

