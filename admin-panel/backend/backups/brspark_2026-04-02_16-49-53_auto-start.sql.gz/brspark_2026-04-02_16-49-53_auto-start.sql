--
-- PostgreSQL database dump
--

\restrict n02ZgM9SaIuVS4SlAQ9P7U0pWfWaKce1yHuakCFxKhAFW3uZkBnB2pEldCjGEbJ

-- Dumped from database version 14.20 (Homebrew)
-- Dumped by pg_dump version 14.20 (Homebrew)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: AssetType; Type: TYPE; Schema: public; Owner: alex
--

CREATE TYPE public."AssetType" AS ENUM (
    'REAL_ESTATE',
    'TERRESTRIAL',
    'AQUATIC',
    'SPECIAL',
    'OTHER'
);


ALTER TYPE public."AssetType" OWNER TO alex;

--
-- Name: AuditCategory; Type: TYPE; Schema: public; Owner: alex
--

CREATE TYPE public."AuditCategory" AS ENUM (
    'AUTH',
    'DATA',
    'ADMIN',
    'SYSTEM'
);


ALTER TYPE public."AuditCategory" OWNER TO alex;

--
-- Name: BillingCycle; Type: TYPE; Schema: public; Owner: alex
--

CREATE TYPE public."BillingCycle" AS ENUM (
    'MONTHLY',
    'YEARLY'
);


ALTER TYPE public."BillingCycle" OWNER TO alex;

--
-- Name: Channel; Type: TYPE; Schema: public; Owner: alex
--

CREATE TYPE public."Channel" AS ENUM (
    'EMAIL',
    'PUSH',
    'WHATSAPP',
    'SMS'
);


ALTER TYPE public."Channel" OWNER TO alex;

--
-- Name: DocType; Type: TYPE; Schema: public; Owner: alex
--

CREATE TYPE public."DocType" AS ENUM (
    'TERMS_OF_USE',
    'PRIVACY_POLICY',
    'LGPD_DPA',
    'COOKIE_POLICY'
);


ALTER TYPE public."DocType" OWNER TO alex;

--
-- Name: IntType; Type: TYPE; Schema: public; Owner: alex
--

CREATE TYPE public."IntType" AS ENUM (
    'AI_LLM',
    'EMAIL',
    'PUSH',
    'STORAGE',
    'WEBHOOK',
    'ERP',
    'PAYMENT',
    'MAPS'
);


ALTER TYPE public."IntType" OWNER TO alex;

--
-- Name: InvoiceStatus; Type: TYPE; Schema: public; Owner: alex
--

CREATE TYPE public."InvoiceStatus" AS ENUM (
    'PENDING',
    'PAID',
    'OVERDUE',
    'VOID'
);


ALTER TYPE public."InvoiceStatus" OWNER TO alex;

--
-- Name: LocationType; Type: TYPE; Schema: public; Owner: alex
--

CREATE TYPE public."LocationType" AS ENUM (
    'BUILDING',
    'FLOOR',
    'ROOM',
    'AREA',
    'WAREHOUSE',
    'OTHER'
);


ALTER TYPE public."LocationType" OWNER TO alex;

--
-- Name: MetatagType; Type: TYPE; Schema: public; Owner: alex
--

CREATE TYPE public."MetatagType" AS ENUM (
    'ASSET_TYPE',
    'STOCK_CATEGORY',
    'SERVICE_CATEGORY',
    'ASSET_STATUS',
    'GLOBAL_TAG',
    'EXPENSE_CATEGORY',
    'REVENUE_CATEGORY',
    'MEDIA_CATEGORY'
);


ALTER TYPE public."MetatagType" OWNER TO alex;

--
-- Name: MovementType; Type: TYPE; Schema: public; Owner: alex
--

CREATE TYPE public."MovementType" AS ENUM (
    'IN',
    'OUT',
    'TRANSFER'
);


ALTER TYPE public."MovementType" OWNER TO alex;

--
-- Name: NotifStatus; Type: TYPE; Schema: public; Owner: alex
--

CREATE TYPE public."NotifStatus" AS ENUM (
    'SENT',
    'DELIVERED',
    'FAILED',
    'BOUNCED'
);


ALTER TYPE public."NotifStatus" OWNER TO alex;

--
-- Name: SubStatus; Type: TYPE; Schema: public; Owner: alex
--

CREATE TYPE public."SubStatus" AS ENUM (
    'ACTIVE',
    'PAST_DUE',
    'CANCELLED',
    'TRIALING'
);


ALTER TYPE public."SubStatus" OWNER TO alex;

--
-- Name: TelemetryEventType; Type: TYPE; Schema: public; Owner: alex
--

CREATE TYPE public."TelemetryEventType" AS ENUM (
    'SESSION_OPEN',
    'SESSION_CLOSE',
    'OS_ACCEPT',
    'OS_START',
    'CHECKIN',
    'CHECKOUT',
    'TRANSIT_START',
    'TRANSIT_END',
    'HEARTBEAT',
    'GEOFENCE_ENTER',
    'GEOFENCE_EXIT',
    'PAUSE',
    'RESUME',
    'FRAUD_FLAG',
    'INTEGRITY_CHECK',
    'POLICY_VIOLATION'
);


ALTER TYPE public."TelemetryEventType" OWNER TO alex;

--
-- Name: TenantStatus; Type: TYPE; Schema: public; Owner: alex
--

CREATE TYPE public."TenantStatus" AS ENUM (
    'TRIAL',
    'ACTIVE',
    'SUSPENDED',
    'CANCELLED'
);


ALTER TYPE public."TenantStatus" OWNER TO alex;

--
-- Name: UserRole; Type: TYPE; Schema: public; Owner: alex
--

CREATE TYPE public."UserRole" AS ENUM (
    'ADMIN',
    'MANAGER',
    'USER'
);


ALTER TYPE public."UserRole" OWNER TO alex;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: Admin; Type: TABLE; Schema: public; Owner: alex
--

CREATE TABLE public."Admin" (
    id text NOT NULL,
    email text NOT NULL,
    name text NOT NULL,
    password text NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public."Admin" OWNER TO alex;

--
-- Name: Asset; Type: TABLE; Schema: public; Owner: alex
--

CREATE TABLE public."Asset" (
    id text NOT NULL,
    "tenantId" text NOT NULL,
    "parentId" text,
    title text NOT NULL,
    type public."AssetType" NOT NULL,
    status text DEFAULT 'Operacional'::text NOT NULL,
    description text,
    "imageUrl" text,
    "locationId" text,
    metadata jsonb,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL,
    "deletedAt" timestamp(3) without time zone
);


ALTER TABLE public."Asset" OWNER TO alex;

--
-- Name: AssetShare; Type: TABLE; Schema: public; Owner: alex
--

CREATE TABLE public."AssetShare" (
    id text NOT NULL,
    "assetId" text NOT NULL,
    "ownerEmail" text NOT NULL,
    "sharedWithEmail" text NOT NULL,
    permission text NOT NULL,
    modules jsonb NOT NULL,
    status text DEFAULT 'PENDING'::text NOT NULL,
    "invitedAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "expiresAt" timestamp(3) without time zone
);


ALTER TABLE public."AssetShare" OWNER TO alex;

--
-- Name: AuditLog; Type: TABLE; Schema: public; Owner: alex
--

CREATE TABLE public."AuditLog" (
    id text NOT NULL,
    "tenantId" text,
    "userId" text,
    "adminId" text,
    action text NOT NULL,
    resource text NOT NULL,
    category public."AuditCategory" NOT NULL,
    metadata jsonb,
    "ipAddress" text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public."AuditLog" OWNER TO alex;

--
-- Name: ChatContact; Type: TABLE; Schema: public; Owner: alex
--

CREATE TABLE public."ChatContact" (
    id text NOT NULL,
    "requesterId" text NOT NULL,
    "addresseeId" text NOT NULL,
    status text DEFAULT 'PENDING'::text NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public."ChatContact" OWNER TO alex;

--
-- Name: ChatMessage; Type: TABLE; Schema: public; Owner: alex
--

CREATE TABLE public."ChatMessage" (
    id text NOT NULL,
    "roomId" text NOT NULL,
    "senderId" text NOT NULL,
    "senderName" text NOT NULL,
    type text DEFAULT 'text'::text NOT NULL,
    content text,
    "mediaUrl" text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public."ChatMessage" OWNER TO alex;

--
-- Name: ChatRoom; Type: TABLE; Schema: public; Owner: alex
--

CREATE TABLE public."ChatRoom" (
    id text NOT NULL,
    name text,
    description text,
    "avatarColor" text DEFAULT '#2563EB'::text,
    "isGroup" boolean DEFAULT false NOT NULL,
    "creatorId" text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public."ChatRoom" OWNER TO alex;

--
-- Name: ChatRoomMember; Type: TABLE; Schema: public; Owner: alex
--

CREATE TABLE public."ChatRoomMember" (
    id text NOT NULL,
    "roomId" text NOT NULL,
    "userId" text NOT NULL,
    role text DEFAULT 'MEMBER'::text NOT NULL,
    "joinedAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "lastReadAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public."ChatRoomMember" OWNER TO alex;

--
-- Name: ChecklistExecution; Type: TABLE; Schema: public; Owner: alex
--

CREATE TABLE public."ChecklistExecution" (
    id text NOT NULL,
    "templateId" text,
    "ownerEmail" text NOT NULL,
    "assetId" text,
    status text DEFAULT 'PENDING'::text NOT NULL,
    responses jsonb,
    metadata jsonb,
    "locationAddress" text,
    "locationLat" double precision,
    "locationLng" double precision,
    "locationRadius" integer,
    "locationZoneType" text,
    "locationPolygon" jsonb,
    "gpsLocation" jsonb,
    "startedAt" timestamp(3) without time zone,
    "completedAt" timestamp(3) without time zone,
    "syncedAt" timestamp(3) without time zone,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public."ChecklistExecution" OWNER TO alex;

--
-- Name: ChecklistTemplate; Type: TABLE; Schema: public; Owner: alex
--

CREATE TABLE public."ChecklistTemplate" (
    id text NOT NULL,
    "tenantId" text,
    title text NOT NULL,
    description text,
    settings jsonb NOT NULL,
    "schemaData" jsonb NOT NULL,
    metadata jsonb,
    version integer DEFAULT 1 NOT NULL,
    "isActive" boolean DEFAULT true NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public."ChecklistTemplate" OWNER TO alex;

--
-- Name: CollectionPolicy; Type: TABLE; Schema: public; Owner: alex
--

CREATE TABLE public."CollectionPolicy" (
    id text NOT NULL,
    "tenantId" text,
    "sectorCode" text,
    label text DEFAULT 'Padrão'::text NOT NULL,
    "locationEnabled" boolean DEFAULT true NOT NULL,
    "locationBackgroundEnabled" boolean DEFAULT true NOT NULL,
    "locationIntervalIdleMin" integer DEFAULT 30 NOT NULL,
    "locationIntervalTransitMin" integer DEFAULT 2 NOT NULL,
    "locationIntervalOnSiteMin" integer DEFAULT 5 NOT NULL,
    "locationDistanceFilterMeters" integer DEFAULT 200 NOT NULL,
    "retentionGpsRawDays" integer DEFAULT 15 NOT NULL,
    "retentionEventsYears" integer DEFAULT 5 NOT NULL,
    "retentionAuditDays" integer DEFAULT 180 NOT NULL,
    "retentionMetricsDays" integer DEFAULT 730 NOT NULL,
    "mockGpsAction" text DEFAULT 'WARN'::text NOT NULL,
    "rootJailbreakAction" text DEFAULT 'WARN'::text NOT NULL,
    "clockDriftMaxSeconds" integer DEFAULT 300 NOT NULL,
    "requireExplicitConsent" boolean DEFAULT true NOT NULL,
    "consentGranular" boolean DEFAULT true NOT NULL,
    "legalBasis" text DEFAULT 'LGPD'::text NOT NULL,
    "requireCheckinPhoto" boolean DEFAULT false NOT NULL,
    "allowOfflineCheckin" boolean DEFAULT true NOT NULL,
    "minOnSiteMinutes" integer DEFAULT 0 NOT NULL,
    "outOfPolicyAction" text DEFAULT 'PROCEED_FLAG'::text NOT NULL,
    "isActive" boolean DEFAULT true NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public."CollectionPolicy" OWNER TO alex;

--
-- Name: ComplianceAcceptance; Type: TABLE; Schema: public; Owner: alex
--

CREATE TABLE public."ComplianceAcceptance" (
    id text NOT NULL,
    "docId" text NOT NULL,
    "userId" text,
    "tenantId" text,
    "ipAddress" text,
    "acceptedAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public."ComplianceAcceptance" OWNER TO alex;

--
-- Name: ComplianceDoc; Type: TABLE; Schema: public; Owner: alex
--

CREATE TABLE public."ComplianceDoc" (
    id text NOT NULL,
    type public."DocType" NOT NULL,
    version text NOT NULL,
    title text NOT NULL,
    content text NOT NULL,
    "isActive" boolean DEFAULT false NOT NULL,
    "publishedAt" timestamp(3) without time zone,
    "createdBy" text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL,
    "sectorCode" text,
    "tenantId" text
);


ALTER TABLE public."ComplianceDoc" OWNER TO alex;

--
-- Name: ConsentRecord; Type: TABLE; Schema: public; Owner: alex
--

CREATE TABLE public."ConsentRecord" (
    id text NOT NULL,
    "tenantId" text,
    "ownerEmail" text NOT NULL,
    "policyId" text,
    "docId" text,
    "consentType" text NOT NULL,
    accepted boolean NOT NULL,
    "ipAddress" text,
    "deviceId" text,
    "appVersion" text,
    "acceptedAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "revokedAt" timestamp(3) without time zone
);


ALTER TABLE public."ConsentRecord" OWNER TO alex;

--
-- Name: ExecutionMetric; Type: TABLE; Schema: public; Owner: alex
--

CREATE TABLE public."ExecutionMetric" (
    id text NOT NULL,
    "tenantId" text,
    "executionId" text NOT NULL,
    "ownerEmail" text NOT NULL,
    "transitDurationMin" integer,
    "siteArrivalDelayMin" integer,
    "onSiteDurationMin" integer,
    "idleTimeMin" integer,
    "distanceKm" double precision,
    "geofenceBreaches" integer DEFAULT 0 NOT NULL,
    "routeDeviationMaxMeters" integer,
    "scoreExecution" integer,
    "scoreReliability" integer,
    "scoreRisk" integer,
    "fraudFlags" jsonb,
    "calculatedAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    source text DEFAULT 'BATCH'::text NOT NULL
);


ALTER TABLE public."ExecutionMetric" OWNER TO alex;

--
-- Name: FeatureFlag; Type: TABLE; Schema: public; Owner: alex
--

CREATE TABLE public."FeatureFlag" (
    id text NOT NULL,
    key text NOT NULL,
    label text NOT NULL,
    description text NOT NULL,
    icon text,
    enabled boolean DEFAULT true NOT NULL,
    "tenantId" text,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public."FeatureFlag" OWNER TO alex;

--
-- Name: Integration; Type: TABLE; Schema: public; Owner: alex
--

CREATE TABLE public."Integration" (
    id text NOT NULL,
    name text NOT NULL,
    type public."IntType" NOT NULL,
    icon text,
    "apiKey" text,
    "baseUrl" text,
    "webhookUrl" text,
    "lastTestedAt" timestamp(3) without time zone,
    metadata jsonb,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL,
    description text,
    status text DEFAULT 'ACTIVE'::text NOT NULL
);


ALTER TABLE public."Integration" OWNER TO alex;

--
-- Name: Invoice; Type: TABLE; Schema: public; Owner: alex
--

CREATE TABLE public."Invoice" (
    id text NOT NULL,
    "subscriptionId" text NOT NULL,
    amount numeric(10,2) NOT NULL,
    status public."InvoiceStatus" DEFAULT 'PENDING'::public."InvoiceStatus" NOT NULL,
    "dueDate" timestamp(3) without time zone NOT NULL,
    "paidAt" timestamp(3) without time zone,
    "externalId" text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public."Invoice" OWNER TO alex;

--
-- Name: LocaleProfile; Type: TABLE; Schema: public; Owner: alex
--

CREATE TABLE public."LocaleProfile" (
    id text NOT NULL,
    "countryCode" text NOT NULL,
    name text NOT NULL,
    language text DEFAULT 'pt-BR'::text NOT NULL,
    currency text DEFAULT 'BRL'::text NOT NULL,
    "currencySymbol" text DEFAULT 'R$'::text NOT NULL,
    "dateFormat" text DEFAULT 'DD/MM/YYYY'::text NOT NULL,
    "numberFormat" text DEFAULT 'PT_STYLE'::text NOT NULL,
    timezone text DEFAULT 'UTC'::text NOT NULL,
    "taxIdLabel" text DEFAULT 'Tax ID'::text NOT NULL,
    "postalCodeLabel" text DEFAULT 'Postal Code'::text NOT NULL,
    "measureSystem" text DEFAULT 'METRIC'::text NOT NULL,
    "isActive" boolean DEFAULT true NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public."LocaleProfile" OWNER TO alex;

--
-- Name: Location; Type: TABLE; Schema: public; Owner: alex
--

CREATE TABLE public."Location" (
    id text NOT NULL,
    "tenantId" text NOT NULL,
    name text NOT NULL,
    type public."LocationType" DEFAULT 'BUILDING'::public."LocationType" NOT NULL,
    address text,
    floor text,
    room text,
    icon text,
    latitude double precision,
    longitude double precision,
    "parentId" text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public."Location" OWNER TO alex;

--
-- Name: Metatag; Type: TABLE; Schema: public; Owner: alex
--

CREATE TABLE public."Metatag" (
    id text NOT NULL,
    type public."MetatagType" NOT NULL,
    key text NOT NULL,
    "ptBr" text NOT NULL,
    "enUs" text NOT NULL,
    "esEs" text NOT NULL,
    icon text,
    color text,
    "isActive" boolean DEFAULT true NOT NULL,
    "sortOrder" integer DEFAULT 0 NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public."Metatag" OWNER TO alex;

--
-- Name: NotificationLog; Type: TABLE; Schema: public; Owner: alex
--

CREATE TABLE public."NotificationLog" (
    id text NOT NULL,
    "templateId" text NOT NULL,
    recipient text NOT NULL,
    channel public."Channel" NOT NULL,
    status public."NotifStatus" DEFAULT 'SENT'::public."NotifStatus" NOT NULL,
    "sentAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    metadata jsonb
);


ALTER TABLE public."NotificationLog" OWNER TO alex;

--
-- Name: NotificationTemplate; Type: TABLE; Schema: public; Owner: alex
--

CREATE TABLE public."NotificationTemplate" (
    id text NOT NULL,
    key text NOT NULL,
    label text NOT NULL,
    channel public."Channel" NOT NULL,
    subject text,
    body text NOT NULL,
    variables jsonb,
    "isActive" boolean DEFAULT true NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public."NotificationTemplate" OWNER TO alex;

--
-- Name: Plan; Type: TABLE; Schema: public; Owner: alex
--

CREATE TABLE public."Plan" (
    id text NOT NULL,
    name text NOT NULL,
    "priceMonthly" numeric(10,2) NOT NULL,
    "priceYearly" numeric(10,2) NOT NULL,
    "maxAssets" integer NOT NULL,
    "maxUsers" integer NOT NULL,
    "storageGb" integer NOT NULL,
    features jsonb NOT NULL,
    "isActive" boolean DEFAULT true NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public."Plan" OWNER TO alex;

--
-- Name: PushToken; Type: TABLE; Schema: public; Owner: alex
--

CREATE TABLE public."PushToken" (
    id text NOT NULL,
    "userId" text NOT NULL,
    token text NOT NULL,
    device text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public."PushToken" OWNER TO alex;

--
-- Name: ServiceProvider; Type: TABLE; Schema: public; Owner: alex
--

CREATE TABLE public."ServiceProvider" (
    id text NOT NULL,
    name text NOT NULL,
    category text NOT NULL,
    rating double precision DEFAULT 0 NOT NULL,
    reviews integer DEFAULT 0 NOT NULL,
    photo text,
    tags jsonb,
    keywords text,
    phone text,
    email text,
    city text,
    state text DEFAULT 'SP'::text NOT NULL,
    verified boolean DEFAULT false NOT NULL,
    "isActive" boolean DEFAULT true NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public."ServiceProvider" OWNER TO alex;

--
-- Name: StockItem; Type: TABLE; Schema: public; Owner: alex
--

CREATE TABLE public."StockItem" (
    id text NOT NULL,
    "assetId" text NOT NULL,
    name text NOT NULL,
    sku text NOT NULL,
    "currentStock" integer DEFAULT 0 NOT NULL,
    "minStock" integer DEFAULT 1 NOT NULL,
    unit text DEFAULT 'un'::text NOT NULL,
    "subLocation" text,
    "unitPrice" numeric(10,2),
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public."StockItem" OWNER TO alex;

--
-- Name: StockMovement; Type: TABLE; Schema: public; Owner: alex
--

CREATE TABLE public."StockMovement" (
    id text NOT NULL,
    "itemId" text NOT NULL,
    type public."MovementType" NOT NULL,
    quantity integer NOT NULL,
    reason text,
    "fromAssetId" text,
    "toAssetId" text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public."StockMovement" OWNER TO alex;

--
-- Name: Subscription; Type: TABLE; Schema: public; Owner: alex
--

CREATE TABLE public."Subscription" (
    id text NOT NULL,
    "tenantId" text NOT NULL,
    "planId" text NOT NULL,
    "billingCycle" public."BillingCycle" DEFAULT 'MONTHLY'::public."BillingCycle" NOT NULL,
    status public."SubStatus" DEFAULT 'ACTIVE'::public."SubStatus" NOT NULL,
    "currentStart" timestamp(3) without time zone NOT NULL,
    "currentEnd" timestamp(3) without time zone NOT NULL,
    "cancelledAt" timestamp(3) without time zone,
    "trialEndsAt" timestamp(3) without time zone,
    "externalId" text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public."Subscription" OWNER TO alex;

--
-- Name: TechnicianProfile; Type: TABLE; Schema: public; Owner: alex
--

CREATE TABLE public."TechnicianProfile" (
    id text NOT NULL,
    "userId" text NOT NULL,
    status text DEFAULT 'PENDING'::text NOT NULL,
    score double precision DEFAULT 5.0 NOT NULL,
    cft text,
    specialty text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public."TechnicianProfile" OWNER TO alex;

--
-- Name: TelemetryEvent; Type: TABLE; Schema: public; Owner: alex
--

CREATE TABLE public."TelemetryEvent" (
    id text NOT NULL,
    "tenantId" text,
    "ownerEmail" text NOT NULL,
    "deviceId" text,
    "executionId" text,
    "eventType" public."TelemetryEventType" NOT NULL,
    lat double precision,
    lng double precision,
    accuracy double precision,
    altitude double precision,
    speed double precision,
    heading double precision,
    "locationSource" text,
    "batteryLevel" double precision,
    "batteryCharging" boolean,
    "networkType" text,
    "appVersion" text,
    "osVersion" text,
    "deviceModel" text,
    "isMockLocation" boolean DEFAULT false NOT NULL,
    "isRooted" boolean DEFAULT false NOT NULL,
    "clockDriftMs" integer,
    "serverTimestamp" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "deviceTimestamp" timestamp(3) without time zone,
    payload jsonb,
    "retentionTier" text DEFAULT 'OPERATIONAL'::text NOT NULL,
    "expiresAt" timestamp(3) without time zone
);


ALTER TABLE public."TelemetryEvent" OWNER TO alex;

--
-- Name: Tenant; Type: TABLE; Schema: public; Owner: alex
--

CREATE TABLE public."Tenant" (
    id text NOT NULL,
    name text NOT NULL,
    slug text NOT NULL,
    email text NOT NULL,
    phone text,
    "taxId" text,
    "defaultLang" text DEFAULT 'pt-BR'::text NOT NULL,
    status public."TenantStatus" DEFAULT 'TRIAL'::public."TenantStatus" NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL,
    "avatarUrl" text,
    "localeId" text,
    "ownerName" text NOT NULL,
    "sectorCode" text
);


ALTER TABLE public."Tenant" OWNER TO alex;

--
-- Name: TranslationOverride; Type: TABLE; Schema: public; Owner: alex
--

CREATE TABLE public."TranslationOverride" (
    id text NOT NULL,
    "tenantId" text NOT NULL,
    key text NOT NULL,
    language text NOT NULL,
    value text NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public."TranslationOverride" OWNER TO alex;

--
-- Name: User; Type: TABLE; Schema: public; Owner: alex
--

CREATE TABLE public."User" (
    id text NOT NULL,
    "tenantId" text NOT NULL,
    email text NOT NULL,
    name text NOT NULL,
    password text NOT NULL,
    role public."UserRole" DEFAULT 'USER'::public."UserRole" NOT NULL,
    "isActive" boolean DEFAULT true NOT NULL,
    "lastLogin" timestamp(3) without time zone,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL,
    "avatarUrl" text
);


ALTER TABLE public."User" OWNER TO alex;

--
-- Name: UserModuleData; Type: TABLE; Schema: public; Owner: alex
--

CREATE TABLE public."UserModuleData" (
    id text NOT NULL,
    "ownerEmail" text NOT NULL,
    module text NOT NULL,
    data jsonb NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public."UserModuleData" OWNER TO alex;

--
-- Name: _prisma_migrations; Type: TABLE; Schema: public; Owner: alex
--

CREATE TABLE public._prisma_migrations (
    id character varying(36) NOT NULL,
    checksum character varying(64) NOT NULL,
    finished_at timestamp with time zone,
    migration_name character varying(255) NOT NULL,
    logs text,
    rolled_back_at timestamp with time zone,
    started_at timestamp with time zone DEFAULT now() NOT NULL,
    applied_steps_count integer DEFAULT 0 NOT NULL
);


ALTER TABLE public._prisma_migrations OWNER TO alex;

--
-- Data for Name: Admin; Type: TABLE DATA; Schema: public; Owner: alex
--

COPY public."Admin" (id, email, name, password, "createdAt", "updatedAt") FROM stdin;
cmnhrwhb50000l828dmz8w1u0	admin@brspark.com	Administrador Demo	$2a$10$K5Gw6YEgD8dKkFReUMkvrOWrSyDk3gQVybAA8bCTSAGk5r0SGkesW	2026-04-02 17:53:13.87	2026-04-02 17:53:24.554
\.


--
-- Data for Name: Asset; Type: TABLE DATA; Schema: public; Owner: alex
--

COPY public."Asset" (id, "tenantId", "parentId", title, type, status, description, "imageUrl", "locationId", metadata, "createdAt", "updatedAt", "deletedAt") FROM stdin;
\.


--
-- Data for Name: AssetShare; Type: TABLE DATA; Schema: public; Owner: alex
--

COPY public."AssetShare" (id, "assetId", "ownerEmail", "sharedWithEmail", permission, modules, status, "invitedAt", "expiresAt") FROM stdin;
\.


--
-- Data for Name: AuditLog; Type: TABLE DATA; Schema: public; Owner: alex
--

COPY public."AuditLog" (id, "tenantId", "userId", "adminId", action, resource, category, metadata, "ipAddress", "createdAt") FROM stdin;
cmnhhqj64000i3yrjoyd41ka7	cmnhhqj5c000e3yrjmvwv50er	cmnhhqj5w000g3yrj2m7fnu6n	\N	USER_REGISTER	alex@brspark.com	AUTH	\N	\N	2026-04-02 13:08:40.204
cmnhhqp3i000k3yrj3ksacor8	cmnhhqj5c000e3yrjmvwv50er	cmnhhqj5w000g3yrj2m7fnu6n	\N	USER_LOGIN	alex@brspark.com	AUTH	\N	\N	2026-04-02 13:08:47.887
cmnhhrrqf000m3yrj8k5f9izk	cmnhhqj5c000e3yrjmvwv50er	cmnhhqj5w000g3yrj2m7fnu6n	\N	USER_LOGIN	alex@brspark.com	AUTH	\N	\N	2026-04-02 13:09:37.959
cmnhhz6p8007i3yrjuoi7xhv8	cmnhhqj5c000e3yrjmvwv50er	cmnhhqj5w000g3yrj2m7fnu6n	\N	USER_LOGIN	alex@brspark.com	AUTH	\N	\N	2026-04-02 13:15:23.949
cmnhr9dmh0a309g8mueiw933b	cmnhhqj5c000e3yrjmvwv50er	cmnhhqj5w000g3yrj2m7fnu6n	\N	USER_LOGIN	alex@brspark.com	AUTH	\N	\N	2026-04-02 17:35:16.025
cmnhrxx3p003nl0zim1gwwksj	\N	\N	\N	SYNC_OS_COMPLETED	ChecklistExecution	DATA	{"hasGps": false, "ownerEmail": "alex@brspark.com", "templateId": "chk_mnhro4is", "executionId": "cmnhrqhbi0b9j9g8mtnd7ocdb"}	\N	2026-04-02 17:54:21.012
cmnhrxx4k003ol0zioziegn64	\N	\N	\N	SYNC_OS_COMPLETED	ChecklistExecution	DATA	{"hasGps": false, "ownerEmail": "alex@brspark.com", "templateId": "chk_mnhro4is", "executionId": "cmnhrqhbi0b9j9g8mtnd7ocdb"}	\N	2026-04-02 17:54:21.045
cmnhrxx5a003pl0zi4pm4gmjp	\N	\N	\N	SYNC_OS_COMPLETED	ChecklistExecution	DATA	{"hasGps": false, "ownerEmail": "alex@brspark.com", "templateId": "chk_mnhro4is", "executionId": "cmnhrqhbi0b9j9g8mtnd7ocdb"}	\N	2026-04-02 17:54:21.071
cmnhrxx8a003ql0zitnj8vstt	\N	\N	\N	SYNC_OS_COMPLETED	ChecklistExecution	DATA	{"hasGps": false, "ownerEmail": "alex@brspark.com", "templateId": "chk_mnhro4is", "executionId": "cmnhrqhbi0b9j9g8mtnd7ocdb"}	\N	2026-04-02 17:54:21.178
cmnhry81x0052l0zieauhrl16	\N	\N	cmnhrwhb50000l828dmz8w1u0	LOGIN	Admin Console	AUTH	\N	\N	2026-04-02 17:54:35.204
cmnht03e800k2quvgtwftftfm	\N	\N	cmnhrwhb50000l828dmz8w1u0	LOGIN	Admin Console	AUTH	\N	\N	2026-04-02 18:24:02.096
cmnht46ox00pjquvgqqijwp9b	\N	\N	cmnhrwhb50000l828dmz8w1u0	LOGIN	Admin Console	AUTH	\N	\N	2026-04-02 18:27:12.993
cmnhtb56h00z2quvgaotk0p0n	\N	\N	\N	SYNC_OS_COMPLETED	ChecklistExecution	DATA	{"hasGps": false, "ownerEmail": "alex@brspark.com", "templateId": "chk_mnhro4is", "executionId": "cmnht8qog00vkquvgverzll77"}	\N	2026-04-02 18:32:37.625
cmnhtb56l00z3quvgehlfcmk0	\N	\N	\N	SYNC_OS_COMPLETED	ChecklistExecution	DATA	{"hasGps": false, "ownerEmail": "alex@brspark.com", "templateId": "chk_mnhro4is", "executionId": "cmnht8qog00vkquvgverzll77"}	\N	2026-04-02 18:32:37.629
cmnhtrfo7006sf5jr99vysotq	\N	\N	\N	SYNC_OS_COMPLETED	ChecklistExecution	DATA	{"hasGps": false, "ownerEmail": "alex@brspark.com", "templateId": "chk_mnhro4is", "executionId": "cmnhtnyp4001zf5jrvv0r23qa"}	\N	2026-04-02 18:45:17.72
cmnhtrfob006tf5jraizt9s64	\N	\N	\N	SYNC_OS_COMPLETED	ChecklistExecution	DATA	{"hasGps": false, "ownerEmail": "alex@brspark.com", "templateId": "chk_mnhro4is", "executionId": "cmnhtnyp4001zf5jrvv0r23qa"}	\N	2026-04-02 18:45:17.724
cmnhv5qhn0215f5jrmh1cr3px	\N	\N	cmnhrwhb50000l828dmz8w1u0	LOGIN	Admin Console	AUTH	\N	\N	2026-04-02 19:24:24.539
cmnhv9qg9026hf5jr9oty8kbv	\N	\N	cmnhrwhb50000l828dmz8w1u0	LOGIN	Admin Console	AUTH	\N	\N	2026-04-02 19:27:31.113
\.


--
-- Data for Name: ChatContact; Type: TABLE DATA; Schema: public; Owner: alex
--

COPY public."ChatContact" (id, "requesterId", "addresseeId", status, "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: ChatMessage; Type: TABLE DATA; Schema: public; Owner: alex
--

COPY public."ChatMessage" (id, "roomId", "senderId", "senderName", type, content, "mediaUrl", "createdAt") FROM stdin;
\.


--
-- Data for Name: ChatRoom; Type: TABLE DATA; Schema: public; Owner: alex
--

COPY public."ChatRoom" (id, name, description, "avatarColor", "isGroup", "creatorId", "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: ChatRoomMember; Type: TABLE DATA; Schema: public; Owner: alex
--

COPY public."ChatRoomMember" (id, "roomId", "userId", role, "joinedAt", "lastReadAt") FROM stdin;
\.


--
-- Data for Name: ChecklistExecution; Type: TABLE DATA; Schema: public; Owner: alex
--

COPY public."ChecklistExecution" (id, "templateId", "ownerEmail", "assetId", status, responses, metadata, "locationAddress", "locationLat", "locationLng", "locationRadius", "locationZoneType", "locationPolygon", "gpsLocation", "startedAt", "completedAt", "syncedAt", "createdAt") FROM stdin;
cmnhrqhbi0b9j9g8mtnd7ocdb	chk_mnhro4is	alex@brspark.com	\N	COMPLETED	{"field_4248": "{\\"action\\":\\"CHEGADA\\",\\"timestamp\\":\\"2026-04-02T17:52:04.330Z\\",\\"coordinates\\":{\\"lat\\":-23.569983,\\"lng\\":-46.7851655},\\"address\\":\\"Parque Chico Mendes,  - Jd Bussocaba City, Osasco - SP\\",\\"traversedPath\\":[[-23.569983,-46.7851655]]}", "field_21036": "file:///Users/alex/Library/Developer/CoreSimulator/Devices/99E0B8BD-911F-42C8-A707-E7AA58227EEE/data/Containers/Data/Application/63BD2007-9626-4C9B-920B-136B093842C7/Library/Caches/ImagePicker/A7F606A3-78BC-4282-B393-F5A8E2158EE6.heic", "field_66812": "Sim", "field_75000": "SIG_V1|meta:{\\"lat\\":-23.569983,\\"lng\\":-46.7851655,\\"address\\":\\",  - Osasco, SP\\",\\"ip\\":\\"2804:7f0:9383:8b58:b9fe:d321:ec05:865c\\"}|M60.33333333333333,179.00000127156574 L61,179.00000127156574 L92,169.66666793823242 L166,140.33333460489905 L187.66666666666666,119.66666793823242 L191,102.33333460489905 L191.66666666666666,100.66666793823242 L191.66666666666666,100.33333460489905 L191.66666666666666,99.66666793823242 L191.66666666666666,99.33333460489905 L191.66666666666666,99.66666793823242|M191.66666666666666,101.00000127156574 L191.66666666666666,100.66666793823242 L103.33333333333333,73.33333460489905 L77,78.66666793823242 L58.66666666666666,100.00000127156574 L58,104.66666793823242|M59.66666666666666,99.66666793823242 L128,218.00000127156568 L133.66666666666666,222.66666793823242 L172.33333333333331,183.00000127156568 L173,173.66666793823242 L181,192.00000127156568 L213.33333333333331,199.66666793823242 L248.33333333333331,178.66666793823242 L249,178.33333460489905 L249.33333333333331,178.66666793823242 L253.66666666666663,184.33333460489905 L260.66666666666663,201.66666793823242 L262.3333333333333,207.33333460489905 L257.3333333333333,222.66666793823242 L252,228.33333460489905 L240.66666666666663,230.33333460489905 L229,230.33333460489905 L203.66666666666666,225.00000127156568 L186,218.33333460489905 L164.33333333333331,201.66666793823242 L161,188.33333460489905 L171,179.33333460489905 L174.66666666666666,177.33333460489905 L203.66666666666666,172.66666793823242 L233,169.66666793823242 L240.66666666666663,169.66666793823242 L247.66666666666663,167.00000127156574 L249.33333333333331,165.66666793823242 L256.66666666666663,157.33333460489905 L258,156.00000127156574 L282.66666666666663,150.66666793823242 L317.66666666666663,140.66666793823242 L319,140.33333460489905 L319.3333333333333,140.00000127156574 L328.66666666666663,120.66666793823242 L330.66666666666663,109.66666793823242 L330.66666666666663,108.33333460489905 L330.66666666666663,109.33333460489905 L336.3333333333333,139.33333460489905 L336.66666666666663,139.33333460489905 L336.66666666666663,138.66666793823242", "field_75975": "{\\"action\\":\\"SAIDA\\",\\"timestamp\\":\\"2026-04-02T17:51:36.803Z\\",\\"coordinates\\":{\\"lat\\":-23.569983,\\"lng\\":-46.7851655},\\"address\\":\\"Parque Chico Mendes,  - Jd Bussocaba City, Osasco - SP\\"}", "__time_field_4248": "2026-04-02T17:52:04.330Z", "__time_field_21036": "2026-04-02T17:54:01.637Z", "__time_field_66812": "2026-04-02T17:52:10.089Z", "__time_field_75000": "2026-04-02T17:54:17.283Z", "__time_field_75975": "2026-04-02T17:51:36.804Z", "__section_end_page_1": "2026-04-02T17:54:19.304Z", "__section_start_page_1": "2026-04-02T17:51:37.044Z"}	{"icon": "build-outline", "refId": "chk_mnhro4is", "title": "Rota", "acceptedAt": "2026-04-02T17:50:40.054Z", "appVersion": "1.0", "receivedAt": "2026-04-02T17:48:35.018Z", "description": "Tarefa de rotina despachada.", "devicePlatform": "AppMovel", "durationSeconds": 214}	\N	44.8492	7.343651	150	segment	[[44.849368, 7.343243], [44.849033, 7.34406]]	null	2026-04-02 17:50:44.616	2026-04-02 17:54:19.305	2026-04-02 17:54:21.044	2026-04-02 17:48:33.965
cmnht8qog00vkquvgverzll77	chk_mnhro4is	alex@brspark.com	\N	COMPLETED	{"field_4248": "{\\"action\\":\\"CHEGADA\\",\\"timestamp\\":\\"2026-04-02T18:31:40.775Z\\",\\"coordinates\\":{\\"lat\\":-23.569983,\\"lng\\":-46.7851655},\\"address\\":\\"Parque Chico Mendes,  - Jd Bussocaba City, Osasco - SP\\",\\"traversedPath\\":[[-23.569983,-46.7851655],[-23.569983,-46.7851655]]}", "field_21036": "file:///Users/alex/Library/Developer/CoreSimulator/Devices/99E0B8BD-911F-42C8-A707-E7AA58227EEE/data/Containers/Data/Application/63BD2007-9626-4C9B-920B-136B093842C7/Library/Caches/ImagePicker/01481CF1-D738-41CB-8EB6-EC38B439637C.jpg", "field_66812": "Sim", "field_75000": "SIG_V1|meta:{\\"lat\\":-23.569983,\\"lng\\":-46.7851655,\\"address\\":\\",  - Osasco, SP\\",\\"ip\\":\\"2804:7f0:9383:8b58:b9fe:d321:ec05:865c\\"}|M144,217.66666793823242 L186.6666666666667,196.66666793823242 L233.00000000000003,174.66666793823242 L335.6666666666667,120.33333460489908 L366.00000000000006,101.33333460489908 L366.6666666666667,100.33333460489908 L365.6666666666667,101.00000127156574 L343.6666666666667,126.66666793823242 L335.33333333333337,133.66666793823242 L306.6666666666667,152.66666793823242 L266.33333333333337,172.66666793823242 L232.33333333333337,187.33333460489905 L207.00000000000003,192.00000127156574 L195.33333333333337,193.33333460489905 L185.6666666666667,190.00000127156574 L174.00000000000003,185.33333460489905 L168.6666666666667,176.33333460489908 L159.6666666666667,145.00000127156574 L158.33333333333337,133.33333460489908 L159.00000000000006,131.66666793823242 L165.33333333333337,131.33333460489908 L177.00000000000003,135.33333460489908 L192.33333333333337,148.00000127156574 L218.00000000000003,172.00000127156574 L238.33333333333337,197.33333460489905 L249.66666666666669,210.00000127156574 L278.6666666666667,238.00000127156574 L335.6666666666667,235.00000127156574 L392.00000000000006,205.00000127156574 L392.33333333333337,204.66666793823242 L392.33333333333337,205.33333460489905 L393.6666666666667,206.66666793823242 L393.6666666666667,207.00000127156574 L394.33333333333337,207.00000127156574 L398.00000000000006,204.66666793823242 L411.00000000000006,194.33333460489905 L423.00000000000006,180.66666793823242 L426.6666666666667,171.00000127156574 L426.6666666666667,170.00000127156574 L423.00000000000006,168.66666793823242 L409.33333333333337,168.66666793823242 L401.6666666666667,173.33333460489908 L400.6666666666667,175.66666793823242 L400.6666666666667,176.00000127156574 L402.6666666666667,176.33333460489908 L421.6666666666667,166.66666793823242 L436.6666666666667,156.00000127156574 L448.33333333333337,150.00000127156574 L449,150.66666793823242 L450.6666666666667,161.00000127156574 L447.6666666666667,168.66666793823242 L426.33333333333337,186.66666793823242 L410.6666666666667,190.66666793823242 L403.6666666666667,189.66666793823242 L402.00000000000006,182.00000127156574 L402.00000000000006,172.66666793823242 L409.00000000000006,162.00000127156574 L418.33333333333337,159.00000127156574 L434,163.33333460489908 L444.33333333333337,169.00000127156574 L461.6666666666667,183.66666793823242 L469,190.00000127156574 L478.6666666666667,193.00000127156574 L486.33333333333337,193.00000127156574 L495.66666666666674,186.00000127156574 L501,174.66666793823242 L502.33333333333337,170.33333460489908 L502.66666666666674,170.33333460489908 L504,171.00000127156574 L507.66666666666674,174.66666793823242 L515.3333333333334,178.66666793823242 L526.6666666666667,179.66666793823242 L532.3333333333334,178.00000127156574 L542,173.66666793823242 L563,165.00000127156574 L564.3333333333334,165.00000127156574 L564.3333333333334,165.33333460489908 L565.3333333333334,165.33333460489908 L570.6666666666667,164.66666793823242 L576.3333333333334,164.00000127156574 L586,164.00000127156574 L588.6666666666667,164.00000127156574 L590.6666666666667,164.00000127156574 L595,164.00000127156574 L604.6666666666666,163.33333460489908 L616,162.33333460489908 L617.6666666666666,163.66666793823242 L618.6666666666666,165.00000127156574 L620.3333333333334,166.00000127156574 L634.3333333333334,158.33333460489908 L643,152.00000127156574 L653.3333333333334,146.00000127156574 L656.6666666666666,145.66666793823242 L658,147.33333460489908 L661.6666666666666,152.00000127156574 L664,151.33333460489908 L671.3333333333334,138.00000127156574 L675,126.33333460489908 L678.6666666666666,112.66666793823242 L682.6666666666666,95.00000127156574 L686,85.33333460489908 L686.6666666666666,84.33333460489908 L687.3333333333334,84.33333460489908 L687.6666666666666,84.66666793823242 L694,94.00000127156574 L700.6666666666666,109.33333460489908 L705.3333333333334,199.00000127156574 L686.6666666666666,222.00000127156574 L652.6666666666666,236.33333460489905 L613,239.66666793823242 L569.3333333333334,229.66666793823242 L529.3333333333334,213.00000127156574 L495,193.33333460489905 L472,179.33333460489908 L472.6666666666667,175.00000127156574 L474.6666666666667,169.66666793823242 L480,161.00000127156574 L489.6666666666667,156.00000127156574 L501,154.00000127156574 L526.6666666666667,152.66666793823242 L612,168.00000127156574 L645.6666666666666,177.66666793823242 L665.3333333333334,186.00000127156574 L668,187.33333460489905 L672,192.00000127156574 L687.6666666666666,205.33333460489905 L693.3333333333334,206.66666793823242 L709,208.00000127156574 L730.3333333333334,202.33333460489905 L742.6666666666666,194.66666793823242 L759.3333333333334,173.66666793823242 L763.6666666666666,148.00000127156574 L765,130.33333460489908 L762.6666666666666,126.66666793823242 L761,125.00000127156574 L756.3333333333334,123.33333460489908 L745,123.33333460489908 L737.3333333333334,128.00000127156574 L722,144.33333460489908 L720.3333333333334,148.33333460489908 L719.6666666666666,146.33333460489908 L718.6666666666666,136.66666793823242 L718.6666666666666,127.00000127156574 L724.6666666666666,113.33333460489908 L741,105.33333460489908 L764.6666666666666,103.66666793823242 L796,113.66666793823242 L801.3333333333334,116.66666793823242 L807,119.00000127156574 L817.3333333333334,117.66666793823242 L818,115.00000127156574 L817,110.00000127156574 L816.3333333333334,109.00000127156574 L816,109.00000127156574", "field_75975": "{\\"action\\":\\"SAIDA\\",\\"timestamp\\":\\"2026-04-02T18:31:01.016Z\\",\\"coordinates\\":{\\"lat\\":-23.569983,\\"lng\\":-46.7851655},\\"address\\":\\"Parque Chico Mendes,  - Jd Bussocaba City, Osasco - SP\\"}", "__time_field_4248": "2026-04-02T18:31:40.775Z", "__time_field_21036": "2026-04-02T18:32:08.565Z", "__time_field_66812": "2026-04-02T18:31:53.660Z", "__time_field_75000": "2026-04-02T18:32:31.588Z", "__time_field_75975": "2026-04-02T18:31:01.016Z", "__section_end_page_1": "2026-04-02T18:32:37.205Z", "__section_start_page_1": "2026-04-02T18:31:01.039Z"}	{"icon": "build-outline", "refId": "chk_mnhro4is", "title": "Rota", "acceptedAt": "2026-04-02T18:30:53.912Z", "appVersion": "1.0", "receivedAt": "2026-04-02T18:30:48.175Z", "description": "Tarefa de rotina despachada.", "devicePlatform": "AppMovel", "durationSeconds": 103}	\N	-17.20713	-49.918002	150	segment	[[-17.205391, -49.946573], [-17.208869, -49.889431]]	null	2026-04-02 18:30:53.941	2026-04-02 18:32:37.205	2026-04-02 18:32:37.615	2026-04-02 18:30:45.52
cmnhtnyp4001zf5jrvv0r23qa	chk_mnhro4is	alex@brspark.com	\N	COMPLETED	{"field_4248": "{\\"action\\":\\"CHEGADA\\",\\"timestamp\\":\\"2026-04-02T18:44:07.697Z\\",\\"coordinates\\":{\\"lat\\":-23.569983,\\"lng\\":-46.7851655},\\"address\\":\\"Parque Chico Mendes,  - Jd Bussocaba City, Osasco - SP\\",\\"traversedPath\\":[[-23.569983,-46.7851655],[-23.569983,-46.7851655],[37.33240731,-122.03046898],[37.33240731,-122.03046898],[37.33233141,-122.0312186],[37.33233141,-122.0312186],[37.33233141,-122.0312186],[37.33233141,-122.0312186],[37.33233141,-122.0312186],[37.33233141,-122.0312186]]}", "field_21036": "http://localhost:3001/uploads/storage/checklists/unknown_empresa_com/cmnhtnyp4001zf5jrvv0r23qa_field_21036_1775155517486.jpg", "field_75000": "SIG_V1|meta:{\\"lat\\":-23.569983,\\"lng\\":-46.7851655,\\"address\\":\\",  - Osasco, SP\\",\\"ip\\":\\"2804:7f0:9383:8b58:b9fe:d321:ec05:865c\\"}|M57.66666666666674,189.66666793823242 L230.00000000000003,106.33333460489908 L266.00000000000006,92.00000127156574 L320.00000000000006,69.00000127156574 L352.00000000000006,56.33333460489908 L346.00000000000006,60.000001271565736 L331.00000000000006,72.33333460489908 L316.6666666666667,82.66666793823242 L282.33333333333337,102.33333460489908 L206.00000000000003,135.33333460489908 L154.33333333333337,154.33333460489908 L116.66666666666671,169.00000127156574 L99.00000000000004,177.33333460489908 L99.00000000000004,177.66666793823242 L99.66666666666671,177.33333460489908 L125.33333333333337,169.66666793823242 L193.00000000000003,152.00000127156574 L262.6666666666667,137.66666793823242 L332.33333333333337,125.00000127156574 L372.00000000000006,120.33333460489908 L372.33333333333337,120.33333460489908 L365.00000000000006,125.00000127156574 L339.33333333333337,135.66666793823242 L325.6666666666667,141.66666793823242 L298.00000000000006,151.00000127156574 L268.33333333333337,160.33333460489908 L256.6666666666667,164.66666793823242 L238.66666666666669,170.00000127156574 L239.33333333333337,170.00000127156574 L244.66666666666669,170.66666793823242 L247.33333333333337,170.66666793823242 L247.66666666666669,170.66666793823242 L248.00000000000006,171.00000127156574 L248.66666666666669,171.00000127156574 L254.00000000000006,169.00000127156574 L284.00000000000006,155.00000127156574 L306.33333333333337,144.66666793823242 L372.33333333333337,114.33333460489908 L448.33333333333337,87.00000127156574 L514,73.00000127156574 L545.6666666666667,74.00000127156574 L552.6666666666667,84.33333460489908 L554,104.00000127156574 L534,142.00000127156574 L525,153.33333460489908 L517.3333333333334,157.33333460489908 L509.66666666666674,159.66666793823242 L506.33333333333337,160.00000127156574 L498.66666666666674,161.00000127156574 L489,164.00000127156574 L486.33333333333337,165.66666793823242 L485,166.66666793823242 L485,167.00000127156574 L484.6666666666667,167.00000127156574 L470.33333333333337,168.33333460489908 L462.6666666666667,168.33333460489908 L449,168.33333460489908 L433.6666666666667,168.33333460489908 L416.00000000000006,165.66666793823242 L413.33333333333337,165.00000127156574 L413.00000000000006,164.66666793823242 L412.33333333333337,163.33333460489908|M455.33333333333337,132.33333460489908 L459.6666666666667,133.33333460489908 L471,134.66666793823242 L490.6666666666667,137.00000127156574 L506,138.33333460489908 L514.3333333333334,138.33333460489908|M407.66666666666674,96.00000127156574 L483,82.33333460489908 L556.6666666666667,73.33333460489908 L688,66.33333460489908 L708.3333333333334,68.33333460489908 L675.3333333333334,91.33333460489908 L619.6666666666666,105.33333460489908 L558,114.33333460489908 L532.3333333333334,117.66666793823242 L531.6666666666667,118.00000127156574 L545.3333333333334,118.00000127156574 L601,112.66666793823242 L668.6666666666666,111.00000127156574 L734.3333333333334,111.00000127156574 L782.3333333333334,126.33333460489908 L723.6666666666666,189.00000127156574 L658,208.66666793823242 L578.3333333333334,216.00000127156574 L494.66666666666674,216.00000127156574 L409.00000000000006,206.66666793823242 L341.33333333333337,194.33333460489905 L293.6666666666667,182.33333460489908 L276.00000000000006,178.66666793823242 L276.33333333333337,178.66666793823242 L288.00000000000006,178.66666793823242|M503.33333333333337,172.66666793823242 L504.33333333333337,172.66666793823242 L505.66666666666674,172.66666793823242 L515.3333333333334,171.33333460489908 L551,170.00000127156574 L610.6666666666666,164.66666793823242 L734,148.66666793823242 L773.6666666666666,142.00000127156574 L807,139.00000127156574 L810.3333333333334,138.33333460489908 L811.3333333333334,138.33333460489908 L811.6666666666666,139.00000127156574 L813.6666666666666,140.00000127156574 L823.6666666666666,147.33333460489908 L827.3333333333334,151.00000127156574 L829,152.66666793823242 L831.3333333333334,156.33333460489908 L833.6666666666666,160.00000127156574 L834,160.66666793823242 L834,160.33333460489908 L836.3333333333334,148.66666793823242 L837.6666666666666,137.00000127156574 L839.6666666666666,126.66666793823242 L840,126.66666793823242 L840.3333333333334,128.00000127156574 L847.3333333333334,138.33333460489908 L850.3333333333334,144.00000127156574 L853.6666666666666,147.66666793823242 L855,148.66666793823242 L853.6666666666666,140.33333460489908 L853.6666666666666,135.00000127156574 L854.3333333333334,135.33333460489908 L855.3333333333334,136.66666793823242 L855.6666666666666,137.33333460489908 L856.3333333333334,138.33333460489908|M40.33333333333337,239.66666793823242 L41.00000000000005,239.00000127156574 L53.00000000000004,225.00000127156574 L58.666666666666714,222.00000127156574 L66.33333333333339,219.00000127156574 L69.66666666666671,219.00000127156574 L73.33333333333339,220.66666793823242 L88.66666666666671,233.33333460489905 L101.66666666666671,242.33333460489905 L109.33333333333337,247.00000127156574 L131.6666666666667,257.33333460489905 L147.33333333333337,261.33333460489905 L176.33333333333337,255.33333460489905 L188.00000000000003,243.66666793823242 L194.00000000000003,232.00000127156574 L196.33333333333337,220.33333460489905 L196.6666666666667,218.00000127156574 L197.33333333333337,218.00000127156574 L198.00000000000003,218.00000127156574 L258.6666666666667,243.33333460489905 L321.6666666666667,256.00000127156574 L341.33333333333337,256.00000127156574 L343.6666666666667,256.00000127156574 L343.6666666666667,255.33333460489905 L347.6666666666667,250.33333460489905 L361.6666666666667,241.33333460489905 L375.33333333333337,234.00000127156574 L397.33333333333337,222.00000127156574 L423.00000000000006,213.00000127156574 L464.33333333333337,207.00000127156574 L486,207.00000127156574 L505.66666666666674,211.33333460489905 L527,219.66666793823242 L530.3333333333334,220.33333460489905 L536,219.66666793823242 L541.6666666666667,218.33333460489905 L551.3333333333334,216.00000127156574 L558.6666666666667,213.33333460489905 L570.3333333333334,210.66666793823242 L575,209.66666793823242 L590.3333333333334,210.66666793823242 L598,212.66666793823242 L607.6666666666666,214.66666793823242 L617,214.66666793823242 L624.6666666666666,214.66666793823242 L640.3333333333334,212.33333460489905 L664,207.66666793823242 L685.6666666666666,205.00000127156574 L697,203.33333460489905 L707.3333333333334,205.33333460489905 L720.6666666666666,209.66666793823242 L724.3333333333334,210.33333460489905 L728,209.66666793823242 L729.6666666666666,209.00000127156574 L732,208.33333460489905 L735.6666666666666,208.33333460489905 L736.6666666666666,208.33333460489905 L738.6666666666666,210.00000127156574 L748.3333333333334,214.33333460489905 L758,219.33333460489905 L769.6666666666666,223.00000127156574 L779,223.33333460489905 L790.3333333333334,222.33333460489905 L796,220.00000127156574 L800.6666666666666,217.66666793823242 L801.3333333333334,217.33333460489905 L803,218.00000127156574 L811.6666666666666,223.33333460489905 L825.6666666666666,231.33333460489905 L833.3333333333334,234.33333460489905 L838,234.33333460489905 L843,234.00000127156574 L845.3333333333334,233.33333460489905 L847.6666666666666,233.33333460489905 L853.3333333333334,235.33333460489905 L861,238.33333460489905 L865.6666666666666,238.66666793823242 L867.6666666666666,238.66666793823242 L867.6666666666666,238.33333460489905 L876.3333333333334,233.66666793823242 L887.6666666666666,231.66666793823242 L889.6666666666666,231.00000127156574 L890,231.00000127156574", "field_75975": "{\\"action\\":\\"SAIDA\\",\\"timestamp\\":\\"2026-04-02T18:43:34.763Z\\",\\"coordinates\\":{\\"lat\\":-23.569983,\\"lng\\":-46.7851655},\\"address\\":\\"Parque Chico Mendes,  - Jd Bussocaba City, Osasco - SP\\"}", "__time_field_4248": "2026-04-02T18:44:07.697Z", "__time_field_21036": "2026-04-02T18:44:18.060Z", "__time_field_75000": "2026-04-02T18:44:32.150Z", "__time_field_75975": "2026-04-02T18:43:34.763Z", "__section_end_page_1": "2026-04-02T18:45:17.414Z", "__section_start_page_1": "2026-04-02T18:43:34.808Z"}	{"icon": "build-outline", "refId": "chk_mnhro4is", "title": "Rota", "acceptedAt": "2026-04-02T18:42:53.337Z", "appVersion": "1.0", "receivedAt": "2026-04-02T18:42:40.125Z", "description": "Tarefa de rotina despachada.", "devicePlatform": "AppMovel", "durationSeconds": 144}	\N	-16.174903	-51.91452	150	segment	[[-16.153347, -51.70166], [-16.19646, -52.12738]]	null	2026-04-02 18:42:53.356	2026-04-02 18:45:17.414	2026-04-02 18:45:17.714	2026-04-02 18:42:35.752
\.


--
-- Data for Name: ChecklistTemplate; Type: TABLE DATA; Schema: public; Owner: alex
--

COPY public."ChecklistTemplate" (id, "tenantId", title, description, settings, "schemaData", metadata, version, "isActive", "createdAt", "updatedAt") FROM stdin;
chk_mnhro4is	\N	Rota		{"rules": [], "globalGeofenceRadius": 200, "requireGlobalGeofence": false}	[{"id": "field_75975", "icon": "arrow-up", "type": "transit_start", "label": "Iniciar Deslocamento", "options": null, "required": false, "textMask": null, "iconColor": "#0F172A", "calcFormula": null, "dependsOnId": "", "description": "", "iconLibrary": "FontAwesome", "defaultValue": "", "dependsOnValue": "", "geofenceRadius": null, "dependsOnOperator": "=="}, {"id": "field_4248", "icon": "arrows-alt", "type": "transit_end", "label": "Finalizar Deslocamento", "options": null, "required": false, "textMask": null, "iconColor": "#0F172A", "calcFormula": null, "dependsOnId": "", "description": "", "iconLibrary": "FontAwesome", "defaultValue": "", "dependsOnValue": "", "geofenceRadius": null, "dependsOnOperator": "=="}, {"id": "field_66812", "icon": "aliwangwang", "type": "yes_no", "label": "Sim / Não (Toggle)", "options": null, "required": false, "textMask": null, "iconColor": "#1c50ca", "calcFormula": null, "dependsOnId": "", "description": "", "iconLibrary": "AntDesign", "defaultValue": "", "dependsOnValue": "", "geofenceRadius": null, "dependsOnOperator": "=="}, {"id": "field_57585", "icon": "", "type": "file_upload", "label": "Enviar PDF/Doc", "options": null, "required": false, "textMask": null, "calcFormula": null, "dependsOnId": "", "description": "", "defaultValue": "", "dependsOnValue": "", "geofenceRadius": null, "dependsOnOperator": "=="}, {"id": "field_40882", "icon": "", "type": "photo_stamped", "label": "Foto Carimbada (Ao Vivo)", "options": null, "required": false, "textMask": null, "calcFormula": null, "dependsOnId": "", "description": "", "defaultValue": "", "dependsOnValue": "", "geofenceRadius": null, "dependsOnOperator": "=="}, {"id": "field_21036", "icon": "", "type": "photo", "label": "Foto (Galeria Livre)", "options": null, "required": false, "textMask": null, "calcFormula": null, "dependsOnId": "", "description": "", "defaultValue": "", "dependsOnValue": "", "geofenceRadius": null, "dependsOnOperator": "=="}, {"id": "field_75000", "icon": "", "type": "signature", "label": "Assinatura", "options": null, "required": false, "textMask": null, "calcFormula": null, "dependsOnId": "", "description": "", "defaultValue": "", "dependsOnValue": "", "geofenceRadius": null, "dependsOnOperator": "=="}, {"id": "field_82052", "icon": "", "type": "hidden", "label": "Campo Oculto", "options": null, "required": false, "textMask": null, "calcFormula": null, "dependsOnId": "", "description": "", "defaultValue": "", "dependsOnValue": "", "geofenceRadius": null, "dependsOnOperator": "=="}]	{"icon": ""}	1	t	2026-04-02 17:46:44.14	2026-04-02 17:46:44.14
\.


--
-- Data for Name: CollectionPolicy; Type: TABLE DATA; Schema: public; Owner: alex
--

COPY public."CollectionPolicy" (id, "tenantId", "sectorCode", label, "locationEnabled", "locationBackgroundEnabled", "locationIntervalIdleMin", "locationIntervalTransitMin", "locationIntervalOnSiteMin", "locationDistanceFilterMeters", "retentionGpsRawDays", "retentionEventsYears", "retentionAuditDays", "retentionMetricsDays", "mockGpsAction", "rootJailbreakAction", "clockDriftMaxSeconds", "requireExplicitConsent", "consentGranular", "legalBasis", "requireCheckinPhoto", "allowOfflineCheckin", "minOnSiteMinutes", "outOfPolicyAction", "isActive", "createdAt", "updatedAt") FROM stdin;
cmnhgi1rs000cedboz4pbavp7	\N	\N	Padrão Global	t	t	30	2	5	200	15	5	180	730	WARN	WARN	300	t	t	LGPD	f	t	0	PROCEED_FLAG	t	2026-04-02 12:34:04.793	2026-04-02 12:34:04.793
cmnhgi1rs000aedbo1qs68ys2	\N	\N	Padrão Global	t	t	30	2	5	200	15	5	180	730	WARN	WARN	300	t	t	LGPD	f	t	0	PROCEED_FLAG	t	2026-04-02 12:34:04.792	2026-04-02 12:34:04.792
cmnhgi1u2000ledbo2e4s9nne	\N	\N	Padrão Global	t	t	30	2	5	200	15	5	180	730	WARN	WARN	300	t	t	LGPD	f	t	0	PROCEED_FLAG	t	2026-04-02 12:34:04.874	2026-04-02 12:34:04.874
\.


--
-- Data for Name: ComplianceAcceptance; Type: TABLE DATA; Schema: public; Owner: alex
--

COPY public."ComplianceAcceptance" (id, "docId", "userId", "tenantId", "ipAddress", "acceptedAt") FROM stdin;
\.


--
-- Data for Name: ComplianceDoc; Type: TABLE DATA; Schema: public; Owner: alex
--

COPY public."ComplianceDoc" (id, type, version, title, content, "isActive", "publishedAt", "createdBy", "createdAt", "updatedAt", "sectorCode", "tenantId") FROM stdin;
\.


--
-- Data for Name: ConsentRecord; Type: TABLE DATA; Schema: public; Owner: alex
--

COPY public."ConsentRecord" (id, "tenantId", "ownerEmail", "policyId", "docId", "consentType", accepted, "ipAddress", "deviceId", "appVersion", "acceptedAt", "revokedAt") FROM stdin;
cmnhguuaz00023yrjny5gnwh2	\N	tech@brspark.com	\N	\N	LOCATION_BACKGROUND	t	::1	\N	1.0	2026-04-02 12:44:01.643	\N
\.


--
-- Data for Name: ExecutionMetric; Type: TABLE DATA; Schema: public; Owner: alex
--

COPY public."ExecutionMetric" (id, "tenantId", "executionId", "ownerEmail", "transitDurationMin", "siteArrivalDelayMin", "onSiteDurationMin", "idleTimeMin", "distanceKm", "geofenceBreaches", "routeDeviationMaxMeters", "scoreExecution", "scoreReliability", "scoreRisk", "fraudFlags", "calculatedAt", source) FROM stdin;
cmnhrxwy5003ml0zixdixrenr	\N	cmnhrqhbi0b9j9g8mtnd7ocdb	alex@brspark.com	\N	\N	\N	\N	0	0	\N	40	100	0	null	2026-04-02 17:54:20.812	REALTIME
cmnhtb51a00z1quvgbhcgbaa0	\N	cmnht8qog00vkquvgverzll77	alex@brspark.com	\N	\N	\N	\N	0	0	\N	40	100	0	null	2026-04-02 18:32:37.439	REALTIME
cmnhtrflg006rf5jrs5550t0z	\N	cmnhtnyp4001zf5jrvv0r23qa	alex@brspark.com	\N	\N	\N	\N	0	0	\N	40	50	45	[{"lat": 37.33240731, "lng": -122.03046898, "reason": "MOCK_LOCATION", "severity": "HIGH"}]	2026-04-02 18:45:17.621	REALTIME
\.


--
-- Data for Name: FeatureFlag; Type: TABLE DATA; Schema: public; Owner: alex
--

COPY public."FeatureFlag" (id, key, label, description, icon, enabled, "tenantId", "updatedAt") FROM stdin;
\.


--
-- Data for Name: Integration; Type: TABLE DATA; Schema: public; Owner: alex
--

COPY public."Integration" (id, name, type, icon, "apiKey", "baseUrl", "webhookUrl", "lastTestedAt", metadata, "createdAt", "updatedAt", description, status) FROM stdin;
\.


--
-- Data for Name: Invoice; Type: TABLE DATA; Schema: public; Owner: alex
--

COPY public."Invoice" (id, "subscriptionId", amount, status, "dueDate", "paidAt", "externalId", "createdAt") FROM stdin;
\.


--
-- Data for Name: LocaleProfile; Type: TABLE DATA; Schema: public; Owner: alex
--

COPY public."LocaleProfile" (id, "countryCode", name, language, currency, "currencySymbol", "dateFormat", "numberFormat", timezone, "taxIdLabel", "postalCodeLabel", "measureSystem", "isActive", "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: Location; Type: TABLE DATA; Schema: public; Owner: alex
--

COPY public."Location" (id, "tenantId", name, type, address, floor, room, icon, latitude, longitude, "parentId", "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: Metatag; Type: TABLE DATA; Schema: public; Owner: alex
--

COPY public."Metatag" (id, type, key, "ptBr", "enUs", "esEs", icon, color, "isActive", "sortOrder", "createdAt", "updatedAt") FROM stdin;
cmnhgwp9000033yrjo4bw7jf1	MEDIA_CATEGORY	foto	Foto	Foto	Foto	camera-outline	#3B82F6	t	0	2026-04-02 12:45:28.404	2026-04-02 12:45:28.404
cmnhgwpa900043yrjwalyd0mk	MEDIA_CATEGORY	video	Vídeo	Vídeo	Vídeo	videocam-outline	#8B5CF6	t	1	2026-04-02 12:45:28.449	2026-04-02 12:45:28.449
cmnhgwpab00053yrjqpxn2ki9	MEDIA_CATEGORY	documento	Documento	Documento	Documento	document-text-outline	#F59E0B	t	2	2026-04-02 12:45:28.452	2026-04-02 12:45:28.452
cmnhgwpae00063yrj5odh568a	MEDIA_CATEGORY	planta_baixa	Planta Baixa	Planta Baixa	Planta Baixa	map-outline	#10B981	t	3	2026-04-02 12:45:28.454	2026-04-02 12:45:28.454
cmnhgwpah00073yrjczi6purf	MEDIA_CATEGORY	nota_fiscal	Nota Fiscal	Nota Fiscal	Nota Fiscal	receipt-outline	#EF4444	t	4	2026-04-02 12:45:28.457	2026-04-02 12:45:28.457
cmnhgwpak00083yrjoflalzze	MEDIA_CATEGORY	contrato	Contrato	Contrato	Contrato	reader-outline	#6366F1	t	5	2026-04-02 12:45:28.46	2026-04-02 12:45:28.46
cmnhgwpal00093yrjy14vtvom	MEDIA_CATEGORY	laudo	Laudo / Relatório	Laudo / Relatório	Laudo / Relatório	clipboard-outline	#F97316	t	6	2026-04-02 12:45:28.462	2026-04-02 12:45:28.462
cmnhgwpao000a3yrj1q154hb1	MEDIA_CATEGORY	manutencao	Manutenção	Manutenção	Manutenção	construct-outline	#64748B	t	7	2026-04-02 12:45:28.464	2026-04-02 12:45:28.464
cmnhgwpaq000b3yrj03ikvtl4	MEDIA_CATEGORY	seguro	Seguro	Seguro	Seguro	shield-outline	#0EA5E9	t	8	2026-04-02 12:45:28.467	2026-04-02 12:45:28.467
cmnhgwpas000c3yrjwh11nnlq	MEDIA_CATEGORY	outro	Outro	Outro	Outro	ellipsis-horizontal-outline	#9CA3AF	t	9	2026-04-02 12:45:28.468	2026-04-02 12:45:28.468
\.


--
-- Data for Name: NotificationLog; Type: TABLE DATA; Schema: public; Owner: alex
--

COPY public."NotificationLog" (id, "templateId", recipient, channel, status, "sentAt", metadata) FROM stdin;
\.


--
-- Data for Name: NotificationTemplate; Type: TABLE DATA; Schema: public; Owner: alex
--

COPY public."NotificationTemplate" (id, key, label, channel, subject, body, variables, "isActive", "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: Plan; Type: TABLE DATA; Schema: public; Owner: alex
--

COPY public."Plan" (id, name, "priceMonthly", "priceYearly", "maxAssets", "maxUsers", "storageGb", features, "isActive", "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: PushToken; Type: TABLE DATA; Schema: public; Owner: alex
--

COPY public."PushToken" (id, "userId", token, device, "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: ServiceProvider; Type: TABLE DATA; Schema: public; Owner: alex
--

COPY public."ServiceProvider" (id, name, category, rating, reviews, photo, tags, keywords, phone, email, city, state, verified, "isActive", "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: StockItem; Type: TABLE DATA; Schema: public; Owner: alex
--

COPY public."StockItem" (id, "assetId", name, sku, "currentStock", "minStock", unit, "subLocation", "unitPrice", "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: StockMovement; Type: TABLE DATA; Schema: public; Owner: alex
--

COPY public."StockMovement" (id, "itemId", type, quantity, reason, "fromAssetId", "toAssetId", "createdAt") FROM stdin;
\.


--
-- Data for Name: Subscription; Type: TABLE DATA; Schema: public; Owner: alex
--

COPY public."Subscription" (id, "tenantId", "planId", "billingCycle", status, "currentStart", "currentEnd", "cancelledAt", "trialEndsAt", "externalId", "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: TechnicianProfile; Type: TABLE DATA; Schema: public; Owner: alex
--

COPY public."TechnicianProfile" (id, "userId", status, score, cft, specialty, "createdAt", "updatedAt") FROM stdin;
cmnhr8sw90a2j9g8m4sk391vj	cmnhhqj5w000g3yrj2m7fnu6n	ACTIVE	5	\N	\N	2026-04-02 17:34:49.161	2026-04-02 17:34:49.161
\.


--
-- Data for Name: TelemetryEvent; Type: TABLE DATA; Schema: public; Owner: alex
--

COPY public."TelemetryEvent" (id, "tenantId", "ownerEmail", "deviceId", "executionId", "eventType", lat, lng, accuracy, altitude, speed, heading, "locationSource", "batteryLevel", "batteryCharging", "networkType", "appVersion", "osVersion", "deviceModel", "isMockLocation", "isRooted", "clockDriftMs", "serverTimestamp", "deviceTimestamp", payload, "retentionTier", "expiresAt") FROM stdin;
cmnhgupgc00003yrj16djy6ut	\N	test@brspark.com	\N	\N	SESSION_OPEN	-23.5505	-46.6333	15	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 12:43:55.356	\N	null	OPERATIONAL	2026-09-29 12:43:55.354
cmnhid0hx00rz3yrjx67fssf3	\N	unknown	dev_szkcjr	cmngw885r005p7y155oxu7qiw	OS_ACCEPT	\N	\N	\N	\N	\N	\N	GPS	\N	\N	UNKNOWN	1.0.0	26.3.1	Simulator iOS	f	f	4	2026-04-02 13:26:09.093	2026-04-02 13:26:08.883	{"previousState": "IDLE"}	LEGAL	2031-04-02 13:26:09.092
cmnhidbh600sf3yrjfgzwv9iz	\N	unknown	\N	\N	HEARTBEAT	-23.569983	-46.7851655	5	0	-1	-1	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 13:26:23.323	2026-04-02 13:26:17.669	null	RAW_SHORT	2026-04-17 13:26:23.322
cmnhidmvs00sv3yrjqupyu2vh	\N	unknown	dev_szkcjr	cmngw885r005p7y155oxu7qiw	OS_ACCEPT	\N	\N	\N	\N	\N	\N	GPS	\N	\N	UNKNOWN	1.0.0	26.3.1	Simulator iOS	f	f	-1	2026-04-02 13:26:38.105	2026-04-02 13:26:37.933	{"previousState": "DISPATCHED"}	LEGAL	2031-04-02 13:26:38.102
cmnhidmvs00sw3yrj435sc22k	\N	unknown	\N	\N	HEARTBEAT	-23.569983	-46.7851655	5	0	-1	-1	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 13:26:38.105	2026-04-02 13:26:37.749	null	RAW_SHORT	2026-04-17 13:26:38.102
cmnhif5be00v53yrj9sahfgfl	\N	unknown	dev_szkcjr	cmngw885r005p7y155oxu7qiw	OS_ACCEPT	\N	\N	\N	\N	\N	\N	GPS	\N	\N	UNKNOWN	1.0.0	26.3.1	Simulator iOS	f	f	8	2026-04-02 13:27:48.65	2026-04-02 13:27:45.286	{"previousState": "IDLE"}	LEGAL	2031-04-02 13:27:48.649
cmnhif5be00v63yrjdg10zh7l	\N	unknown	\N	\N	HEARTBEAT	-23.569983	-46.7851655	5	0	-1	-1	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 13:27:48.65	2026-04-02 13:27:45.042	null	RAW_SHORT	2026-04-17 13:27:48.649
cmnhif96q00vh3yrjnhto9zam	\N	unknown	dev_szkcjr	cmngw885r005p7y155oxu7qiw	OS_ACCEPT	\N	\N	\N	\N	\N	\N	GPS	\N	\N	UNKNOWN	1.0.0	26.3.1	Simulator iOS	f	f	-2	2026-04-02 13:27:53.666	2026-04-02 13:27:49.304	{"previousState": "DISPATCHED"}	LEGAL	2031-04-02 13:27:53.665
cmnhif96q00vi3yrj9g46y0hj	\N	unknown	\N	\N	HEARTBEAT	-23.569983	-46.7851655	5	0	-1	-1	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 13:27:53.666	2026-04-02 13:27:49.051	null	RAW_SHORT	2026-04-17 13:27:53.665
cmnhigepx00x23yrjcc0g2duk	\N	unknown	dev_szkcjr	cmngw885r005p7y155oxu7qiw	OS_ACCEPT	\N	\N	\N	\N	\N	\N	GPS	\N	\N	UNKNOWN	1.0.0	26.3.1	Simulator iOS	f	f	9	2026-04-02 13:28:47.493	2026-04-02 13:28:47.366	{"previousState": "DISPATCHED"}	LEGAL	2031-04-02 13:28:47.492
cmnhigfr100x83yrjyr6gw7wk	\N	unknown	\N	\N	HEARTBEAT	-23.569983	-46.7851655	5	0	-1	-1	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 13:28:48.829	2026-04-02 13:28:47.339	null	RAW_SHORT	2026-04-17 13:28:48.828
cmnhivt0w01he3yrjibb378vq	\N	unknown	dev_szkcjr	cmngw885r005p7y155oxu7qiw	OS_ACCEPT	\N	\N	\N	\N	\N	\N	GPS	\N	\N	UNKNOWN	1.0.0	26.3.1	Simulator iOS	f	f	-116	2026-04-02 13:40:45.872	2026-04-02 13:40:41.567	{"previousState": "DISPATCHED"}	LEGAL	2031-04-02 13:40:45.87
cmnhivt0w01hf3yrjjm5hycq7	\N	unknown	\N	\N	HEARTBEAT	-23.569983	-46.7851655	5	0	-1	-1	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 13:40:45.872	2026-04-02 13:40:41.161	null	RAW_SHORT	2026-04-17 13:40:45.87
cmnhr9hmq0a3d9g8mkgcxvg3z	cmnhhqj5c000e3yrjmvwv50er	alex@brspark.com	dev_szkcjr	\N	SESSION_OPEN	\N	\N	\N	\N	\N	\N	GPS	\N	\N	UNKNOWN	1.0.0	26.3.1	Simulator iOS	f	f	-106	2026-04-02 17:35:21.218	2026-04-02 17:35:16.922	{}	OPERATIONAL	2026-09-29 17:35:21.216
cmnhrb85j0a5r9g8mckgo44l2	\N	unknown	dev_szkcjr	\N	SESSION_OPEN	\N	\N	\N	\N	\N	\N	GPS	\N	\N	UNKNOWN	1.0.0	26.3.1	Simulator iOS	f	f	6	2026-04-02 17:36:42.248	2026-04-02 17:36:42.087	{}	OPERATIONAL	2026-09-29 17:36:42.247
cmnhrtfrb0bh09g8m3rdlnrcp	\N	unknown	dev_szkcjr	cmnhrqhbi0b9j9g8mtnd7ocdb	OS_ACCEPT	\N	\N	\N	\N	\N	\N	GPS	\N	\N	UNKNOWN	1.0.0	26.3.1	Simulator iOS	f	f	-45	2026-04-02 17:50:51.911	2026-04-02 17:50:40.178	{"previousState": "IDLE"}	LEGAL	2031-04-02 17:50:51.884
cmnhrtfiz0bgw9g8meixc78k2	\N	unknown	dev_szkcjr	cmnhrqhbi0b9j9g8mtnd7ocdb	OS_ACCEPT	\N	\N	\N	\N	\N	\N	GPS	\N	\N	UNKNOWN	1.0.0	26.3.1	Simulator iOS	f	f	-45	2026-04-02 17:50:51.611	2026-04-02 17:50:40.178	{"previousState": "IDLE"}	LEGAL	2031-04-02 17:50:51.611
cmnhrtf8n0bgu9g8m5z2rf4f5	\N	unknown	dev_szkcjr	cmnhrqhbi0b9j9g8mtnd7ocdb	OS_ACCEPT	\N	\N	\N	\N	\N	\N	GPS	\N	\N	UNKNOWN	1.0.0	26.3.1	Simulator iOS	f	f	-45	2026-04-02 17:50:51.239	2026-04-02 17:50:40.178	{"previousState": "IDLE"}	LEGAL	2031-04-02 17:50:51.208
cmnhrtfkc0bgy9g8mr1drf0g1	\N	unknown	dev_szkcjr	cmnhrqhbi0b9j9g8mtnd7ocdb	OS_ACCEPT	\N	\N	\N	\N	\N	\N	GPS	\N	\N	UNKNOWN	1.0.0	26.3.1	Simulator iOS	f	f	-45	2026-04-02 17:50:51.66	2026-04-02 17:50:40.178	{"previousState": "IDLE"}	LEGAL	2031-04-02 17:50:51.659
cmnhrtf7b0bgs9g8mw1z5rekj	\N	unknown	dev_szkcjr	cmnhrqhbi0b9j9g8mtnd7ocdb	OS_ACCEPT	\N	\N	\N	\N	\N	\N	GPS	\N	\N	UNKNOWN	1.0.0	26.3.1	Simulator iOS	f	f	-45	2026-04-02 17:50:51.184	2026-04-02 17:50:40.178	{"previousState": "IDLE"}	LEGAL	2031-04-02 17:50:50.967
cmnhrtfkc0bgz9g8m4o9coxew	\N	unknown	\N	\N	HEARTBEAT	-23.569983	-46.7851655	5	0	-1	-1	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 17:50:51.66	2026-04-02 17:50:40.752	null	RAW_SHORT	2026-04-17 17:50:51.659
cmnhrtfiz0bgx9g8m9jf22zmm	\N	unknown	\N	\N	HEARTBEAT	-23.569983	-46.7851655	5	0	-1	-1	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 17:50:51.611	2026-04-02 17:50:40.752	null	RAW_SHORT	2026-04-17 17:50:51.611
cmnhrtf7j0bgt9g8mpc2clbzt	\N	unknown	\N	\N	HEARTBEAT	-23.569983	-46.7851655	5	0	-1	-1	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 17:50:51.184	2026-04-02 17:50:40.752	null	RAW_SHORT	2026-04-17 17:50:50.967
cmnhrtf8n0bgv9g8mdjkh25lo	\N	unknown	\N	\N	HEARTBEAT	-23.569983	-46.7851655	5	0	-1	-1	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 17:50:51.239	2026-04-02 17:50:40.752	null	RAW_SHORT	2026-04-17 17:50:51.208
cmnhrtfrb0bh19g8melp76gxq	\N	unknown	\N	\N	HEARTBEAT	-23.569983	-46.7851655	5	0	-1	-1	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 17:50:51.911	2026-04-02 17:50:40.752	null	RAW_SHORT	2026-04-17 17:50:51.884
cmnhrufd00bk49g8mkhakgz4u	\N	unknown	dev_szkcjr	cmnhrqhbi0b9j9g8mtnd7ocdb	TRANSIT_START	\N	\N	\N	\N	\N	\N	GPS	\N	\N	UNKNOWN	1.0.0	26.3.1	Simulator iOS	f	f	-4	2026-04-02 17:51:38.051	2026-04-02 17:51:36.074	{"previousState": "DISPATCHED"}	LEGAL	2031-04-02 17:51:38.048
cmnhrufd00bk59g8mumlxae5f	\N	unknown	\N	\N	HEARTBEAT	-23.569983	-46.7851655	5	0	-1	-1	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 17:51:38.051	2026-04-02 17:51:36.082	null	RAW_SHORT	2026-04-17 17:51:38.048
cmnhrxyhk003wl0zikj60jev4	\N	unknown@empresa.com	dev_szkcjr	cmnhrqhbi0b9j9g8mtnd7ocdb	SESSION_CLOSE	\N	\N	\N	\N	\N	\N	GPS	\N	\N	UNKNOWN	1.0.0	26.3.1	Simulator iOS	f	f	-35	2026-04-02 17:54:22.808	2026-04-02 17:54:20.099	{"previousState": "IN_TRANSIT"}	OPERATIONAL	2026-09-29 17:54:22.807
cmnhrxyhm003xl0zinfo86p1o	\N	unknown@empresa.com	dev_szkcjr	cmnhrqhbi0b9j9g8mtnd7ocdb	SESSION_CLOSE	\N	\N	\N	\N	\N	\N	GPS	\N	\N	UNKNOWN	1.0.0	26.3.1	Simulator iOS	f	f	-35	2026-04-02 17:54:22.811	2026-04-02 17:54:20.099	{"previousState": "IN_TRANSIT"}	OPERATIONAL	2026-09-29 17:54:22.81
cmnhslt190014quvgeygqf2z7	\N	unknown	dev_szkcjr	cmnhrqhbi0b9j9g8mtnd7ocdb	OS_ACCEPT	\N	\N	\N	\N	\N	\N	GPS	\N	\N	UNKNOWN	1.0.0	26.3.1	Simulator iOS	f	f	6	2026-04-02 18:12:55.485	2026-04-02 18:12:55.438	{"previousState": "IDLE"}	LEGAL	2031-04-02 18:12:55.484
cmnht90hm00w0quvgb26boerv	\N	unknown	dev_szkcjr	cmnht8qog00vkquvgverzll77	OS_ACCEPT	\N	\N	\N	\N	\N	\N	GPS	\N	\N	UNKNOWN	1.0.0	26.3.1	Simulator iOS	f	f	0	2026-04-02 18:30:58.234	2026-04-02 18:30:53.922	{"previousState": "DISPATCHED"}	LEGAL	2031-04-02 18:30:58.231
cmnht90hm00w1quvgvy7tuptg	\N	unknown	\N	\N	HEARTBEAT	-23.569983	-46.7851655	5	0	-1	-1	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 18:30:58.234	2026-04-02 18:30:53.973	null	RAW_SHORT	2026-04-17 18:30:58.231
cmnht94cs00w7quvgmalrzbb8	\N	unknown	dev_szkcjr	cmnht8qog00vkquvgverzll77	TRANSIT_START	\N	\N	\N	\N	\N	\N	GPS	\N	\N	UNKNOWN	1.0.0	26.3.1	Simulator iOS	f	f	19	2026-04-02 18:31:03.245	2026-04-02 18:31:00.835	{"previousState": "DISPATCHED"}	LEGAL	2031-04-02 18:31:03.242
cmnht94ct00w8quvg6uc7wrpm	\N	unknown	\N	\N	HEARTBEAT	-23.569983	-46.7851655	5	0	-1	-1	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 18:31:03.245	2026-04-02 18:31:00.799	null	RAW_SHORT	2026-04-17 18:31:03.242
cmnhtb5ur00z9quvgtcvokbkh	\N	unknown@empresa.com	dev_szkcjr	cmnht8qog00vkquvgverzll77	SESSION_CLOSE	\N	\N	\N	\N	\N	\N	GPS	\N	\N	UNKNOWN	1.0.0	26.3.1	Simulator iOS	f	f	-30	2026-04-02 18:32:38.5	2026-04-02 18:32:37.306	{"previousState": "IN_TRANSIT"}	OPERATIONAL	2026-09-29 18:32:38.499
cmnhtodp8002kf5jr53ojt1fj	\N	unknown	dev_szkcjr	cmnhtnyp4001zf5jrvv0r23qa	OS_ACCEPT	\N	\N	\N	\N	\N	\N	GPS	\N	\N	UNKNOWN	1.0.0	26.3.1	Simulator iOS	f	f	2	2026-04-02 18:42:55.196	2026-04-02 18:42:53.355	{"previousState": "IDLE"}	LEGAL	2031-04-02 18:42:55.195
cmnhtodp8002lf5jr6dfeu396	\N	unknown	\N	\N	HEARTBEAT	-23.569983	-46.7851655	5	0	-1	-1	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 18:42:55.196	2026-04-02 18:42:52.846	null	RAW_SHORT	2026-04-17 18:42:55.195
cmnhtp8or003qf5jrdo5o3nqh	\N	unknown	dev_szkcjr	cmnhtnyp4001zf5jrvv0r23qa	TRANSIT_START	\N	\N	\N	\N	\N	\N	GPS	\N	\N	UNKNOWN	1.0.0	26.3.1	Simulator iOS	f	f	22	2026-04-02 18:43:35.356	2026-04-02 18:43:34.526	{"previousState": "DISPATCHED"}	LEGAL	2031-04-02 18:43:35.355
cmnhtp8or003rf5jrvi6ttfuu	\N	unknown	\N	\N	HEARTBEAT	-23.569983	-46.7851655	5	0	-1	-1	\N	\N	\N	\N	\N	\N	\N	f	f	\N	2026-04-02 18:43:35.356	2026-04-02 18:43:30.993	null	RAW_SHORT	2026-04-17 18:43:35.355
cmnhtp8or003sf5jrqh8mara0	\N	unknown	dev_szkcjr	cmnhtnyp4001zf5jrvv0r23qa	FRAUD_FLAG	37.33240731	-122.03046898	\N	\N	\N	\N	GPS	\N	\N	UNKNOWN	1.0.0	26.3.1	Simulator iOS	t	f	-8	2026-04-02 18:43:35.356	2026-04-02 18:43:34.872	{"lat": 37.33240731, "lng": -122.03046898, "reason": "MOCK_LOCATION", "severity": "HIGH"}	LEGAL	2031-04-02 18:43:35.355
cmnhtp8or003tf5jr84hv6jbp	\N	unknown	\N	\N	HEARTBEAT	37.33240731	-122.03046898	65	0	-1	-1	\N	\N	\N	\N	\N	\N	\N	t	f	\N	2026-04-02 18:43:35.356	2026-04-02 18:43:34.802	null	RAW_SHORT	2026-04-17 18:43:35.355
cmnhtrhzl006zf5jrb2167vkh	\N	unknown@empresa.com	dev_szkcjr	cmnhtnyp4001zf5jrvv0r23qa	SESSION_CLOSE	\N	\N	\N	\N	\N	\N	GPS	\N	\N	UNKNOWN	1.0.0	26.3.1	Simulator iOS	f	f	-44	2026-04-02 18:45:20.721	2026-04-02 18:45:17.527	{"previousState": "IN_TRANSIT"}	OPERATIONAL	2026-09-29 18:45:20.72
\.


--
-- Data for Name: Tenant; Type: TABLE DATA; Schema: public; Owner: alex
--

COPY public."Tenant" (id, name, slug, email, phone, "taxId", "defaultLang", status, "createdAt", "updatedAt", "avatarUrl", "localeId", "ownerName", "sectorCode") FROM stdin;
cmnhhqj5c000e3yrjmvwv50er	Alex	alex	alex@brspark.com	\N	\N	pt-BR	TRIAL	2026-04-02 13:08:40.176	2026-04-02 13:08:40.176	\N	\N	Alex	\N
\.


--
-- Data for Name: TranslationOverride; Type: TABLE DATA; Schema: public; Owner: alex
--

COPY public."TranslationOverride" (id, "tenantId", key, language, value, "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: User; Type: TABLE DATA; Schema: public; Owner: alex
--

COPY public."User" (id, "tenantId", email, name, password, role, "isActive", "lastLogin", "createdAt", "updatedAt", "avatarUrl") FROM stdin;
cmnhhqj5w000g3yrj2m7fnu6n	cmnhhqj5c000e3yrjmvwv50er	alex@brspark.com	Alex	$2a$10$eKNvxvkUGs4RfuO28hMEculRY80pNedDbiaZ6i5yLEciMgGLHmSyq	ADMIN	t	2026-04-02 17:35:15.977	2026-04-02 13:08:40.196	2026-04-02 17:35:15.978	file:///Users/alex/Library/Developer/CoreSimulator/Devices/99E0B8BD-911F-42C8-A707-E7AA58227EEE/data/Containers/Data/Application/63BD2007-9626-4C9B-920B-136B093842C7/Library/Caches/ImagePicker/1593E486-74A9-4F59-B88C-C9C5B7213B79.jpg
\.


--
-- Data for Name: UserModuleData; Type: TABLE DATA; Schema: public; Owner: alex
--

COPY public."UserModuleData" (id, "ownerEmail", module, data, "updatedAt", "createdAt") FROM stdin;
cmnhgha6o0000edbotlvxyl8r	alex@brspark.com	stock_items	[{"id": "local_stock_1774732811358", "sku": "Qwewqe", "name": "Wqewq", "unit": "un", "category": "Suprimentos", "minStock": 2, "costPrice": 0, "locationId": null, "owner_email": "alex@brspark.com", "subLocation": null, "currentStock": 1, "asset_location_id": null}]	2026-04-02 19:35:34.154	2026-04-02 12:33:29.04
cmnhgha7b0004edboe1zksx0k	alex@brspark.com	insurance_policies	[{"id": "ins_1774477825766_cwk5h", "type": "RESIDENTIAL", "status": "ACTIVE", "assetId": "brsp-190135", "endDate": "209383", "insurer": "Teste", "createdAt": "2026-03-25T22:30:25.766Z", "startDate": "2026-03-25", "brokerName": "", "deductible": 0, "ownerEmail": "alex@brspark.com", "brokerPhone": "", "documentUri": "file:///var/mobile/Containers/Data/Application/B49F90C2-F617-4081-910B-D71CE9F435F3/Library/Caches/ExponentExperienceData/@anonymous/BrsparkMobile-be63636c-8058-4d28-bef6-7ebf19f8191b/DocumentPicker/F0257E79-A544-48D8-AEC0-14D3CE2AB092.pages", "policyNumber": "123", "premiumValue": 0, "coverageAmount": 0, "alertDaysBefore": 10, "coverageDetails": ""}, {"id": "ins_1774477826163_pyzx0", "type": "RESIDENTIAL", "status": "ACTIVE", "assetId": "brsp-190135", "endDate": "209383", "insurer": "Teste", "createdAt": "2026-03-25T22:30:26.163Z", "startDate": "2026-03-25", "brokerName": "", "deductible": 0, "ownerEmail": "alex@brspark.com", "brokerPhone": "", "documentUri": "file:///var/mobile/Containers/Data/Application/B49F90C2-F617-4081-910B-D71CE9F435F3/Library/Caches/ExponentExperienceData/@anonymous/BrsparkMobile-be63636c-8058-4d28-bef6-7ebf19f8191b/DocumentPicker/F0257E79-A544-48D8-AEC0-14D3CE2AB092.pages", "policyNumber": "123", "premiumValue": 0, "coverageAmount": 0, "alertDaysBefore": 10, "coverageDetails": ""}, {"id": "ins_1774648334205_drxzi", "type": "RESIDENTIAL", "status": "ACTIVE", "assetId": "brsp-134786", "endDate": "2026-04-27", "insurer": "Teste", "createdAt": "2026-03-27T21:52:14.205Z", "startDate": "2026-03-27", "brokerName": "", "deductible": 0, "ownerEmail": "alex@brspark.com", "brokerPhone": "", "documentUri": "http://192.168.15.73:3001/uploads/storage/docs/alex_brspark_com/ins_1774648334205_drxzi.insurance_355", "policyNumber": "355", "premiumValue": 0, "coverageAmount": 0, "alertDaysBefore": 1, "coverageDetails": ""}, {"id": "ins_1774648335970_y32ey", "type": "RESIDENTIAL", "status": "ACTIVE", "assetId": "brsp-134786", "endDate": "2026-04-27", "insurer": "Teste", "createdAt": "2026-03-27T21:52:15.970Z", "startDate": "2026-03-27", "brokerName": "", "deductible": 0, "ownerEmail": "alex@brspark.com", "brokerPhone": "", "documentUri": "http://192.168.15.73:3001/uploads/storage/docs/alex_brspark_com/ins_1774648335970_y32ey.insurance_355", "policyNumber": "355", "premiumValue": 0, "coverageAmount": 0, "alertDaysBefore": 1, "coverageDetails": ""}, {"id": "ins_1774648337353_bjq8z", "type": "RESIDENTIAL", "status": "ACTIVE", "assetId": "brsp-134786", "endDate": "2026-04-27", "insurer": "Teste", "createdAt": "2026-03-27T21:52:17.353Z", "startDate": "2026-03-27", "brokerName": "", "deductible": 0, "ownerEmail": "alex@brspark.com", "brokerPhone": "", "documentUri": "http://192.168.15.73:3001/uploads/storage/docs/alex_brspark_com/ins_1774648337353_bjq8z.insurance_355", "policyNumber": "355", "premiumValue": 0, "coverageAmount": 0, "alertDaysBefore": 1, "coverageDetails": ""}, {"id": "ins_1774648337620_kuvjy", "type": "RESIDENTIAL", "status": "ACTIVE", "assetId": "brsp-134786", "endDate": "2026-04-27", "insurer": "Teste", "createdAt": "2026-03-27T21:52:17.620Z", "startDate": "2026-03-27", "brokerName": "", "deductible": 0, "ownerEmail": "alex@brspark.com", "brokerPhone": "", "documentUri": "http://192.168.15.73:3001/uploads/storage/docs/alex_brspark_com/ins_1774648337620_kuvjy.insurance_355", "policyNumber": "355", "premiumValue": 0, "coverageAmount": 0, "alertDaysBefore": 1, "coverageDetails": ""}, {"id": "ins_1774648337870_l14de", "type": "RESIDENTIAL", "status": "ACTIVE", "assetId": "brsp-134786", "endDate": "2026-04-27", "insurer": "Teste", "createdAt": "2026-03-27T21:52:17.870Z", "startDate": "2026-03-27", "brokerName": "", "deductible": 0, "ownerEmail": "alex@brspark.com", "brokerPhone": "", "documentUri": "http://192.168.15.73:3001/uploads/storage/docs/alex_brspark_com/ins_1774648337870_l14de.insurance_355", "policyNumber": "355", "premiumValue": 0, "coverageAmount": 0, "alertDaysBefore": 1, "coverageDetails": ""}]	2026-04-02 19:35:34.169	2026-04-02 12:33:29.047
cmnhgha7b0003edboqnmkfzho	alex@brspark.com	costs_recurring	[{"id": "rec-mn69xf9l-h54zj", "type": "REVENUE", "amount": 2500, "status": "ACTIVE", "assetId": "brsp-215880", "frequency": "MONTHLY", "ownerEmail": "alex@brspark.com", "description": "Tedte", "nextDueDate": "2026-03-25", "alertDaysBefore": 1, "totalInstallments": 2, "remainingInstallments": 2}, {"id": "ins_cost_ins_1774477825766_cwk5h", "type": "EXPENSE", "amount": 0, "status": "ACTIVE", "assetId": "brsp-190135", "category": "SEGURO", "frequency": "YEARLY", "ownerEmail": "alex@brspark.com", "description": "Seguro Residencial — Teste", "nextDueDate": "209383", "alertDaysBefore": 10}, {"id": "ins_cost_ins_1774477826163_pyzx0", "type": "EXPENSE", "amount": 0, "status": "ACTIVE", "assetId": "brsp-190135", "category": "SEGURO", "frequency": "YEARLY", "ownerEmail": "alex@brspark.com", "description": "Seguro Residencial — Teste", "nextDueDate": "209383", "alertDaysBefore": 10}, {"id": "rec-mn8wim0o-uh9wo", "type": "REVENUE", "amount": 1000, "status": "ACTIVE", "assetId": "brsp-756993", "frequency": "MONTHLY", "ownerEmail": "alex@brspark.com", "description": "Aluguel", "nextDueDate": "2026-03-28", "alertDaysBefore": 1, "totalInstallments": 12, "remainingInstallments": 12}, {"id": "rec-mn8wlgmp-owx71", "type": "REVENUE", "amount": 300, "status": "ACTIVE", "assetId": "brsp-134786", "frequency": "MONTHLY", "ownerEmail": "alex@brspark.com", "description": "Aluguel", "nextDueDate": "2026-03-27", "alertDaysBefore": 1, "totalInstallments": 12, "remainingInstallments": 12}, {"id": "rec-mn8wma7d-j64lj", "type": "REVENUE", "amount": 50, "status": "ACTIVE", "assetId": "brsp-756993", "frequency": "MONTHLY", "ownerEmail": "alex@brspark.com", "description": "Teste", "nextDueDate": "2026-03-27", "alertDaysBefore": 1, "totalInstallments": 12, "remainingInstallments": 12}, {"id": "rec-mn8wmvf1-vx666", "type": "EXPENSE", "amount": 300, "status": "ACTIVE", "assetId": "brsp-756993", "frequency": "MONTHLY", "ownerEmail": "alex@brspark.com", "description": "Teste rec", "nextDueDate": "2026-03-27", "alertDaysBefore": 1, "totalInstallments": 12, "remainingInstallments": 12}, {"id": "rec-mn8wn9yc-roy0r", "type": "EXPENSE", "amount": 50, "status": "ACTIVE", "assetId": "brsp-756993", "frequency": "MONTHLY", "ownerEmail": "alex@brspark.com", "description": "2", "nextDueDate": "2026-03-27", "alertDaysBefore": 1, "totalInstallments": 12, "remainingInstallments": 12}, {"id": "rec-mn8wnmsw-3nbph", "type": "REVENUE", "amount": 100, "status": "ACTIVE", "assetId": "brsp-756993", "frequency": "MONTHLY", "ownerEmail": "alex@brspark.com", "description": "3", "nextDueDate": "2026-03-27", "alertDaysBefore": 1, "totalInstallments": 12, "remainingInstallments": 12}, {"id": "rec-mn8wo9xg-olj46", "type": "REVENUE", "amount": 100, "status": "ACTIVE", "assetId": "brsp-134786", "frequency": "MONTHLY", "ownerEmail": "alex@brspark.com", "description": "1", "nextDueDate": "2026-03-27", "alertDaysBefore": 1, "totalInstallments": 12, "remainingInstallments": 12}, {"id": "rec-mn8wolzq-k0t6i", "type": "EXPENSE", "amount": 200, "status": "ACTIVE", "assetId": "brsp-134786", "frequency": "MONTHLY", "ownerEmail": "alex@brspark.com", "description": "2", "nextDueDate": "2026-03-27", "alertDaysBefore": 1, "totalInstallments": 12, "remainingInstallments": 12}, {"id": "rec-mn8wwasg-y98d3", "type": "EXPENSE", "amount": 50, "status": "ACTIVE", "assetId": "brsp-134786", "frequency": "MONTHLY", "ownerEmail": "alex@brspark.com", "description": "Netflix", "nextDueDate": "2026-03-27", "alertDaysBefore": 1}, {"id": "ins_cost_ins_1774648334205_drxzi", "type": "EXPENSE", "amount": 0, "status": "ACTIVE", "assetId": "brsp-134786", "category": "SEGURO", "frequency": "YEARLY", "ownerEmail": "alex@brspark.com", "description": "Seguro Residencial — Teste", "nextDueDate": "2026-04-27", "alertDaysBefore": 1}, {"id": "ins_cost_ins_1774648335970_y32ey", "type": "EXPENSE", "amount": 0, "status": "ACTIVE", "assetId": "brsp-134786", "category": "SEGURO", "frequency": "YEARLY", "ownerEmail": "alex@brspark.com", "description": "Seguro Residencial — Teste", "nextDueDate": "2026-04-27", "alertDaysBefore": 1}, {"id": "ins_cost_ins_1774648337353_bjq8z", "type": "EXPENSE", "amount": 0, "status": "ACTIVE", "assetId": "brsp-134786", "category": "SEGURO", "frequency": "YEARLY", "ownerEmail": "alex@brspark.com", "description": "Seguro Residencial — Teste", "nextDueDate": "2026-04-27", "alertDaysBefore": 1}, {"id": "ins_cost_ins_1774648337620_kuvjy", "type": "EXPENSE", "amount": 0, "status": "ACTIVE", "assetId": "brsp-134786", "category": "SEGURO", "frequency": "YEARLY", "ownerEmail": "alex@brspark.com", "description": "Seguro Residencial — Teste", "nextDueDate": "2026-04-27", "alertDaysBefore": 1}, {"id": "ins_cost_ins_1774648337870_l14de", "type": "EXPENSE", "amount": 0, "status": "ACTIVE", "assetId": "brsp-134786", "category": "SEGURO", "frequency": "YEARLY", "ownerEmail": "alex@brspark.com", "description": "Seguro Residencial — Teste", "nextDueDate": "2026-04-27", "alertDaysBefore": 1}, {"id": "ins_cost_ins_1774648441070_05axk", "type": "EXPENSE", "amount": 0, "status": "ACTIVE", "assetId": "brsp-134786", "category": "SEGURO", "frequency": "YEARLY", "ownerEmail": "alex@brspark.com", "description": "Seguro Residencial — Teste", "nextDueDate": "2026-04-27", "alertDaysBefore": 1}]	2026-04-02 19:35:34.162	2026-04-02 12:33:29.046
cmnhgha7b0002edbo0e4apd4k	alex@brspark.com	asset_docs	[{"id": "qdce4o", "uri": "https://pub-5fc6db4a467f3070a46bf138e5b79edb.r2.dev/docs/alex_brspark_com/qdce4o.pdf", "type": "pdf", "title": "NF-e - Nota Fiscal Eletrônica de Serviços - São Paulo.pdf", "assetId": "brsp-190135", "version": 1, "category": "general", "createdAt": "2026-03-25T23:39:27.408Z", "description": ""}, {"id": "5b8tw4", "uri": "https://pub-5fc6db4a467f3070a46bf138e5b79edb.r2.dev/docs/alex_brspark_com/5b8tw4.pdf", "type": "pdf", "title": "Currículo Thais 2025.pdf", "assetId": "brsp-190135", "version": 1, "category": "general", "createdAt": "2026-03-25T23:39:33.198Z", "description": ""}, {"id": "nmft9b", "uri": "", "type": "folder", "title": "Teste", "assetId": "brsp-756993", "version": 1, "category": "general", "createdAt": "2026-03-26T18:13:09.048Z"}, {"id": "4oc4kl", "uri": "/BrSpark/docs/alex_brspark_com/4oc4kl.pdf", "type": "pdf", "title": "NF-e - Nota Fiscal Eletrônica de Serviços - São Paulo.pdf", "assetId": "brsp-756993", "version": 1, "category": "general", "parentId": "nmft9b", "createdAt": "2026-03-26T18:13:15.140Z", "description": ""}, {"id": "wf9ejb", "uri": "", "type": "folder", "title": "123", "assetId": "brsp-756993", "version": 1, "category": "general", "createdAt": "2026-03-26T18:16:09.617Z"}, {"id": "krsucl", "uri": "", "type": "folder", "title": "1", "assetId": "brsp-756993", "version": 1, "category": "general", "parentId": "nmft9b", "createdAt": "2026-03-26T18:20:06.259Z"}]	2026-04-02 19:35:34.166	2026-04-02 12:33:29.044
cmnhgha6q0001edboo6v4fuzq	alex@brspark.com	costs_expenses	[{"id": "exp-mn67vmfh-dy607", "date": "2026-03-25", "type": "EXPENSE", "amount": 532, "status": "PENDING", "assetId": "brsp-215880", "category": "OUTROS", "ownerEmail": "alex@brspark.com", "description": "Pneu"}, {"id": "exp-mn67xbkl-2bu76", "date": "2026-03-25", "type": "EXPENSE", "amount": 523.87, "status": "PENDING", "assetId": "brsp-585500", "category": "OUTROS", "ownerEmail": "alex@brspark.com", "description": "Pneu"}, {"id": "exp-mn684uwl-189lr", "date": "2026-03-25", "type": "EXPENSE", "amount": 582, "status": "PENDING", "assetId": "brsp-585500", "category": "OUTROS", "ownerEmail": "alex@brspark.com", "description": "Pmeu"}, {"id": "exp-mn68cwe3-e1zb0", "date": "2026-03-25", "type": "EXPENSE", "amount": 235, "status": "PENDING", "assetId": "brsp-215880", "category": "OUTROS", "ownerEmail": "alex@brspark.com", "description": "Pneu"}, {"id": "exp-mn6hn1bs-ka6kt", "date": "2026-03-25", "type": "EXPENSE", "amount": 152, "status": "PENDING", "assetId": "brsp-190135", "category": "OUTROS", "ownerEmail": "alex@brspark.com", "description": "Luz"}, {"id": "exp-mn6hp6c6-u9q2w", "date": "2026-03-25", "type": "EXPENSE", "amount": 500, "status": "PENDING", "assetId": "brsp-628386", "category": "OUTROS", "ownerEmail": "alex@brspark.com", "description": "Pmeu"}, {"id": "exp-mn7gcdd2-74nic", "date": "2026-03-26", "type": "REVENUE", "amount": 100, "status": "PENDING", "assetId": "brsp-756993", "category": "OUTROS", "ownerEmail": "alex@brspark.com", "description": "Testw"}, {"id": "exp-mn8wkyku-t309v", "date": "2026-03-27", "type": "REVENUE", "amount": 100, "status": "PENDING", "assetId": "brsp-134786", "category": "OUTROS", "ownerEmail": "alex@brspark.com", "description": "Teste"}, {"id": "exp-mn8wuoci-3bvk6", "date": "2026-03-27", "type": "EXPENSE", "amount": 25, "status": "PENDING", "assetId": "brsp-134786", "category": "OUTROS", "ownerEmail": "alex@brspark.com", "description": "Teste22"}]	2026-04-02 19:35:34.159	2026-04-02 12:33:29.043
\.


--
-- Data for Name: _prisma_migrations; Type: TABLE DATA; Schema: public; Owner: alex
--

COPY public._prisma_migrations (id, checksum, finished_at, migration_name, logs, rolled_back_at, started_at, applied_steps_count) FROM stdin;
bde75b4c-c3db-4c87-ad8f-4ddea978e83b	73224fe465c7de5be1d4f58cef71fe703fb824623c5ac8e5cb2f2f6321e13618	2026-04-02 09:29:07.113358-03	20260323143455_init	\N	\N	2026-04-02 09:29:06.610775-03	1
84bbcd60-be5b-45e6-900e-32306a1742e6	b00868e21b0ca2a3323cd88c3837296362a8462505fcd8fd176873fdd031d0e0	2026-04-02 09:29:07.13236-03	20260324001407_add_locale_profiles	\N	\N	2026-04-02 09:29:07.113955-03	1
f83613b8-779c-4e16-a62d-948470bdec9f	4aee8126753b087ae1d49fcb712baf2e1c6e24482a4c62352b79d536d572e4fe	2026-04-02 09:29:07.146501-03	20260324005528_add_translation_overrides	\N	\N	2026-04-02 09:29:07.133527-03	1
fa379f63-5407-4f05-a7dd-6d66af351e5b	9d60239b46e3f387ba472534b063e7b1ec3b3261abed0fc6518319807e150d9f	2026-04-02 09:29:07.148304-03	20260324173511_add_expense_revenue_metatag_types	\N	\N	2026-04-02 09:29:07.147179-03	1
e2963595-78f5-4441-9e46-2309eb8f2573	589531bd1df68a2b7555da033cb015bbcbd21f47a34108adc3062f3239503fdd	2026-04-02 09:29:07.154377-03	20260325225008_add_user_module_data	\N	\N	2026-04-02 09:29:07.148785-03	1
e5bde5ae-a5c2-4076-a92e-aa28036b3f05	69261f245187956b568acf26c08edaaa8f37d68a4f7837d767ad498780c8045e	2026-04-02 09:29:07.155548-03	20260325230353_add_media_category	\N	\N	2026-04-02 09:29:07.154849-03	1
40d54862-aae6-4c63-b3be-94f7b4bdaecf	78071a54b17cd3c1f7831a52989a8e4b26c043c6761ea11357637c77c6134b4e	2026-04-02 09:29:07.165256-03	20260326005347_init_asset_shares	\N	\N	2026-04-02 09:29:07.155935-03	1
753e0335-6db2-46bd-8091-20c9c2899850	dad8b317482d5cf9c3cae44bb195dd16d21ea33da651aa95bff6efc0876ae2f0	2026-04-02 09:29:08.614109-03	20260402122908_data_collection_foundation	\N	\N	2026-04-02 09:29:08.594042-03	1
\.


--
-- Name: Admin Admin_pkey; Type: CONSTRAINT; Schema: public; Owner: alex
--

ALTER TABLE ONLY public."Admin"
    ADD CONSTRAINT "Admin_pkey" PRIMARY KEY (id);


--
-- Name: AssetShare AssetShare_pkey; Type: CONSTRAINT; Schema: public; Owner: alex
--

ALTER TABLE ONLY public."AssetShare"
    ADD CONSTRAINT "AssetShare_pkey" PRIMARY KEY (id);


--
-- Name: Asset Asset_pkey; Type: CONSTRAINT; Schema: public; Owner: alex
--

ALTER TABLE ONLY public."Asset"
    ADD CONSTRAINT "Asset_pkey" PRIMARY KEY (id);


--
-- Name: AuditLog AuditLog_pkey; Type: CONSTRAINT; Schema: public; Owner: alex
--

ALTER TABLE ONLY public."AuditLog"
    ADD CONSTRAINT "AuditLog_pkey" PRIMARY KEY (id);


--
-- Name: ChatContact ChatContact_pkey; Type: CONSTRAINT; Schema: public; Owner: alex
--

ALTER TABLE ONLY public."ChatContact"
    ADD CONSTRAINT "ChatContact_pkey" PRIMARY KEY (id);


--
-- Name: ChatMessage ChatMessage_pkey; Type: CONSTRAINT; Schema: public; Owner: alex
--

ALTER TABLE ONLY public."ChatMessage"
    ADD CONSTRAINT "ChatMessage_pkey" PRIMARY KEY (id);


--
-- Name: ChatRoomMember ChatRoomMember_pkey; Type: CONSTRAINT; Schema: public; Owner: alex
--

ALTER TABLE ONLY public."ChatRoomMember"
    ADD CONSTRAINT "ChatRoomMember_pkey" PRIMARY KEY (id);


--
-- Name: ChatRoom ChatRoom_pkey; Type: CONSTRAINT; Schema: public; Owner: alex
--

ALTER TABLE ONLY public."ChatRoom"
    ADD CONSTRAINT "ChatRoom_pkey" PRIMARY KEY (id);


--
-- Name: ChecklistExecution ChecklistExecution_pkey; Type: CONSTRAINT; Schema: public; Owner: alex
--

ALTER TABLE ONLY public."ChecklistExecution"
    ADD CONSTRAINT "ChecklistExecution_pkey" PRIMARY KEY (id);


--
-- Name: ChecklistTemplate ChecklistTemplate_pkey; Type: CONSTRAINT; Schema: public; Owner: alex
--

ALTER TABLE ONLY public."ChecklistTemplate"
    ADD CONSTRAINT "ChecklistTemplate_pkey" PRIMARY KEY (id);


--
-- Name: CollectionPolicy CollectionPolicy_pkey; Type: CONSTRAINT; Schema: public; Owner: alex
--

ALTER TABLE ONLY public."CollectionPolicy"
    ADD CONSTRAINT "CollectionPolicy_pkey" PRIMARY KEY (id);


--
-- Name: ComplianceAcceptance ComplianceAcceptance_pkey; Type: CONSTRAINT; Schema: public; Owner: alex
--

ALTER TABLE ONLY public."ComplianceAcceptance"
    ADD CONSTRAINT "ComplianceAcceptance_pkey" PRIMARY KEY (id);


--
-- Name: ComplianceDoc ComplianceDoc_pkey; Type: CONSTRAINT; Schema: public; Owner: alex
--

ALTER TABLE ONLY public."ComplianceDoc"
    ADD CONSTRAINT "ComplianceDoc_pkey" PRIMARY KEY (id);


--
-- Name: ConsentRecord ConsentRecord_pkey; Type: CONSTRAINT; Schema: public; Owner: alex
--

ALTER TABLE ONLY public."ConsentRecord"
    ADD CONSTRAINT "ConsentRecord_pkey" PRIMARY KEY (id);


--
-- Name: ExecutionMetric ExecutionMetric_pkey; Type: CONSTRAINT; Schema: public; Owner: alex
--

ALTER TABLE ONLY public."ExecutionMetric"
    ADD CONSTRAINT "ExecutionMetric_pkey" PRIMARY KEY (id);


--
-- Name: FeatureFlag FeatureFlag_pkey; Type: CONSTRAINT; Schema: public; Owner: alex
--

ALTER TABLE ONLY public."FeatureFlag"
    ADD CONSTRAINT "FeatureFlag_pkey" PRIMARY KEY (id);


--
-- Name: Integration Integration_pkey; Type: CONSTRAINT; Schema: public; Owner: alex
--

ALTER TABLE ONLY public."Integration"
    ADD CONSTRAINT "Integration_pkey" PRIMARY KEY (id);


--
-- Name: Invoice Invoice_pkey; Type: CONSTRAINT; Schema: public; Owner: alex
--

ALTER TABLE ONLY public."Invoice"
    ADD CONSTRAINT "Invoice_pkey" PRIMARY KEY (id);


--
-- Name: LocaleProfile LocaleProfile_pkey; Type: CONSTRAINT; Schema: public; Owner: alex
--

ALTER TABLE ONLY public."LocaleProfile"
    ADD CONSTRAINT "LocaleProfile_pkey" PRIMARY KEY (id);


--
-- Name: Location Location_pkey; Type: CONSTRAINT; Schema: public; Owner: alex
--

ALTER TABLE ONLY public."Location"
    ADD CONSTRAINT "Location_pkey" PRIMARY KEY (id);


--
-- Name: Metatag Metatag_pkey; Type: CONSTRAINT; Schema: public; Owner: alex
--

ALTER TABLE ONLY public."Metatag"
    ADD CONSTRAINT "Metatag_pkey" PRIMARY KEY (id);


--
-- Name: NotificationLog NotificationLog_pkey; Type: CONSTRAINT; Schema: public; Owner: alex
--

ALTER TABLE ONLY public."NotificationLog"
    ADD CONSTRAINT "NotificationLog_pkey" PRIMARY KEY (id);


--
-- Name: NotificationTemplate NotificationTemplate_pkey; Type: CONSTRAINT; Schema: public; Owner: alex
--

ALTER TABLE ONLY public."NotificationTemplate"
    ADD CONSTRAINT "NotificationTemplate_pkey" PRIMARY KEY (id);


--
-- Name: Plan Plan_pkey; Type: CONSTRAINT; Schema: public; Owner: alex
--

ALTER TABLE ONLY public."Plan"
    ADD CONSTRAINT "Plan_pkey" PRIMARY KEY (id);


--
-- Name: PushToken PushToken_pkey; Type: CONSTRAINT; Schema: public; Owner: alex
--

ALTER TABLE ONLY public."PushToken"
    ADD CONSTRAINT "PushToken_pkey" PRIMARY KEY (id);


--
-- Name: ServiceProvider ServiceProvider_pkey; Type: CONSTRAINT; Schema: public; Owner: alex
--

ALTER TABLE ONLY public."ServiceProvider"
    ADD CONSTRAINT "ServiceProvider_pkey" PRIMARY KEY (id);


--
-- Name: StockItem StockItem_pkey; Type: CONSTRAINT; Schema: public; Owner: alex
--

ALTER TABLE ONLY public."StockItem"
    ADD CONSTRAINT "StockItem_pkey" PRIMARY KEY (id);


--
-- Name: StockMovement StockMovement_pkey; Type: CONSTRAINT; Schema: public; Owner: alex
--

ALTER TABLE ONLY public."StockMovement"
    ADD CONSTRAINT "StockMovement_pkey" PRIMARY KEY (id);


--
-- Name: Subscription Subscription_pkey; Type: CONSTRAINT; Schema: public; Owner: alex
--

ALTER TABLE ONLY public."Subscription"
    ADD CONSTRAINT "Subscription_pkey" PRIMARY KEY (id);


--
-- Name: TechnicianProfile TechnicianProfile_pkey; Type: CONSTRAINT; Schema: public; Owner: alex
--

ALTER TABLE ONLY public."TechnicianProfile"
    ADD CONSTRAINT "TechnicianProfile_pkey" PRIMARY KEY (id);


--
-- Name: TelemetryEvent TelemetryEvent_pkey; Type: CONSTRAINT; Schema: public; Owner: alex
--

ALTER TABLE ONLY public."TelemetryEvent"
    ADD CONSTRAINT "TelemetryEvent_pkey" PRIMARY KEY (id);


--
-- Name: Tenant Tenant_pkey; Type: CONSTRAINT; Schema: public; Owner: alex
--

ALTER TABLE ONLY public."Tenant"
    ADD CONSTRAINT "Tenant_pkey" PRIMARY KEY (id);


--
-- Name: TranslationOverride TranslationOverride_pkey; Type: CONSTRAINT; Schema: public; Owner: alex
--

ALTER TABLE ONLY public."TranslationOverride"
    ADD CONSTRAINT "TranslationOverride_pkey" PRIMARY KEY (id);


--
-- Name: UserModuleData UserModuleData_pkey; Type: CONSTRAINT; Schema: public; Owner: alex
--

ALTER TABLE ONLY public."UserModuleData"
    ADD CONSTRAINT "UserModuleData_pkey" PRIMARY KEY (id);


--
-- Name: User User_pkey; Type: CONSTRAINT; Schema: public; Owner: alex
--

ALTER TABLE ONLY public."User"
    ADD CONSTRAINT "User_pkey" PRIMARY KEY (id);


--
-- Name: _prisma_migrations _prisma_migrations_pkey; Type: CONSTRAINT; Schema: public; Owner: alex
--

ALTER TABLE ONLY public._prisma_migrations
    ADD CONSTRAINT _prisma_migrations_pkey PRIMARY KEY (id);


--
-- Name: Admin_email_key; Type: INDEX; Schema: public; Owner: alex
--

CREATE UNIQUE INDEX "Admin_email_key" ON public."Admin" USING btree (email);


--
-- Name: AssetShare_assetId_sharedWithEmail_key; Type: INDEX; Schema: public; Owner: alex
--

CREATE UNIQUE INDEX "AssetShare_assetId_sharedWithEmail_key" ON public."AssetShare" USING btree ("assetId", "sharedWithEmail");


--
-- Name: ChatContact_requesterId_addresseeId_key; Type: INDEX; Schema: public; Owner: alex
--

CREATE UNIQUE INDEX "ChatContact_requesterId_addresseeId_key" ON public."ChatContact" USING btree ("requesterId", "addresseeId");


--
-- Name: ChatRoomMember_roomId_userId_key; Type: INDEX; Schema: public; Owner: alex
--

CREATE UNIQUE INDEX "ChatRoomMember_roomId_userId_key" ON public."ChatRoomMember" USING btree ("roomId", "userId");


--
-- Name: ChecklistExecution_ownerEmail_idx; Type: INDEX; Schema: public; Owner: alex
--

CREATE INDEX "ChecklistExecution_ownerEmail_idx" ON public."ChecklistExecution" USING btree ("ownerEmail");


--
-- Name: ChecklistExecution_ownerEmail_status_idx; Type: INDEX; Schema: public; Owner: alex
--

CREATE INDEX "ChecklistExecution_ownerEmail_status_idx" ON public."ChecklistExecution" USING btree ("ownerEmail", status);


--
-- Name: ChecklistExecution_status_idx; Type: INDEX; Schema: public; Owner: alex
--

CREATE INDEX "ChecklistExecution_status_idx" ON public."ChecklistExecution" USING btree (status);


--
-- Name: CollectionPolicy_tenantId_idx; Type: INDEX; Schema: public; Owner: alex
--

CREATE INDEX "CollectionPolicy_tenantId_idx" ON public."CollectionPolicy" USING btree ("tenantId");


--
-- Name: CollectionPolicy_tenantId_sectorCode_key; Type: INDEX; Schema: public; Owner: alex
--

CREATE UNIQUE INDEX "CollectionPolicy_tenantId_sectorCode_key" ON public."CollectionPolicy" USING btree ("tenantId", "sectorCode");


--
-- Name: ConsentRecord_ownerEmail_idx; Type: INDEX; Schema: public; Owner: alex
--

CREATE INDEX "ConsentRecord_ownerEmail_idx" ON public."ConsentRecord" USING btree ("ownerEmail");


--
-- Name: ConsentRecord_ownerEmail_policyId_consentType_key; Type: INDEX; Schema: public; Owner: alex
--

CREATE UNIQUE INDEX "ConsentRecord_ownerEmail_policyId_consentType_key" ON public."ConsentRecord" USING btree ("ownerEmail", "policyId", "consentType");


--
-- Name: ConsentRecord_tenantId_idx; Type: INDEX; Schema: public; Owner: alex
--

CREATE INDEX "ConsentRecord_tenantId_idx" ON public."ConsentRecord" USING btree ("tenantId");


--
-- Name: ExecutionMetric_executionId_idx; Type: INDEX; Schema: public; Owner: alex
--

CREATE INDEX "ExecutionMetric_executionId_idx" ON public."ExecutionMetric" USING btree ("executionId");


--
-- Name: ExecutionMetric_executionId_key; Type: INDEX; Schema: public; Owner: alex
--

CREATE UNIQUE INDEX "ExecutionMetric_executionId_key" ON public."ExecutionMetric" USING btree ("executionId");


--
-- Name: ExecutionMetric_tenantId_ownerEmail_idx; Type: INDEX; Schema: public; Owner: alex
--

CREATE INDEX "ExecutionMetric_tenantId_ownerEmail_idx" ON public."ExecutionMetric" USING btree ("tenantId", "ownerEmail");


--
-- Name: FeatureFlag_key_tenantId_key; Type: INDEX; Schema: public; Owner: alex
--

CREATE UNIQUE INDEX "FeatureFlag_key_tenantId_key" ON public."FeatureFlag" USING btree (key, "tenantId");


--
-- Name: LocaleProfile_countryCode_key; Type: INDEX; Schema: public; Owner: alex
--

CREATE UNIQUE INDEX "LocaleProfile_countryCode_key" ON public."LocaleProfile" USING btree ("countryCode");


--
-- Name: Metatag_key_key; Type: INDEX; Schema: public; Owner: alex
--

CREATE UNIQUE INDEX "Metatag_key_key" ON public."Metatag" USING btree (key);


--
-- Name: NotificationTemplate_key_key; Type: INDEX; Schema: public; Owner: alex
--

CREATE UNIQUE INDEX "NotificationTemplate_key_key" ON public."NotificationTemplate" USING btree (key);


--
-- Name: Plan_name_key; Type: INDEX; Schema: public; Owner: alex
--

CREATE UNIQUE INDEX "Plan_name_key" ON public."Plan" USING btree (name);


--
-- Name: PushToken_token_key; Type: INDEX; Schema: public; Owner: alex
--

CREATE UNIQUE INDEX "PushToken_token_key" ON public."PushToken" USING btree (token);


--
-- Name: StockItem_assetId_sku_key; Type: INDEX; Schema: public; Owner: alex
--

CREATE UNIQUE INDEX "StockItem_assetId_sku_key" ON public."StockItem" USING btree ("assetId", sku);


--
-- Name: Subscription_tenantId_key; Type: INDEX; Schema: public; Owner: alex
--

CREATE UNIQUE INDEX "Subscription_tenantId_key" ON public."Subscription" USING btree ("tenantId");


--
-- Name: TechnicianProfile_userId_key; Type: INDEX; Schema: public; Owner: alex
--

CREATE UNIQUE INDEX "TechnicianProfile_userId_key" ON public."TechnicianProfile" USING btree ("userId");


--
-- Name: TelemetryEvent_executionId_idx; Type: INDEX; Schema: public; Owner: alex
--

CREATE INDEX "TelemetryEvent_executionId_idx" ON public."TelemetryEvent" USING btree ("executionId");


--
-- Name: TelemetryEvent_expiresAt_idx; Type: INDEX; Schema: public; Owner: alex
--

CREATE INDEX "TelemetryEvent_expiresAt_idx" ON public."TelemetryEvent" USING btree ("expiresAt");


--
-- Name: TelemetryEvent_ownerEmail_serverTimestamp_idx; Type: INDEX; Schema: public; Owner: alex
--

CREATE INDEX "TelemetryEvent_ownerEmail_serverTimestamp_idx" ON public."TelemetryEvent" USING btree ("ownerEmail", "serverTimestamp");


--
-- Name: TelemetryEvent_tenantId_eventType_serverTimestamp_idx; Type: INDEX; Schema: public; Owner: alex
--

CREATE INDEX "TelemetryEvent_tenantId_eventType_serverTimestamp_idx" ON public."TelemetryEvent" USING btree ("tenantId", "eventType", "serverTimestamp");


--
-- Name: Tenant_email_key; Type: INDEX; Schema: public; Owner: alex
--

CREATE UNIQUE INDEX "Tenant_email_key" ON public."Tenant" USING btree (email);


--
-- Name: Tenant_slug_key; Type: INDEX; Schema: public; Owner: alex
--

CREATE UNIQUE INDEX "Tenant_slug_key" ON public."Tenant" USING btree (slug);


--
-- Name: TranslationOverride_tenantId_key_language_key; Type: INDEX; Schema: public; Owner: alex
--

CREATE UNIQUE INDEX "TranslationOverride_tenantId_key_language_key" ON public."TranslationOverride" USING btree ("tenantId", key, language);


--
-- Name: UserModuleData_ownerEmail_idx; Type: INDEX; Schema: public; Owner: alex
--

CREATE INDEX "UserModuleData_ownerEmail_idx" ON public."UserModuleData" USING btree ("ownerEmail");


--
-- Name: UserModuleData_ownerEmail_module_key; Type: INDEX; Schema: public; Owner: alex
--

CREATE UNIQUE INDEX "UserModuleData_ownerEmail_module_key" ON public."UserModuleData" USING btree ("ownerEmail", module);


--
-- Name: User_email_tenantId_key; Type: INDEX; Schema: public; Owner: alex
--

CREATE UNIQUE INDEX "User_email_tenantId_key" ON public."User" USING btree (email, "tenantId");


--
-- Name: Asset Asset_locationId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: alex
--

ALTER TABLE ONLY public."Asset"
    ADD CONSTRAINT "Asset_locationId_fkey" FOREIGN KEY ("locationId") REFERENCES public."Location"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: Asset Asset_parentId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: alex
--

ALTER TABLE ONLY public."Asset"
    ADD CONSTRAINT "Asset_parentId_fkey" FOREIGN KEY ("parentId") REFERENCES public."Asset"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: Asset Asset_tenantId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: alex
--

ALTER TABLE ONLY public."Asset"
    ADD CONSTRAINT "Asset_tenantId_fkey" FOREIGN KEY ("tenantId") REFERENCES public."Tenant"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: AuditLog AuditLog_adminId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: alex
--

ALTER TABLE ONLY public."AuditLog"
    ADD CONSTRAINT "AuditLog_adminId_fkey" FOREIGN KEY ("adminId") REFERENCES public."Admin"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: AuditLog AuditLog_tenantId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: alex
--

ALTER TABLE ONLY public."AuditLog"
    ADD CONSTRAINT "AuditLog_tenantId_fkey" FOREIGN KEY ("tenantId") REFERENCES public."Tenant"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: AuditLog AuditLog_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: alex
--

ALTER TABLE ONLY public."AuditLog"
    ADD CONSTRAINT "AuditLog_userId_fkey" FOREIGN KEY ("userId") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: ChatMessage ChatMessage_roomId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: alex
--

ALTER TABLE ONLY public."ChatMessage"
    ADD CONSTRAINT "ChatMessage_roomId_fkey" FOREIGN KEY ("roomId") REFERENCES public."ChatRoom"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: ChatRoomMember ChatRoomMember_roomId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: alex
--

ALTER TABLE ONLY public."ChatRoomMember"
    ADD CONSTRAINT "ChatRoomMember_roomId_fkey" FOREIGN KEY ("roomId") REFERENCES public."ChatRoom"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: ChecklistExecution ChecklistExecution_templateId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: alex
--

ALTER TABLE ONLY public."ChecklistExecution"
    ADD CONSTRAINT "ChecklistExecution_templateId_fkey" FOREIGN KEY ("templateId") REFERENCES public."ChecklistTemplate"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: CollectionPolicy CollectionPolicy_tenantId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: alex
--

ALTER TABLE ONLY public."CollectionPolicy"
    ADD CONSTRAINT "CollectionPolicy_tenantId_fkey" FOREIGN KEY ("tenantId") REFERENCES public."Tenant"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: ComplianceAcceptance ComplianceAcceptance_docId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: alex
--

ALTER TABLE ONLY public."ComplianceAcceptance"
    ADD CONSTRAINT "ComplianceAcceptance_docId_fkey" FOREIGN KEY ("docId") REFERENCES public."ComplianceDoc"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: ComplianceDoc ComplianceDoc_tenantId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: alex
--

ALTER TABLE ONLY public."ComplianceDoc"
    ADD CONSTRAINT "ComplianceDoc_tenantId_fkey" FOREIGN KEY ("tenantId") REFERENCES public."Tenant"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: ConsentRecord ConsentRecord_docId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: alex
--

ALTER TABLE ONLY public."ConsentRecord"
    ADD CONSTRAINT "ConsentRecord_docId_fkey" FOREIGN KEY ("docId") REFERENCES public."ComplianceDoc"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: ConsentRecord ConsentRecord_policyId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: alex
--

ALTER TABLE ONLY public."ConsentRecord"
    ADD CONSTRAINT "ConsentRecord_policyId_fkey" FOREIGN KEY ("policyId") REFERENCES public."CollectionPolicy"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: FeatureFlag FeatureFlag_tenantId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: alex
--

ALTER TABLE ONLY public."FeatureFlag"
    ADD CONSTRAINT "FeatureFlag_tenantId_fkey" FOREIGN KEY ("tenantId") REFERENCES public."Tenant"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: Invoice Invoice_subscriptionId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: alex
--

ALTER TABLE ONLY public."Invoice"
    ADD CONSTRAINT "Invoice_subscriptionId_fkey" FOREIGN KEY ("subscriptionId") REFERENCES public."Subscription"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: Location Location_parentId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: alex
--

ALTER TABLE ONLY public."Location"
    ADD CONSTRAINT "Location_parentId_fkey" FOREIGN KEY ("parentId") REFERENCES public."Location"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: Location Location_tenantId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: alex
--

ALTER TABLE ONLY public."Location"
    ADD CONSTRAINT "Location_tenantId_fkey" FOREIGN KEY ("tenantId") REFERENCES public."Tenant"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: NotificationLog NotificationLog_templateId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: alex
--

ALTER TABLE ONLY public."NotificationLog"
    ADD CONSTRAINT "NotificationLog_templateId_fkey" FOREIGN KEY ("templateId") REFERENCES public."NotificationTemplate"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: PushToken PushToken_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: alex
--

ALTER TABLE ONLY public."PushToken"
    ADD CONSTRAINT "PushToken_userId_fkey" FOREIGN KEY ("userId") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: StockItem StockItem_assetId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: alex
--

ALTER TABLE ONLY public."StockItem"
    ADD CONSTRAINT "StockItem_assetId_fkey" FOREIGN KEY ("assetId") REFERENCES public."Asset"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: StockMovement StockMovement_itemId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: alex
--

ALTER TABLE ONLY public."StockMovement"
    ADD CONSTRAINT "StockMovement_itemId_fkey" FOREIGN KEY ("itemId") REFERENCES public."StockItem"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: Subscription Subscription_planId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: alex
--

ALTER TABLE ONLY public."Subscription"
    ADD CONSTRAINT "Subscription_planId_fkey" FOREIGN KEY ("planId") REFERENCES public."Plan"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: Subscription Subscription_tenantId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: alex
--

ALTER TABLE ONLY public."Subscription"
    ADD CONSTRAINT "Subscription_tenantId_fkey" FOREIGN KEY ("tenantId") REFERENCES public."Tenant"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: TechnicianProfile TechnicianProfile_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: alex
--

ALTER TABLE ONLY public."TechnicianProfile"
    ADD CONSTRAINT "TechnicianProfile_userId_fkey" FOREIGN KEY ("userId") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: Tenant Tenant_localeId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: alex
--

ALTER TABLE ONLY public."Tenant"
    ADD CONSTRAINT "Tenant_localeId_fkey" FOREIGN KEY ("localeId") REFERENCES public."LocaleProfile"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: TranslationOverride TranslationOverride_tenantId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: alex
--

ALTER TABLE ONLY public."TranslationOverride"
    ADD CONSTRAINT "TranslationOverride_tenantId_fkey" FOREIGN KEY ("tenantId") REFERENCES public."Tenant"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: User User_tenantId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: alex
--

ALTER TABLE ONLY public."User"
    ADD CONSTRAINT "User_tenantId_fkey" FOREIGN KEY ("tenantId") REFERENCES public."Tenant"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- PostgreSQL database dump complete
--

\unrestrict n02ZgM9SaIuVS4SlAQ9P7U0pWfWaKce1yHuakCFxKhAFW3uZkBnB2pEldCjGEbJ

